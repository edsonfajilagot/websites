<!DOCTYPE html>  
<html>  
<head>  
<meta charset="UTF-8">  
<title>HTML Online Editor</title>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<meta name="Description" content="HTML Online Editor" />
<meta name="google" value="notranslate" />
<base href="http://www.tutorialspoint.com" />
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=yes">
<script type="text/javascript" src="/scripts/easyui/jquery-1.8.1.min.js"></script>
<link rel="stylesheet" type="text/css" href="/scripts/easyui/themes/gray/easyui.css">
<link rel="stylesheet" type="text/css" href="/scripts/easyui/themes/icon.css">
<script type="text/javascript" src="/scripts/easyui/jquery.easyui.min.js"></script>
<script type="text/javascript" src="/scripts/jquery.ba-resize.min.js"></script>
<link rel="stylesheet" type="text/css" href="/scripts/col.css" />
<script type="text/javascript">
$(window).load(function () {
   $("#cc").css({"visibility":"visible"});
   $("#cc").fadeIn(1000);
   $("#loading").css({"visibility":"hidden"});
});
$(window).load(function(){
      var newwidth = $(window).width();
      newwidth = newwidth / 2;
      var p = $("#cc").layout('panel','east');
      p.panel('resize',{width:newwidth});
      $('#cc').layout('resize');
});
$(document).ready(function () {
    $("#view").load( function() {
        $('#wait').hide(); 
        event.preventDefault();
    } );
    submitForm();
});
$("#view").load(function() {
   $('#wait').hide();
});
</script>
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-232293-6";
urchinTracker();
</script>
</head>
<body class="easyui-layout notranslate" id="cc">
<form method="POST" id="ff" target="contentview" action="/cgi-bin/webpage.php">
<input type="hidden" name="lang"/>
<input type="hidden" name="html"/>
<input type="hidden" name="process" value="1429523614_26148"/>
<input type="hidden" name="root" value="/web/com/1429523614_26148"/>
<div id="loading"></div>
<div data-options="region:'north',split:false,border:false, closable:true, collapsible:true,minimizable:true,maximizable:true" style="height:50px; background:#dd1c17 !important;"><!-- TOP MENU STARTS -->
<div style="padding:0px;">
<img src="/images/final-logo.png" style="display:inline;float:left;height:50px;"/><h1 id="version">HTML Online Editor</h1>
</div>  
</div><!-- TOP MENU ENDS -->
<div data-options="region:'east',iconCls:'icon-result',title:'Result',split:true,tools:'#tab-tools2',toolPosition:'right'" id="bottom" style="height:300px;"><!-- BOTTOM PANEL STARTS --> 
<iframe id="view" name="contentview" class="notranslate" style="background:#fff;position:relative;width:100%;height:99%;border:0px solid #aaa;margin:0px;padding:0px;overflow:auto;">
</iframe>
</div><!-- BOTTOM PANEL ENDS --> 
<div data-options="region:'center',collapsible:true, split:true" style="padding:0px;" id="left"><!-- LEFT STARTS -->
<div data-options="fit:true,border:false,tools:'#tab-tools',toolPosition:'left'" id="tt" class="easyui-tabs">  
<div title="testAngularJS.htm" style="padding:0px;">  
<pre id="html" class="editclass notranslate"></pre>
</div> 
</div>
<div id="tab-tools" style="border-top:0px; border-right:0px;">
      <div id='wait' style='display:none'>
          <img style="margin-left:4px;margin-top:0px;width:24px; height:24px;" src='/images/loading.gif'/>
      </div>
      <a href="javascript:void(0)" onclick="javascript:submitForm();return false" class="easyui-linkbutton" data-options="plain:true,iconCls:'icon-compile'" target="view" style="width:65px;white-space: nowrap;"><b>Execute</b></a>
</div>
</div><!-- LEFT ENDS -->
</form>
<script src="/ace/src-min/ace.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
   var editors = {};
   var element = window.parent.$("#source");
   $("#html").text($(element).text());


   editors['html'] = new ace.edit('html');
   editors['html'].setTheme("ace/theme/crimson_editor");
   editors['html'].getSession().setMode("ace/mode/html");
   editors['html'].getSession().setUseWrapMode(true);
   editors['html'].resize(true);  

   function submitForm(){
      $('#wait').show(); 
      $("[name='lang']").val("jquery");
      $("[name='html']").val(editors['html'].getValue());
      $('#view').html("");
      $("#ff").submit();
   }    
   $(function(){
      editors['html'].resize(true);  
      $('#cc').layout('panel','south').panel({
          onResize:function(){
              $('#wait').hide(); 
              editors['html'].resize(true);  
          },
          onExpand:function(){
              editors['html'].resize(true);  
          },
          onCollapse:function(){
              editors['html'].resize(true);  
          },
      });
   });
</script>
</div>
</div>
</body>
</html>
