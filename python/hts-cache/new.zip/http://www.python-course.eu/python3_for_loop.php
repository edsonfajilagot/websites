<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: For Loops</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction into loops and the for Loop in Python. Simulating C-style loops with range" />
<meta name="Keywords" content="Python, for loop, loops, example, introduction, list iteration, 
side effects, iterating, pythagoren numbers" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/logo100.png" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<h3>Mythology</h3>
The first great achievement of Apollo was to slay the huge serpent Python. In some texts 
Python is an enormous dragon and not a serpent. 
<br>  
But who was this mythical creature? Python was created out of the slime and mud left after 
the great flood. She was  appointed by Gaia (Mother Earth) to guard the oracle of Delphi, 
known as Pytho. After having defeated Python Apollo remade
her former home and the oracle as his own.
<br>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_for-schleife.php">For-Schleifen</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="for_loop.php">For Loops in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="for_loop.php">For Loops in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_loops.php">Loops, while Loop</a><br>
<LINK rel="prev" href="python3_loops.php">Next Chapter: <a href="python3_print.php">Output with Print</a><br>
<LINK rel="next" href="python3_print.php"></div>
<h2>For Loops</h2>

<h3>Introduction</h3>
<img class="imgright" src="images/ring2.png" alt="Ring as a Symbol of the for loop" />
Like the while loop the for loop is a programming language statement, i.e. an iteration statement,
which allows a code block to be repeated a certain number of times. 
<br><br>There are hardly programming languages without for loops, but the for loop exists in many
different flavours, i.e. both the syntax and the semantics differs from one programming language 
to another. 
<br><br>
Different kinds of for loops:
<ul>
<li>Count-controlled for loop (Three-expression for loop)<br>
This is by far the most common type. This statement is the one used by C. 
The header of this kind of for loop consists of a three-parameter loop control expression. Generally it has
the form:
<br>
<code>for (A; Z; I)</code>
<br>
A is the initialisation part, Z determines a termination expression and I is the counting expression, where
the loop variable is incremented or dcremented. 
An example of this kind of loop is the for-loop of the programming language C:
<br>
<code>for (i=0; i <= n; i++)</code>
<br>
This kind of for loop is not implemented in Python!
 </li>
<li>Numeric Ranges
<br>
This kind of for loop is a simplification of the previous kind. It's a counting or enumerating loop.
Starting with a start value and counting up to an end value, like <code>for i = 1 to 100</code>
<br>
Python doesn't use this either.
</li> 
<li>Vectorized for loops
<br>
They behave as if all iterations are executed in parallel. This means for example that all expressions
on the right side of assignment statements get evaluated before the assignements.
</li>
<li>Iterator-based for loop
<br>
Finally, we come to the one used by Python. This kind of a for loop iterates over an enumeration of a set 
of items. It is usually characterized by the use of an implicit or explicit 
iterator. In each iteration step a loop variable is set to a value in a sequence or other orderable 
data collection. This kind of for loop is known in most Unix and Linux shells and it is the one which
is implemented in Python.</li>
</ul>

 
<br>


<h3>Syntax of the For Loop</h3>
<p>
As we mentioned earlier, the Python for loop is an iterator based for loop. It steps through the
items in any ordered sequence list, i.e. string, lists, tuples, the keys of dictionaries and other
iterables. The Python for loop starts with the keyword "for" followed by an arbitrary variable name,
whihc will hold the values of the following sequence object, which is stepped through. The general syntax
looks like this:
<br>
<pre>
for &lt;variable&gt; in &lt;sequence&gt;:
	&lt;statements&gt;
else:
	&lt;statements&gt;
</pre>

The items of the sequence object are assigned one after the other to the loop variable;
to be precise the variable points to the items. For each item the loop body is executed. 
<br><br>
<br>Example of a simple for loop in Python:
<pre>
>>> languages = ["C", "C++", "Perl", "Python"] 
>>> for x in languages:
...     print x
... 
C
C++
Perl
Python
>>> 
</pre>
<br>
<img class="imgright" src="images/CanOfSpam" alt="Can of Spam" />
The else block is special; while Perl programmer are familiar with it, it's an unknown concept
to C and C++ programmers. Semantically, it works exactly as the optional else of a while loop.
It will be executed only if the loop, if the loop hasn't been "broken" by a break statement. 
So it will only be executed, after all the items of the sequence in the header have been
used.
<br><br>
If a break statement has to be executed in the programm flow of the for loop, the loop will
be exited and the program flow will continue with the first statement following the for loop,
if there is any at all. Usually break statements are wrapped into conditional statements, e.g.
<br>
<pre>
edibles = ["ham", "spam","eggs","nuts"]
for food in edibles:
    if food == "spam":
        print("No more spam please!")
        break
    print("Great, delicious " + food)
else:
    print("I am so glad: No spam!")
print("Finally, I finished stuffing myself")
</pre>

If we call this script, we get the following result:
<br>
<pre>
$ python for.py 
Great, delicious ham
No more spam please!
Finally, I finished stuffing myself
$ 
</pre>

Removing "spam" from our list of edibles, we will gain the following output:
<pre>
$ python for.py 
Great, delicious ham
Great, delicious eggs
Great, delicious nuts
I am so glad: No spam!
Finally, I finished stuffing myself
$
</pre>

Maybe, our disgust with spam is not so high, that we want to stop consuming the other food.
Now, this calls into play the continue statement. In the following
little script we use the continue statement to go on with our list of edibles, when we have
encountered a spam item. So continue prevents us from eating spam!
<pre>
edibles = ["ham", "spam", "eggs","nuts"]
for food in edibles:
    if food == "spam":
        print("No more spam please!")
        continue
    print("Great, delicious " + food)
    # here can be the code for enjoying our food :-)
else:
    print("I am so glad: No spam!")
print("Finally, I finished stuffing myself")
</pre>
The output looks as follows:
<pre>
$ python for.py 
Great, delicious ham
No more spam please!
Great, delicious eggs
Great, delicious nuts
I am so glad: No spam!
Finally, I finished stuffing myself
$
</pre>

</p>

<h3>The range() Function</h3>
<p>
The built-in function range() is the right function to iterate over a 
sequence of numbers. It generates an iterator of arithmetic progressions:

<br>
Example:
<pre>
>>> range(10)
range(0, 10)
>>> list(range(10))
[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
>>> 
</pre>
range(n) generates an iterator to progress the integer numbers starting with 1 
and ending with (n -1). To produce the list with these numbers, we have to cast
rang() with the list(), as we did in the previous example.
<br>
range() can also be called with two arguments:
<pre>
range(begin,end)
</pre>
The above call produces the list iterator of numbers starting with begin (inclusive) and 
ending with one less than the number "end".
<br>
Example:
<pre>
>>> range(4,10)
range(4, 10)
>>> list(range(4,10))
[4, 5, 6, 7, 8, 9]
>>> 
</pre>

<br>
So far the increment of range() has been 1. We can specify a different increment 
with a third argument.
The increment is called the "step". It can be both negative 
and positive, but not zero:
<pre>
range(begin,end, step)
</pre>

Example with step:
<br>
<pre>
>>> list(range(4,50,5))
[4, 9, 14, 19, 24, 29, 34, 39, 44, 49]
>>> 
</pre>
It can be done backwards as well:
<pre>
>>> list(range(42,-12,-7))
[42, 35, 28, 21, 14, 7, 0, -7]
>>> 
</pre>

The range() function is especially useful in combination with the for loop, as 
we can see in the following example. The range() function supplies the numbers 
from 1 to 100 for the for loop to calculate the sum of these numbers:

<pre>
n = 100

sum = 0
for counter in range(1,n+1):
    sum = sum + counter

print("Sum of 1 until %d: %d" % (n,sum))
</pre>

<h3>Calculation of the Pythagorean Numbers</h3>
<img class="imgright" src="images/pythagoras_proof.png" alt="Pythagorean theorem proof" />
Generally, it is assumed, that the Pythagorean theorem was discoverd by Pythagoras, that is 
why it has its name. But there is a debate whether the Pythagorean theorem might have 
been discovered earlier or by others independently. For the Pythagoreans,  - a mystical movement,
based on mathematics, religion and philosophy, -  the integer numbers satisfying the theorem were
special numbers, which had been sacred to them. 
<br><br>
These days Pythagorean numbers are not mystical anymore. Though to some pupils at school 
or other people, who are not on good terms with mathematics, they may still appear so.
<br><br>
So the definition is very simple: <br>Three integers satisfying 
a<sup>2</sup>+b<sup>2</sup>=c<sup>2</sup>  
are called Pythagorean numbers.
<br><br>
The following program calculates all pythagorean numbers less than a 
maximal number.
<br>
Remark: We havae to import the math module to be able to calculate the square root of a
number.
<br><br>
<pre>
#!/usr/bin/env python3
from math import sqrt
n = int(input("Maximale Zahl? "))
for a in range(1,n+1):
    for b in range(a,n):
        c_square = a**2 + b**2
        c = int(sqrt(c_square))
        if ((c_square - c**2) == 0):
            print(a, b, c)
</pre>

<h3>Iterating over Lists with range()</h3>

If you have to access the indices of a list, it doesn't look to be a good idea to 
use the for loop to iterate over the lists. We can access all the elements, but the 
index of an element is not available. But there is a way to access both the index of an 
element and the element itself. The solution consists in using range() in combination
with the length function  len():

<pre>
fibonacci = [0,1,1,2,3,5,8,13,21]
for i in range(len(fibonacci)):
    print(i,fibonacci[i])
print()
</pre>

The output looks like this:
<pre>
0 0
1 1
2 1
3 2
4 3
5 5
6 8
7 13
8 21
</pre>

Remark: If you apply len() to a list or a tuple, you get the number of elements of 
this sequence.
<br><br>
<h3>List iteration with Side Effects</h3>
If you loop over a list, it's best to avoid changing the list in the loop body. 
To give you an example, what can happen, have a look at the following example:
<pre>
colours = ["red"]
for i in colours:
    if i == "red":
        colours += ["black"]
    if i == "black":
        colours += ["white"]
print(colours)
</pre>
What will be printed by "print colours"?
<pre>
['red', 'black', 'white']
</pre>
To avoid these side effects, it's best to work on a copy by using the slicing operator, as can
be seen in the next example:
<pre>
colours = ["red"]
for i in colours[:]:
    if i == "red":
        colours += ["black"]
    if i == "black":
        colours += ["white"]
print(colours)
</pre>
Now the output looks like this:
<pre>
['red', 'black']
</pre>
We still might have done something, what we shouldn't have done. We changed the list "colours", 
but our change hasn't had any effect on the loop anymore. The elements to be looped remained the
same during the iterations.
<br><br>
</p>

<div id="contextlinks">Previous Chapter: <a href="python3_loops.php">Loops, while Loop</a><br>
<LINK rel="prev" href="python3_loops.php">Next Chapter: <a href="python3_print.php">Output with Print</a><br>
<LINK rel="next" href="python3_print.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
