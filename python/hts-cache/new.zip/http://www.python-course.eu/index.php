<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Tutorials, Python Courses: Online and On Site</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Free comprehensive online tutorials suitable for self-study and high-quality on site Python courses in Europe, Canada (Toronto) and the US" />
<meta name="Keywords" content="Python, course, courses, training, tutorial, self-study programming, language,beginners, advanced, introduction, self-study, learn, training, training courses" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li class="active"><a id="current" href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/python_head.jpg" alt="box" />    <h2>Home</h2>

<div class="menu">

<ul>
</ul>

</div>

<p>
 <new>New topics</new>
<br>We have started a new topic: <a href="graphs_python.php">Introduction and Tutorial in Graph theory with an implementation in Python.</a>
<br>Something which has been missing in our tutorial: <a href="python3_formatted_output.php">Formatting Strings or output</a>
<br>
<hr>
Topics for advanced programmers, which are not covered by our tutorial and most other tutorials and books on Python:<br>
<ul>
<li>For learning more about some objects used or maintained by the
    interpreter and to functions that interact strongly with the Python interpreter:<br><a href="sys_module.php">Introduction into the sys Module</a></li>
<li>The interface to the operating system: <a href="os_module_shell.php">Python and the Shell</a></li>
<li>Only for Linux and Unix-like systems: <a href="forking.php">Forks and Forking in Python</a></li>
<li>Learn more about light weight processes: <a href="threads.php">Introduction into threads in Python</a></li>
<li>You can learn more about pipes than beer: <a href="pipes.php">Pipe, Pipes and "99 Bottles of Beer"</a></li>
<li><a href="numpy.php">Introduction and Tutorial on NumPy</a></li>
<li><a href="matrix_arithmetic.php">Matrix Arithmetic using NumPy and Python</a></li>
<li>Some linear algebra with Python: <a href="linear_combinations.php">Linear Combinations</a></li>
<li>Introduction into Graph Theory and an implementation in Python: <a href="graphs_python.php">Graphs and Python</a></li>
<li>Something from theoretical Computer Science: Implemenatation of a <a href="finite_state_machine.php">Finite State Machine (FSM)</a> in Python</li>
<li>For those interested in learning more about theoretical Computer Science: Definition and Implementation of a <a href="turing_machine.php">Turing machine</a> in Python</li>
<li><a href="text_classification_introduction.php">Introduction into Text Classification</a></li>
<li><a href="text_classification_python.php">Text Classification using Python</a></li>
<li>	<a href="towers_of_hanoi.php">Recursive Function for Towers of Hanoi</a></li>
<li>	<a href="mastermind.php">Mastermind / Bulls and Cows</a></li>
<li>An introduction into using database interfaces in Python for
 <a href="sql_python.php">SQL, MySQL and SQLite</a>
</li>
<li>"And now for something completely different: 	<a href="python_scores.php">Python Music Scores Using Lilypond</a></li>
</ul>
<hr>

Supported by:<br>
<a href="http://www.bodenseo.com"><img style="width: 150px;" alt="Bodenseo,
Python, training courses"
		     src="images/bodenseo_python_training.gif"><br>Python Training Courses</a>
<hr>
We also like to thank <a href="http://www.mitchinson.net"> www.mitchinson.net </a> for providing the beautiful stylesheet of 
this website.<br><br><br>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu">Python Kurs</a><h3>Python Courses</h3>
This website contains a free and extensive online tutorial by Bernd Klein, well suited for self-learning. 
However, you can attend one of his <a href="python_classes.php">Python courses</a> in Paris,
London, Toronto, Berlin, Frankfurt, Hamburg Munich or Lake Constance.
<br><br>
<p>If you  want to learn Python fast and efficiently, you should consider a 
<a href="http://www.bodenseo.com/courses.php?topic=Python">
<img class="imgright" src="images/bodenseo_stairs_to_python2.png" alt="Bodenseo step to python" />
<br>Python Training course</a> at Bodenseo. You will find the right 
<a href="http://www.bodenseo.com/course/python_training_course.html">course for a beginner</a>,
<a href="http://www.bodenseo.com/course/python_training_course_intermediate.html">intermediate</a> 
or special seminars for advanced students like the 
<a href="http://www.bodenseo.com/course/python_xml_training_course.html">Python & XML Training Course</a>.
<br>
<br>
All the Python seminars are available in German as well: 
<a href="http://www.bodenseo.de/kurse.php?topic=Python">Python-Kurse</a>"
<br>
<hr>
<br>
<h3>Trainings in the US and Canada</h3>
<img class="imgright" src="images/gooderham_building_toronto.jpg" alt="Trainings in Toronto" />
We offer training courses in Canada, i.e. Toronto and Ottawa, and the United States as well, you can have a look at our website
<a href="http://www.python-training-courses.com">Python-trainings.com</a> to find the optimal class for you.


<h3>Another Quote</h3>
In my daily work, I work on very large, complex, distributed systems built out of 
many Python modules and packages. The focus is very similar to what you find, for 
example, in Java and, in general, in systems programming languages.
(Guido van Rossum) 
 </p>

</p></div>

<div id="content">

<h2>Introduction</h2>
<p><img class="imgleft" src="images/python_logo_3_130.jpg" alt="box" />
Although Python is an easy to learn and powerful programming language as it is 
known in common parlance, there is nevertheless need of a good introduction and 
tutorial on the Python language. 
<br><br>
Why yet another documentation and tutorial on Python? 
Aren't there enough websites with tutorials and books dealing with Python? 
Isn't there already everything said about the programming language Python? 
<br><br>
These were the questions which came to our mind, when we started this website in June 2010.
Yes, there are lots of tutorials and introductions, but we wanted to present a different 
approach, with other - more interesting - examples, better explanatory diagrams and so
on. We had a lot to build on, above all the longstanding experience of Bernd Klein as a 
computer scientist and Python lecturer. Actually, this online course is based on the material 
from the classroom training courses of Bodenseo.  
<br>
<br> 


</p>
 




<div class="intro">

<h3>Online Course</h3>
<div class="textmenu">
<p class="update">
You will find a complete introduction into Python in our online tutorial:
<ul>
<li>In our first chapter you learn how to use the 
<a href="interactive.php">Python Interactive Interpreter</a> 
(<a href="python3_interactive.php">in Python3</a>)
</li>

<li>You will see how easy it is to 
<a href="execute_script.php">Execute a Script in Python</a>.
(<a href="python3_execute_script.php">in Python3</a>)
</li>
<li>Python differs from other programming languages in many ways, but the
most striking one is obviously it's <a href="blocks.php">"Structuring with Indentation"</a>
(<a href="python3_blocks.php">in Python3</a>)

</li>
<li>Variables are easier to be used than in many other programming languages but still there
are some things to point out about "<a href="variables.php">Data Types and Variables</a>"
(<a href="python3_variables.php">in Python3</a>).</li>
<li>Though <a href="operators.php">operators</a>(<a href="python3_operators.php">in Python3</a>) are more or less the same as in other languages, we have to cover them anyway.</li>

<li>Assignments can be quite tricky in Python. When will an object be copied and when 
will we just have a reference? What's the difference between a 
<a href="deep_copy.php">shallow and a deep copy</a>(<a href="python3_deep_copy.php">in Python3</a>)?
</li>
<li><a href="conditional_statements.php">Conditional statements</a>(<a href="python3_conditional_statements.php">in Python3</a>) are straightforward in 
Python</li>
<li>The same is true for the <a href="loops.php">(<a href="python3_loops.php">in Python3</a>) while loops</a>, but there is this special "else" part.</li>
<li>The <a href="for_loop.php">for loops</a> (<a href="python3_for_loop.php">in Python3</a>) seem to be quite strange if you are used to 
C but easy if you know the bash shell</li>
<li>The <a href="python3_formatted_output.php">different ways to format data</a> (Only in our Python 3 tutorial).

<li>In this chapter of our course we will have a closer look at 
<a href="sequential_data_types.php">sequential data types</a> (<a href="python3_sequential_data_types.php">in Python3</a>)</li>
<li><a href="dictionaries.php">Dictionaries</a> (<a href="python3_dictionaries.php">in Python3</a>) are one of the best things 
Python has to offer</li>
<li>It's possible to use sets in Pythons programs as well: We cover both 
<a href="sets_frozensets.php">sets and frozensets</a> (<a href="python3_sets_frozensets.php">in Python3</a>) </li>
<li>Programming without <a href="functions.php">functions</a> (<a href="python3_functions.php">in Python3</a>) would be like cooking without salt and spices.</li>
<li>And a very special spice for your "cooking" can be a 
<a href="recursive_functions.php">recursive function</a> (<a href="python3_recursive_functions.php">in Python3</a>).</li>
<li>To understand functions properly, you need a thorough understanding of arguments and 
<a href="passing_arguments.php">parameter passing</a> (<a href="python3_passing_arguments.php">in Python3</a>).</li>
<li>In the next chapter of our seminar you will find all you have to know about 
<a href="namespaces.php">namespaces</a> (<a href="python3_namespaces.php">in Python3</a>).</li>
</ul>
</p> 
</div></div>

<div class="intro2">

<h3>Further Topics</h3>
<div class="textmenu">
<ul>
<li><a href="global_vs_local_variables.php">Global and local variables</a> (<a href="python3_global_vs_local_variables.php">in Python3</a>) is a topic, 
which can be different for beginners.</li>
<li>A language without the ability to read and write data files would be. So we will introduce you
in our course to the essentials of <a href="file_management.php">file management</a> (<a href="python3_file_management.php">in Python3</a>).</li>
<li>A program, especially a large one, shouldn't be called a program, 
if it isn't <a href="modules_and_modular_programming.php">written in
a modular way</a> (<a href="python3_modules_and_modular_programming.php">in Python3</a>).</li>
<li><a href="python3_memoization.php">Memoisation</a> is a technique used in computing to speed up programs 
by giving functions memory.</li>
<li>Text processing without regular expressions is only piecemeal. That's why we present in 
our tutorial a detailled <a href="re.php">introduction into regular expressions under Python</a> (<a href="python3_re.php">in Python3</a>), continued
by a chapter with <a href="re_advanced.php">advanced regular expressions</a> (<a href="python3_re_advanced.php">in Python3</a>).

</li>
<li>Something very controversial in Python: <a href="lambda.php">Lambda Operator</a> (<a href="python3_lambda.php">in Python3</a>)</li>
<li>It's no secret, that Guido van Rossum doesn't like lambda Operators. Here we give you an introduction 
into his preferred way, i.e. <a href="list_comprehension.php">List Comprehension</a> (<a href="python3_list_comprehension.php">in Python3</a>)</li>
<li><a href="exception_handling.php">Exception Handling</a> (<a href="python3_exception_handling.php">in Python3</a>) is a concept which is comparatively new, i.e. it hasn't been known in programming languages like C and Fortran but in C++ and Java. </li>
<li>Generators are not only good for producing electricity, in Python 
<a href="generators.php">generators</a> (<a href="python3_generators.php">in Python3</a>) are the most
powerful tool to create iterators.</li>
<li>Yes, Python is a fully object oriented language! So we offer a complete online course
into the details of OOP. You suggest working through the following chapters in this order: 
<ul>
  <li><a href="python3_object_oriented_programming.php">General 
  Introduction into Object Oriented Programming (OOP)</a>
  <li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a>
  <li><a href="python3_properties.php">Properties vs. Getters and Setters</a>
  <li><a href="python3_inheritance.php">Inheritance</a>
  <li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a>
  <li><a href="python3_magic_methods.php">Magic Methods and Operator Overlaoding</a>
</ul>


</li>
</ul>
</div>
<p class="update">
</p> </div>

<div class="intro3">

<h4>Our next Training Courses</h4>
<br>Our next open Python classes with Bernd Klein, the author of this website:
<br><b>Toronto</b>:  3<sup>rd</sup> - 7<sup>th</sup> of November, 2014:
<br><a href="http://ca.bodenseo.com/courses.php?topic=Python">Python Training Course in Toronto</a>
<br><b>London</b>:  20<sup>th</sup> - 24<sup>rd</sup> of October, 2014: 
<br><a href="http://www.bodenseo.com/course/python_training_course_intermediate.html">Python Intensive Course in London</a>
<br><b>Berlin</b>:  10<sup>th</sup> - 14<sup>th</sup> of November, 2014: 
<br><a href="http://www.bodenseo.com/course/python_training_course_intermediate.html">Python Intensive Course in Berlin</a>
<br><b>Lake Constance / Zurich</b>:  1<sup>st</sup> - 5<sup>th</sup> of September, 2014:
<br><a href="http://www.bodenseo.com/course/python_training_course_intermediate.html">Python Intensive  Course</a>
<br><b>Paris</b>:  1<sup>st</sup> - 5<sup>th</sup> of December, 2014:
<br><a href="http://www.bodenseo.com/course/python_text_processing_course.html">Python Text Processing Course</a>
<br><b>Munich</b>:  8<sup>th</sup> - 12<sup>th</sup> of December, 2014:
<br><a href="http://www.bodenseo.com/course/python_training_course.html">Python Training Course</a>
<br>

 
<br><br>
<h4>A Course is not a Course</h4>
<p class="update">
The question is ambiguous. First we want to explain, why this website is called
"A Python Course". This website is seen all over the world 
and the expression "course" has varying meanings in the English speaking world.
Both in the United States and Canada, a course is a teaching unit, which might last
e.g. one academic term. The students normally get a grade or some academic credit 
for attending the course, usually after having passed an exam.
<br><br>
 In the United Kingdom and Australia the term "course" usually defines the complete 
 programme of studies required to complete a major or a study path leading to a 
 university degree. The word "unit" is used in the UK to refer to an 
 academic course in the North American sense. 
 <br><br>
On the one hand, we had the US and Canadian sense in mind: Our Python is one teaching
unit and when you have successfully passed it, you are capable of programming 
in Python. On the other hand, we had the original meaning of the word in mind: 
A "course of instruction" as it might be used in book titles like "A Course in 
Programming Python".

</p> </div>

</div>


