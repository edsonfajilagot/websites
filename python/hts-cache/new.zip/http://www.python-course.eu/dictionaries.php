<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: Dictionaries</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Dictionaries and Operators and Methods on Dictionaries in Python" />
<meta name="Keywords" content="Python, course, Dictionaries, dictionary, methods, mapping, associative, 
Operators" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/blocks100.jpg" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<h3>Mythology</h3>
The first great achievement of Apollo was to slay the huge serpent Python. In some texts 
Python is an enormous dragon and not a serpent. 
<br>  
But who was this mythical creature? Python was created out of the slime and mud left after 
the great flood. She was  appointed by Gaia (Mother Earth) to guard the oracle of Delphi, 
known as Pytho. After having defeated Python Apollo remade
her former home and the oracle as his own.
<br>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/dictionaries.php">Dictionaries</a><h3>Python 2.7</h3>This tutorial deals with Python Version 2.7<br>This chapter from our course is available in a version for Python3: <a href="python3_dictionaries.php">Dictionaries</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>"I think it is inevitable that people program poorly. Training will not 
substantially help matters. We have to learn to live with it."</i>
 (Alan Perlis)

<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="sequential_data_types.php">Sequential Data Types</a><br>
<LINK rel="prev" href="sequential_data_types.php">Next Chapter: <a href="sets_frozensets.php">Sets and Frozen Sets</a><br>
<LINK rel="next" href="sets_frozensets.php"></div>
<h2>Dictionaries</h2>
<p>
<h3>Introduction</h3>
We have already become acquainted with lists in the previous chapter. 
In this chapter of our online Python course we will present the dictionaries 
and the operators and methods on dictionaries. Python programs or scripts without
lists and dictionaries are nearly inconceivable. Like lists dictionaries can 
easily be changed, can be shrunk and grown ad libitum at run time. They shrink
and grow without the necessity of making copies. Dictionaries can be contained in 
lists and vice versa. But what's the difference
between lists and dictionaries? Lists are ordered sets of objects, whereas dictionaries
are unordered sets. But the main difference is that items in dictionaries are accessed
via keys and not via their position. A dictionary is an associative array (also known
as hashes). Any key of the dictionary is associated (or mapped) to a value. The
values of a dictionary can be any Python data type. So dictionaries are unordered 
key-value-pairs.
<br><br>
Dictionary don't support the sequence operation of the sequence data types like strings, tuples
and lists. Dictionaries belong to the built-in mapping type. They are the sole
representative of this kind!

<br><br>
At the end of this chapter, we will show how a dictionary can be turned into one
list, containing (key,value)-tuples or two lists, i.e. one with the keys and one 
with the values. This transformation can be done reversely as well.
<br><br>
<h3>Examples of Dictionaries</h3>    

Our first example is the most simple dictionary, an empty dictionary:
<pre>
>>> empty = {}
>>> empty
{}
</pre>
In honour to the patron saint of Python "Monty Python", we'll have now some special
food dictionaries. What's Python without "ham", "egg" and "spam"?
<pre>
>>> food = {"ham" : "yes", "egg" : "yes", "spam" : "no" }
>>> food
{'egg': 'yes', 'ham': 'yes', 'spam': 'no'}
>>> food["spam"] = "yes"
>>> food
{'egg': 'yes', 'ham': 'yes', 'spam': 'yes'}
>>> 
</pre>

Our next example is a simple German-English dictionary:
<br>
<pre>
# -*- coding: iso-8859-1 -*-

en_de = {"red" : "rot", "green" : "gr�n", "blue" : "blau", "yellow":"gelb"}
print en_de
print en_de["red"]
</pre>
The first line of the previous script is necessary to use the iso-8859-1 code with
German Umlaute. The file has to be saved in this coding as well.
<br><br>
What about having another language dictionary, let's say German-French?  
Now it's even possible to translate from English to French, even though we don't 
have an English-French-dictionary. de_fr[en_de["red"]] gives us the French word
for "red", i.e. "rouge":
<pre>
# -*- coding: iso-8859-1 -*-

en_de = {"red" : "rot", "green" : "gr�n", "blue" : "blau", "yellow":"gelb"}
print en_de
print en_de["red"]
de_fr = {"rot" : "rouge", "gr�n" : "vert", "blau" : "bleu", "gelb":"jaune"}
print "The French word for red is: " + de_fr[en_de["red"]]
</pre>


We can use arbitrary types as values in a dictionary, but there is a restriction 
for the keys. Only immutable data types can be used as keys, i.e. no lists or
dictionaries can be used: 

<br>If you use a mutable data type as a key, you get an error message:
<pre>
>>> dic = { [1,2,3]:"abc"}
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
TypeError: list objects are unhashable
</pre>
Tuple as keys are okay, as you can see in the following example:
<pre>
>>> dic = { (1,2,3):"abc", 3.1415:"abc"}
>>> dic
{(1, 2, 3): 'abc'}
</pre>

Let's improve our examples with the natural language dictionaries a bit. We create a 
dictionary of dictionaries:
<pre>
# -*- coding: iso-8859-1 -*-

en_de = {"red" : "rot", "green" : "gr�n", "blue" : "blau", "yellow":"gelb"}
de_fr = {"rot" : "rouge", "gr�n" : "vert", "blau" : "bleu", "gelb":"jaune"}

dictionaries = {"en_de" : en_de, "de_fr" : de_fr }
print dictionaries["de_fr"]["blau"]
</pre>

</p>
<h3>Operators on Dictionaries</h3>
<p>
<table
style="text-align: left; width: 100%; background-color: rgb(255, 255, 153);"
border="0" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<th style="vertical-align: top;">Operator<br>
</th>
<th style="vertical-align: top;">Explanation<br>
</th>
</tr>
<tr>
<td style="vertical-align: top;">len(d)<br>
</td>
<td style="vertical-align: top;">returns the number of stored entries, i.e. 
the number of (key,value) pairs.<br>
</td>
</tr>
<tr>
<td style="vertical-align: top;">del d[k]<br>
</td>
<td style="vertical-align: top;">deletes the key k together with his value<br>
</td>
</tr>
<tr>
<td style="vertical-align: top;">k in d<br>
</td>
<td style="vertical-align: top;">True, if a key k exists in the dictionary d<br>
</td>
</tr>
<tr>
<td style="vertical-align: top;">k not in d<br>
</td>
<td style="vertical-align: top;">True, if a key k doesn't exist in the dictionary d<br>
</td>
</tr>
</tbody>
</table>
</p>
<h3>Accessing non Existing Keys</h3>
<p>
If you try to access a key which doesn't exist, you will get an error message:
<pre>
>>> words = {"house" : "Haus", "cat":"Katze"}
>>> words["car"]
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
KeyError: 'car'
</pre>
You can prevent this by using the "in" operator:
<pre>
>>> if "car" in words: print words["car"]
... 
>>> if "cat" in words: print words["cat"]
... 
Katze
</pre>
</p>
<h3>Important Methods</h3>
A dictionary can be copied with the method copy():
<pre>
>>> w = words.copy()
>>> words["cat"]="chat"
>>> print w
{'house': 'Haus', 'cat': 'Katze'}
>>> print words
{'house': 'Haus', 'cat': 'chat'}
</pre>
The content of a dictionary can be cleared with the method clear().
The dictionary is not deleted, but set to an empty dictionary:
<pre>
>>> w.clear()
>>> print w
{}
</pre>
</p>
<h3>Update: Merging Dictionaries</h3>
<p>
What about concatenating dictionaries, like we did with lists? There is something 
similar for dictionaries: the update method<br>
update() merges the keys and values of one dictionary into
another, overwriting values of the same key:

<pre>
>>> w={"house":"Haus","cat":"Katze","red":"rot"}
>>> w1 = {"red":"rouge","blau":"bleu"}
>>> w.update(w1)
>>> print w
{'house': 'Haus', 'blau': 'bleu', 'red': 'rouge', 'cat': 'Katze'}
</pre>
</p>
<h3>Iterating over a Dictionary</h3>
<p>
No method is needed to interate over a dictionary:
<pre>
for key in d:
	print key
</pre>
But it's possible to use the method iterkeys():
<pre>
for key in d.iterkeys():
	print key
</pre>
The method itervalues() is a convenient way for iterating directly over the values:
<pre>
for val in d.itervalues():
	print val
</pre>
The above loop is of course equivalent to the following one:
<pre>
for key in d:
	print d[key]
</pre>
</p>
<br>
<h3>Connection between Lists and Dictionaries</h3>
<p>
<img class="imgright" src="images/zipper_sphere.gif" 
alt="zipper on a ball"/>

If you have worked for a while with Python, nearly inevitably the moment will come,
when you want or have to convert lists into dictionaries or vice versa.
It wouldn't be too hard to write a function doing this. But Python wouldn't be Python, 
if it didn't provide such functionalities. 

<br><br>
If we have a dictionary <br><br>
<FONT FACE="courier">{"list":"Liste", "dictionary":"W�rterbuch", "function":"Funktion"}
</FONT>
<br><br>
we could turn this into a list with two-tuples: <br><br>
<FONT FACE="courier">[("list","Liste"), ("dictionary","W�rterbuch"), ("function","Funktion")]
</FONT>

</p>


<h3>Lists from Dictionaries</h3>
<p>
It's possible to create lists from dictionaries  by using the methods items(), 
keys() and values(). As the name implies the method keys() creates a list, 
which consists solely of the keys of the dictionary. While values() produces a list
consisting of the values.  items() can be used to create a list consisting of 
2-tuples of (key,value)-pairs:
<pre>
>>> w={"house":"Haus","cat":"Katze","red":"rot"}
>>> w.items()
[('house', 'Haus'), ('red', 'rot'), ('cat', 'Katze')]
>>> w.keys()
['house', 'red', 'cat']
>>> w.values()
['Haus', 'rot', 'Katze']
</pre>
If we apply the method items() to a dictionary, we have no information loss, i.e. it
is possible to recreate the original dictionary from the list created by items().
Even though this list of 2-tuples has the same entropy, i.e. the information content
is the same, the efficiency of both approaches is completely different. The dictionary
data type provides highly efficient methods to access, delete and change elements of the
dictionary, while in the case of lists these functions have to be implemented by the 
programmer.


<h3>Dictionaries from Lists</h3>

Now we will turn out attention to the art of cooking, but don't be afraid, this
remain a python course and not a cooking course. 
We want to show you, how to turn lists into dictionaries, if these lists satisfy
certain conditions.
<br>
We have two lists, one containing the dishes and the other one the corresponding
countries:
<pre>
>>> dishes = ["pizza", "sauerkraut", "paella", "Hamburger"]
>>> countries = ["Italy", "Germany", "Spanien", "USA"]
</pre>
Now we will create a dictionary, which assigns a dish to a country, of course according
to the common prejudices. 
For this purpose we need the function zip(). The name zip was well chosen, because
the two lists get combined like a zipper. 
<br>
<pre>
>>> country_specialities = zip(countries, dishes)
>>> print country_specialities
[('Italy', 'pizza'), ('Germany', 'sauerkraut'), ('Spanien', 'paella'), ('USA', 'Hamburger')]
>>> 
</pre>
The variable country_specialities contains now the "dictionary" in the 2-tuple list form.
This form can be easily transformed into a real dictionary with the function dict().
<pre>
>>> country_specialities_dict = dict(country_specialities)
>>> print country_specialities_dict
{'Germany': 'sauerkraut', 'Spanien': 'paella', 'Italy': 'pizza', 'USA': 'Hamburger'}
>>> 
</pre>
There is still one question concerning the function zip(). What happens, if one
of the two argument lists contains more elements than the other one? 
It's easy: The superfluous elements will not be used: 
<pre>
>>> countries = ["Italy", "Germany", "Spanien", "USA", "Switzerland"]
>>> dishes = ["pizza", "sauerkraut", "paella", "Hamburger"]
>>> country_specialities = zip(countries,dishes)
>>> print country_specialities
[('Italy', 'pizza'), ('Germany', 'sauerkraut'), ('Spanien', 'paella'), ('USA', 'Hamburger')]
</pre>
So in this course, we will not answer the burning question, what the national dish of
Switzerland is.
<br><br>
<div id="contextlinks">Previous Chapter: <a href="sequential_data_types.php">Sequential Data Types</a><br>
<LINK rel="prev" href="sequential_data_types.php">Next Chapter: <a href="sets_frozensets.php">Sets and Frozen Sets</a><br>
<LINK rel="next" href="sets_frozensets.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
