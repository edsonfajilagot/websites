<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Books on Python: Learning Python by Mark Lutz</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Python Books: Mark Lutz, Learning Python; a thorough introduction into the details of Python" />
<meta name="Keywords" content="Python, Python3, books, learning python, mark lutz" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li class="active"><a id="current" href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/python_books_left.jpg" alt="box" />    <h2>Python Books</h2>

<div class="menu">

<ul>
<li><a href="learning_python.php">Mark Lutz: Learning Python</a></li><li><a href="programming_python.php">Mark Lutz: Programming Python</a></li><li><a href="dive_into_python.php">Dive into Python</a></li><li><a href="natural_language_processing_with_python.php">Natural Language Processing with Python</a></li><li><a href="rapid_gui_programming_with_python.php">Rapid GUI Programming with Python and Qt</a></li><li><a href="python_in_a_nutshell.php">Python in a Nutshell</a></li></ul>

</div>

<p>
<br>
<hr>
<i>"The man who doesn't read good books has no advantage over the man who can't read them."</i>
<br>(Mark Twain)
<br>
<hr>
<br>
<i>"There is no such thing as a moral or an immoral book. Books are well written or badly written."</i>
<br>(Oscar Wilde)
<br>
<hr>
<i>"I think it is good that books still exist, but they do make me sleepy."</i>
<br>(Frank Zappa)
<br>
<hr>
<br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Canada, the US, and Europe</a>


</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
<h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

Computers are like bikinis. They save people a lot of guesswork.<br>
(Sam Ewing)
<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>

<div id="content">

<div id="contextlinks">Next Chapter: <a href="programming_python.php">Mark Lutz: Programming Python</a><br>
<LINK rel="next" href="programming_python.php"></div>
<h2>Python Books: Learning Python, Mark Lutz</h2>
<h3>The Blurb</h3>
<p>
<img class="imgright" src="images/learning_python.jpg" alt="Python book shelf" />    
Google and YouTube use Python because it's highly adaptable, easy to maintain, and allows for rapid 
development. If you want to write high-quality, efficient code that's easily integrated with other 
languages and tools, this hands-on book will help you be productive with Python quickly -- 
whether you're new to programming or just new to Python. It's an easy-to-follow self-paced tutorial, 
based on author and Python expert Mark Lutz's popular training course.
<br><br>
Each chapter contains a stand-alone lesson on a key component of the language, and includes a unique 
Test Your Knowledge section with practical exercises and quizzes, so you can practice new skills and 
test your understanding as you go. You'll find lots of annotated examples and illustrations to help 
you get started with Python 3.0.

<br>
<ul>                                                        
<li>Learn about Python's major built-in object types, such as numbers, lists, and dictionaries</li>   
<li>Create and process objects using Python statements, and learn Python's general syntax model</li>   
<li>Structure and reuse code using functions, Python's basic procedural tool</li>      
<li>Learn about Python modules: packages of statements, functions, and other tools, organized into 
larger components</li>
<li>Discover Python's object-oriented programming tool for structuring code</li>                                                        <li>Learn about the exception-handling model, and development tools for writing larger programs</li>                                                        <li>Explore advanced Python tools including decorators, descriptors, metaclasses, and Unicode processing</li>                                                    </ul>   
</ul>

<h3>Details</h3>
Title:    Learning Python, 4th Edition <br>
By:    Mark Lutz <br>
Publisher:    O'Reilly Media <br>
Formats:        Print,       Ebook,        Safari Books Online<br>
<br>
Print:    October 2009<br> 
Ebook:    September 2009 
Pages:    1216 <br>
Print ISBN:    978-0-596-15806-4<br>
ISBN 10:    0-596-15806-8<br>
Ebook ISBN:    978-0-596-80598-2<br>
ISBN 10:    0-596-80598-5 <br>

<h3>About the Author</h3>
Mark Lutz is the world leader in Python training, the author of Python's earliest and best-selling texts, 
and a pioneering figure in the Python community since 1992. He has been a software developer for 
25 years, and is the author of O'Reilly's Programming Python, 3rd Edition and Python Pocket Reference, 
3rd Edition.

</p>					 


</div>


<div id="contextlinks">Next Chapter: <a href="programming_python.php">Mark Lutz: Programming Python</a><br>
<LINK rel="next" href="programming_python.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
