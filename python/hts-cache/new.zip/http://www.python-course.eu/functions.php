<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: Functions</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction to functions in Python with and without parameters" />
<meta name="Keywords" content="Python, Function, Functions, parameter, optional parameter, 
parameters, Docstring" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/mandelbrot2.gif" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<h3>Mythology</h3>
The first great achievement of Apollo was to slay the huge serpent Python. In some texts 
Python is an enormous dragon and not a serpent. 
<br>  
But who was this mythical creature? Python was created out of the slime and mud left after 
the great flood. She was  appointed by Gaia (Mother Earth) to guard the oracle of Delphi, 
known as Pytho. After having defeated Python Apollo remade
her former home and the oracle as his own.
<br>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/funktionen.php">Funktionen</a><h3>Python 2.7</h3>This tutorial deals with Python Version 2.7<br>This chapter from our course is available in a version for Python3: <a href="python3_functions.php">Functions</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

Man is the best computer we can put aboard a spacecraft...and the only one that can be mass produced with unskilled labor.<br> (Wernher von Braun)
<br>
<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="deep_copy.php">Shallow and Deep Copy</a><br>
<LINK rel="prev" href="deep_copy.php">Next Chapter: <a href="recursive_functions.php">Recursion and Recursive Functions</a><br>
<LINK rel="next" href="recursive_functions.php"></div>
<h2>Functions</h2>
<h3>Syntax</h3>
<p>
Functions are a construct to structure programs. They are known in most programming
languages, sometimes also called subroutines or procedures. Functions
are used to utilize code in more than one place in a program. The only way without 
functions to reuse code consists in copying the code.  
<br><br>
A function in Python is defined by a def statement. The general syntax looks like
this:
<pre>
def function-name(Parameter list):
    statements, i.e. the function body
</pre>
The parameter list consists of none or more parameters. Parameters are called 
arguments, if the function is called. The function body consists of indented
statements. The function body gets executed every time the function is called.
<br>
Parameter can be mandatory or optional. The optional parameters (zero or more) must 
follow the mandatory parameters.
<br><br>
Function bodies can contain a return statement. It can be anywhere in the function
body. This statement ends the execution of the function call and "returns" the result,
i.e. the value of the expression following the return keyword, to the caller.
If there is no return statement in the function code, the function ends, when the 
control flow reaches the end of the function body. 

<br>Example:
<pre>
>>> def add(x, y):
...     """Return x plus y"""
...     return x + y
... 
>>> 
</pre>
In the following interactive session, the function we previously defined 
will be called:
<pre>
>>> add(4,5)
9
>>> add(8,3)
11
>>>
</pre>
<h3>Example of a Function with Optional Parameters</h3>
<p>
<pre>
>>> def add(x, y=5):
...     """Return x plus y, optional"""
...     return x + y
... 
>>> 
</pre>
Calls to this function could look like this:
<pre>
>>> add(4)
9
>>> add(8,3)
11
>>> 
</pre>
</p>
<h3>Docstring</h3>
<p>
The first statement in the body of a function is usually a string, 
which can be accessed with function_name.__doc__

<br>This statement is called <b>Docstring</b>.
<br>Example:<br>
<pre>
>>> execfile("function1.py")
>>> add.__doc__
'Returns x plus y'
>>> add2.__doc__
'Returns x plus y, optional'
>>>
</pre>
</p>
<h3>Keyword Parameters</h3>
<p>
Using keyword parameters is an alternative way to make function calls.
The definition of the function doesn't change. 
<br>An example:<br>
<pre>
def sumsub(a, b, c=0, d=0):
    return a - b + c - d
</pre>
Keyword parameters can only be those, which are not used as positional arguments.
<pre>
>>> execfile("funktion1.py")
>>> sumsub(12,4)
8
>>> sumsub(12,4,27,23)
12
>>> sumsub(12,4,d=27,c=23)
4
</pre>
</p>
<h3>Arbitrary Number of Parameters</h3>
<p>
There are many situations in programming, in which the exact number of necessary
parameters cannot be determined a-priori. An arbitrary parameter number can be 
accomplished in Python with so-called tuple references. An asterisk "*" is used in front
of the last parameter name to denote it as a tuple reference. 
This asterisk shouldn't be mistaken with the C syntax, where this notation is connected
with pointers.

<br>Example:<br>
<pre>
def arbitrary(x, y, *more):
    print "x=", x, ", x=", y 
    print "arbitrary: ", more
</pre>
x and y are regular positional parameters in the previous function. *more is a 
tuple reference. 

<br>Example:
<pre>
>>> execfile("funktion1.py")
>>> arbitrary(3,4)
x= 3 , x= 4
arbitrary:  ()
>>> arbitrary(3,4, "Hello World", 3 ,4)
x= 3 , x= 4
arbitrary:  ('Hello World', 3, 4)
</pre>
</p>

<div id="contextlinks">Previous Chapter: <a href="deep_copy.php">Shallow and Deep Copy</a><br>
<LINK rel="prev" href="deep_copy.php">Next Chapter: <a href="recursive_functions.php">Recursion and Recursive Functions</a><br>
<LINK rel="next" href="recursive_functions.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
