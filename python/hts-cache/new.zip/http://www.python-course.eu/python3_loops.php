<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: While Loops</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Chapter on loops with simple and practical examples using while loops in Python." />
<meta name="Keywords" content="Python, course, loops, while, else, example, examples" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/stairs.jpg" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<hr>
<h3>Endless Loops</h3>
<img class="imgright" src="images/moebius_ring.png" alt="Ring as a Symbol of the for loop" />
An infinite loop, or a continuous loop, is a sequence of statements in a computer program which loops endlessly.
<br><br>
<h3>Loops in Music</h3>
In electronic music, a loop is a sample which is repeated continuously. Loops may be created by using tape loops, 
delay effects, sampling, a sampler or special computer software.
<hr>
<br>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo,
Linux, courses and seminars"
		     src="images/bodenseo_python_training.gif"><br>Linux and Python Courses and Seminars</a>
<br>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_schleifen.php">Schleifen</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="loops.php">While Loops in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="loops.php">While Loops in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_conditional_statements.php">Conditional Statements</a><br>
<LINK rel="prev" href="python3_conditional_statements.php">Next Chapter: <a href="python3_for_loop.php">For Loops</a><br>
<LINK rel="next" href="python3_for_loop.php"></div>
<h2>Loops</h2>
<h3>General Structure of a Loop</h3>
<p>

Many algorithms make it necessary for a programming language to have a construct 
which makes it possible to carry out a sequence of statements repeatedly. The code 
within the loop, i.e. the code carried out repeatedly, is called the body of the loop.
<br><br>
<img class="imgright" src="images/while_loop_1.png" alt="Flowchart of a loop" />

Essentially, there are three different kinds of loops:
<ul>
<li>Count-controlled loops
<br>
A construction for repeating a loop a certain number of times. 
An example of this kind of loop is the for-loop of the programming language C:
<br>
<i>for (i=0; i <= n; i++)</i>
<br>Python doesn't know this kind of loop. 
</li>
<li>Condition-controlled loop
<br>
A loop will be repeated until a given condition changes, i.e. changes from True to False or from 
False to True, depending on the kind of loop. There are while loops and do while loops with this
behaviour. 
</li>
<li>Collection-controlled loop
<br>
This is a special construct which allow looping through the elements of a "collection", which can be
an array, list or other ordered sequence. Like the for loop of the bash shell (e.g. for i in *, do echo $i; done) or the foreach
loop of Perl. 
</li>
</ul>


<br>Python supplies two different kinds of loops: the while loop and the for loop, which correspond to 
the condition-controlled loop and collection-controlled loop. 

<br><br>

Most loops contain a counter or more generally variables, which change their values 
in the course of calculation. These variables have to be initialized before the loop is 
is started. The counter or other variables, which can be altered in the body of the loop,
are contained in the condition. Before the body of the loop is executed, the condition is
evaluated. If it evaluates to True, the body gets executed. After the body is finished, the
condition will be evaluated again. The body of the loop will be executed as long as the 
condition yields True. 

 </p>
<br>

<h3>A Simple Example with a While Loop</h3>
<p>It's best to illustrate the operating principle of a loop with a simple Python example.
The following small script calculates the sum of the numbers from 1 to 100. 
We will later introduce a more elegant way to do it.  

<br>
<pre>
#!/usr/bin/env python3

n = 100

sum = 0
counter = 1
while counter <= n:
    sum = sum + counter
    counter += 1

print("Sum of 1 until %d: %d" % (n,sum))
</pre>
<br>
</p>
<h3>Using a while Loop for Reading Standard Input</h3>

Before we go on with the while loop, we want to introduce some fundamental things
on standard input and standard output. Normally, the keyboard serves as the standard
input. The standard output is usually the terminal or console where the script
had been started, which prints the output. A script is supposed to send its error messages
to the standard error. 
<br>Python has these three channels as well:
<ul>
<li>standard input
<li>standard output
<li>standard error
</ul>
They are contained in the module sys. Their names are:
<ul>
<li>sys.stdin
<li>sys.stdout
<li>sys.stderror
</ul>.
</p>

<p>
The following script shows how to read with a while loop character by character from 
standard input (keyboard). 
<pre>
import sys 

text = ""
while 1:
   c = sys.stdin.read(1)
   text = text + c
   if c == '\n':
       break

print("Input: %s" % text)
</pre>
Though it's possible to read input like this, usually the function input()
is used. 
<pre>
>>> name = input("What's your name?\n")
What's your name?
Tux
>>> print(name)
Tux
>>> 
</pre>
  
</p>

<h3>The else Part</h3>
<p>
<img class="imgleft" src="images/while_loop_with_else.png" alt="While Loop with else part" />
Similar to the if statement, the while loop of Python has also an optional else part. 
This is an unfamiliar construct for many programmers of traditional programming languages.
<br>
The statements in the else part are executed, when the condition is not fulfilled anymore. 
Some might ask themselves now, where the possible benefit of this extra branch is. If the 
statements of the additional else part were placed right after the while loop without an else,
they would have been executed anyway, wouldn't they. We need to understand a new language 
construct, i.e. the break statement, to obtain a benefit from the additional else branch 
of the while loop.
<br>The general syntax of a while loop looks like this:<br><br>
<code>
while condition:<br>
	statement_1<br>
	...<br>
	statement_n<br>
else:<br>
	statement_1<br>
	...<br>
	statement_n<br>
</code>

</p>

<h3>Premature Termination of a while Loop</h3>
<p>
<img class="imgright" src="images/while_loop_with_else_break.png" 
alt="While Loop with else part and break" />
So far, a while loop only ends, if the condition in the loop head is fulfilled. 
With the help of a break statement a while loop can be left prematurely, i.e.
as soon as the control flow of the program comes to a break inside of a while loop 
(or other loops) the loop will be immediately left.
"break" shouldn't be confused with the continue statement. "continue" stops the
current iteration of the loop and starts the next iteration by checking the condition.
<br>Now comes the crucial point: If a loop is left by break, the else part is not executed.
<br><br>
This behaviour will be illustrated in the following example, a little guessing number game.
A human player has to guess a number between a range of 1 to n.
The player inputs his guess. The program informs the player, if this number is larger, 
smaller or equal to the secret number, i.e. the number which the program has randomly created.
If the player wants to gives up, he or she can input a 0 or a negative number.
<br>
Hint:
The program needs to create a random number. Therefore it's necessary to include the module
"random". 


<pre>
import random
n = 20
to_be_guessed = int(n * random.random()) + 1
guess = 0
while guess != to_be_guessed:
    guess = int(input("New number: "))
    if guess > 0:
        if guess > to_be_guessed:
            print("Number too large")
        else:
            print("Number too small")
    else:
        print("Sorry, that you're giving up!")
        break
else:
    print("Congratulation. You made it!")
</pre>
<br>

The output of a game session might look like this:
<pre>
$ python3 number_game.py 
New number: 12
Number too small
New number: 15
Number too small
New number: 18
Number too large
New number: 17
Number too small
Congratulation. You made it!
$ 
</pre>
</p>
<div id="contextlinks">Previous Chapter: <a href="python3_conditional_statements.php">Conditional Statements</a><br>
<LINK rel="prev" href="python3_conditional_statements.php">Next Chapter: <a href="python3_for_loop.php">For Loops</a><br>
<LINK rel="next" href="python3_for_loop.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
