<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Interactive Mode</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction to the interactive mode of Python and its interactive Shell" />
<meta name="Keywords" content="Python, interactive, interactive mode, interpreter, strings" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/python_head.jpg" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<hr>
<h3>First Steps</h3>
<i>"Take the first step, and your mind will mobilize all its forces to your aid. 
But the first essential is that you begin. Once the battle is startled, all that 
is within and without you will come to your assistance." (Robert Collier, the author 
of self help books)</i>
<br>
<br>He also wrote: <i>"The first essential, of course, is to know what you want."</i>
<br>We hope you know what you want, and that it means to learn, to understand and to
apply Python.
<br><br>
Aiming in the same direction is a famous quote by J.P. Morgan <i>"The first step 
towards getting somewhere is to decide that you are not going to stay where you are."</i>
<br><br>
<h3>Breaking the Shell</h3>
<i>"Your pain is the breaking of the shell that encloses your understanding."</i> (Kahlil 
Gibran, Lebanese poet and artist)
<br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_interaktiv.php">Der Interpreter</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="interactive.php">Interactive Mode in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="interactive.php">Interactive Mode in Python 2.x</a>
 </p>




    
</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_history_and_philosophy.php">The Origins of Python</a><br>
<LINK rel="prev" href="python3_history_and_philosophy.php">Next Chapter: <a href="python3_execute_script.php">Executing a Script</a><br>
<LINK rel="next" href="python3_execute_script.php"></div>
<h2>The Interpreter, an Interactive Shell</h2>

<h3>The Terms Interactive and Shell</h3>

<p>
<img class="imgright" src="images/shells.jpg" alt="Interaktive Shells sind wie Muschelgeh�use" />
The term interactive traces back to the Latin expression "inter agere". 
The verb "agere" means amongst other things "to do something" and "to act", while
"inter" denotes the spatial and temporal position to things and events, i.e. 
"Between" or "among" objects, persons, and events. 
So "inter agere" means "to act between" oder "to act among" these.
<br><br>
With this in mind, we can say that the interactive shell is between the user and the operating 
system (e.g. Linux, Unix, Windows or others). Instead of an operating system an interpreter can be used for a programming language like Python as well. The Python interpreter can be used from an interactive shell.
<br><br>
The interactive shell is also interactive in the way, that it stands between the commands or actions and their execution. 
This means the Shell waits for commands from the user, which it executes and returns the result of
the execution. After this the shell waits for the next input.
<br><br>
A shell in biology is a calcium carbonate "wall" which protects snails or mussels from its environment or its
enemies. Similarly, a shell in operating systems lies between the kernel of the operating system
and the user. It's a "protection" in both direction. The user doesn't have to use the complicated
basic functions of the OS but is capable of using simple and easier to understand shell commands.
The kernel is protected from unintended incorrect usages of system function. 
<br><br>
Python offers a comfortable command line interface with the Python shell, which is also known
as the "Python interactive shell".
<br>It looks like the term "interaktive Shell" is a tautology, because "Shell" is interactive on 
its own, at least the kind of shells we have described in the previous paragraphs.
<br><br>
<h3>Using the Python interactive Shell</h3>
With the Python interactive interpreter it is easy to check Python commands. 
The Python interpreter can be invoked by typing the command "python" without any 
parameter followed by the "return" key at the shell prompt:
<pre>
python
</pre>
</p>
<p>Python comes back with the following information:
<pre>
$ python
Python 2.6.5 (r265:79063, Apr 16 2010, 13:57:41) 
[GCC 4.4.3] on linux2
Type "help", "copyright", "credits" or "license" for more information.
>>>
</pre>
A closer look at the output above reveaks that we have the wrong Python Version. We want to use
Python 3.x, but Python 2.6.5 is the installed standard.
<br><br>
The easiest way to check if a Python 3.x version is installed: Open a Terminal. Type in python
but no return. Instead type the "Tab" key. You will see possible extensions and other installed
versions, if there are some:
<pre>
bernd@venus:~$ python
python                python2.6-config      python3               python3-config        python-dbg-config     
python2               python2.6-dbg         python3.1             python-config         
python2.6             python2.6-dbg-config  python3.1-config      python-dbg            
bernd@venus:~$ python
</pre>

If no other Python version shows up, python3.x has to be installed.
Afterwards, we can start the newly installed version by typing in the full name with the version: 
 <pre>
$ python3.1
Python 3.1.2 (r312:79147, Sep 27 2010, 09:57:50) 
[GCC 4.4.3] on linux2
Type "help", "copyright", "credits" or "license" for more information.
>>> 
</pre>
</p>
<p>
Once the Python interpreter is started, you can issue any command at the command 
prompt ">>>". 
<br>
Let's see, what happens, if we type in the word "hello":
<pre>
>>> hello
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
NameError: name 'hello' is not defined
>>> 
</pre>
Of course, "hello" is not a proper Python command, so the interactive shell returns ("raises") an error. 
<br>
<br>
The first real command we will use is the print command. We will create the mandatory "Hello World" statement:
<pre>
>>> print("Hello World")
Hello World
>>> 
</pre>

It couldn't have been easier, could it? Oh yes, it can be written in a even simpler way. In the interactive Python interpreter - but not in a program - the print is not necessary. We can just type in a string or a number and it will be "echoed"
<pre>
>>> "Hello World"
'Hello World'
>>> 3
3
>>> 
</pre>
<br>
<h3>How to Quit the Python Shell</h3> 
<p>
So, we have just started, and we already talk about quitting the shell. We do this, because we
know, how annoying it can be, if you don't know how to properly quit a program.
<br><br>
It's easy to end the interactive session: You can either use 
exit() or Ctrl-D (i.e. EOF) to exit. The brackets behind the exit function are crucial. 
(Warning: exit without brackets works in Python2.x but doesn't work anymore in Python3.x)
<br>
</p>
<br> 
<h3>The Shell as a Simple Calculator</h3>
 
 
In the following example we use the interpreter as a simple calculator by typing an
arithmetic expression:

<pre>
>>> 4.567 * 8.323 * 17
646.18939699999999
>>> 
</pre>

Python follows the usual order of operations in expressions. The standard order of operations 
is expressed in the following enumeration:
<ol>
	<li>exponents and roots</li>
	<li>multiplication and division</li>
	<li>addition and subtraction</li>
</ol>
This means, that we don't need paranthesis in the expression "3 + (2 * 4):
<pre>
>>> 3 + 2 * 4
11
>>> 
</pre>
The most recent output value is automatically stored by the interpreter in a special
variable with the name "_". So we can print the output from the recent example again by 
typing an underscore after the prompt:
<pre>
>>> _
11
>>> 
</pre>
The underscore can be used in other expressions like any other variable:
<pre>
>>> _ * 3
33
>>> 
</pre>
</p> 

<br>
The underscore variable is only available in the Python shell. It's NOT available 
in Python scripts or programs.
<br><br>
<h3>Using Variables</h3>
It's simple to use variables in the Python shell. If you are an absolute beginner
and if you don't know anything about variable, please confer our chapter 
about variables and data types.
<br>
Values can be saved in variables. Variable names don't require any special tagging,
like they do in Perl, where you have to use dollar signs, percentage signs and at signs
to tag variables: 
<pre>
>>> maximal = 124
>>> width = 94
>>> print(maximal - width)
30
>>> 
</pre>

</p> 
<br>
<h3>Multiline Statements</h3>
We haven't introduced multine statements so far. So beginners can skip the rest of this chapter 
and can continue with the following chapters.
<br><br>
We will show, how the interactive prompt deals with multiline statements like for loops. 

<pre>
>>> l = ["A",42,78,"Just a String"]
>>> for character in l:
...     print(character)
... 
A
42
78
Just a String
>>> 
</pre>
<br>
After having input "for character in l:" the interpretor expects the input of the next line
to be indented. In other words: The interpretor expects an indented block, which is the body
of the for loop. This indented block will be iterated. The interpretor shows this "expectation"
by showing three dots "..." instead of the standard Python interactive propmt ">>>".
Another special feauture of the interactive shell: When we have finished with the indented
lines, i.e. the block, we have to enter an empty line to indicate, that the block is finished.

<br>
<b>Attention:</b> The additional empty line is only necessary in the interactive shell!
In a Python program, it' enough to return to the indentation level of the for line, the one with
the colon ":" at the end.

<br><br>

<h3>Strings</h3>
      <p class="update">
Strings are created by putting a sequence of characters in quotes. Strings can be surrounded by single quotes, double quotes or tripple quotes, which are made up of three single or three double quotes. 

Strings are immutable. This means that once defined, they cannot be changed. We will cover this topic in detail in another chapter.

<pre>
  >>> "Hello" + " " + "World"
'Hello World'
  </pre>

<br>
String in tripple quotes can span several lines without using the escape character:

<pre>
>>> city = """
... Toronto is the largest city in Canada 
... and the provincial capital of Ontario. 
... It is located in Southern Ontario on the 
... northwestern shore of Lake Ontario.
... """
>>> print(city)

Toronto is the largest city in Canada 
and the provincial capital of Ontario. 
It is located in Southern Ontario on the 
northwestern shore of Lake Ontario.

>>> 
</pre>


There is a multiplication on strings defined, which is essentially a multiple concatenation:
<pre>
  >>> ".-." * 4
'.-..-..-..-.'
>>>
  </pre>

</p>



</div>


<div id="contextlinks">Previous Chapter: <a href="python3_history_and_philosophy.php">The Origins of Python</a><br>
<LINK rel="prev" href="python3_history_and_philosophy.php">Next Chapter: <a href="python3_execute_script.php">Executing a Script</a><br>
<LINK rel="next" href="python3_execute_script.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
