<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: A Tutorial</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial on how to create a dynamic website with Python and WSGI" />
<meta name="Keywords" content="Python, dynamic, website, WSGI, Python, tutorial" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li class="active"><a id="current" href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/filmstrip1.jpg" alt="box" />    <h2>Advanced Topics</h2>

<div class="menu">

<ul>
<li><a href="sys_module.php">Introduction into the sys module</a></li><li><a href="os_module_shell.php">Python and the Shell</a></li><li><a href="forking.php">Forks and Forking in Python</a></li><li><a href="threads.php">Introduction into Threads</a></li><li><a href="pipes.php">Pipe, Pipes and "99 Bottles of Beer"</a></li><li><a href="graphs_python.php">Graph Theory and Graphs in Python"</a></li><li><a href="pygraph.php">Graphs: PyGraph"</a></li><li><a href="networkx.php">Graphs: NetworkX"</a></li><li><a href="finite_state_machine.php">Finite State Machine in Python</a></li><li><a href="turing_machine.php">Turing Machine in Python</a></li><li><a href="numpy.php">NumPy Module</a></li><li><a href="matrix_arithmetic.php">Matrix Arithmetic</a></li><li><a href="linear_combinations.php">Linear Combinations</a></li><li><a href="text_classification_introduction.php">Introduction into Text Classification using Naive Bayes</a></li><li><a href="text_classification_python.php">Python Implementation of Text Classification</a></li><li><a href="towers_of_hanoi.php">Example for recursive Programming: Towers of Hanoi</a></li><li><a href="mastermind.php">Mastermind / Bulls and Cows</a></li><li><a href="dynamic_websites_wsgi.php">Creating dynamic websites with WSGI</a></li><li><a href="dynamic_websites.php">Dynamic websites with mod_python</a></li><li><a href="pylons.php">Dynamic websites with Pylons</a></li><li><a href="sql_python.php">Python, SQL, MySQL and SQLite</a></li><li><a href="python_scores.php">Python Scores</a></li></ul>

</div>

<p>
<br>
<hr>
<br>
<h3>Dynamic Websites</h3>
Not about the web neither on the dynamic websites, but it fits anyway:
<br><br>
<i>"Sometimes one creates a dynamic impression by saying something, and sometimes one creates as significant 
an impression by remaining silent."</i>
<br>
(Dalai Lama)
<br><br><br>
<img src="images/filmstrip.jpg" alt="A strip of film from the animated film Katsudō Shashin (1907)" />
<br><br>
<hr>
Supported by:<br>
<a href="http://www.bodenseo.com"><img style="width: 150px;" alt="Bodenseo, seminars and training courses"
		     src="images/bodenseo_python_training.gif"><br>Python seminars and trainings courses all over the world</a>
		     <br><br>		     
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
<h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>"A programming language is for thinking about programs, not for expressing programs 
you've already thought of. It should be a pencil, not a pen. "</i> (Paul Graham)<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="mastermind.php">Mastermind / Bulls and Cows</a><br>
<LINK rel="prev" href="mastermind.php">Next Chapter: <a href="dynamic_websites.php">Dynamic websites with mod_python</a><br>
<LINK rel="next" href="dynamic_websites.php"></div>
<br>
<h2>Creating dynamic websites with Python and WSGI</h2>
<br><br>
<h3>Introduction</h3>

<img class="imgright" width="500" src="images/filmstrip3.jpg" alt="A strip of film from the animated film Katsudō Shashin (1907), modified by Bernd Klein" />  

<span style="color:red;background-color:light-grey;">
Please notice:
<br>Work on this topic is under process. (August 2014)
</span>
<br><br>

WSGI is the Web Server Gateway Interface. It is a specification that describes how web servers
communicate with web applications. It is a framework for the Python. It was originally specified in 2003.
WSGI has become a standard for Python web application development. WSGI has been specified in 
<a href="http://legacy.python.org/dev/peps/pep-3333/">PEP 3333</a>. The abstract says "This document 
specifies a proposed standard interface between web servers and Python web applications or frameworks, 
to promote web application portability across a variety of web servers."
<br>
<br>
<h3>Simple Example with WSGI</h3>

We demonstrate the way of working with a simple example, actually as simple as simple can be.
All it does will be to greet a visitor of the website with "Hello my friend!", we just had enough of "Hello World".

<pre>
from wsgiref.simple_server import make_server

def application(environ, start_response):
    start_response("200 OK", [("Content-type", "text/plain")])
    return ["Hello my friend!".encode("utf-8")]


server = make_server('localhost', 8080, application)
server.serve_forever()
</pre>

You can save this program wherever you want on your computer. If you start it with "python3 greeting.py",
you can visit the URL "localhost:8080" with a browser of your choice. You should see now: "Hello my friend!"
This text will appear within your browser. On the terminal, you will the an output, 
which looks similar to this:
<br><br>
<pre>
$ python3 hello_wsgi.py 
127.0.0.1 - - [19/Aug/2014 10:31:39] "GET / HTTP/1.1" 200 16
</pre>

You may have noticed that we used Python 3 to start the server. The program runs with Python 2 as well.
There are lots of similar examples out there on the web which don't work for Python 3. The reason is in many cases,
that they don't return a bytes string, but a "simple" str class instance. So, if you drop the method call 
'.encode("utf-8")', the program will only run with Pyhton2 but not with Python3 anymore.
<br><br>
We used the simple reference implementation wsgiref of WSGI, which is included in Python's standard library.
It's easier to for testing purposes. The make_server method takes five parameters:
<br><br>
<ul>
<li>host: the host name can be 'localhost' or any other host name, like your server name 
"server = make_server('saturn', 8080, application)" or a domain or IP address, e.g. 
server = make_server('192.168.170.128', 8080, application), which makes it possible to access
this web server from another computer in the network.
</li>
<li>
port: We use 8080 as the port number
</li>
<li>
app: This has to be a reference to a function, which is returning a list with the results. Every element of this
list has to be a bytes string.
</li>
<li>We will not discuss the optional keyword parameters  
"server_class=<class 'wsgiref.simple_server.WSGIServer'>, handler_class"</li>
</ul>

The function "app" - used as the third parameter of make_server - needs two parameters:

<ul>
<li>environ</li>
<li>start_response: start_response has to be a callable with three parameters:
status, response_headers, exc_info=None
<br>
status contains the numeric HTTP status code of the response, e.g. "200 OK", "404 NOT FOUND", or
"500 SERVER ERROR". response_headers contains the HTTP message for the status code used. exc_info used for 
traceback information is optional.
</li>
</ul>
<br><br>

<h3>Another example</h3>
The following program  nothing new. It's just the previous example, which has to be extended so that the
function application returns the first 30 lines of text from the novel Ulysses by James Joyce:
<br><br>
<pre>
from wsgiref.simple_server import make_server

def application(environ, start_response):
    start_response("200 OK", [("Content-type", "text/plain")])

    fh = open("ulysses.txt")
    lines = [fh.readline().encode("utf-8") for i in range(30)]

    return lines


server = make_server('saturn', 8080, application)
server.serve_forever()
</pre>
<br>
The browser output looks like this:
<br><br>
<img src="images/ulysses_start.png" alt="Beginning of the novel ulysses by web browser wsgi" />

<div id="contextlinks">Previous Chapter: <a href="mastermind.php">Mastermind / Bulls and Cows</a><br>
<LINK rel="prev" href="mastermind.php">Next Chapter: <a href="dynamic_websites.php">Dynamic websites with mod_python</a><br>
<LINK rel="next" href="dynamic_websites.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
