<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Passing Arguments</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="The passing of parameters and arguments in Python. Explaining the difference between call by object sharing, call by value and call by name." />
<meta name="Keywords" content="Python, Python3, Parameter, Parameters, Arguments, passing, references, call, value, reference" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/relay-race_small.jpg" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<hr>
<h3>Other Arguments</h3>
In this chapter of our tutorial, we are talking about all kinds of Python arguments: fixed and variable in number. We can be sure, that Wilde was talking about the "real" kind of arguments, when he wrote: 
<br>
<i> 
"Arguments are to be avoided; they are always vulgar and often convincing."
</i>
<br><br>
The writer Hubbard was also talking about the attempt to persuade someone of something, by giving reasons or evidence for accepting a particular conclusion:
<br>
<i>"If you can't answer a man's arguments, all is not lost; you can still call him vile names."</i>
<br>
(Elbert Hubbard, writer, 1856 - 1915)
<br>
<i>"Discussion is an exchange of knowledge; an argument an exchange of ignorance."</i>
<br>
(Robert Quillen, American humorist and journalist, 1887 - 1948)
<br><br>
<hr>
<br>
Let's get back to Oscar Wilde, who lived before the age of computers, so he had no Python arguments in mind, when he said:
<br>
<i>"I dislike arguments of any kind. They are always vulgar, and often convincing."</i>
<br><br>
<hr>
<br><br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br><br>
<h3>Function</h3>
<i>"Success is more a function of consistent common sense than it is of genius"</i>
<br>(An Wang, Computer engineer and inventor, 1920 - 1990)
<br><br>
<hr>
<br><br>
The American author Dean Ray Koontz has something to say about the functions of intellect:
<br>
<i>
"Some people think only intellect counts: knowing how to solve problems, knowing how to get by, knowing how to identify an advantage and seize it. But the functions of intellect are insufficient without courage, love, friendship, compassion and empathy."
</i>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_parameter.php">Parameter�bergabe</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="passing_arguments.php">Passing Arguments in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="passing_arguments.php">Passing Arguments in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_memoization.php">Memoization and Decorators</a><br>
<LINK rel="prev" href="python3_memoization.php">Next Chapter: <a href="python3_namespaces.php">Namespaces</a><br>
<LINK rel="next" href="python3_namespaces.php"></div>
<h2>Parameters and Arguments</h2>
A function or procedure usually needs some information about the environment, in which it has
been called. The interface between the environment, from which the function has been called, 
and the function, i.e. the function body, consists of special variables, which are called 
parameters. By using these parameters, it's possible to use all kind of objects from "outside" 
inside of a function. The syntax for how parameters  are declared and the semantics for 
how the arguments are passed to the parameters of the function or procedure are depending
on the programming language.
<br><br>
Very often the terms parameter and argument are used synonymously, but there is a clear 
difference. Parameters are inside functions or procedures, while arguments are used in 
procedure calls, i.e. the values passed to the function at run-time. 

<br><br>
<h3>"call by value" and "call by name"</h3>
<p>
<img class="imgright" src="images/relay-race.jpg" alt="Parameter�bergabe als Staffellauf" />
The evaluation strategy for arguments, i.e. how the arguments from a function call are
passed to the parameters of the function, differs from programming language to programming
language. The most common evaluation strategies are "call by value" and "call by reference":
<ul>
    <li><b>Call by Value</b>
    <br>
The most common strategy is the call-by-value evaluation, sometimes also called pass-by-value. 
This strategy is used in C and C++ for example.  In call-by-value, the argument expression 
is evaluated, and the result of this evaluation is bound to the corresponding variable in 
the function. So, if the expression is a variable, its value will be assigned (copied) to the
corresponding parameter. This ensures, that the variable in the caller's scope will be 
unchanged when the function returns.
<br><br>
    <li><b>Call by Reference</b><br>
In call-by-reference evaluation, which is also known as pass-by-reference, a function gets 
an implicit reference  to the argument, rather than a copy of its value. As a consequence, 
the function can modify the argument, i.e. the value of the variable in the caller's scope 
can be changed. BY using Call by Reference we save both computation time and memory space, 
because arguments do not need to be copied.
On the other hand this harbours the disadvantage that variables can be "accidentally" 
changed in a function call. So special care has to be taken to "protect" the values, 
which shouldn't be changed.
<br>Many programming language support call-by-reference, like C or C++, but Perl uses 
it as default.
</ul>
In ALGOL 60 and COBOL has been known a different concept, which was called call-by-name, 
which isn't used anymore in modern languages. 
</p>
<br><br>
<h3>and what about Python?</h3>
<img class="imgleft" src="images/HumptyDumpty.jpg" alt="Humpty Dumpty" />
There are books which call the strategy of Python call-by-value and others call it 
call-by-reference. You may ask yourself, what is right.
<br><br>
Humpty Dumpty supplies the explanation:
<br><br>
<i>
--- "When I use a word," Humpty Dumpty said, in a rather a scornful tone, "it means just what I choose it to mean - neither more nor less."<br>
<br>
--- "The question is," said Alice, "whether you can make words mean so many different things."
<br>
<br>
--- "The question is," said Humpty Dumpty, "which is to be master - that's all."
<br><br>
</i>Lewis Carroll, Through the Looking-Glass<br>
<br><br>
To come back to our initial question what evaluation strategy is used in Python: 
The authors who call the mechanism call-by-value and those who call it call-by-reference 
are stretching the definitions until they fit.
<br><br>Correctly speaking, Python uses a mechanism, which is known as "Call-by-Object", 
sometimes also called  "Call by Object Reference" or "Call by Sharing".<br>
<br><img class="imgright" src="images/parameter_uebergabe1.png" alt="Paramter�bergabe" />
If you pass immutable arguments like integers, strings or tuples to a function, the passing 
acts like call-by-value. The object reference is passed to the function parameters. They can't be 
changed within the function, because they can't be changed at all, 
i.e. they are immutable. 
It's different, if we pass mutable arguments. They are also passed by object reference, but they can be changed
in place in the function. If we pass a list to a function, we have to consider two cases: Elements of a list can be
changed in place, i.e. the list will be changed even in the caller's scope. If a new list is assigned to the name, 
the old list will not be affected, i.e. the list in the caller's scope will remain untouched.
<br><br>
First, let's have a look at the integer variables. The parameter inside of the function remains a reference to the
arguments variable, as long as the parameter is not changed. As soon as a new value will be assigned to it, Python
creates a separate local variable. The caller's variable will not be changed this way:
<br><br>
<pre>
def ref_demo(x):
    print("x=",x," id=",id(x))
    x=42
    print("x=",x," id=",id(x))
</pre>
<img class="imgright" src="images/parameter_uebergabe2.png" alt="Paramter�bergabe" />
<br>
In the example above, we used the id() function, which takes an object as a parameter. 
id(obj) returns the "identity" of the object "obj". This identity, the return value of
the function, is an integer which is unique and constant for this object during its lifetime.
Two different objects with non-overlapping lifetimes may have the same id() value.
<br><br>
If you call the function ref_demo() of the previous exampe - like we do in the green 
block further down - we can check with the id() function what happens to x:
We can see that in the main scope, x has the identity 41902552. In the first print statement
of the ref_demo() function, the x from the main scope is used, because we can see that we
get the same identity. After we have assigned the value 42 to x, x gets a new identity 41903752, i.e. 
a separate memory location from the global x. So, when we are back in the main scope x has still
the original value 9.
<br><br>
This means, that Python initially behaves like call-by-reference, but as soon as we are changing the
value of such a variable, i.e. as soon as we assign a new object to it, Python "switches" to
 call-by-value. This means, that a local variable x will be created and the value of the global
 variable x will be copied into it.
<br>
<pre>
>>> x = 9
>>> id(x)
9251936
>>> ref_demo(x)
x= 9  id= 9251936
x= 42  id= 9252992
>>> id(x)
9251936
>>> 
</pre>
<h3>Side effects</h3>
A function is said to have a side effect, if, in addition to producing a return value, 
it modifies the caller's environment in other ways. 
For example, a function might modify a global or static variable, modify one of its arguments, 
raise an exception, write data to a display or file and so on. 
<br><br>
There are situations, in which these side effects are intended, i.e. they are part of the 
functions specification. But in other cases, they are not wanted , they are hidden side effects. 
In this chapter we are only interested in the side effects, which change one or more global variables,
which have been passed as arguments to a function.
<br>
Let's assume, we are passing a list to a function. We expect, that the 
function is not changing this list. First let's have a look at a function
which has no side effects. As a new list is assigned to the parameter list in func1(), 
a new memory location is created for list and list becomes a local variable.
<pre>
>>> def no_side_effects(cities):
...     print(cities)
...     cities = cities + ["Birmingham", "Bradford"]
...     print(cities)
... 
>>> locations = ["London", "Leeds", "Glasgow", "Sheffield"]
>>> no_side_effects(locations)
['London', 'Leeds', 'Glasgow', 'Sheffield']
['London', 'Leeds', 'Glasgow', 'Sheffield', 'Birmingham', 'Bradford']
>>> print(locations)
['London', 'Leeds', 'Glasgow', 'Sheffield']
>>> 
</pre>
This changes drastically, if we increment the list by using augmented assignment operator +=.
To show this, we change the previous function rename it to "side_effects" in the following example:

<pre>
>>> def side_effects(cities):
...     print(cities)
...     cities += ["Birmingham", "Bradford"]
...     print(cities)
... 
>>> locations = ["London", "Leeds", "Glasgow", "Sheffield"]
>>> side_effects(locations)
['London', 'Leeds', 'Glasgow', 'Sheffield']
['London', 'Leeds', 'Glasgow', 'Sheffield', 'Birmingham', 'Bradford']
>>> print(locations)
['London', 'Leeds', 'Glasgow', 'Sheffield', 'Birmingham', 'Bradford']
>>> 
</pre>

We can see, that Birmingham and Bradford are included in the global list locations as well, because
+= acts as an in-place operation. 
<br><br>
The user of this function can prevent this side effect by passing a copy to the function. 
A shallow copy is sufficient, because there are no nested structures in the list. To satisfy our French 
customers as well, we change the city names in the next example to demonstrate the effect of 
the slice operator in the function call:

<pre>
>>> def side_effects(cities):
...     print(cities)
...     cities += ["Paris", "Marseille"]
...     print(cities)
... 
>>> locations = ["Lyon", "Toulouse", "Nice", "Nantes", "Strasbourg"]
>>> side_effects(locations[:])
['Lyon', 'Toulouse', 'Nice', 'Nantes', 'Strasbourg']
['Lyon', 'Toulouse', 'Nice', 'Nantes', 'Strasbourg', 'Paris', 'Marseille']
>>> print(locations)
['Lyon', 'Toulouse', 'Nice', 'Nantes', 'Strasbourg']
>>> 
</pre>

We can see, that the global list locations has not been effected by the execution of the function.

<h3>Command Line Arguments</h3>
If you use a command line interface, i.e. a text user interface (TUI) , and not 
a graphical user interface (GUI), command line arguments are very useful. They are 
arguments which are added after the function call in the same line.
<br><br>
It's easy to write Python scripts using command line arguments. If you call
a Python script from a shell, the arguments are placed after the script name. 
The arguments are separated by spaces. Inside of the script these argumetns are 
accessible through the list variable sys.argv. The name of the script is included
in this list sys.argv[0]. sys.argv[1] contains the first parameter, sys.argv[2] the
second and so on. 
<br>
The following script (arguments.py) prints all arguments:
<br>
<pre>
 # Module sys has to be imported:
import sys                

# Iteration over all arguments:
for eachArg in sys.argv:   
        print(eachArg)
</pre>
Example call to this script:
<pre>
python argumente.py python course for beginners
</pre>
This call creates the following output:
<pre>
argumente.py
python
course
for
beginners
</pre>
<br>
<h3>Variable Length of Parameters</h3>
We will introduce now functions, which can take an arbitrary number of arguments.
Those who have some programming background in C or C++ know this from the varargs feature 
of these languages. 
<br><br>
Some definitions, which are not really necessary for the following:
A function with an arbitrary number of arguments is usually
called a variadic function in computer science. To use another special term: A variadic function
is a function of indefinite arity. The arity of a function or an operation is the number of 
arguments or operands that the function or operation takes. The term war derived from 
words like "unary", "binary", "ternary", all ending in "ary".
<br><br>
The asterisk "*" is used in Python to define a variable number
of arguments. The asterisk character has to precede a variable identifier in the 
parameter list. 

<pre>
>>> def varpafu(*x): print(x)
... 
>>> varpafu()
()
>>> varpafu(34,"Do you like Python?", "Of course")
(34, 'Do you like Python?', 'Of course')
>>> 
</pre>

We learn from the previous example, that the arguments passed to the function call of 
varpafu() are collected in a tuple, which can be accessed as a "normal" variable x
within the body of the function. If the function is called without any arguments, the
value of x is an empty tuple.
<br><br>
Sometimes, it's necessary to use positional parameters followed by an arbitrary number of
parameters in a function definition. This is possible, but the positional parameters always
have to precede the arbitrary parameters. In the following example, we have a positional
parameter "city", - the main location, - which always have to be given, followed by an arbitrary
number of other locations:
<br>

<pre>
>>> def locations(city, *other_cities): print(city, other_cities)
... 
>>> locations("Paris")
Paris ()
>>> locations("Paris", "Strasbourg", "Lyon", "Dijon", "Bordeaux", "Marseille")
Paris ('Strasbourg', 'Lyon', 'Dijon', 'Bordeaux', 'Marseille')
>>> 
</pre>

<h4>Exercise</h4>
Write a function which calculates the arithmetic mean of a variable number of values.

<h4>Solution</h4>

<pre>
def arithmetic_mean(x, *l):
    """ The function calculates the arithmetic mean of a non-empty
        arbitrary number of numbers """
    sum = x
    for i in l:
        sum += i

    return sum / (1.0 + len(l))
</pre>

You might ask yourself, why we used both a positional parameter "x" and the variable 
parameter "*l" in our function definition. We could have only used *l to contain all
our numbers. The idea is, that we wanted to enforce, that we always have a non-empty list
of numbers. This is necessary to prevent a division by zero error, because the average
of a non-empty list of numbers is not defined. 
<br><br>
In the following interactive Python session, we can learn how to use this function.
We assume that the function arithmetic_mean is saved in a file called statistics.py.

<pre>
>>> from statistics import arithmetic_mean
>>> arithmetic_mean(4,7,9)
6.666666666666667
>>> arithmetic_mean(4,7,9,45,-3.7,99)
26.71666666666667
</pre>

This works fine, but there is a catch. What if somebody wants to call the function
with a list, instead of a variable number of numbers, as we have shown above? We can
see in the following, that we raise an error, as most hopefully, you might expect:

<pre>
>>> l = [4,7,9,45,-3.7,99]
>>> arithmetic_mean(l)
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
  File "statistics.py", line 8, in arithmetic_mean
    return sum / (1.0 + len(l))
TypeError: unsupported operand type(s) for /: 'list' and 'float'
</pre>

The rescue is using another asterisk:

<pre>
>>> arithmetic_mean(*l)
26.71666666666667
>>> 
</pre>
<br><br>
<h3>* in Function Calls</h3>
A * can appear in function calls as well, as we have just seen in the previous exercise:
The semantics is in this case "inverse" to a star in a function definition. An argument 
will be unpacked and not packed. In other words, the elements of the list or tuple are
singularized: 

<pre>
>>> def f(x,y,z):
...     print(x,y,z)
... 
>>> p = (47,11,12)
>>> f(*p)
(47, 11, 12)
</pre>

There is hardly any need to mention that this way of calling our function
is more comfortable the the following one:

<pre>
>>> f(p[0],p[1],p[2])
(47, 11, 12)
>>> 
</pre>

Additionally to being less comfortable, the previous call (f(p[0],p[1],p[2])) 
doesn't work in the general case, i.e. lists of unknown lengths. "Unknown" mean,
that the length is only known at runtime and not when we are writing the script.
<br><br>
<h3>Arbitrary Keyword Parameters</h3>
There is also a mechanism for an arbitrary number of keyword parameters.
To do this, we use the double asterisk "**" notation:

<pre>
>>> def f(**args):
...     print(args)
... 
>>> f()
{}
>>> f(de="Germnan",en="English",fr="French")
{'fr': 'French', 'de': 'Germnan', 'en': 'English'}
>>> 
</pre>

<h3>Double Asterisk in Function Calls</h3>
The following example demonstrates the usage of  ** in a
function call:

<pre>
>>> def f(a,b,x,y):
...     print(a,b,x,y)
...
>>> d = {'a':'append', 'b':'block','x':'extract','y':'yes'}
>>> f(**d)
('append', 'block', 'extract', 'yes')
</pre>
and now in combination with *: 
<pre>
>>> t = (47,11)
>>> d = {'x':'extract','y':'yes'}
>>> f(*t, **d)
(47, 11, 'extract', 'yes')
>>> 
</pre>


<div id="contextlinks">Previous Chapter: <a href="python3_memoization.php">Memoization and Decorators</a><br>
<LINK rel="prev" href="python3_memoization.php">Next Chapter: <a href="python3_namespaces.php">Namespaces</a><br>
<LINK rel="next" href="python3_namespaces.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
