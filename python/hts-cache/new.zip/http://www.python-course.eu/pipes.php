<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Advanced: Pipes in Python</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Communication with Pipes in Python or how to sing 99 bottles of beer in Python" />
<meta name="Keywords" content="Python, course, pipe, pipes, beer, bottles, fork" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li class="active"><a id="current" href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/pipes.jpg" alt="box" />    <h2>Advanced Topics</h2>

<div class="menu">

<ul>
<li><a href="sys_module.php">Introduction into the sys module</a></li><li><a href="os_module_shell.php">Python and the Shell</a></li><li><a href="forking.php">Forks and Forking in Python</a></li><li><a href="threads.php">Introduction into Threads</a></li><li><a href="pipes.php">Pipe, Pipes and "99 Bottles of Beer"</a></li><li><a href="graphs_python.php">Graph Theory and Graphs in Python"</a></li><li><a href="pygraph.php">Graphs: PyGraph"</a></li><li><a href="networkx.php">Graphs: NetworkX"</a></li><li><a href="finite_state_machine.php">Finite State Machine in Python</a></li><li><a href="turing_machine.php">Turing Machine in Python</a></li><li><a href="numpy.php">NumPy Module</a></li><li><a href="matrix_arithmetic.php">Matrix Arithmetic</a></li><li><a href="linear_combinations.php">Linear Combinations</a></li><li><a href="text_classification_introduction.php">Introduction into Text Classification using Naive Bayes</a></li><li><a href="text_classification_python.php">Python Implementation of Text Classification</a></li><li><a href="towers_of_hanoi.php">Example for recursive Programming: Towers of Hanoi</a></li><li><a href="mastermind.php">Mastermind / Bulls and Cows</a></li><li><a href="dynamic_websites_wsgi.php">Creating dynamic websites with WSGI</a></li><li><a href="dynamic_websites.php">Dynamic websites with mod_python</a></li><li><a href="pylons.php">Dynamic websites with Pylons</a></li><li><a href="sql_python.php">Python, SQL, MySQL and SQLite</a></li><li><a href="python_scores.php">Python Scores</a></li></ul>

</div>

<p>
<h3>More Pipes</h3>
A pipe is a hollow cylinder or tube, usually but not necessarily of circular 
cross-section. Pipes are used to conduct liquids, gas, or other substances which 
can flow.
<hr>
Smoke can "flow" as well, so we have a device for smokers as well, which is called
pipe: It consists of a tube of wood or other material with a small bowl at one of 
its ends.
<br>
<br>
<img src="images/organ_pipes_small.jpg" width="150"  border="0" alt="organ pipes">
And then there are all these pipes in music: tubular wind instruments, e.g. flutes or the 
tubes of an organ. 
And in Scottland you will find very special pipes, i.e. the bagpipe.

<br>
<br>
<hr>
<br>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Python and Linux courses"
		     src="images/bodenseo_python_training.gif"><br>Linux and Python Courses and Seminars</a>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/pipes.php">Pipes in Python</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein with 
material from his live <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training course, you may have a look at the 
<a href="http://ca.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<br>
<font size="1">� kabliczech - Fotolia.com</font>


<br><br>
<h3>Python Tricks</h3>
<i>
"Python tricks" is a tough one, cuz the language is so clean. E.g., C makes an art of confusing 
pointers with arrays and strings, which leads to lotsa neat pointer tricks; APL mistakes 
everything for an array, leading to neat one-liners; and Perl confuses everything period, 
making each line a joyous adventure <wink>.
</i>
(Tim Peters, Pythoneer who formulated the "Zen of Python")
<h3>Python compared to Lisp</h3>
Greenspun's "Tenth Rule of Programming" states:
<br>
<i>
Any sufficiently complicated C or Fortran program contains an ad hoc, informally-specified, 
bug-ridden, slow implementation of half of Common Lisp.
</i>
Sounds complicated? Lisp is complicated. Guido van Rossum compared it - or to be precise 
Common Lisp and Scheme - to Python with the following words:
<i>
"These languages are close to Python in their dynamic semantics, but so different in their approach 
to syntax that a comparison becomes almost a religious argument: is Lisp's lack of syntax an 
advantage or a disadvantage? It should be noted that Python has introspective capabilities 
similar to those of Lisp, and Python programs can construct and execute program fragments on 
the fly. Usually, real-world properties are decisive: Common Lisp is big (in every sense), 
and the Scheme world is fragmented between many incompatible versions, where Python has a 
single, free, compact implementation."
</i>
<br>(excerpt from "Comparing Python to Other Languages" by Guido van Rossum)

<h3>Wizards and Magic</h3>
<i>
"Things in Python are very clear, but are harder to find than the secrets of wizards. 
Things in Perl are easy to find, but look like arcane spells to invoke magic."
</i>

 </p>

</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="threads.php">Introduction into Threads</a><br>
<LINK rel="prev" href="threads.php">Next Chapter: <a href="graphs_python.php">Graph Theory and Graphs in Python"</a><br>
<LINK rel="next" href="graphs_python.php"></div>
<h2>Pipes in Python</h2>
<h3>Pipe</h3>
<p>
<img class="imgright" src="images/tunnels_pipes_300.jpg" alt="Tunnel and Pipe" />
Unix or Linux without pipes is unthinkable, or at least, pipelines are a very important part of 
Unix and Linux applications. Small elements
are put together by using pipes. Processes are chained together by their standard streams, i.e. the 
output of one process is used as the input of another process. To chain processes like this, so-called 
anonomymous pipes are used.
<br>The concept of pipes and pipelines was introduced by Douglas McIlroy, 
one of the authors of the early command shells, after he noticed that much of the time they 
were processing the output of one program as the input to another. 
Ken Thompson added the concept of pipes to the UNIX operating system in 1973. Pipelines have later been 
ported to other operating systems like DOS, OS/2 and Microsoft Windows as well.
<br><br>
Generally there are two kinds of pipes:
<ul>
<li>anonymous pipes<br>and</li>
<li>named pipes</li>
</ul>
Anonymous pipes exist solely within Prozesses and are usually used in combination with forks.
<h3>Beer Pipe in Python</h3>
<img class="imgright" src="images/bottles_99.jpg" alt="99 Bottles of Beer" />
"99 Bottles of Beer" is a traditional song in the United States and Canada. The song is derived 
from the English "Ten Green Bottles". The song consists of 100 verses, which are very similiar. Just 
the number of bottles varies. Only one, i.e. the hundredth verse is slighly different. This song 
is often sung on long trips, because it is easy to memorize, especially when drunken, and it can 
take a long time to sing. 
<br><br>
Here are the lyrics of this song:
<br><br>
<i>
    Ninety-nine bottles of beer on the wall, 
    Ninety-nine bottles of beer.
    Take one down, pass it around, 
    Ninety-eight bottles of beer on the wall.
</i>
<br><br>
The next verse is the same starting with 98 bottles of beer. So the general rule is, 
each verse one bottle less, until there in none left. The song normally ends here.
But we want to implement the Aleph-Null (i.e. the infinite) version of this song with an
additional verse: 
<br><br>
<i>
	No more bottles of beer on the wall,
	no more bottles of beer.
	Go to the store and buy some more,
	Ninety-nine bottles of beer on the wall.
</i>
<br><br>
This song has been implemented in all conceivable computer languages like "Whitespace" or "Brainfuck". 
You find the collection at <a href="http://99-bottles-of-beer.net">http://99-bottles-of-beer.net</a>
<br>
We program the Aleph-Null variant of the song with a fork and a pipe:
<br>
<pre>
import os

def child(pipeout):
  bottles = 99
  while True:
    bob = "bottles of beer"
    otw = "on the wall"
    take1 = "Take one down and pass it around"
    store = "Go to the store and buy some more"

    if bottles > 0:
      values =  (bottles, bob, otw, bottles, bob, take1, bottles - 1,bob,otw)
      verse = "%2d %s %s,\n%2d %s.\n%s,\n%2d %s %s." % values
      os.write(pipeout, verse)
      bottles -= 1
    else:
      bottles = 99
      values =  (bob, otw, bob, store, bottles, bob,otw)
      verse = "No more %s %s,\nno more %s.\n%s,\n%2d %s %s." % values
      os.write(pipeout, verse)
      
def parent():
    pipein, pipeout = os.pipe()
    if os.fork() == 0:
        child(pipeout)
    else:
        counter = 1
        while True:
            if counter % 100:
                verse = os.read(pipein, 117)
            else:
                verse = os.read(pipein, 128)
            print 'verse %d\n%s\n' % (counter, verse)
            counter += 1

parent()
</pre>
The problem in the code above is, that we or better the parent process have to know exactly 
how many bytes the child will send each time. For the first 99 verses it will be 117 Bytes 
(<code>verse = os.read(pipein, 117)</code>) and for the Aleph-Null verse it will be 128 bytes 
(<code>verse = os.read(pipein, 128)</code>
<br><br>
We fixed this in the following impelementation, in which we read complete lines:
<pre>
import os

def child(pipeout):
  bottles = 99
  while True:
    bob = "bottles of beer"
    otw = "on the wall"
    take1 = "Take one down and pass it around"
    store = "Go to the store and buy some more"

    if bottles > 0:
      values =  (bottles, bob, otw, bottles, bob, take1, bottles - 1,bob,otw)
      verse = "%2d %s %s,\n%2d %s.\n%s,\n%2d %s %s.\n" % values
      os.write(pipeout, verse)
      bottles -= 1
    else:
      bottles = 99
      values =  (bob, otw, bob, store, bottles, bob,otw)
      verse = "No more %s %s,\nno more %s.\n%s,\n%2d %s %s.\n" % values
      os.write(pipeout, verse)
def parent():
    pipein, pipeout = os.pipe()
    if os.fork() == 0:
        os.close(pipein)
        child(pipeout)
    else:
        os.close(pipeout)
        counter = 1
        pipein = os.fdopen(pipein)
        while True:
            print 'verse %d' % (counter)
            for i in range(4):
                verse = pipein.readline()[:-1]
                print '%s' % (verse)
            counter += 1
            print

parent()
</pre>

<h3>Bidirectional Pipes</h3>
Now we come to something completely non-alcoholic. It's a simple guessing game, which small children
often play. We want to implement this game with bidirectional Pipes. 
There is an explanation of this game in our tutorial in the chapter about  
<a href="loops.php">loops</a>. The following diagram explains both the rules of the game and the way 
we implemented it:
<br>
<br>
<img class="img" src="images/game_bidirectional_pipes.png" alt="Guessing game as Pipe" />
<br>
<br>
The Devisor has to guess a number between a range of 1 to n. The Guesser inputs his guess. 
The Devisor informs the player, if this number is larger, smaller or equal to the secret number, 
i.e. the number which the Devisor has randomly created. 
Both the Devisor and the Guesser write their results into log files, i.e. deviser.log and 
guesser.log respectively.
<br><br>
This is the complete implementation:
<pre>
import os, sys, random


def deviser(max):
    fh = open("devisor.log","w")
    to_be_guessed = int(max * random.random()) + 1
    
    guess = 0
    while guess != to_be_guessed:
        guess = int(raw_input())
        fh.write(str(guess) + " ")
        if guess > 0:
            if guess > to_be_guessed:
                print 1
            elif guess < to_be_guessed:
                print -1
            else:
                print 0
            sys.stdout.flush()       
        else:
            break
    fh.close()

def guesser(max):
    fh = open("guesser.log","w")
    bottom = 0
    top = max
    fuzzy = 10
    res = 1
    while res != 0:
        guess = (bottom + top) / 2
        print guess
        sys.stdout.flush()       
        fh.write(str(guess) + " ")
        res = int(raw_input())
        if res == -1: # number is higher
            bottom = guess
        elif res == 1:
            top = guess
        elif res == 0:
            message = "Wanted number is %d" % guess
            fh.write(message)
        else: # this case shouldn't occur
            print "input not correct"
            fh.write("Something's wrong")
   

n = 100
stdin  = sys.stdin.fileno() # usually 0
stdout = sys.stdout.fileno() # usually 1

parentStdin, childStdout  = os.pipe() 
childStdin,  parentStdout = os.pipe() 
pid = os.fork()
if pid:
    # parent process
    os.close(childStdout)
    os.close(childStdin)
    os.dup2(parentStdin,  stdin)
    os.dup2(parentStdout, stdout)
    deviser(n)
else:
    # child process
    os.close(parentStdin)
    os.close(parentStdout)
    os.dup2(childStdin,  stdin)
    os.dup2(childStdout, stdout)
    guesser(n)

</pre>

<h3>Named Pipes, Fifos</h3>
<img class="imgright" src="images/named_pipes.png" alt="Example: Pipe with 3 processes in and one out" />
Under Unix as well as under Linux it's possible to create Pipes, which are implemented 
as files. 
<br><br>
These Pipes are called "named pipes" or sometimes Fifos (First In First Out).
<br><br>
A process reads from and writes to such a pipe as if it were a regular file.
Sometimes more than one process write to such a pipe but only one process reads from it.
<br><br>
The following example illustrates the case, in which one process (child process) writes 
to the pipe and another process (the parent process) reads from this pipe. 
<br>
<br><br>
<pre>
import os, time, sys
pipe_name = 'pipe_test'

def child( ):
    pipeout = os.open(pipe_name, os.O_WRONLY)
    counter = 0
    while True:
        time.sleep(1)
        os.write(pipeout, 'Number %03d\n' % counter)
        counter = (counter+1) % 5

def parent( ):
    pipein = open(pipe_name, 'r')
    while True:
        line = pipein.readline()[:-1]
        print 'Parent %d got "%s" at %s' % (os.getpid(), line, time.time( ))

if not os.path.exists(pipe_name):
    os.mkfifo(pipe_name)  
pid = os.fork()    
if pid != 0:
    parent()
else:       
    child()
</pre>
<br><br>

</p>

<div id="contextlinks">Previous Chapter: <a href="threads.php">Introduction into Threads</a><br>
<LINK rel="prev" href="threads.php">Next Chapter: <a href="graphs_python.php">Graph Theory and Graphs in Python"</a><br>
<LINK rel="next" href="graphs_python.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
