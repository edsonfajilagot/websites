<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: Python Online Course</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Python-Course is a detailled introduction into the programming language
Python for beginners with information an literature and weblinks." />
<meta name="Keywords" content="Python, course, tutorial, introduction, zen, self-study" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/Teaching.png" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<br>
<hr>


</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This tutorial is available in German as well:
    <a href="http://www.python-kurs.eu/kurs.php">Python Tutorial in Deutsch</a><h3>Python 2.7</h3>This tutorial deals with Python Version 2.7<br>This chapter from our course is available in a version for Python3: <a href="python3_course.php">Python Online Course</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>"I think the special thing about Python is that it's a writers' commune. 
The writers are in charge. The writers decide what the material is."</i> (Eric Idle )<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>

<div id="content">

<h2>Tutorial</h2>

    <p><img class="imgleft" src="images/python_animated150.gif" alt="animated Python Logo" />

This tutorial is an introduction into the basic concepts and features of the Python language and in the 
general programming methods as well. 
<br><br>
The tutorial is suitable for absolute beginners, but the topics are covered in great detail so that 
intermediate or advanced programmers might still find some useful and interesting information, which 
they might have overlooked or avoided in the past. 
<br><br>
The idea of this tutorial is to provide a course which is suitable for self-study. The beginner will 
be enabled to read and write Python scripts and use and create modules and classes as well. 
<br><br>
Though it's possible to read this tutorial off-line - as a matter of fact, you can create a nice printout
of this website without the sidebars on the left and right side by using the print facility of your browser. 
Just give it a try! But it will be more efficient if you work on this course online, so that you will have 
a Python interpreter at hand for hands-on experience.
<br><br>
It's a platitude, if we say, that a website is different from a book. Very often a textbook and a website
with the same topic differ in two aspects:
<ul>
<li>A book is often more thorough</li>
<li>A book is static by nature, i.e unprecise formulations and errors can't be removed and there 
will be no growth in quantity and quality, e.g. further facts or explanatory examples can't be added.</li>
</ul>
The first one is usually an advantage for books in paper, but the second one is a clear advantage for
an online tutorial. We think, that our website is as thorough as many paper based Python books, so we
can easily compete with them. Secondly, we are continually working on this website, so that you can see
it grow and improve, if you keep returning to it.
<br><br>
We started work on this website in June 2010. The tutorial is based on material from our classroom training 
courses.
We work both on our classroom courses and on this tutorial true to the motto, which William A. Foster has 
coined:
<br>
<i>"Quality is never an accident; it is always the result of high intention, sincere effort, intelligent 
direction and skilful execution; it represents the wise choice of many alternatives."</i>

<br>
</p>					 


</div>


