<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: Exception Handling</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction into Exception handling, using the programming language Python" />
<meta name="Keywords" content="Python, tutorial, course, exception handling, error, errors" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/python_logo_band_aid_small.jpg" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<br>
<hr>
<br>
<h3>Exception from the Rule</h3>
<i>"There are two great rules of life, the one general and the other particular. 
The first is that everyone can in the end, get what he wants, if he only tries. 
That is the general rule. The particular rule is that every individual is, 
more or less, an exception to the rule."</i>
<br>
Samuel Butler
<br>
<h3>Delicate Handling</h3>
<i>"The finest qualities of our nature, like the bloom on fruits, can be preserved 
only by the most delicate handling. Yet we do not treat ourselves nor one another 
thus tenderly."</i>
<br>Henry David Thoreau
<hr>
Supported by:<br>
<a href="http://www.bodenseo.ca"><img style="width: 150px;" alt="Bodenseo, courses, seminars and training 
in Canada"
		     src="images/bodenseo_python_training.gif"><br>Python Training Courses in Canada</a>
		     <br><br>		     

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/ausnahmebehandlung.php">Ausnahmebehandlung</a><h3>Python 2.7</h3>This tutorial deals with Python Version 2.7<br>This chapter from our course is available in a version for Python3: <a href="python3_exception_handling.php">Exception Handling</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein. 
<br>
If you are interested in an instructor-led classroom training in Canada or the US, you may have a look at the 
<a href="http://ca.bodenseo.com/courses.php?topic=Python">Python courses
by Bernd Klein at Bodenseo<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
<br>
<font size="1">� kabliczech - Fotolia.com</font>
<br><br>
Overview of <a href="python_classes.php">Python courses</a> by Bernd Klein.


<br><br>
<h3>The Truth in Errors</h3>
<i>"The first step towards amendment is the recognition of error."</i><br>
Seneca
<br><br>
<i>"The world always makes the assumption that the exposure of an error is identical with the 
discovery of truth - that the error and truth are simply opposite. They are nothing of the sort.
What the world turns to, when it is cured of one error, is usually simply another error, and 
maybe one worse than the first one."</i>
<br>
H.L. Mencken
<i>
"Great services are not canceled by one act or by one single error."
</i>
Benjamin Disraeli
 </p>
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="generators.php">Generators</a><br>
<LINK rel="prev" href="generators.php">Next Chapter: <a href="object_oriented_programming.php">Object Oriented Programming</a><br>
<LINK rel="next" href="object_oriented_programming.php"></div><img class="imgright" src="images/python_logo_band_aid.jpg" alt="Python logo with band aid" />  

<h2>Exception Handling</h2>
<p>
An exception is an error that happens during the execution of a program. Exceptions are known to non-programmers 
as instances that do not conform to a general rule. The name "exception" in computer science has this meaning
as well: It implies that the problem (the exception) doesn't occur frequently, i.e. the exception is the 
"exception to the rule". Exception handling is a construct in some programming languages  to handle
or deal with errors automatically. Many programming languages like C++, Objective-C, PHP, Java, Ruby, Python, 
and many others have built-in support for exception handling.
</p>
<p>
Error handling is generally resolved by saving the state of execution at the moment the error occurred and
interrupting the normal flow of the program to execute a special function or piece of code, which is known
as the exception handler. Depending on the kind of error ("division by zero", "file open error" and so on) 
which had occurred, the error handler can "fix" the
problem and the program can be continued afterwards with the previously saved data.
</p>
<br>
<h3>Exception Handling in Python</h3>
<p>
Exceptions handling in Python is very similar to Java. The code, which harbours the risk of an exception,
is embedded in a try block. But whereas in Java exceptions are caught by catch clauses, we have statements 
introduced by an "except" keyword in Python. It's possible to "create custom-made" exceptions: With the raise 
statement it's possible to force a specified exception to occur. 
</p>
<p>
Let's look at a simple example. Assuming we want to ask the user to enter an integer number. If we use a
raw_input(), the input will be a string, which we have to cast into an integer. If the input has not been 
a valid integer, we will generate (raise) a ValueError. We show this in the following interactive session:
<pre>
>>> n = int(raw_input("Please enter a number: "))
Please enter a number: 23.5
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
ValueError: invalid literal for int() with base 10: '23.5'
</pre>
With the aid of exception handling, we can write robust code for reading an integer from input:
<pre>
while True:
    try:
        n = raw_input("Please enter an integer: ")
        n = int(n)
        break
    except ValueError:
        print("No valid integer! Please try again ...")
print "Great, you successfully entered an integer!"
</pre>
It's a loop, which breaks only, if a valid integer has been given.
<br>
The example script works like this:<br>
The while loop is entered. The code within the try clause will be executed statement by statement.
If no exception occurs during the execution, the execution will reach the break statement and the while
loop will be left. If an exception occurs, i.e. in the casting of n, the rest of the try block will
be skipped and the except clause will be executed. The raised error, in our case a ValueError, has to match 
one of the names after except. In our example only one, i.e. "ValueError:". After having printed the text
of the print statement, the execution does another loop. It starts with a new raw_input().
<br><br>
An example usage could look like this:
<br>
<pre>
$ python integer_read.py 
Please enter an integer: abc
No valid integer! Please try again ...
Please enter an integer: 42.0
No valid integer! Please try again ...
Please enter an integer: 42
Great, you successfully entered an integer!
$
</pre> 
</p>
<br>
<h3>Multiple Except Clauses</h3>
<p>
A try statement may have more than one except clause for different exceptions. But at most one except clause
will be executed.
</p>
<p>
Our next example shows a try clause, in which we open a file for reading, read a line from this file and convert
this line into an integer. There are at least two possible exceptions: 
<ul>
<li>an IOError</li>
<li>ValueError</li>
</ul>
Just in case we have an additional unnamed except clause for an unexpected error:
<pre>
import sys

try:
    f = open('integers.txt')
    s = f.readline()
    i = int(s.strip())
except IOError as (errno, strerror):
    print "I/O error({0}): {1}".format(errno, strerror)
except ValueError:
    print "No valid integer in line."
except:
    print "Unexpected error:", sys.exc_info()[0]
    raise
</pre> 
The handling of the IOError in the previous example is of special interest. The IOError returns a tuple with
an error number and a string with the error message, which we assign to the variables errno and strerror by 
"except IOError as (errno, strerror)".
<br>
If we call the above script with a non-existing file, we get the message:
<pre>
I/O error(2): No such file or directory
</pre>
And if the file integers.txt is not readable, e.g. if we don't have the permission to read it, we get the 
following message:
<pre>
I/O error(13): Permission denied
</pre> 
An except clause may name more than one exception in a tuple of error names, as we see in the following example:
<pre>
try:
    f = open('integers.txt')
    s = f.readline()
    i = int(s.strip())
except (IOError, ValueError):
    print "An I/O error or a ValueError occurred"
except:
    print "An unexpected error occurred"
    raise
</pre>
</p>
<br>
<h3>Clean-up Actions (try ... finally)</h3>
So far the try statement had always been paired with except clauses. But there is another way to use it as well. 
The try 
statement can be followed by a finally clause. Finally clauses are called clean-up or termination clauses, because
they must be executed under all circumstances, i.e. a "finally" clause is always executed regardless if an exception 
occurred in a try block or not.
<br>
A simple example to demonstrate the finally clause:
<pre>
try:
    x = float(raw_input("Your number: "))
    inverse = 1.0 / x
finally:
    print("There may or may not have been an exception.")
print "The inverse: ", inverse
</pre>
Let's look at the output of the previous script, if we first input a correct number and after this a string, which
is raising an error:
<pre>
bernd@venus:~/tmp$ python finally.py 
Your number: 34
There may or may not have been an exception.
The inverse:  0.0294117647059
bernd@venus:~/tmp$ python finally.py 
Your number: Python
There may or may not have been an exception.
Traceback (most recent call last):
  File "finally.py", line 3, in &lt;module&gt;
    x = float(raw_input("Your number: "))
ValueError: invalid literal for float(): Python
bernd@venus:~/tmp$ 
</pre>
<br>
<h3>Combining try, except and finally</h3>
"finally" and "except" can be used together for the same try block, as can be seen the following Python example:
<pre>
try:
    x = float(raw_input("Your number: "))
    inverse = 1.0 / x
except ValueError:
    print "You should have given either an int or a float"
except ZeroDivisionError:
    print "Infinity"
finally:
    print("There may or may not have been an exception.")
</pre>
The output of the previous script, if saved as "finally2.py", for various values looks like this:
<pre>
bernd@venus:~/tmp$ python finally2.py 
Your number: 37
There may or may not have been an exception.
bernd@venus:~/tmp$ python finally2.py 
Your number: seven 
You should have given either an int or a float
There may or may not have been an exception.
bernd@venus:~/tmp$ python finally2.py 
Your number: 0
Infinity
There may or may not have been an exception.
bernd@venus:~/tmp$ 
</pre>
<br>
<h3>else Clause</h3>
The try ... except statement has an optional else clause. An else block has to be positioned after all the except 
clauses. An else clause will be executed if the try clause doesn't raise an exception.
<br><br>
The following example opens a file and reads in all the lines into a list called "text":
<pre>
import sys
file_name = sys.argv[1]
text = []
try:
    fh = open(file_name, 'r')
    text = fh.readlines()
    fh.close()
except IOError:
    print 'cannot open', file_name

if text:
    print text[100]
</pre>

This example receives the file name via a command line argument. So make sure, that you call it properly:
Let's assume that you saved this program as "exception_test.py". In this case, you have to call it with 
<pre>
python exception_test.py integers.txt
</pre>
If you don't want this behaviour, just change the line "file_name = sys.argv[1]" to "file_name = 'integers.txt'".
<br><br>
The previous example is nearly the same as:
<pre>
import sys
file_name = sys.argv[1]
text = []
try:
    fh = open(file_name, 'r')
except IOError:
    print 'cannot open', file_name
else:
    text = fh.readlines()
    fh.close()

if text:
    print text[100]
</pre>
The main difference is, that in the first case, all statements of the try block can lead to the same error 
message "cannot open ...", which is wrong, if fh.close() or fh.readlines() raise an error.
<br>
<h3>The assert Statement</h3>
The assert statement is intended for debugging statements.
It can be seen as an abbreviated notation for a conditional raise statement, i.e. an exception is only
raised, if a certain condition is not True.
<br>
Without using the assert statement, we can formulate it like this in Python:
<br>
<pre>
if not &lt;some_test&gt;:
        raise AssertionError(&lt;message&gt;)
</pre>
The following code, using the assert statement, is semantically equivalent, i.e. has the same meaning:
<pre>
assert &lt;some_test&gt;, &lt;message&gt;
</pre>
The line above can be "read" as: If &lt;some_test&gt; evaluates to False, an exception is raised and 
&lt;message&gt; will be output.
<br><br>
Example:
<br>
<pre>
>>> x = 5
>>> y = 3
>>> assert x < y, "x has to be smaller than y"
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
AssertionError: x has to be smaller than y
>>>
</pre>
<br>
Hint: assert should not be used to catch programming errors like
x / 0, because Python traps such programming errors itself!
<br>
assert should be used for trapping user-defined constraints! 

<br><br>
<div id="contextlinks">Previous Chapter: <a href="generators.php">Generators</a><br>
<LINK rel="prev" href="generators.php">Next Chapter: <a href="object_oriented_programming.php">Object Oriented Programming</a><br>
<LINK rel="next" href="object_oriented_programming.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
