<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Python Online Course</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="This is a detailled online introduction course into the programming language
Python suitable for self-study." />
<meta name="Keywords" content="Python, Python3, course, training, beginning, beginners, tutorial, course, courses, self-study" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/Teaching.png" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<hr>

This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
<br>
<h3>New Beginning</h3>

<i>"Every new beginning comes from some other beginning's end." (Seneca)</i>
<br><br>
The programming language Python is a new beginning. It's on top of "other beginning",
like C, C++, Perl, Lisp and other scripting and programming languages.
<br>Python3 is a new beginning as well. It's still Python, but it's rectifying
some aberations and inconsistencies of previous versions. But essentially, it's
still Python!
<br>
<h3>Training</h3>
<i>"Education is not the piling on of learning, information, data, facts, skills, 
or abilities - that's training or instruction - but is rather making visible 
what is hidden as a seed." (Thomas Moore)</i>
<br>


<hr>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This tutorial is available in German as well:
    <a href="http://www.python-kurs.eu/python3_kurs.php">Python Tutorial in Deutsch</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="course.php">Python Online Course in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="course.php">Python Online Course in Python 2.x</a>
 </p>




    
</p></div>

<div id="content">

<img class="imgright" src="images/python_3.png" alt="Python 3 green and yellow" width=150 />
<h2>Python3 Tutorial</h2>
<p>   
Those who want to learn Python ask themselves quite often: "Which version should I use?"
If you are free to choose, i.e. if there are no restriction by previous code or company 
standards, we think you should start with Python3. So, please go on with this tutorial,
which is meant to be a tutorial for beginners and programmers switching from other programming
languages to Python.
<br><br>
It's an introduction into Python for beginners and intermediate learners with lots of examples 
and exercises! It's suitable and meant for self-study. 
<br><br>
This online Python course was created and is maintained by Bernd Klein, an experienced Python trainer, 
giving training classes all over the world.





<div class="intro">

<h3>News</h3>
<div class="textmenu">
<p class="update">
<b>July 2014:</b><br>
An introduction into using database interfaces in Python for 
<a href="sql_python.php">SQL, MySQL and SQLite</a>
<br><br>
<b>March 2014:</b><br>
We are currently completely revising the chapter on object oriented 
programming. It's more or less complete rewrite. The 
<a href="python3_object_oriented_programming_old.php">old version dealing with OOP</a> 
can still be accessed, though we recommend to work through the new ones.

<br>
The topic now comprises five instead of previously only one chapter:
<ul>
<li><a href="python3_object_oriented_programming.php">General 
Introduction into Object Oriented Programming (OOP)</a>
<li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a>
<li><a href="python3_properties.php">Properties vs. Getters and Setters</a>
<li><a href="python3_inheritance.php">Inheritance</a>
<li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a>
<li><a href="python3_magic_methods.php">Magic Methods and Operator Overlaoding</a>
</ul>


</div>
</p> 

<h4>Any Help is Welcome!</h4>
Though we do our best to prevent errors, we need your help to ensure that all the 
information presented in this tutorial is correct and up to date.
If you find spelling and grammatical errors, it will be great if you will point them 
out to us, so that we can fix them! We are continually improving this website and this 
will assist us in making it the best tutorial! The same is true of course, if you 
find logical problems or errors in the text or the code examples. We hope that there
are only few of them left in the text! But as the saying goes, nobody is perfect!
Please use the contact button!






</div>

<div class="intro2">
<h3>Ads for training classes</h3>
<div class="textmenu">
This website is ad-free! There are no paid-for ads. 
The only things advertised here are the book by Bernd Klein, the author of
this tutorial, and the training classes given by the author.
</div>


<p class="update">
</p> 


<h3>Tutorial in hard copy</h3>
<div class="textmenu">
There is no PDF version available, but you can create it yourself.
You can use the print functionality of your browser to do this.
Use "Print to File" and you will get a nicely formatted version of a chapter.
<br>

<h4>Thanks!</h4>
Thank you very much for using this tutorial! We hope that you will enjoy learning
Python with us!

 
</div>

</div>




<div class="intro3">

<h3>Classroom training Courses</h3>

This tutorial is, as we have already mentioned, intended for self-study!
But some people need to learn Python very quick or prefer to learn in a classrom
with an experienced trainer. You may consider visiting one of the courses by 
Bernd Klein, the author of this tutorial. 

<h4>Our next Training Courses</h4>
<br>Our next open Python classes with Bernd Klein, the author of this website:
<br><b>Toronto</b>:  3<sup>rd</sup> - 7<sup>th</sup> of November, 2014:
<br><a href="http://ca.bodenseo.com/courses.php?topic=Python">Python Training Course in Toronto</a>
<br><b>London</b>:  20<sup>th</sup> - 24<sup>rd</sup> of October, 2014: 
<br><a href="http://www.bodenseo.com/course/python_training_course_intermediate.html">Python Intensive Course in London</a>
<br><b>Berlin</b>:  10<sup>th</sup> - 14<sup>th</sup> of November, 2014: 
<br><a href="http://www.bodenseo.com/course/python_training_course_intermediate.html">Python Intensive Course in Berlin</a>
<br><b>Lake Constance / Zurich</b>:  1<sup>st</sup> - 5<sup>th</sup> of September, 2014:
<br><a href="http://www.bodenseo.com/course/python_training_course_intermediate.html">Python Intensive  Course</a>
<br><b>Paris</b>:  1<sup>st</sup> - 5<sup>th</sup> of December, 2014:
<br><a href="http://www.bodenseo.com/course/python_text_processing_course.html">Python Text Processing Course</a>
<br><b>Munich</b>:  8<sup>th</sup> - 12<sup>th</sup> of December, 2014:
<br><a href="http://www.bodenseo.com/course/python_training_course.html">Python Training Course</a>
<br>

 

<h3>Advanced Topics</h3>

<h5>System Programming with Python</h5>  
Python has various modules to support system focused programming.
The <a href="sys_module.php">sys module</a> is introduced in the first chapter. A focal point are the data streams (stdin, stdout, stderr) and redirections of strteams.
The interaction between  is the focus in the following chapter of our course.
<br>
The interaction between <a href="os_module_shell.php">Python and the Linux Shell</a> is another 
topic of our advanced section. This chapter is followed by <a href="forking.php">Forks and Forking</a>.
<br><br>You can learn more about threads and threading in our <a href="threads.php">Introduction into Threads</a>.
We show how to find the active IP addresses in a local network by using forks.
<br><br>
We demonstrate in <a href="pipes.php">"Pipe, Pipes and '99 Bottles of Beer'"</a> how to write a 
program which is construing the famous American song "99 bottles of
beer" by using forked processes and Pipes. So, if you need a good example of pipes and forks working
together you will find it here.

<h5>Graph Theory</h5>
We have three chapters dealing with Graphs. 

<ul>
<li>A general introduction into the Graph theory and the corresponding Python code can be found in
<a href="graphs_python.php">"Graphs in Python"</a>  You will also here the implementations of a graph 
class with essential 
functionalities for graph creation, manipulation and calculations.</li>
<li>Introduction into the module <a href="pygraph.php" name="NetworkX">pygraph</a></li>
<li>Introduction into the module <a href="networkx.php">NetworkX</a></li>
</ul>
</ul>

<h5>Computer Science and Computer Linguistics</h5>
<a href="finite_state_machine.php">Finite State Machines</a> are not only used in computer science but in 
natural language processing as well. We cover the concept of the Finite State Machine in great 
detail, so that even an amateur in Computer Science can understand the examples.
At least we hope so.
<br><br>
Alan Turing's <a href="turing_machine.php">Turing Machines</a> and above all the underlying theory is a must 
for every computer scientist. We show a simple implementation of a Turing Machine.  
<br><br>
If you are interested in Classifying documents, the 
<a href="text_classification_introduction.php">Introduction into Text Classification using Naive Bayes</a>
and our <a href="text_classification_python.php">Python Implementation of Text Classification</a> will be
the right chapters for you.
<h5>Numerical Computations with Python</h5>
If you want to get efficient and fast results with arrays and matrices, 
the <a href="numpy.php">NumPy</a> module of
Python is definitely the right tool collection for you. You will find answers to your questions in
our tutorial, i.e. in our chapters "NumPy Module" and <a href="matrix_arithmetic.php">"Matrix Arithmetic"</a>.
<br><br>
We also provide an introduction into <a href="linear_combinations.php">Linear Combination</a>

<h5>Music</h5>

It's also possible to create scores with Python: You can find a complete working example in  
<a href="python_scores.php">Creating Musical Scores With Python</a>

<br><br>
If you feel that the above topics are to complicated or sophisticated for you, you might
like our course for beginners in Python. You find a documented link list in the following lines:

<h5>Databases with Python</h5>

An introduction into using database interfaces in Python for <a href="sql_python.php">SQL, MySQL and SQLite</a>

<h5>"Games"</h5>

What you find are not real games! We show a recursive solution to 
<a href="towers_of_hanoi.php">Towers of Hanoi</a> and a game 
<a href="mastermind.php">Cows and Bulls</a> better known in a commercial version called "Mastermind".












</div>


