<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: Regular Expression for Advanced Users</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Second Part of our Introduction into Regular Expression under Python" />
<meta name="Keywords" content="Python, introduction, advanced, regular expression" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/stairs_green_small.jpg" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<h3>Mythology</h3>
The first great achievement of Apollo was to slay the huge serpent Python. In some texts 
Python is an enormous dragon and not a serpent. 
<br>  
But who was this mythical creature? Python was created out of the slime and mud left after 
the great flood. She was  appointed by Gaia (Mother Earth) to guard the oracle of Delphi, 
known as Pytho. After having defeated Python Apollo remade
her former home and the oracle as his own.
<br>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/re_fortgeschrittene.php">Regul�re Ausdr�cke f�r Fortgeschrittene</a><h3>Python 2.7</h3>This tutorial deals with Python Version 2.7<br>This chapter from our course is available in a version for Python3: <a href="python3_re_advanced.php">Regular Expression for Advanced Users</a>

<h3>Python Training Courses</h3>
<p>

<p>If you  want to learn Python fast and efficiently, the right step will be a 
<a href="http://www.bodenseo.com/courses.php?topic=Python">
<br>Python Training course</a> at Bodenseo. There are also
 special seminars for advanced students like the 
 <a href="http://www.bodenseo.com/course/python_xml_training_course.html">Python & XML Training Course</a>.
 If you want to acquire special knowledge in Text Processing and Text Classification, then  
<a href="http://www.bodenseo.com/course/python_text_processing_course.html">"Python Text Processing 
Course"</a> will be the right one for you.
<br>
All the Python seminars are available in German as well: 
<a href="http://www.bodenseo.de/kurse.php?topic=Python">Python-Kurse</a>"

 
<a href="http://www.bodenseo.com/courses.php?topic=Python">
<img class="imgright" src="images/bodenseo_stairs_to_python2.png" alt="Bodenseo step to python" />
<br>Python Courses</a> at Bodenseo.
<br><br>
You can book Bernd Klein for on-site <a href="python_classes.php">Python courses</a> as 
well.

<br><br>
<h3>Perl and Regular Expressions</h3>
"Perl's nature encourages the use of regular expressions almost to the exclusion of all other 
techniques; they are far and away the most "obvious" (at least, to people who don't know any better) 
way to get from point A to point B."
(Jamie Zawinski)
<h3>Another Quote</h3>
In my daily work, I work on very large, complex, distributed systems built out of 
many Python modules and packages. The focus is very similar to what you find, for 
example, in Java and, in general, in systems programming languages.
(Guido van Rossum) 
 </p>

</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="re.php">Introduction in Regular Expressions</a><br>
<LINK rel="prev" href="re.php">Next Chapter: <a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a><br>
<LINK rel="next" href="lambda.php"></div>
<img class="imgright" src="images/stairs_green_fog.jpg" alt="stairway to success with Python" />  

<h2>Regular Expressions</h2>
<p>
<br>
In our <a href="re.php">introduction to regular expressions</a> we have covered the basic aspects of regular
expressions. We have seen, what the simplest regular expression looks like. We have also learnt, how to use
regular expressions in Python by using the search() and the match() methods of the re module. You should be
familiar with formulating and using character classes and the predefined character classes like \d, \D, \s, \S, and 
so on. You should have learnt how to match the beginning and the end of a string. You should know the special
meaning of the question mark to make items optional. We have also introduced the quantifiers to repeat characters
and groups arbitrarily or in certain ranges.
<br><br>
You should also be familiar with grouping and backreferences. Furthermore, we had explained 
the match objects of the re module and the information they contain and how to retrieve this
 information by using the methods span(), start(), end(), and group().
<br><br>
The introduction ended with a comprehensive example in Python.
<br><br>
In this chapter we will continue with our explanations of the syntax of the regular expressions. We will also
explain further methods of the Python module re.
<br><br>
<h3>Finding all Matched Substrings</h3>
The Python module re provides another great method, which other languages like Perl and Java don't provide.
<pre>
re.findall(pattern, string[, flags])
</pre>
findall returns all non-overlapping matches of pattern in string, as a list of strings. 
The string is scanned left-to-right, and matches are returned in the order in which they are found. 
<pre>
>>> t="A fat cat doesn't eat oat but a rat eats bats."
>>> mo = re.findall("[force]at", t)
>>> print mo
['fat', 'cat', 'eat', 'oat', 'rat', 'eat']
</pre>
If one or more groups are present in the pattern, findall returns a list of groups; this will be a list 
of tuples if the pattern has more than one group. 
<pre>
>>> import re
>>> items = re.findall("[0-9]+.*: .*", "Customer number: 232454, Date: February 12, 2011")
>>> print items
['232454, Date: February 12, 2011']
>>> items = re.findall("([0-9]+).*: (.*)", "Customer number: 232454, Date: February 12, 2011")
>>> print items
[('232454', 'February 12, 2011')]
>>> 
</pre>

<h4>Alternations</h4>
In our introduction to regular expressions we had introduced character classes. Character classes 
offer a choice out of a set of characters. Sometimes we need a choice between several regular expression.
It's a logical or and that's why the symbol for this construct is the  "|" symbol. 
<br>
In the following example, we check, if one of the cities London, Paris, Zurich or Strasbourg appear in a
string preceded by the word "destination":

<pre>
 >>> import re
>>> str = "The destination is London!"
>>> mo = re.search(r"destination.*(London|Paris|Zurich|Strasbourg)",str)
>>> if mo: print mo.group()
... 
destination is London
>>> 
</pre>

If you think the previous example is too artificial, here is another one.
Let's assume, tha you want to filter your email. You want to find all the correspondence 
(conversations) between you and Guido van Rossum, the creator and designer of Python. 
The following regular expression is helpful for this purpose:
<pre>
r"(^To:|^From:) (Guido|van Rossum)"
</pre>

This expression matches all lines starting with either 'To:' or 'From:', followed by a 
space and then either by the first name 'Guido' or the surnae 'van Rossum'.

<h3>Compiling Regular Expressions</h3>
If you want to use the same regexp more than once in a script, it might be a good idea 
to use a regular expression object, i.e. the regex is compiled. 
<br>
The general syntax:
<pre>
re.compile(pattern[, flags])
</pre>

compile returns a regex object, which can be used later for searching and replacing.
The expressions behaviour can be modified by specifying a flag value.
<br><br>

<table cellpadding="2" cellspacing="2" border="1">
<tr><td><b>Abbreviation</b></td><td><b>Full name</b></td><td><b>Description</b></td></tr>
<tr><td>re.I</td><td>re.IGNORECASE</td><td>Makes the regular expression case-insensitive</td></tr>
<tr><td>re.L</td><td>re.LOCALE</td><td>The behavious of some special sequences like 
\w, \W, \b,\s, \S will be made dependant on the current locale, i.e. the user's language, country aso.</td></tr>
<tr><td>re.M</td><td>re.MULTILINE</td><td>^ and $ will match at the beginning and at the end of each line and
not just at the beginning and the end of the string</td></tr>
<tr><td>re.S</td><td>re.DOTALL</td><td>The dot "." will match every character <b>plus the newline</b></td></tr>
<tr><td>re.U</td><td>re.UNICODE</td><td>Makes \w, \W, \b, \B, \d, \D, \s, \S dependent on Unicode 
character properties</td></tr>
<tr><td>re.X</td><td>re.VERBOSE</td><td>Allowing "verbose regular expressions", i.e. 
whitespace are ignored. This means that spaces, tabs, and carriage returns are not matched as such. 
If you want to match a space in a verbose regular expression, you'll need to escape it by escaping it 
with a backslash in front of it or include it in a character class.<br>
# are also ignored, except when in a character class or preceded by an non-escaped backslash.
Everything following a "#" will be ignored until the end of the line, so this character can be
used to start a comment. 
</td></tr>
</table>

<br><br>

Compiled regular objects usually are not saving much time, because Python internally compiles 
AND CACHES regexes whenever you use them with re.search() or re.match(). The only extra time 
a non-compiled regex takes is the time it needs to check the cache, which is a key lookup of
a dictionary.<br>
<br>
A good reason to use them is to separate the defintion of a regex from its use.
<br><br>
<h4>Example</h4>
We have already introduced a regular expression for matching a superset of UK postcodes 
in our introductory chapter:
<pre>
r"[A-z]{1,2}[0-9R][0-9A-Z]? [0-9][ABD-HJLNP-UW-Z]{2}"
</pre>
<br><br>
We demonstrate with this regular expression, how we can use the compile functionality of the module re
in the following interactive session. The regular expression "regex" is compiled with re.compile(regex) and
the compiled object is saved in the object compiled_re. Now we call the method search() of the object
compiled_re: 

<pre>
>>> import re
>>> regex = r"[A-z]{1,2}[0-9R][0-9A-Z]? [0-9][ABD-HJLNP-UW-Z]{2}"
>>> address = "BBC News Centre, London, W12 7RJ"
>>> compiled_re = re.compile(regex)
>>> res = compiled_re.search(address)
>>> print res
<_sre.SRE_Match object at 0x7fc9f688f6b0>
>>> 

</pre>

<h3>Splitting a String With or Without with Regular Expressions</h3>
There is a string method split, which can be used to split a string into a list of substrings.

<br><br>
<code>
str.split([sep[, maxsplit]])
</code>
<br><br>
As you can see, the method split has two optional parameters. If none is given (or is None) , 
a string will be separated into substring using whitespaces as delimiters, i.e. every
substring consisting purely of whitespaces is used as a delimiter. 
<br><br>
<img src="images/re_split.gif" alt="Splitting an image" />  

<br><br>

We demonstrate this 
behaviour with a famous quotation by Abraham Lincoln:
<br>
<pre>
>>> law_courses = "Let reverence for the laws be breathed by every American mother to the lisping babe that prattles on her lap. Let it be taught in schools, in seminaries, and in colleges. Let it be written in primers, spelling books, and in almanacs. Let it be preached from the pulpit, proclaimed in legislative halls, and enforced in the courts of justice. And, in short, let it become the political religion of the nation."
>>> law_courses.split()
['Let', 'reverence', 'for', 'the', 'laws', 'be', 'breathed', 'by', 'every', 'American', 'mother', 'to', 'the', 'lisping', 'babe', 'that', 'prattles', 'on', 'her', 'lap.', 'Let', 'it', 'be', 'taught', 'in', 'schools,', 'in', 'seminaries,', 'and', 'in', 'colleges.', 'Let', 'it', 'be', 'written', 'in', 'primers,', 'spelling', 'books,', 'and', 'in', 'almanacs.', 'Let', 'it', 'be', 'preached', 'from', 'the', 'pulpit,', 'proclaimed', 'in', 'legislative', 'halls,', 'and', 'enforced', 'in', 'the', 'courts', 'of', 'justice.', 'And,', 'in', 'short,', 'let', 'it', 'become', 'the', 'political', 'religion', 'of', 'the', 'nation.']
>>> 
</pre>


<br>
Now we look at a string, which could stem from an Excel or an OpenOffice calc file. 
We have seen in our previous example, that split takes whitespaces as default separators. 
We want to split the string in the following little example using semicolons as separators. The only thing
we have to do is to use ";" as an argument of split(): 
<pre>
>>> line = "James;Miller;teacher;Perl"
>>> line.split(";")
['James', 'Miller', 'teacher', 'Perl']
</pre> 

The method split() has another optional parameter: maxsplit
<br>
If maxsplit is given, at most maxsplit splits are done. This means that the resulting
list will have at most "maxsplit + 1" elements.
<br>
We will illustrate the mode of operation of maxsplit in the next example:
<pre>
>>> mammon = "The god of the world's leading religion. The chief temple is in the holy city of New York."
>>> mammon.split(" ",3)
['The', 'god', 'of', "the world's leading religion. The chief temple is in the holy city of New York."]
</pre>
We used a Blank as a delimiter string in the previous example, which can be a problem:
If multiple blanks or whitespaces are connected, split() will split the string after every single blank, so that
we will get emtpy strings and strings with only a tab inside ('\t') in our result list:
<pre>
>>> mammon = "The god  \t of the world's leading religion. The chief temple is in the holy city of New York."
>>> mammon.split(" ",5)
['The', 'god', '', '\t', 'of', "the world's leading religion. The chief temple is in the holy city of New York."]
>>> 
</pre> 
We can prevent the separation of empty strings by using None as the first argument. Now split will use the default 
behaviour, i.e. every substring consisting of connected whitespace characters will be
taken as one separator:
<pre>
>>> mammon.split(None,5)
['The', 'god', 'of', 'the', "world's", 'leading religion. The chief temple is in the holy city of New York.']
</pre>

<h4>Regular Expression Split</h4>
The string method split() is the right tool in many cases, but what, if you want e.g.
to get the bare words of a text, i.e. without any special characters and whitespaces.
If we want this, we have to use the split function from the re module. We illustrate 
this method with a short text from the beginning of Metamorphoses by Ovid:
<pre>
>>> import re
>>> metamorphoses = "OF bodies chang'd to various forms, I sing: Ye Gods, from whom these miracles did spring, Inspire my numbers with coelestial heat;"
>>> re.split("\W+",metamorphoses)
['OF', 'bodies', 'chang', 'd', 'to', 'various', 'forms', 'I', 'sing', 'Ye', 'Gods', 'from', 'whom', 'these', 'miracles', 'did', 'spring', 'Inspire', 'my', 'numbers', 'with', 'coelestial', 'heat', '']
</pre>

The following example is a good case, where the regular expression is really superior to the string split. 
Let''s assume that we have data lines with surnames, firstnames and profesions of names. We want to clear the 
data line of the superfluous and redundant text descriptions, i.e. "surname: ", "prename: " and so on, so that
we have solely the surname in the first column, the firstname in the second column and the profession in the third
column:
<br>
<pre>
>>> import re
>>> lines = ["surname: Obama, prename: Barack, profession: president", "surname: Merkel, prename: Angela, profession: chancellor"]
>>> for line in lines:
...     re.split(",* *\w*: ", line)
... 
['', 'Obama', 'Barack', 'president']
['', 'Merkel', 'Angela', 'chancellor']
>>> 
</pre>

We can easily improve the script by using a slice operator,
so that we don't have the empty string as the first element of our result lists:
<pre>
>>> import re
>>> lines = ["surname: Obama, prename: Barack, profession: president", "surname: Merkel, prename: Angela, profession: chancellor"]
>>> for line in lines:
...     re.split(",* *\w*: ", line)[1:]
... 
['Obama', 'Barack', 'president']
['Merkel', 'Angela', 'chancellor']
>>> 
</pre>

<h3>Search and Replace with sub</h3>
<pre>
re.sub(regex, replacement, subject)
</pre>

Every match of the regular expression  regex in the string subject will be replaced by the string replacement.
<br>
Example:
<pre>
>>> import re
>>> str = "yes I said yes I will Yes."
>>> res = re.sub("[yY]es","no", str)
>>> print res
no I said no I will no.
</pre>


<br><br>
<div id="contextlinks">Previous Chapter: <a href="re.php">Introduction in Regular Expressions</a><br>
<LINK rel="prev" href="re.php">Next Chapter: <a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a><br>
<LINK rel="next" href="lambda.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
