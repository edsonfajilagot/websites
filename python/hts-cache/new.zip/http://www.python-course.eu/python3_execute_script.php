<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Execute a Script</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="This chapter shows how to execute a Python script or program. The 
details of Python Byte Code and the Python virtual machine (PVM) are also illustrated." />
<meta name="Keywords" content="Python, Python3, Code, execute, PVM, PYthon Virtual Machine, script, interpreter, Compiler, pyc extension, byte code, 
virtual machine" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/python_head.jpg" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<br>
<hr>
<br>
<h3>Difference between a Script and a Program</h3>
There is a fluent passage between scripts and programs. There is a kind
of nether land, where the result of the programming can be correctly called a script
or a program. But there are works which are clearly programs and others which are definitely
scripts and can't be called programs.
<br><br>
Script can mean womething written by hand and a particular orthography or writing system.
The term script is also used for a written version of a play, film or some other
work of dramatic composition. 
<br>
<br>
In the past, we could say a program is compiled (C, C++) and a script is interpreted (like bash scripts).
But nowadays this is not a clear dividing line anymore. Modern languages like Python and Java are interpreted
and compiled without the necessity of the strict edit-compile-test-debug cycle. Of course, compilation
in Python and Java doesn't mean, that they are compiled into machine code. They are compiled into pseudo 
or virtual machine code, which is byte code close to machine code.
<br><br>
A script is something comparatively small, but you would never call the "Hello World" program written in
C a script, because it is compiled. But as we said before: With languages like Python the traditional 
difference is dissolving. You can start writing a small Python script. But while your script is 
getting larger and maturing, you will pass through the no-man's-land, where your work is both a script
and a program, but finally it will reach a stage, where it is not a script anymore but clearly a program. 
<br><br> 
<hr>
Supported by:<br>
<a href="http://www.bodenseo.com"><img style="width: 150px;" alt="Bodenseo, courses, seminars and training 
in Linux and Python"
		     src="images/bodenseo_python_training.gif"><br>Courses and Seminars for Linux and Python</a>
		     <br><br>
		     <hr>		     

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_skript_ausfuehren.php">Ausf�hren von Python-Code</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="execute_script.php">Execute a Script in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="execute_script.php">Execute a Script in Python 2.x</a>
 </p>




    
</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_interactive.php">Starting with Python: The Interactive Shell</a><br>
<LINK rel="prev" href="python3_interactive.php">Next Chapter: <a href="python3_blocks.php">Indentation</a><br>
<LINK rel="next" href="python3_blocks.php"></div>
<h2>Execute a Python script</h2>
<p>
So far we have played around with Python commands in the Python shell. We want to write
now our first serious Python program. You will hardly find any beginner's  textbook on programming,
which don't start with the "nearly mandatory" "Hello World" programm, i.e. a program which prints
the string "Hello World", which looks on the Python shell like this:

<pre>
$ python3
Python 3.1.2 (r312:79147, Sep 27 2010, 09:57:50) 
[GCC 4.4.3] on linux2
Type "help", "copyright", "credits" or "license" for more information.
>>> print("Hello World!")
Hello World!
>>> 
</pre>

But, as we said at the beginning, we want to write a "serious" script now. We use a slight
variation of the "Hello World" theme. We have to include our print statement into a file.
To save and edit our program in a file we need
an editor. There are lots of editors, but you should choose one, which supports syntax 
highlighting and indentation. Under Linux you can use vi, vim, emacs, geany, gedit and umpteen 
others. The emacs works under windows as well.
<br><br>So, after you have found the editor of your choice, you can input your mini script, i.e.
<pre>
print("My first simple Python script!")
</pre>

and save it as <b>my_first_simple_script.py</b>. 
<br>
The suffix .py is not really necessary under Linux but it's good style to use it. But the extension 
is essential, if you want to write modules.</p>
<h3>Start a Python script</h3>
<p>
Let's assume our script is in a subdirectory under the home directory of user monty:
<pre>
monty@python:~$ cd python
monty@python:~/python$ python my_first_simple_script.py 
My first simple Python script!
monty@python:~/python$
</pre>
<br><br>
It can be started under Windows in a Command prompt
 (start -> All Programs -> Accessories -> Command Prompt):
 <br><br>
<img  src="images/python_script_start_windows.png" alt="Starting a Python Script under Windows." />
<br>

</p>
<h3>Python Internals</h3>
Most probably you will have read somewhere, that the Python language is an interpreted 
programming or script language. The truth is: Python is both an interpreted and a compiled
language. But calling Python a compiled language would be misleading. People would assume
that the compiler translates the Python code into machine language. Python code is translated 
into intermediate code, which has to be executed by a virtual machine, known as the PVM, the 
Python virtual machine. This is a similar approach to the one taken by Java. 
There is even a way of translating
Python programs into Java byte code for the Java Virtual Machine (JVM). This can be achieved
with Jython.
<br><br>
The question is, do I have to compile my Python scripts to make them faster or how can I compile
them? The answer is easy: Normally, you don't need to do anything and you shouldn't bother,
because "Python" is doing the thinking for you, i.e. it takes the necessary steps automatically.
<br><br>
For whatever reason you want to compile a python program manually? No problem. It can be done 
with the module py_compile, either using the interpreter shell
<pre>
>>> import py_compile
>>> py_compile.compile('my_first_simple_script.py')
>>> 
</pre>
or using the following command at the shell prompt
<pre>
python -m py_compile my_first_simple_script.py
</pre>
Either way, a file named "easy_to_write.pyc" will be created. This file can be executed under Linux, 
if the has been made executable beforehand:
<pre>
monty@python:~/examples$ python3 -m py_compile my_first_simple_script.py
monty@python:~/examples$ chmod 755 my_first_simple_script.pyc
monty@python:~/examples$ ./my_first_simple_script.pyc
My first simple Python script!
monty@python:~/examples$
</pre>



<br>You can also automatically compile all files in a directory using the compileall module. 
You can do it from the shell prompt by running compileall.py and providing the path of the  
directory containing the Python files to compile:

<pre>
monty@python:~/python$ python -m compileall .
Listing . ...
</pre>


<br><br>
But as we have said, you don't have to bother about compiling Python code. The compilation is 
hidden from the user. Some newbies to Python wonder sometimes where these ominous files with the 
.pyc suffix might come from. If Python has write-access for the directory where the Python program 
resides, it will store the compiled byte code in a file that ends with a .pyc suffix. If Python 
has no write access, the program will work anyway. The byte code will be produced but discarded 
when the program exits.<br>
Whenever a Python program is called, Python will check, if there exists a compiled version with 
the .pyc suffix. This file has to be newer than the file with the .py suffix. If such a file exists,
Python will load the byte code, which will speed up the start up time of the script. If there exists
no byte code version, Python will create the byte code before it starts the execution of the program.
Execution of a Python program means execution of the byte code on the Python Virtual Machine (PVM). 
<br><br>
</p>
<img src="images/py_pyc_overview.gif" width="400" border="0" hspace="12" vspace="0" alt="Compilation of a Python script">
<p>
Every time a Python script is executed, byte code is created. But only, if a Python program is 
imported as a module, the byte code will be stored in the corresponding .pyc file.
<br>
So the following will not create a byte code file:
<pre>
monty@python:~/python$ python my_first_simple_script.py
My first simple Python script!
monty@python:~/python$
</pre>
The import in the following session will create a byte code file with the name "easy_to_write.pyc":
<pre>
monty@python:~/tmp$ ls 
my_first_simple_script.py
monty@python:~/tmp$ python
Python 2.6.5 (r265:79063, Apr 16 2010, 13:57:41) 
[GCC 4.4.3] on linux2
Type "help", "copyright", "credits" or "license" for more information.
>>> import my_first_simple_script
My first simple Python script!
>>> exit()
monty@python:~/tmp$ ls
my_first_simple_script.py  my_first_simple_script.pyc
monty@python:~/tmp$ 
</pre>
</p>
<div class="intro">
<h3>Compiler</h3>
<p class="update">
Definition: A compiler is a computer program that transforms (translates) source code of a 
programming language (the source language) into another computer language 
(the target language). In most cases compilers are used to transform source code 
into executable  program, i.e. they translate code from high-level programming languages into 
low (or lower) level languages, mostly assembly or machine code. 
      </p>
      
</div>
<div class="intro2">

<h3>Interpreter</h3>

<p class="update">
Definition: An interpreter is a computer program that executes instructions written in a 
programming language. It can either 
<ul>
<li>execute the source code directly or
<li>translates the source code in a first step into a more efficient representation and 
executes this code 
</ul>
</p> </div>



</p> </div>

</div>


<div id="contextlinks">Previous Chapter: <a href="python3_interactive.php">Starting with Python: The Interactive Shell</a><br>
<LINK rel="prev" href="python3_interactive.php">Next Chapter: <a href="python3_blocks.php">Indentation</a><br>
<LINK rel="next" href="python3_blocks.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
