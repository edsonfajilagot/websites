<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Exception Handling</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction on Exception handling with try, except and finally" />
<meta name="Keywords" content="Python, tutorial, course, exception handling, try, except, finally" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/python_logo_band_aid_small.jpg" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<hr>
<h3>Exceptions</h3>
<i>"Nothing travels faster than the speed of light with the possible exception of bad news, 
which obeys its own special laws."</i>
(Douglas Adams)
<br>
<i>"General principles should not be based on exceptional cases."</i>
(Robert J. Sawyer)
<hr>
<br>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Python and Linux Courses Logo"
		     src="images/bodenseo_python_training.gif"><br>Linux and Python Training Courses</a>
<br>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_ausnahmebehandlung.php">Ausnahmebehandlung</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="exception_handling.php">Exception Handling in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="exception_handling.php">Exception Handling in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_generators.php">Iterators and Generators</a><br>
<LINK rel="prev" href="python3_generators.php">Next Chapter: <a href="python3_object_oriented_programming.php">Object Oriented Programming</a><br>
<LINK rel="next" href="python3_object_oriented_programming.php"></div><br>
<h2>Errors and Exceptions</h2>
<p>
<br>
<h3>Exception Handling</h3>
<img class="imgright" src="images/python_logo_band_aid.jpg" alt="Python logo with band aid" />  
<br>
An exception is an error that happens during the execution of a program. Exceptions are known to non-programmers 
as instances that do not conform to a general rule. The name "exception" in computer science has this meaning
as well: It implies that the problem (the exception) doesn't occur frequently, i.e. the exception is the 
"exception to the rule". Exception handling is a construct in some programming languages  to handle
or deal with errors automatically. Many programming languages like C++, Objective-C, PHP, Java, Ruby, Python, 
and many others have built-in support for exception handling.
</p>
<p>
Error handling is generally resolved by saving the state of execution at the moment the error occurred and
interrupting the normal flow of the program to execute a special funtion or piece of code, which is known
as the exception handler. Depending on the kind of error ("division by zero", "file open error" and so on) 
which had occurred, the error handler can "fix" the
problem and the programm can be continued afterwards with the previously saved data.
</p>
<br>
<h3>Exception Handling in Python</h3>
<p>
Exceptions handling in Python is very similar to Java. The code, which harbours the risk of an exception,
is embedded in a try block. But whereas in Java exceptions are caught by catch clauses, we have statements 
introduced by an "except" keyword in Python. It's possible to "create custome-made" exceptions: With the raise 
statement it's possible to force a specified exception to occur. 
</p>
<p>
Let's look at a simple example. Assuming we want to ask the user to enter an integer number. If we use a
input(), the input will be a string, which we have to cast into an integer. If the input has not been 
a valid integer, we will generate (raise) a ValueError. We show this in the following interactive session:
<pre>
>>> n = int(input("Please enter a number: "))
Please enter a number: 23.5
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
ValueError: invalid literal for int() with base 10: '23.5'
</pre>
With the aid of exception handling, we can write robust code for reading an integer from input:
<pre>
while True:
    try:
        n = input("Please enter an integer: ")
        n = int(n)
        break
    except ValueError:
        print("No valid integer! Please try again ...")
print("Great, you successfully entered an integer!")
</pre>
It's a loop, which breaks only, if a valid integer has been given.
<br>
The example script works like this:<br>
The while loop is entered. The code within the try clause will be executed statement by statement.
If no exception occurs during the execution, the execution will reach the break statement and the while
loop will be left. If an exception occurs, i.e. in the casting of n, the rest of the try block will
be skipped and the execpt clause will be executed. The raised error, in our case a ValueError, has to match 
one of the names after except. In our example only one, i.e. "ValueError:". After having printed the text
of the print statement, the execution does another loop. It starts with a new input().
<br><br>
An example usage could look like this:
<br>
<pre>
$ python integer_read.py 
Please enter an integer: abc
No valid integer! Please try again ...
Please enter an integer: 42.0
No valid integer! Please try again ...
Please enter an integer: 42
Great, you successfully entered an integer!
$
</pre> 
</p>
<br>
<h3>Multiple Except Clauses</h3>
<p>
A try statement may have more than one except clause for different exceptions. But at most one except clause
will be executed.
</p>
<p>
Our next example shows a try clause, in which we open a file for reading, read a line from this file and convert
this line into an integer. There are at least two possible exceptions: 
<ul>
<li>an IOError</li>
<li>ValueError</li>
</ul>
Just in case we have an additional unnamed except clause for an unexspected error:
<pre>
import sys

try:
    f = open('integers.txt')
    s = f.readline()
    i = int(s.strip())
except IOError as (errno, strerror):
    print("I/O error({0}): {1}".format(errno, strerror))
except ValueError:
    print("No valid integer in line.")
except:
    print("Unexpected error:", sys.exc_info()[0])
    raise
</pre> 
The handling of the IOError in the previous example is of special interest. The IOError returns a tuple with
an error number and a string with the error message, which we assign to the variables errno and strerror by 
"except IOError as (errno, strerror)".
<br>
If we call the above script with a non-existing file, we get the message:
<pre>
I/O error(2): No such file or directory
</pre>
And if the file integers.txt is not readable, e.g. if we don't have the permission to read it, we get the 
following message:
<pre>
I/O error(13): Permission denied
</pre> 
An except clause may name more than one execption in a tuple of error names, as we see in the following example:
<pre>
try:
    f = open('integers.txt')
    s = f.readline()
    i = int(s.strip())
except (IOError, ValueError):
    print("An I/O error or a ValueError occurred")
except:
    print("An unexpected error occurred")
    raise
</pre>
</p>
<br><br>
<h3>Custom-made Exceptions</h3>

It's possible to create Exceptions yourself:

<pre>
>>> raise SyntaxError("Sorry, my fault!")
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt
SyntaxError: Sorry, my fault!
</pre>

The best or the Pythonic way to do this, consists in defining an 
exception class which inherits from the Exception class.
You will have to go through the chapter on "Object Oriented Programming" to fully
understand the following example:

<pre>
class MyException(Exception):
    pass

raise MyException("An exception doesn't always prove the rule!")
</pre>

If you start this program, you will get the following result:

\begin{lstlisting}
$ python3 exception_eigene_klasse.py 
Traceback (most recent call last):
  File "exception_eigene_klasse.py", line 4, in &lt;module&gt;
    raise MyException("Was falsch ist, ist falsch!")
__main__.MyException: An exception doesn't always prove the rule!
\end{lstlisting}
<br><br>
<h3>Clean-up Actions (try ... finally)</h3>
So far the try statement had always been paired with except clauses. But there is another way to use it as well. 
The try 
statement can be followed by a finally clause. Finally clauses are called clean-up or termination clauses, because
they must be executed under all circumstances, i.e. a "finally" clause is always executed regardless if an exception 
occurred in a try block or not.
<br>
A simple example to demonstrate the finally clause:
<pre>
try:
    x = float(input("Your number: "))
    inverse = 1.0 / x
finally:
    print("There may or may not have been an exception.")
print("The inverse: ", inverse)
</pre>
Let's look at the output of the previous script, if we first input a correct number and after this a string, which
is raising an error:
<pre>
bernd@venus:~/tmp$ python finally.py 
Your number: 34
There may or may not have been an exception.
The inverse:  0.0294117647059
bernd@venus:~/tmp$ python finally.py 
Your number: Python
There may or may not have been an exception.
Traceback (most recent call last):
  File "finally.py", line 3, in &lt;module&gt;
    x = float(input("Your number: "))
ValueError: invalid literal for float(): Python
bernd@venus:~/tmp$ 
</pre>
<br><br>
<h3>Combining try, except and finally</h3>
"finally" and "except" can be used together for the same try block, as can be seen the following Python example:
<pre>
try:
    x = float(input("Your number: "))
    inverse = 1.0 / x
except ValueError:
    print("You should have given either an int or a float")
except ZeroDivisionError:
    print("Infinity")
finally:
    print("There may or may not have been an exception.")
</pre>
The output of the previous script, if saved as "finally2.py", for various values looks like this:
<pre>
bernd@venus:~/tmp$ python finally2.py 
Your number: 37
There may or may not have been an exception.
bernd@venus:~/tmp$ python finally2.py 
Your number: seven 
You should have given either an int or a float
There may or may not have been an exception.
bernd@venus:~/tmp$ python finally2.py 
Your number: 0
Infinity
There may or may not have been an exception.
bernd@venus:~/tmp$ 
</pre>
<br><br>
<h3>else Clause</h3>
The try ... except statement has an optional else clause. An else block has to be positioned after all the except 
clauses. An else clause will be executed if the try clause doesn't raise an exception.
<br><br>
The following example opens a file and reads in all the lines into a list called "text":
<pre>
import sys
file_name = sys.argv[1]
text = []
try:
    fh = open(file_name, 'r')
    text = fh.readlines()
    fh.close()
except IOError:
    print('cannot open', file_name)

if text:
    print(text[100])
</pre>

This example receives the file name via a command line argument. So make sure, that you call it properly:
Let's assume that you saved this program as "exception_test.py". In this case, you have to call it with 
<pre>
python exception_test.py integers.txt
</pre>
If you don't want this behaviour, just change the line "file_name = sys.argv[1]" to "file_name = 'integers.txt'".
<br><br>
The previous example is nearly the same as:
<pre>
import sys
file_name = sys.argv[1]
text = []
try:
    fh = open(file_name, 'r')
except IOError:
    print('cannot open', file_name)
else:
    text = fh.readlines()
    fh.close()

if text:
    print(text[100])
</pre>
The main difference is, that in the first case, all statements of the try block can lead to the same error 
message "cannot open ...", which is wrong, if fh.close() or fh.readlines() raise an error.
<br><br>
<br>
<div id="contextlinks">Previous Chapter: <a href="python3_generators.php">Iterators and Generators</a><br>
<LINK rel="prev" href="python3_generators.php">Next Chapter: <a href="python3_object_oriented_programming.php">Object Oriented Programming</a><br>
<LINK rel="next" href="python3_object_oriented_programming.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
