<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: Inheritance Example</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Example of Inheritance in Python implementing a Clock and a Calendar." />
<meta name="Keywords" content="Python, course, object oriented programming, inheritance, clock, calendar" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/ClockCalendar_small.png" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<h3>Inheritance</h3>
Merriam-Webster's definition of inheritance:
<br>
<ol compact style="margin-left: -1em;">
<li>
  <ol type=a style="margin-left: -2em;">
  <li>the act of inheriting property</li>
  <li>the reception of genetic qualities by transmission from parent to offspring</li>
  <li>the acquisition of a possession, condition, or trait from past generations</li>
  </ol>
</li>
<li>
	<ol type=a style="margin-left: -2em;">
	<li>Tradition</li>	
	<li>a valuable possession that is a common heritage from nature</li>	
	</ol>
</li>
</ol>
 

<br>
<br>
<hr>
<br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Canada, the US, and Europe</a>
<br>
<hr>
<h3>Clocks and Calendars</h3>
<i>"I must govern the clock, not be governed by it."</i>
<br>
(Golda Meir)
<br><br>
<i>
"We must not allow the clock and the calendar to blind us to the fact that each moment 
of life is a miracle and mystery."
</i>
<br>
(H.G. Wells)
<br><br>
The famous novel 1984 by George Orwell starts with clocks out-of-order:
<br>
<i>
"It was a bright cold day in April, and the clocks were striking thirteen."
</i>


</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
<h3>Python 2.7</h3>This tutorial deals with Python Version 2.7<br>This chapter from our course is available in a version for Python3: <a href="python3_inheritance_example.php">Inheritance Example</a><h3>Python Training Courses</h3>
<p>

<p>If you  want to learn Python fast and efficiently, you should consider a 
<a href="http://www.bodenseo.com/courses.php?topic=Python">
<img class="imgright" src="images/radolfzell_segel_bodenseo_logo.jpg" alt="Bodenseo logo" />
<br>Python Training course</a> at Bodenseo. There are also
 special seminars for advanced students like the 
 <a href="http://w ww.bodenseo.com/course/python_xml_training_course.html">Python & XML Training Course</a>.
 If you want to acquire special knowledge in Text Processing and Text Classification, then  
<a href="http://www.bodenseo.com/course/python_text_processing_course.html">"Python Text Processing 
Course"</a> will be the right one for you.
<br>
All the Python seminars are available in German as well: 
<a href="http://www.bodenseo.de/kurse.php?topic=Python">Python-Kurse</a>"
<br><br>
You can also book Bernd Klein for <a href="python_classes.php">onsite training courses</a>



<br><br>
<h3>Inheritance in Python</h3>

One of the greatest advantages of object oriented programming (OOP) is the 
possibility of reuse of code. One way to achieve this consists in using inheritance. 
 



</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="object_oriented_programming.php">Object Oriented Programming</a><br>
<LINK rel="prev" href="object_oriented_programming.php"></div>
<h2>Inheritance Example</h2>
<br><br>
<p>
<h3>Introduction</h3>
<img class="imgright" src="images/ClockCalendar.png" alt="Clock Calendar Class Inheritance" />



There aren't many good examples on inheritance available on the web. They are either extremely 
simple and artificial or they are way to complicated.  We want to close the gap by providing an
example which is on the one hand more realistic - but still not realistic - and on the other 
hand simple enough to see and understand the basic aspects of inheritance. In our previous chapter, 
we introduced inheritance formally. 
<br><br>
To this purpose we define two base classes: One is an implementation of a clock and the other 
one of a calendar. Based on these two classes, we define a class CalendarClock, which inherites
both from the class Calendar and from the class Clock.


<h3>The Clock Class</h3>

<pre>
class Clock(object):

    def __init__(self,hours=0, minutes=0, seconds=0):
        self.__hours = hours
        self.__minutes = minutes
        self.__seconds = seconds

    def set(self,hours, minutes, seconds=0):
        self.__hours = hours
        self.__minutes = minutes
        self.__seconds = seconds

    def tick(self):
        """ Time will be advanced by one second """
        if self.__seconds == 59:
            self.__seconds = 0
            if (self.__minutes == 59):
                self.__minutes = 0
                self.__hours = 0 if self.__hours==23  else self.__hours+1
	    else:
		self.__minutes += 1;
	else:
            self.__seconds += 1;

    def display(self):
        print("%d:%d:%d" % (self.__hours, self.__minutes, self.__seconds))

    def __str__(self):
        return "%2d:%2d:%2d" % (self.__hours, self.__minutes, self.__seconds)

x = Clock()
print(x)
for i in xrange(10000):
    x.tick()
print(x)
</pre>

<br><br>
<h3>The Calendar Class</h3>

<pre>
class Calendar(object):
    months = (31,28,31,30,31,30,31,31,30,31,30,31)

    def __init__(self, day=1, month=1, year=1900):
        self.__day = day
        self.__month = month
        self.__year = year

    def leapyear(self,y):
	if y % 4:
	   # not a leap year
	   return 0;
	else:
	   if y % 100:
	     return 1;
           else:
	     if y % 400:
                return 0
	     else:
		return 1;

    def set(self, day, month, year):
        self.__day = day
        self.__month = month
        self.__year = year


    def get():
	return (self, self.__day, self.__month, self.__year)
    def advance(self):
        months = Calendar.months
	max_days = months[self.__month-1]
	if self.__month == 2:
		max_days += self.leapyear(self.__year)
	if self.__day == max_days:
		self.__day = 1
		if (self.__month == 12):
			self.__month = 1
			self.__year += 1
		else:
			self.__month += 1
	else:
		self.__day += 1


    def __str__(self):
       return str(self.__day)+"/"+ str(self.__month)+ "/"+ str(self.__year)

if __name__ == "__main__":
   x = Calendar()
   print(x)
   x.advance()
   print(x)
</pre>

<br><br>
<h3>The Calendar-Clock Class</h3>
<pre>
from clock import Clock
from calendar import Calendar

class CalendarClock(Clock, Calendar):

   def __init__(self, day,month,year,hours=0, minutes=0,seconds=0):
        Calendar.__init__(self, day, month, year)
        Clock.__init__(self, hours, minutes, seconds)

   def __str__(self):
       return Calendar.__str__(self) + ", " + Clock.__str__(self)


if __name__  == "__main__":
   x = CalendarClock(24,12,57)
   print(x)
   for i in range(1000):
      x.tick()
   for i in range(1000):
      x.advance()
   print(x)
</pre>


<br><br>
<div id="contextlinks">Previous Chapter: <a href="object_oriented_programming.php">Object Oriented Programming</a><br>
<LINK rel="prev" href="object_oriented_programming.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
