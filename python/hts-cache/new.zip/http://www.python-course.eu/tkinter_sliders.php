<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: Sliders in Tkinter</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction into Tkinter: Introduction into Sliders" />
<meta name="Keywords" content="Python, Tkinter, Tk, Introduction, course, tutorial, sliders" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li class="active"><a id="current" href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/sliders.jpg" alt="box" />    <h2>Tkinter Tutorial</h2>

<div class="menu">

<ul>
<li><a href="tkinter_labels.php">Saying Hello with Labels</a></li><li><a href="tkinter_message_widget.php">Message Widget</a></li><li><a href="tkinter_buttons.php">Buttons</a></li><li><a href="tkinter_variable_classes.php">Variable Classes</a></li><li><a href="tkinter_radiobuttons.php">Radiobuttons</a></li><li><a href="tkinter_checkboxes.php">Checkboxes</a></li><li><a href="tkinter_entry_widgets.php">Entry Widgets</a></li><li><a href="tkinter_canvas.php">Canvas Widgets</a></li><li><a href="tkinter_sliders.php">Sliders</a></li><li><a href="tkinter_text_widget.php">Text Widget</a></li><li><a href="tkinter_dialogs.php">Dialogs</a></li><li><a href="tkinter_layout_management.php">Layout Management</a></li><li><a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a></li><li><a href="tkinter_menus.php">Creating Menus</a></li><li><a href="tkinter_events_binds.php">Events and Binds</a></li></ul>

</div>

<p>
<br><br>

<h3>Science Fiction Sliders</h3>
Do you know, that "Sliders" was an American science fiction TV series? It was broadcast between 1995 and 2000. 
The series is about a group of travellers which uses a wormhole to "slide" between different parallel universes.
<br><br>
Another slider which has nothing to do with Tkinter: The seventh album by the British rock band T. Rex, released in
1972, is called "The Slider". It included the hits "Telegram Sam" and "Metal Guru"

<br><br>
<hr>
<br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>


<hr>
We also like to thank Denise Mitchinson for providing the stylesheet of this website.<br>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python_tkinter.php">Sliders / Schieberegler in Tkinter</a>
<h3>Classroom Trainings</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his live <a href="python_classes.php">Python classes</a>
<br>
If you are interested in an instructor-led classroom training course,
you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python and 
Tkinter courses <br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo


<h3>Quote of the Day:</h3>
<p>

Man is the best computer we can put aboard a spacecraft...and the only one that can be mass produced with unskilled labor.<br> (Wernher von Braun)
<br>
<br>
<h3>Graphical User Interface</h3>
A graphical user interface (GUI) is a type of user interface that allows users to interact 
with electronic devices in a graphical way, i.e. with images, rather than text commands.
Originally interactive user interfaces to computers were not graphical, they were text  
oriented and usually consisted of commands, which had to be remembered. 
The DOS operating system from Microsoft and the Bourne shell under Linux are examples
of such user-computer interfaces. 


 </p>

</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="tkinter_canvas.php">Canvas Widgets</a><br>
<LINK rel="prev" href="tkinter_canvas.php">Next Chapter: <a href="tkinter_text_widget.php">Text Widget</a><br>
<LINK rel="next" href="tkinter_text_widget.php"></div>
<h2>Sliders</h2>
<br>
<h3>Introduction</h3>
<img class="imgright" src="images/mixer_with_sliders.jpg" alt="Sliders on a mixer" />
A slider is a Tkinter object with which a user can set a value by moving an indicator. Sliders can be vertically
or horizontally arranged. A slider is created with the Scale method(). 
<br><br>
Using the Scale widget creates a graphical object, which allows the user to select a numerical 
value by moving a knob along a scale of a range of values. The minimum and maximum values can be set as parameters,
 as well as the resolution. We can also determine if we want the slider vertically or horizontally positioned. 
A Scale widget is a good alternative to an Entry widget, if the user is supposed to put in a number from a
finite range, i.e. a bounded numerical value.
<br><br>
<h3>A Simple Example</h3>
<pre>
from Tkinter import *

master = Tk()
w = Scale(master, from_=0, to=42)
w.pack()
w = Scale(master, from_=0, to=200, orient=HORIZONTAL)
w.pack()

mainloop()
</pre>
If we start this script, we get a window with a vertical and a horizontal slider:
<br><br>
<img src="images/horizontal_and_vertical_sliders.png" alt="Horizontal and vertical sliders" />
<br><br>
<h3>Accessing Slider Values</h3>
We have demonstrated in the previous example how to create sliders. But it's not enough to have a slider,
we also need a method to query it's value. We can accomplish this with the get method. We extend the previous
example with a Button to view the values. If this button is pushed, the values of both sliders is printed into 
the terminal from which we have started the script:
<br><br>
<pre>
from Tkinter import *

def show_values():
    print (w1.get(), w2.get())

master = Tk()
w1 = Scale(master, from_=0, to=42)
w1.pack()
w2 = Scale(master, from_=0, to=200, orient=HORIZONTAL)
w2.pack()
Button(master, text='Show', command=show_values).pack()

mainloop()
</pre>

<br><br>
<h3>Initializing Sliders</h3>
A slider starts with the minimum value, which is 0 in our examples. There is a way to initialize Sliders with 
the set(value) method:
<pre>
from Tkinter import *

def show_values():
    print (w1.get(), w2.get())

master = Tk()
w1 = Scale(master, from_=0, to=42)
w1.set(19)
w1.pack()
w2 = Scale(master, from_=0, to=200, orient=HORIZONTAL)
w2.set(23)
w2.pack()
Button(master, text='Show', command=show_values).pack()

mainloop()
</pre>
<br><br>
The previous script creates the following window, if it is called:
<br><br>
<img src="images/improved_slider_example.png" alt="IMproved Slider Example" />
<br><br>
<h3>tickinterval and length</h3>
If the option tickinterval is set to a number, the ticks of the scale will be 
displayed as multiples of that value. We add a tickinterval to our previous example.
<br><br>
<pre>
from Tkinter import *

def show_values():
    print (w1.get(), w2.get())

master = Tk()
w1 = Scale(master, from_=0, to=42, tickinterval=8)
w1.set(19)
w1.pack()
w2 = Scale(master, from_=0, to=200,tickinterval=10, orient=HORIZONTAL)
w2.set(23)
w2.pack()
Button(master, text='Show', command=show_values).pack()

mainloop()
</pre>
If we start this program, we recognize that the vertical slider has the values 0, 8, 16, 24, 32, 40 added to 
its left side. The horizontal slider has also the numbers 0,10,20, 30, ..., but we can't see them, because the 
get smeared on top of each other, because the slider is not long enough:
<br><br>
<img src="images/smeared_tickintervals.png" alt="Illegible tickintervals" />
<br><br>
To solve this problem we have to increase the length of our horizontal slider. We set the option length. length
defines the x dimension, if the scale is horizontal and the y dimension, if the scale is vertical. So we change
the definition of w2 in the following way:
<br><br<
<pre>
w2 = Scale(master, from_=0, to=200, length=600,tickinterval=10, orient=HORIZONTAL)
</pre>
<br><br>
The result looks like this:
<br><br>
<img src="images/slider_length_increased.png" alt="Increasing the length of a slider" />




<br><br>
</div>
<div id="contextlinks">Previous Chapter: <a href="tkinter_canvas.php">Canvas Widgets</a><br>
<LINK rel="prev" href="tkinter_canvas.php">Next Chapter: <a href="tkinter_text_widget.php">Text Widget</a><br>
<LINK rel="next" href="tkinter_text_widget.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
