<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>GUI Programming with Python: Layout Management in Tkinter</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Layout management under Tkinter and Python using pack, grid and place" />
<meta name="Keywords" content="Python, Tkinter, Tk, Introduction, course, tutorial, pack, grid, place, layout, layout management" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li class="active"><a id="current" href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/packed_suitcases_110.jpg" alt="box" />    <h2>Tkinter Tutorial</h2>

<div class="menu">

<ul>
<li><a href="tkinter_labels.php">Saying Hello with Labels</a></li><li><a href="tkinter_message_widget.php">Message Widget</a></li><li><a href="tkinter_buttons.php">Buttons</a></li><li><a href="tkinter_variable_classes.php">Variable Classes</a></li><li><a href="tkinter_radiobuttons.php">Radiobuttons</a></li><li><a href="tkinter_checkboxes.php">Checkboxes</a></li><li><a href="tkinter_entry_widgets.php">Entry Widgets</a></li><li><a href="tkinter_canvas.php">Canvas Widgets</a></li><li><a href="tkinter_sliders.php">Sliders</a></li><li><a href="tkinter_text_widget.php">Text Widget</a></li><li><a href="tkinter_dialogs.php">Dialogs</a></li><li><a href="tkinter_layout_management.php">Layout Management</a></li><li><a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a></li><li><a href="tkinter_menus.php">Creating Menus</a></li><li><a href="tkinter_events_binds.php">Events and Binds</a></li></ul>

</div>

<p>
<br>

<h3>Definition</h3>
Layout in computing is seen as the process of calculating the position of objects subject to a 
number of constraints. 
<br><br>
<hr>
<br><br>
<i>"Almost all quality improvement comes via simplification of design, manufacturing... 
layout, processes, and procedures."</i><br>
(Tom Peters, author of "In Search of Excellence")
<br><br>

<hr>
<br><br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/tkinter_layout_management.php">Layout-Manager und Layout-Management  in Tkinter</a>

<h3>Classroom Trainings</h3>Tutorial
<p>
This website contains a free and extensive online tutorial by Bernd Klein. 
You can attend one of his <a href="python_classes.php">Python courses</a> in Paris,
London, Berlin, Munich or Lake Constance.
<br><br>

A fast and efficient approach to learn Python and Tkinter consists in attending a
<a href="http://www.bodenseo.com/courses.php?topic=Python">classroom training courses 
<br><img style="width: 150px;" 
alt="Bodenseo, Python courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.

<br>
<font size="1">� kabliczech - Fotolia.com</font>
<h3>Quote of the Day:</h3>
<p>

<i>We can only see a short distance ahead, but we can see plenty there that needs to be done.</i>
<br>Alan Turing
<br>
<h3>Graphical User Interface</h3>
A graphical user interface (GUI) is a type of user interface that allows users to interact 
with electronic devices in a graphical way, i.e. with images, rather than text commands.
Originally interactive user interfaces to computers were not graphical, they were text  
oriented and usually consisted of commands, which had to be remembered. 
The DOS operating system from Microsoft and the Bourne shell under Linux are examples
of such user-computer interfaces. 


 </p>

</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="tkinter_dialogs.php">Dialogs</a><br>
<LINK rel="prev" href="tkinter_dialogs.php">Next Chapter: <a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a><br>
<LINK rel="next" href="tkinter_mastermind.php"></div>
<h2>Layout Managers / Geometry Manager</h2>
<br>
<h3>Introduction</h3>
<img class="imgright" src="images/packed_suitcases.jpg" alt="Packed Suitcases, from Wikipedia, Public Domain, Sherlock_Holmes_Museum" />

In this chapter of our Python-Tkinter tutorial we will introduce the layout managers 
or geometry managers, as they are sometimes called as well. Tkinter possess three layout 
managers:
<ul>
<li>pack<br>

</li>
<li>grid</li>
<li>place</li>
</ul>
The three layout managers pack, grid, and place should never be mixed in the same master window!


Geometry managers serve various functions. They:
<ul>
<li>arrange widgets on the screen</li>
<li>register widgets with the underlying windowing system 
<li>manage the display of widgets on the screen</li>
</ul>

Arranging widgets on the screen includes determining the size and position of components. Widgets can 
provide size and alignment information to geometry managers, but the geometry managers has always the 
final say on the positioning and sizing.

<br><br>


<h3>Pack</h3>
Pack is the easiest to use of the three geometry managers of Tk and Tkinter. Instead of having to declare precisely
where a widget should appear on the display screen, we can declare the positions of widgets with the pack command
relative to each other. The pack command takes care of the details. Though the pack command is easier to use, this
layout managers is limited in its possibilities compared to the grid and place mangers. For simple applications
it is definitely the manager of choice. For example simple applications like placing a number of widgets side by side,
or on top of each other.
<br><br>
Example:
<br>
<pre>
from Tkinter import *

root = Tk()

Label(root, text="Red Sun", bg="red", fg="white").pack()
Label(root, text="Green Grass", bg="green", fg="black").pack()
Label(root, text="Blue Sky", bg="blue", fg="white").pack()

mainloop()
</pre>
<br>
<img src="images/packing1.png" alt="Packing some labels" /> 
<br><br>
<h4>fill Option</h4>
In our example, we have packed three labels into the parent widget "root". We used pack() without any options.
So pack had to decide which way to arrange the labels. As you can see, it has chosen to place the label widgets
on top of each other and centre them. Furthermore, we can see, that each label has been given the size of the text. 
If you want to make the widgets as wide as the parent widget, you have to use the fill=X option:
<br><br>
<pre>
from Tkinter import *

root = Tk()

w = Label(root, text="Red Sun", bg="red", fg="white")
w.pack(fill=X)
w = Label(root, text="Green Grass", bg="green", fg="black")
w.pack(fill=X)
w = Label(root, text="Blue Sky", bg="blue", fg="white")
w.pack(fill=X)

mainloop()
</pre>

<img src="images/packing2.png" alt="Packing labels and filling horizontally" /> 
<br><br>
<h4>Padding</h4>
The pack() manager knows four padding options, i.e. internal and external padding and padding in x and y direction:
<br><br>
<table>
<td width="20%" valign="top">padx</td>
<td valign="top">External padding, horizontally
<br><br>
<img src="images/pack_padx.png" alt="Packing labels with the option padx" />
<br><br>
The code for the window above:
<br>
<pre>
from Tkinter import *
root = Tk()
w = Label(root, text="Red Sun", bg="red", fg="white")
w.pack(fill=X,padx=10)
w = Label(root, text="Green Grass", bg="green", fg="black")
w.pack(fill=X,padx=10)
w = Label(root, text="Blue Sky", bg="blue", fg="white")
w.pack(fill=X,padx=10)
mainloop()
</pre>
</td>
</tr>
<tr>
<td valign="top">pady</td>
<td valign="top">External padding, vertically<br><br>
<img src="images/pack_pady.png" alt="Packing labels with the option padx" />
<br><br>
The code for the window above:
<br>
<pre>
from Tkinter import *
root = Tk()
w = Label(root, text="Red Sun", bg="red", fg="white")
w.pack(fill=X,pady=10)
w = Label(root, text="Green Grass", bg="green", fg="black")
w.pack(fill=X,pady=10)
w = Label(root, text="Blue Sky", bg="blue", fg="white")
w.pack(fill=X,pady=10)
mainloop()
</pre>

</td>
</tr>

<tr>
<td valign="top">ipadx</td>
<td valign="top">Internal padding, horizontally.
<br><br>
In the following example, we change only the label with the text "Green Grass", so that
the result can be easier recognized. We have also taken out the fill option.
<br><br>
<img src="images/pack_ipadx.png" alt="Packing labels using ipadx" />
<br><br>
<pre>
from Tkinter import *
root = Tk()
w = Label(root, text="Red Sun", bg="red", fg="white")
w.pack()
w = Label(root, text="Green Grass", bg="green", fg="black")
w.pack(ipadx=10)
w = Label(root, text="Blue Sky", bg="blue", fg="white")
w.pack()
mainloop()
</pre>


</td>
</tr>
<tr>
<td valign="top">ipady</td>
<td valign="top">Internal padding, vertically
<br><br>
We will change the last label of our previous example to ipady=10.
<br><br>
<img src="images/pack_ipadx_ipady.png" alt="Packing labels using ipadx" />
<br><br>

<pre>
from Tkinter import *
root = Tk()
w = Label(root, text="Red Sun", bg="red", fg="white")
w.pack()
w = Label(root, text="Green Grass", bg="green", fg="black")
w.pack(ipadx=10)
w = Label(root, text="Blue Sky", bg="blue", fg="white")
w.pack(ipady=10)
mainloop()
</pre>
</td>
</tr>
<tr>
</table>
The default value in all cases is 0.
<br><br>
<h4>Placing widgets side by side</h4>
We want to place the three label side by side now and shorten the text slightly:
<br><br>
<img src="images/pack_side_left.png" alt="Packing labels side by side" />
<br><br>
The corresponding code looks like this:
<br><br>
<pre>
from Tkinter import *

root = Tk()

w = Label(root, text="red", bg="red", fg="white")
w.pack(padx=5, pady=10, side=LEFT)
w = Label(root, text="green", bg="green", fg="black")
w.pack(padx=5, pady=20, side=LEFT)
w = Label(root, text="blue", bg="blue", fg="white")
w.pack(padx=5, pady=20, side=LEFT)

mainloop()
</pre>
<br><br>
If we change LEFT to RIGHT in the previous example, we get the colours in reverse order:
<br><br>
<img src="images/pack_side_right.png" alt="Packing labels side by side right" />

<br><br>
<h3>Place Geometry Manager</h3>
The Place geometry manager allows you explicitly set the position and size of a window, either in absolute 
terms, or relative to another window. The place manager can be accessed through the place method. It can be
applied to all standard widgets.
<br><br>
We use the place geometry manager in the following example. We are playing around with colours in this example,
i.e. we assign to every label a different colour, which we randomly create using the randrange method of the
random module. We calculate the brightness (grey value) of each colour. If the brightness is less than 120, we
set the foreground colour (fg) of the label to White otherwise to black, so that the text can be easier read. 
<br><br>
<pre>
import Tkinter as tk
import random
    
root = tk.Tk()
# width x height + x_offset + y_offset:
root.geometry("170x200+30+30") 
     
languages = ['Python','Perl','C++','Java','Tcl/Tk']
labels = range(5)
for i in range(5):
   ct = [random.randrange(256) for x in range(3)]
   brightness = int(round(0.299*ct[0] + 0.587*ct[1] + 0.114*ct[2]))
   ct_hex = "%02x%02x%02x" % tuple(ct)
   bg_colour = '#' + "".join(ct_hex)
   l = tk.Label(root, 
                text=languages[i], 
                fg='White' if brightness < 120 else 'Black', 
                bg=bg_colour)
   l.place(x = 20, y = 30 + i*30, width=120, height=25)
          
root.mainloop()
</pre>
<br><br>
<img src="images/tkinter_place.png" alt="example place geometry manager" />
<br><br>
<h3>Grid Manager</h3>
The first geometry manager of Tk had been pack. The algorithmic behaviour of pack is not easy to understand and
it can be difficult to change an existing design. Grid was introduced in 1996 as an alternative to pack. Though
grid is easier to learn and to use and produces nicer layouts, lots of developers keep using pack.
<br><br>
Grid is in many cases the best choice for general use. While pack is sometimes not sufficient for changing 
details in the layout, place gives you complete control of positioning each element, but this makes it a lot
more complex than pack and grid.
<br><br>
The Grid geometry manager places the widgets in a 2-dimensional table, which consists of a number of rows and 
columns. The position of a widget is defined by a row and a column number. Widgets with the same column number
and different row numbers will be above or below each other. Correspondingly, widgets with the same row number
but different column numbers will be on the same "line" and will be beside of each other, i.e. to the left 
or the right.
<br><br>
Using the grid manager means that you create a widget, and use the grid method to tell the manager in which 
row and column to place them. The size of the grid doesn't have to be defined, because the manager automatically 
determines the best dimensions for the widgets used.
<h4>Example with grid</h4>
<pre>
from Tkinter import *

colours = ['red','green','orange','white','yellow','blue']

r = 0
for c in colours:
    Label(text=c, relief=RIDGE,width=15).grid(row=r,column=0)
    Entry(bg=c, relief=SUNKEN,width=10).grid(row=r,column=1)
    r = r + 1

mainloop()
</pre>
<img src="images/tkinter_grid.png" alt="example with the grid geometry manager" />



<br><br>
</div>
<div id="contextlinks">Previous Chapter: <a href="tkinter_dialogs.php">Dialogs</a><br>
<LINK rel="prev" href="tkinter_dialogs.php">Next Chapter: <a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a><br>
<LINK rel="next" href="tkinter_mastermind.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
