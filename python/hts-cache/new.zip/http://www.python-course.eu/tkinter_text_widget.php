<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>GUI Programming with Python: Text Widget</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial and Introduction on Tkinter: Text input for web applications with Text widges" />
<meta name="Keywords" content="Python, Tkinter, Tk, Introduction, course, tutorial, text, texts, input, window, windows, widget, widgets" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li class="active"><a id="current" href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/open_book_small.png" alt="box" />    <h2>Tkinter Tutorial</h2>

<div class="menu">

<ul>
<li><a href="tkinter_labels.php">Saying Hello with Labels</a></li><li><a href="tkinter_message_widget.php">Message Widget</a></li><li><a href="tkinter_buttons.php">Buttons</a></li><li><a href="tkinter_variable_classes.php">Variable Classes</a></li><li><a href="tkinter_radiobuttons.php">Radiobuttons</a></li><li><a href="tkinter_checkboxes.php">Checkboxes</a></li><li><a href="tkinter_entry_widgets.php">Entry Widgets</a></li><li><a href="tkinter_canvas.php">Canvas Widgets</a></li><li><a href="tkinter_sliders.php">Sliders</a></li><li><a href="tkinter_text_widget.php">Text Widget</a></li><li><a href="tkinter_dialogs.php">Dialogs</a></li><li><a href="tkinter_layout_management.php">Layout Management</a></li><li><a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a></li><li><a href="tkinter_menus.php">Creating Menus</a></li><li><a href="tkinter_events_binds.php">Events and Binds</a></li></ul>

</div>

<p>
<br>

<h3>Text in Real Life</h3>
<i>"The first forty years of life give us the text; the next thirty 
supply the commentary on it. "</i>
(Arthur Schopenhauer
<br><br>
<h3>Text in Literature</h3>
<i>"Literature is not exhaustible, for the sufficient and simple reason 
that a single book is not. A book is not an isolated entity: it is a narration, 
an axis of innumerable narrations. One literature differs from another, either 
before or after it, not so much because of the text as for the manner in
 which it is read. "</i>
<br>
(Jorge Luis Borges)
<br><br>
<hr>
<br>
Supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo, courses and 
seminars in Linux and Python"
		     src="images/bodenseo_python_training.gif"><br>Python Training Courses and Seminars </a>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/tkinter_textfelder.php">Textfelder in Tkinter</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein with 
material from his live <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training course, you may have a look at the 
<a href="http://ca.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<br>
<font size="1">� kabliczech - Fotolia.com</font>


<br>
<h3>Quote of the Day:</h3>
<p>

<i>"Any program is only as good as it is useful."</i> (Linus Torvalds)<br>
<h3>Graphical User Interface</h3>
A graphical user interface (GUI) is a type of user interface that allows users to interact 
with electronic devices in a graphical way, i.e. with images, rather than text commands.
Originally interactive user interfaces to computers were not graphical, they were text  
oriented and usually consisted of commands, which had to be remembered. 
The DOS operating system from Microsoft and the Bourne shell under Linux are examples
of such user-computer interfaces. 


 </p>

</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="tkinter_sliders.php">Sliders</a><br>
<LINK rel="prev" href="tkinter_sliders.php">Next Chapter: <a href="tkinter_dialogs.php">Dialogs</a><br>
<LINK rel="next" href="tkinter_dialogs.php"></div>
<h2>Text Widgets</h2>
<br>
<h3>Introduction and Simple Examples</h3>
<img class="imgright" src="images/open_book.png" alt="open Book, Open Clipart" />
<br>
A text widget is used for multi-line text area. The Tkinter text widget is very powerful and flexible 
and can be used for a wide range of tasks. Though one of the main purposes is to provide simple multi-line areas,
as they are often used in forms, text widgets can also be used as simple text editors or even web browsers.  
<br><br>
Furthermore, text widgets can be used to display links, images, and HTML, even using CSS styles.
<br><br>In most other tutorials and text books, it's hard to find a very simple and basic example of a text widget.
That's why we want to start our chapter with a such an example:
<br><br>
We create a text widget by using the Text() method. We set the height to 2, i.e. two lines and the width to 30, i.e.
30 characters. We can apply the method insert() on the object T, which the Text() method had returned, to include
text. We add two lines of text.
<br><br> 
<pre>
from Tkinter import *

root = Tk()
T = Text(root, height=2, width=30)
T.pack()
T.insert(END, "Just a text Widget\nin two lines\n")
mainloop()
</pre>

<br><br>
The result should not be very surprising:
<br><br>
<img src="images/text_widget_simple.png" alt="Simple Text Widget" />

<br><br>
Let's change our little example a tiny little bit. We add another text, the beginning of the famous monologue
from Hamlet:
<pre>
from Tkinter import *

root = Tk()
T = Text(root, height=2, width=30)
T.pack()
quote = """HAMLET: To be, or not to be--that is the question:
Whether 'tis nobler in the mind to suffer
The slings and arrows of outrageous fortune
Or to take arms against a sea of troubles
And by opposing end them. To die, to sleep--
No more--and by a sleep to say we end
The heartache, and the thousand natural shocks
That flesh is heir to. 'Tis a consummation
Devoutly to be wished."""
T.insert(END, quote)
mainloop()
</pre>
<br>
If we start our little script, we get a very unsatisfying result. We can see in the window only the first line
of the monologue and this line is even broken into two lines. We can see only two lines in our window, because we
set the height to the value 2. Furthermpre, the width is set to 30, so Tkinter has to break the first line of the monologue
after 30 characters.
<br><br>
<img src="images/text_widget_simple_hamlet.png" alt="Simple Text Widget" />
<br><br>
One solution to our problem consists in setting the height to the number of lines of our monologue and set width wide 
enough to display the widest line completely.
<br><br>
But there is a better technique, which you are well acquainted with from your browser and other applications: scrolling
<br><br>


<h3>Scrollbars</h3>
So let's add a scrollbar to our window. To this purpose, Tkinter provides the Scrollbar() method. We call it with 
the root object as the only parameter.

<pre>
from Tkinter import *

root = Tk()
S = Scrollbar(root)
T = Text(root, height=4, width=50)
S.pack(side=RIGHT, fill=Y)
T.pack(side=LEFT, fill=Y)
S.config(command=T.yview)
T.config(yscrollcommand=S.set)
quote = """HAMLET: To be, or not to be--that is the question:
Whether 'tis nobler in the mind to suffer
The slings and arrows of outrageous fortune
Or to take arms against a sea of troubles
And by opposing end them. To die, to sleep--
No more--and by a sleep to say we end
The heartache, and the thousand natural shocks
That flesh is heir to. 'Tis a consummation
Devoutly to be wished."""
T.insert(END, quote)
mainloop(  )
</pre>
<br><br>
The result is a lot better. We have now always 4 lines in view, but all lines can be viewed by using the scrollbar on the
right side of the window:
<br><br>

<img src="images/text_widget_simple_scollbar.png" alt="Simple Text Widget with scrollbar" />
<br><br>
<h3>Text Widget with Image</h3>
In our next example, we add an image to the text and bind a command to a text line:

<pre>
from Tkinter import *

root = Tk()

text1 = Text(root, height=20, width=30)
photo=PhotoImage(file='./William_Shakespeare.gif')
text1.insert(END,'\n')
text1.image_create(END, image=photo)

text1.pack(side=LEFT)

text2 = Text(root, height=20, width=50)
scroll = Scrollbar(root, command=text2.yview)
text2.configure(yscrollcommand=scroll.set)
text2.tag_configure('bold_italics', font=('Arial', 12, 'bold', 'italic'))
text2.tag_configure('big', font=('Verdana', 20, 'bold'))
text2.tag_configure('color', foreground='#476042', 
						font=('Tempus Sans ITC', 12, 'bold'))
text2.tag_bind('follow', '<1>', lambda e, t=text2: t.insert(END, "Not now, maybe later!"))
text2.insert(END,'\nWilliam Shakespeare\n', 'big')
quote = """
To be, or not to be, that is the question:
Whether 'tis Nobler in the mind to suffer
The Slings and Arrows of outrageous Fortune,
Or to take Arms against a Sea of troubles,
"""
text2.insert(END, quote, 'color')
text2.insert(END, 'follow-up\n', 'follow')
text2.pack(side=LEFT)
scroll.pack(side=RIGHT, fill=Y)

root.mainloop()
</pre>
<br><br>
<img src="images/text_widget_with_image.png" alt="Text Widget with image" />


<br><br>
</div>
<div id="contextlinks">Previous Chapter: <a href="tkinter_sliders.php">Sliders</a><br>
<LINK rel="prev" href="tkinter_sliders.php">Next Chapter: <a href="tkinter_dialogs.php">Dialogs</a><br>
<LINK rel="next" href="tkinter_dialogs.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
