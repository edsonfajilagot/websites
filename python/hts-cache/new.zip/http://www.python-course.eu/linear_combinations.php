<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Advanced: Linear Combinations</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Calculating linear combinations for finite sets of terms and constants in Python" />
<meta name="Keywords" content="Python, linear combinations, finite sets, constants,program, script,implementation" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li class="active"><a id="current" href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/weights_small.png" alt="box" />    <h2>Advanced Topics</h2>

<div class="menu">

<ul>
<li><a href="sys_module.php">Introduction into the sys module</a></li><li><a href="os_module_shell.php">Python and the Shell</a></li><li><a href="forking.php">Forks and Forking in Python</a></li><li><a href="threads.php">Introduction into Threads</a></li><li><a href="pipes.php">Pipe, Pipes and "99 Bottles of Beer"</a></li><li><a href="graphs_python.php">Graph Theory and Graphs in Python"</a></li><li><a href="pygraph.php">Graphs: PyGraph"</a></li><li><a href="networkx.php">Graphs: NetworkX"</a></li><li><a href="finite_state_machine.php">Finite State Machine in Python</a></li><li><a href="turing_machine.php">Turing Machine in Python</a></li><li><a href="numpy.php">NumPy Module</a></li><li><a href="matrix_arithmetic.php">Matrix Arithmetic</a></li><li><a href="linear_combinations.php">Linear Combinations</a></li><li><a href="text_classification_introduction.php">Introduction into Text Classification using Naive Bayes</a></li><li><a href="text_classification_python.php">Python Implementation of Text Classification</a></li><li><a href="towers_of_hanoi.php">Example for recursive Programming: Towers of Hanoi</a></li><li><a href="mastermind.php">Mastermind / Bulls and Cows</a></li><li><a href="dynamic_websites_wsgi.php">Creating dynamic websites with WSGI</a></li><li><a href="dynamic_websites.php">Dynamic websites with mod_python</a></li><li><a href="pylons.php">Dynamic websites with Pylons</a></li><li><a href="sql_python.php">Python, SQL, MySQL and SQLite</a></li><li><a href="python_scores.php">Python Scores</a></li></ul>

</div>

<p>
<h3>Mythology</h3>
The first great achievement of Apollo was to slay the huge serpent Python. In some texts 
Python is an enormous dragon and not a serpent. 
<br>  
But who was this mythical creature? Python was created out of the slime and mud left after 
the great flood. She was  appointed by Gaia (Mother Earth) to guard the oracle of Delphi, 
known as Pytho. After having defeated Python Apollo remade
her former home and the oracle as his own.
<br>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
<h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>"It is easier to write an incorrect program than understand a correct one. "</i> (Alan Perlis)<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="matrix_arithmetic.php">Matrix Arithmetic</a><br>
<LINK rel="prev" href="matrix_arithmetic.php">Next Chapter: <a href="text_classification_introduction.php">Introduction into Text Classification using Naive Bayes</a><br>
<LINK rel="next" href="text_classification_introduction.php"></div>
<h2>Linear Combination</h2>
<h3>Definitions</h3>
<p>
<img class="imgright" src="images/weights.png" alt="Weights, based on Public Domain image" />  
A linear combination in mathematics is an expression constructed from a set of terms by multiplying 
each term by a constant and adding the results.
<br><br>
Example of a linear combination:
<br>
a &middot x + b &middot y is a linear combination of x and y with a and b constants.
<br><br>
Generally;
<br>
p = &lambda;<sub>1</sub> &middot; x<sub>1</sub> + &lambda;<sub>2</sub> &middot; 
x<sub>2</sub> &hellip; &lambda;<sub>n</sub> &middot; x<sub>n</sub>
<br>
p is the scalar product of the values x<sub>1</sub>, x<sub>2</sub> &hellip; x<sub>n</sub> and  
&lambda;<sub>1</sub>, &lambda;<sub>2</sub> &hellip; &lambda;<sub>n</sub> are called scalars.
<br>In most applications x<sub>1</sub>, x<sub>2</sub> &hellip; x<sub>n</sub> are vectors and 
the lambdas are
integers or real numbers. (For those, who prefer it mor formally:  x<sub>1</sub>, x<sub>2</sub> &hellip;
x<sub>n</sub> &isin; V and V is a vector space, and  
&lambda;<sub>1</sub>, &lambda;<sub>2</sub> &hellip; &lambda;<sub>n</sub> &isin; K with K being a field)
<br><br>
<h3>Linear Combinations in Python</h3> 

The vector y = (3.21, 1.77, 3.65) can be easily written as a linear combination of the unit vectors
(0,0,1), (0,1,0) and (1,0,0):
<br><br>
 (3.21, 1.77, 3.65) = 3.21 &middot; (1,0,0) + 1.77   (0,1,0) + 3.65 &middot; (0,0,1)
<br><br>
We can do the calculation with Python, using the module numpy:
<pre>
>>> import numpy as np
>>> x = np.array([[0,0,1],[0,1,0],[1,0,0]])
>>> y = ([3.65,1.55,3.42])
>>> scalars = np.linalg.solve(x,y)
>>> scalars
array([ 3.42,  1.55,  3.65])
>>> 
</pre>

The previous example was very easy, because we could work out the result in our head. What about writing our
vector y = (3.21, 1.77, 3.65) as a linear combination of the vectors
(0,1,1), (1,1,0) and (1,0,1)? It looks like this in Python:
<br>
<pre>
>>> import numpy as np
>>> x = np.array([[0,1,1],[1,1,0],[1,0,1]])
>>> y = ([3.65,1.55,3.42])
>>> scalars = np.linalg.solve(x,y)
>>> scalars
array([ 0.66,  0.89,  2.76])
>>> 
</pre> 
<br>
<h3>Another Example</h3>
Any integer between -40 and 40 can be written as a linear combination of 1,3,9,27 with scalars being elements
of the set {-1,0,1}. 
<br>
For example:
<br>
7 = 1 &middot; 1 +  (-1) &middot; 3 + 1 &middot; 9 + 0 &middot; 27
<br><br>
We can calculate these scalars with Python. First we need a generator generating all the possible scalar
combinations. If you have problems in understanding the concept of a generator, we recommend the chapter 
"<a href="python3_generators.php">Iterators and Generators</a>" of our tutorial.
<br>
<pre>
def factors_set():
    factors_set = ( (i,j,k,l) for i in [-1,0,1] 
                          for j in [-1,0,1]
                          for k in [-1,0,1]
                          for l in [-1,0,1])
    for factor in factors_set:
        yield factor
</pre>

<br><br>
We will use the memoize() technique (see chapter "<a href="python3_memoization.php">Memoization and Decorators</a>" of out tuorial) to memorize previous results:
<pre>
def memoize(f):
    results = {}
    def helper(n):
        if n not in results:
            results[n] = f(n)
        return results[n]
    return helper
</pre>

<br><br>
Finally, in our function linear_combination() we check every scalar tuple, if it can create the value n:

<pre>
@memoize
def linear_combination(n):
    """ returns the tuple (i,j,k,l) satisfying
        n = i*1 + j*3 + k*9 + l*27      """
    weighs = (1,3,9,27)
      
    for factors in factors_set():
       sum = 0
       for i in range(len(factors)):
          sum += factors[i] * weighs[i]
       if sum == n:
          return factors
</pre>
<br><br>
Putting it all together results in the following script:
<pre>
def factors_set():
    factors_set = ( (i,j,k,l) for i in [-1,0,1] 
                          for j in [-1,0,1]
                          for k in [-1,0,1]
                          for l in [-1,0,1])
    for factor in factors_set:
        yield factor

def memoize(f):
    results = {}
    def helper(n):
        if n not in results:
            results[n] = f(n)
        return results[n]
    return helper

@memoize
def linear_combination(n):
    """ returns the tuple (i,j,k,l) satisfying
        n = i*1 + j*3 + k*9 + l*27      """
    weighs = (1,3,9,27)
      
    for factors in factors_set():
       sum = 0
       for i in range(len(factors)):
          sum += factors[i] * weighs[i]
       if sum == n:
          return factors

# calculate the linear combinations of the first 10 positive integers:
for i in range(1,11):
	print(linear_combination(i))
</pre>
<br><br>
Calling this program returns the following results:
<pre>
(1, 0, 0, 0)
(-1, 1, 0, 0)
(0, 1, 0, 0)
(1, 1, 0, 0)
(-1, -1, 1, 0)
(0, -1, 1, 0)
(1, -1, 1, 0)
(-1, 0, 1, 0)
(0, 0, 1, 0)
(1, 0, 1, 0)
</pre>

</p>


<div id="contextlinks">Previous Chapter: <a href="matrix_arithmetic.php">Matrix Arithmetic</a><br>
<LINK rel="prev" href="matrix_arithmetic.php">Next Chapter: <a href="text_classification_introduction.php">Introduction into Text Classification using Naive Bayes</a><br>
<LINK rel="next" href="text_classification_introduction.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
