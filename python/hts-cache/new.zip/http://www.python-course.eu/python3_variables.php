<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: A Tutorial</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Data Types and Variables in Python; defining and declaring variables" />
<meta name="Keywords" content="Python, data, types, variables, strings, definition, defining, declaration, declaring" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/containers100.jpg" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<hr>
<h3>Data</h3>
<i>"The primary purpose of the Data statement is to give names to constants; 
instead of referring to pi as 3.141592653589793 at every appearance, the 
variable Pi can be given that value with a Data statement and used instead 
of the longer form of the constant. This also simplifies modifying the program, 
should the value of pi change."</i>
(Fortran manual for Xerox Computers)
<br>

<h3>Definition of a Variable</h3>
Having the ability or capacity to change or vary. Being capable of alternation in various ways,
such as variable seasons or variable winds, e.g. a shifting wind varying in force.
<br><br>
<hr>
<br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung: 
    <a href="http://www.python-kurs.eu/python3_variablen.php">Variablen und Datentypen</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="variables.php"> in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="variables.php"> in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_blocks.php">Indentation</a><br>
<LINK rel="prev" href="python3_blocks.php">Next Chapter: <a href="python3_operators.php">Operators</a><br>
<LINK rel="next" href="python3_operators.php"></div>
<h2>Data Types and Variables</h2>
<h3>Introduction</h3>
You have programmed low-level languages like C, C++ or other similar programming languages?
Therefore, you might think you know already enough about data types and variables? 
You know a lot, that's right, but not enough for Python. So it's worth to go on reading this 
chapter on data types and variables in Python. There is a dodgy differences
in the way Python and C deal with variables. There are integers, floating point numbers, strings, 
and many more, but things are not the same as in C or C++.
<br><br>
If you want to use lists or associative arrays in C e.g., you will have to construe the data tpye list 
or associative arrays from scratch, i.e. design memory structure and the allocation management. 
You will have to implement the necessary search and access methods as well.   
Python provides power data types like lists and associative arrays, called dict in Python, 
as a genuine part of the language.
<br><br>
So, this chapter is worth reading both for beginners and for advanced programmers in other programming
languages.
<h3>Variables</h3>
      <p>
<img class="imgleft" src="images/containers300.jpg" alt="variables seen as containers" />
As the name implies, a variable is something which can change. A variable is a way of referring 
to a memory location used by a computer program. 
A variable is a symbolic name for this physical location. This memory location contains values, 
like numbers, text or more complicated types. We can use this variable to tell the computer
save some data in this location or to retrieve some data from this location.
<br><br>
A variable can be seen as a container (or some say a pigeonhole) to store certain values. 
While the program is running, variables are accessed and sometimes changed, i.e. a new value 
will be assigned to a variable.
<br><br>
One of the main differences between Python and strongly-typed languages like C, C++ or Java
is the way it deals with types. In strongly-typed languages every variable must have a unique 
data type. E.g. if a variable is of type integer, solely integers can be saved in the variable during
the duration of the the program. In Java or C, every variable has to be declared before it can be 
used. Declaring a variable means binding it to a data type.
<br><br>
It's a lot easier in Python. There is no declaration of variables required in Python. It's not even
possible. If there is need of a variable, you think of a name and start using it as a variable.
<br><br>
Another remarkable aspect of Python: Not only the value of a variable may change during program 
execution but the type as well. You can assign an integer value to a variable, use it as an integer
for a while and then assign a string to the same variable.
<br>In the following line of code, we assign the value 42 to a variable i:
<pre>
i = 42
</pre>
The equal "=" sign in the assignment shouldn't be seen as an "equal sign". It should be "read" or
interpreted as "is set to", meaning in our example "the variable i is set to 42". Now we will increase
the value of this variable by 1: 
<br>
<pre>
>>> i = i + 1
>>> print(i)
43
>>> 
</pre>
<br>
<h3>Variables vs. Identifiers</h3>
The terms variables and identifiers are very often erroneously used synonymously. 
Simply put, the name of a variable is an identifier, but a variable is "more 
than a name". A variable has many aspects. It is a name, in most cases a type, 
a scope, and above all a value.
Besides this, an identifier is not only used for variables. An identifier can
denote various entities like variables, types, labels, subroutines or functions,
packages and so on. 

<h3>Naming Identifiers of Variables</h3>
Every language has rules for naming identifiers. The rules in Python3 are the
following:
<br><br>
A valid identifier is a non-empty sequence of characters of any length with:
<ul>
<li>
the start character of an identifier can be the underscore "_" or a capital 
or lower case letter. Letter in Python3 mean any letter - even those from 
non-English languages like the German Umlaute "�", "�".
</li>
<li>
the characters following the start character can be anything which is permitted 
as a start character plus the digits. Digit is, what Unicode considers to be a 
digit. Some non-whitespace characters are allowed as well.
</li>
<li>
Just a warning for Windows-spoilt users: Identifiers are case-sensitive
</li>
<li>
Python keywords are not allowed as identifier names
</li>
</ul>
The naming conventions for variable identifiers have been extended in Python3.  

<h3>Python Keywords</h3>


No identifier can have the same name as one of the Python keywords, although they
are obeying the above naming conventions:
<br>
<i>
and, as, assert, break, class, continue, def, del, elif, else, except, finally, 
for, from, global, if, import, in, is, lambda, nonlocal, not, or, pass, raise, 
return, try, while, with, yield
</i>



<h3>Changing Data Types and Storage Locations</h3>
Programming means data processing. Data in a Python program is represented by objects. These objects 
can be
<ul>
<li>built-in, i.e. objects provided by Python, or</li>
<li>objects from extension libraries or</li>
<li>created in the application by the programmer.</li>
</ul>
So we have different "kinds" of objects for different data types. We will have a look at the different
built-in data types in Python. 

<h3>Numbers</h3>
<p>
Python's built-in core data types are in some cases also called object types.  
There are four built-in data types for numbers:
<ul>
<li>Integer
<ul>
<li>Normal integers<br>e.g. 4321
<li>Octal literals (base 8)<br>A number prefixed by 0o (zero and a lowercase "o" or uppercase "O") will be interpreted as an octal number<br>example:<br>
<code>
<font size="3" color="#4D711B">
>>> a = 0o10<br>
>>> print(a)<br>
8
</font>
</code>
</li>
<li>Hexadecimal literals (base 16)<br>
Hexadecimal literals have to be prefixed either by "0x" or "0X".<br>
example:<br>
<code>
<font size="3" color="#4D711B">
>>> hex_number = 0xA0F<br>
>>> print(hex_number)<br>
2575
</font>
</code>
</li>
<li>Binary literals (base 2)<br>
Binary literals can easily be written as well. They have to be prefixed by a leading "0", followed
by a "b" or "B":<br>
<code>
<font size="3" color="#4D711B">
>>> x = 0b101010
>>> x
42
>>> 
</font>
</code>
</li>
</ul>
The functions hex, bin, oct can be used to to convert an integer number into the corresponding 
string representation of the integer number:
<code>
<font size="3" color="#4D711B">
>>> x = hex(19)
>>> x
'0x13'
>>> type(x)
&lt;class 'str'&gt;
>>> x = bin(65)
>>> x
'0b1000001'
>>> x = oct(65)
>>> x
'0o101'
>>> oct(0b101101)
'0o55'
>>> 
</font>
</code>

Integers in Python3 can be of unlimeted size<br>
<pre>
>>> x = 787366098712738903245678234782358292837498729182728
>>> print(x)
787366098712738903245678234782358292837498729182728
>>> x * x * x
488123970070638215986770162105731315538827586091948617997871122950228891123960901918308618286311523282239313708275589787123005317148968569797875581092352
>>> 
</pre>

<li>Long integers<br>
Python 2 has two integer types: int and long. There is no "long int" in Python3 anymore. There is only one "int" type, which contains both "int" and "long" from Python2.  This means that the following code fails in Python 3:

<pre>
>>> 1L
  File "&lt;stdin&gt;", line 1
    1L
     ^
SyntaxError: invalid syntax
>>> x = 43
>>> long(x)
Traceback (most recent call last):
  File "&lth;stdin&gt;", line 1, in &lt;module&gt;
NameError: name 'long' is not defined
>>> 
</pre>


</li>
<li>Floating-point numbers<br>for example: 42.11, 3.1415e-10</li>
<li>Complex numbers<br>
Complex numbers are written as <code>
<font size="3" color="#4D711B"> 
<i>&lt;real part&gt;</i> + <i>&lt;imaginary part&gt;</i>j</i><br>
examples:<br>
<code><font size="3" color="#4D711B"> 
>>> x = 3 + 4j<br>
>>> y = 2 - 3j<br>
>>> z = x + y<br>
>>> print(z)<br>
(5+1j)
</font></code>
</li>
</font>
</code>
<br>  
    </ul>

 </p>
<h3>Strings</h3>
<p>
The task of the first-generation computers in the fourties and fifties had been - due to technical restraints -
focussed on number processing. Text processing had been just a dream that time. Nowadays, one of the main tasks 
of computers is text processing in all its varieties; the most prominent applications are search engines like 
Google. To enable text processing programming languages need suitable data types. Strings are used in all modern
programming languages to store and process textual information. Logically, a string - like any text - is a sequence
of characters. The question remains what a character consists of. In a book, or in a text like the one your are 
reading now, characters consist of graphical shapes, so-called graphemes, consisting of lines, curves and 
crossings in certain angles or positions and so on. The ancient Greeks associated with the word the engraving 
on coins or the stamps on seals. 
<br>
<br>
<img class="imgright" src="images/character_A.png" alt="The letter A in various Fonts / Graphemes" />
In computer science or computer technology, a character is a unit of information. 
These Characters correspond to graphemes, the fundamental units of written or printed language.
Before Unicode came into usage, there was a one to one relationship between bytes and characters, i.e. every
character - of a national variant, i.e. not all the characters of the world - was represented by a single byte.
Such a character byte represents the logical concept of this character and the class of graphemes of this character.
In the image on the right side, we have depicted various representations of the letter "A", i.e. "A" in different 
fonts. So in printing there are various graphical representations or different "encodings" of the abstract concept of
the letter A. (By the way, the letter "A" can be ascribed to an Egyptian hieroglyph with a pictogram of an ox.) 
All of these graphical
representations having certain features in common. In other words, the meaning of a character or a written or 
printed text doesn't depend on the font or writing style used. On a computer the capital A is encoded in binary 
form. If we use ASCII it is encoded - like all the other characters - as the byte 65. 
<br>
ASCII is restricted to 256 bytes or characters. This is enough for languages like English, German and French, but
by far not sufficient for Chinese, Japanese and Korean. That's where Unicode gets into the game. Unicode is a 
standard designed to represent every character from every language, i.e. it can handle any text of the world's 
writing systems. These writing systems can also be used simultaneously, i.e. Roman alphabet mixed with cyrillic
or even Chinese characters. Each letter or character is represented by Unicode as a 4-byte number. E.g. "A"  has
the value U+0041. While ASCII is restricted to 256 characters per encoding, Unicode has virtually no real limitiation.
Theoretically, there are 256<sup>4</sup> (more than 4.29 millions, due to coding restrictions there are "only" 1,112,064 
characters possible) characters  possible. In fact with a little bit
more than 100,000 characters specified less than 1 % of the Unicode number space is used. But there remains the 
question of how to encode Unicode characters. We could use 4 bytes per character which would be a one to one 
mapping from Unicode to the encoding. But this is a waste of memory space; every previous ASCII document would
be 4 times as large in Unicode. There are different encodings for Unicode:

<table style="text-align: left; width: 100%;" border="1" cellpadding="2"
cellspacing="2">
<tbody>
   <tr>
      <th COLSPAN="2">
         <H3><BR>Unicode Encodings</H3>
      </th>
   </tr>
   <tr>
      <th>Name</th>
      <th>Description</th>
   </th>
   
<tr>
<td style="vertical-align: top;">UTF-32<br>
</td>
<td style="vertical-align: top;">It's a one to one encoding, i.e. it takes each Unicode character (a 4-byte number) 
and stores it in 4 bytes. One advantage of this encoding is that you can find the Nth character of a string in 
linear time, because the Nth character starts at the 4�Nth byte. A serious disadvantage of this approach is due
to the fact that it needs four bytes for every character.<br>
</td>
</tr>

<tr>
<td style="vertical-align: top;">UTF-16<br>
</td>
<td style="vertical-align: top;">Hardly anybody needs more than 65535 characters, so UTF-16, which needs 2 bytes,
is a more space efficient alternative to UTF-32. But it is very difficult to access characters outside the range
0 - 65535, i.e. characters from the so-called "astral plane"<br>Another problem of both UTF-32 and UTF-16 consists
in the byte ordering, which is depending on the operating system.
</td>
</tr>

<tr>
<td style="vertical-align: top;">UTF-8<br>
</td>
<td style="vertical-align: top;">UTF8 is a variable-length encoding system for Unicode, i.e. different characters
take up a different number of bytes. ASCII characters use solely one byte per character, which are even the same
as the used to be for the first 128 characters (0�127), i.e. these characters in UTF-8 are indistinguishable 
from ASCII.  But the so-called "Extended Latin" characters like the Umlaute �, � and so on take up two bytes. 
Chinese characters need  three bytes. Finally, the very seldom used characters of the "astral plane" 
need four bytes to be encoded in UTF-8.
<br>A Disadvantage of this approach is that finding the Nth character is more complex, 
the longer the string, the longer it takes to find a specific character. 
<br>
</td>
</tr>


</tbody>
</table>

<h3>String, Unicode and Python</h3>
After this lengthy but necessary introduction, we finally come to python and the way it deals with strings.
All strings in Python 3 are sequences of "pure" Unicode characters, no specific encoding like UTF-8.
<br><br>
Strings are defined by quotes:
<ul>
<li>single quotes (')<br>
'This is a string with single quotes'
<li>double quotes (")<br>
"Obama's dog is called Bo""
<li>triple quotes, both single (''') and (""")<br>
'''String in triple quotes can extend <br>
over multiple lines, like this on, and can contain<br>
'single' and "double" quotes.'''  
</ul>

A string in Python consists of a series or sequence of characters - letters, numbers, 
and special characters. Strings can be subscripted or indexed. Similar to C, the first 
character of a string has has the index 0. There exists no character type in Python. A 
character is simply a string of size one. 
 
<br><br>
<img class="img" src="images/string_indices.gif" width="200" alt="String Indexing or subscripting" /> 
<br>
It's possible to start counting the indices from the right. In this case negative numbers are used, 
starting with -1 for the most right character.
<br><br>
<img class="img" src="images/string_indices_negative.png" width="200" alt="Negative String indices from the right" /> 

<h4>Some operators and functions for strings</h4>
<ul>
<li><b>Concatenation</b><br>
Strings can be glued together (concatenated) with the + operator:<br>
     "Hello" + "World" -> "HelloWorld"
<li><b>Repetition</b><br>
String can be repeated or repeatedly concatenated with the asterisk operator "*":<br>
"*-*" * 3        -> "*-**-**-*"
<li><b>Indexing</b><br>
     "Python"[0]         -> "P"
<li><b>Slicing</b><br>
Substrings can be created with the slice or slicing notation, i.e. two indices in square 
brackets separated by a colon:
<br>
     "Python"[2:4]       -> "th"
     <br><br>
     <img class="img" src="images/string_slicing.png" width="200" alt="String Slicing" />
     <br><br>
<li><b>Size</b><br>
     len("Python")       -> 6
</ul>

<h3>Immutable Strings</h3>
Like strings in Java and unlike C or C++, Python strings cannot be changed. Trying to change
an indexed position will raise an error:
<pre>
>>> s = "Some things are immutable!"
>>> s[-1] = "."
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
TypeError: 'str' object does not support item assignment
>>> 
</pre>

<h3>A String Pecularity</h3>
Strings show a special effect, which we will illustrate in the following example. 
We will need the "is"-Operator. If both a and b are strings, "a is b" checks 
if they have the same identity, i.e. share the same memory location. If "a is b" is True,
then is trivially follows  that "a == b" has to be True as well. 
But "a == b" True doesn't imply that "a is b" is True as well!
<br>
Let's have a look at how strings are stored in Python:
<pre>
>>> a = "Linux"
>>> b = "Linux"
>>> a is b
True
</pre>
Okay, but what happens, if the strings are longer? We use the longest village name in the world in the 
following example. It's a small village with about 3000 inhabitants in the South of the island of 
Anglesey in the Nort-West of Wales:
<pre>
>>> a = "Llanfairpwllgwyngyllgogerychwyrndrobwllllantysiliogogogoch"
>>> b = "Llanfairpwllgwyngyllgogerychwyrndrobwllllantysiliogogogoch"
>>> a is b
True
</pre>
Nothing has changed to our first "Linux" example. But what works for Wales doesn't work e.g. for  
Baden-W�rttemberg in Germany:
<pre>
>>> a = "Baden-W�rttemberg"
>>> b = "Baden-W�rttemberg"
>>> a is b
False
>>> a == b
True
</pre>
You are right, it has nothing to do with geographical places. The special character, i.e. the hyphen, is 
to "blame".

<pre>
>>> a = "Baden!"
>>> b = "Baden!"
>>> a is b
False
>>> a = "Baden1"
>>> b = "Baden1"
>>> a is b
True
</pre>
 
</p>

<h4>Escape Sequences in Strings</h4>
To end our coverage of string in this chapter, we will introduce some escape characters and sequences. 
The backslash (\) character is used to escape characters, i.e. to "escape" the special meaning, 
which this character would otherwise have. Examples for such characters are newline, backslash itself, 
or the quote character. String literals may optionally be prefixed with a letter 'r' or 'R'; 
these strings are called raw strings. Raw strings use different rules for interpreting backslash 
escape sequences.
<br><br>
<table  cellpadding="6" cellspacing="0" border="1" bgcolor="#F5F5F5">
<th>Escape Sequence</th><th>Meaning 	Notes</td></th>
<tr></tr>
<tr><td>\newline</td><td>Ignored </td></tr>	 
<tr><td>\\</td><td> 	Backslash (\) 	</td></tr> 
<tr><td>\'</td><td> 	Single quote (') 	</td></tr> 
<tr><td>\"</td><td> 	Double quote (") 	</td></tr> 
<tr><td>\a </td><td>	ASCII Bell (BEL) 	 </td></tr>
<tr><td>\b </td><td>	ASCII Backspace (BS) </td></tr>	 
<tr><td>\f </td><td>	ASCII Formfeed (FF) 	</td></tr> 
<tr><td>\n </td><td>	ASCII Linefeed (LF) 	</td></tr> 
<tr><td>\N{name} </td><td>	Character named name in the Unicode database (Unicode only)</td></tr> 	 
<tr><td>\r </td><td>	ASCII Carriage Return (CR) 	</td></tr> 
<tr><td>\t </td><td>	ASCII Horizontal Tab (TAB) 	</td></tr> 
<tr><td>\uxxxx </td><td>	Character with 16-bit hex value xxxx (Unicode only)</td></tr>
<tr><td>\Uxxxxxxxx </td><td>	Character with 32-bit hex value xxxxxxxx (Unicode only)</td></tr>
<tr><td>\v </td><td>	ASCII Vertical Tab (VT) 	</td></tr> 
<tr><td>\ooo </td><td>	Character with octal value ooo </td></tr>
<tr><td>\xhh </td><td>	Character with hex value hh</td></tr>
</table>
<br>

<h3>Byte Strings</h3>
Python 3.0 uses the concepts of text and (binary) data instead of Unicode strings and 8-bit strings. 
Every string or text in Python 3 is Unicode, but encoded Unicode is represented as binary data. 
The type used to hold text is str, the type used to hold data is bytes. 
It's not possible to mix text and data in Python 3; it will raise TypeError.
<br>
While a string object holds a sequence of characters (in Unicode), a bytes object holds a 
sequence of bytes, out of the range 0 .. 255, representing the ASCII values.
<br>
Defining bytes objects and casting them into strings:
<pre>
>>> x = b"Hallo"
>>> t = str(x)
>>> u = t.encode("UTF-8")
</pre>

<h3>Variable Types</h3>

As we have said above, the type of a variable can change during the execution of a script. Or to be precise: 
A new object, which can be of any type, will be assigned to it. We illustrate this in our following example: <br> 
<br>

<pre>
i = 42				# data type is implicitly set to integer
i = 42 + 0.11		# data type is changed to float
i = "fourty"		# and now it will be a string  
</pre>

Python automatically takes care of the physical representation for the different data types, i.e.
an integer values will be stored in a different memory location than a float or a string.
<br><br>
What's happening, when we make assignments. Let's look at the following piece of code:
<pre>
>>> x = 3
>>> y = x
>>> y = 2
</pre>
<img class="imgright" src="images/variable_memory.gif" alt="Variables and memory locations" />
The first assignment is unproblematic: Python chooses a memory location for x and saves the 
integer value 3. The second assignment is more worthwhile: Intuitively, you may assume that
Python will find another location for the variable y and will copy the value of 3 in this 
place. But Python goes his own way, which differs from our intuition and the ways of C and C++.
As both variables will have the same value after the assignment, Python lets y point to the
memory location of x.<br>
The critical question arises in the next line of code. Y will be set to the integer value 2. 
What will happen to the value of x? C programmers will assume, that x will be changed to 2 as well,
because we said before, that y "points" to the location of x. But this is not a C-pointer.
Because x and y will not share the same value anymore, y gets his or her own memory location,
containing 2 and x sticks to 3, as can be seen in the animated graphics on the right side.
<br><br>
But what we said before can't be determined by typing in those three lines of code. But how can
we prove it? The identity function id() can be used for this purpose. Every instance (object or 
variable) has an identity, i.e. an integer which is unique within the script or program, i.e. 
other objects have different identities.
<br>So, let's have a look at our previous example and how the identities will change:
<pre>
>>> x = 3
>>> print(id(x))
137220896
>>> y = x
>>> print(id(y))
137220896
>>> y = 2
>>> print(id(y))
137220880
>>> print(id(x))
137220896
>>> 
</pre>
<br>
<h3>Integer Division</h3>
Integer division has been a continous source of errors in previous versions, i.e. before Python3.  Let's divide
 10 by 3 in Python 2.6.5:
 <pre>
 $ python
Python 2.6.5 (r265:79063, Apr 16 2010, 13:57:41) 
[GCC 4.4.3] on linux2
Type "help", "copyright", "credits" or "license" for more information.
>>> 10 / 3
3
>>> 
</pre>
<br>
Though being logical, it's not what most people expect. The idea is, that we are dividing an integer
by an integer so the result should be an integer again. This is done by "floor division", i.e. 
truncating fractional digits. No rounding is used, as we can see:
<pre>
$ python
Python 2.6.5 (r265:79063, Apr 16 2010, 13:57:41) 
[GCC 4.4.3] on linux2
Type "help", "copyright", "credits" or "license" for more information.
>>> 11 / 3
3
>>> 
</pre>
To avoid this, Python3 performs "true" division, i.e. integer by integer results in a float number:
<pre>
$ python3
Python 3.1.2 (r312:79147, Sep 27 2010, 09:57:50) 
[GCC 4.4.3] on linux2
Type "help", "copyright", "credits" or "license" for more information.
>>> x = 11
>>> y = 3
>>> z = x / y
>>> type(z)
&lt;class 'float'&gt;
>>> print(z)
3.66666666667
>>> z = 12
>>> z = x / y
>>> type(z)
&lt;class 'float'&gt;
>>> print(z)
3.66666666667
>>> 
</pre>

If you need integer division in Python3, you have to use floor division "//" explicitly:
<pre>
$ python3
Python 3.1.2 (r312:79147, Sep 27 2010, 09:57:50) 
[GCC 4.4.3] on linux2
Type "help", "copyright", "credits" or "license" for more information.
>>> z = 10 // 3
>>> type(z)
&lt;class 'int'&gt;
>>> print(z)
3
>>> 
</pre>



</p>


<br>
<br>


<div id="contextlinks">Previous Chapter: <a href="python3_blocks.php">Indentation</a><br>
<LINK rel="prev" href="python3_blocks.php">Next Chapter: <a href="python3_operators.php">Operators</a><br>
<LINK rel="next" href="python3_operators.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
