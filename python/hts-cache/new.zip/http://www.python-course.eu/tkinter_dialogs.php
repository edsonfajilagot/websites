<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>GUI Programming with Python: Dialogs in Tkinter</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction into the standard dialogues of Tkinter." />
<meta name="Keywords" content="Python, Tkinter, Tk, Introduction, course, tutorial, standard, dialogues, dialogs" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li class="active"><a id="current" href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/dialogues_110.png" alt="box" />    <h2>Tkinter Tutorial</h2>

<div class="menu">

<ul>
<li><a href="tkinter_labels.php">Saying Hello with Labels</a></li><li><a href="tkinter_message_widget.php">Message Widget</a></li><li><a href="tkinter_buttons.php">Buttons</a></li><li><a href="tkinter_variable_classes.php">Variable Classes</a></li><li><a href="tkinter_radiobuttons.php">Radiobuttons</a></li><li><a href="tkinter_checkboxes.php">Checkboxes</a></li><li><a href="tkinter_entry_widgets.php">Entry Widgets</a></li><li><a href="tkinter_canvas.php">Canvas Widgets</a></li><li><a href="tkinter_sliders.php">Sliders</a></li><li><a href="tkinter_text_widget.php">Text Widget</a></li><li><a href="tkinter_dialogs.php">Dialogs</a></li><li><a href="tkinter_layout_management.php">Layout Management</a></li><li><a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a></li><li><a href="tkinter_menus.php">Creating Menus</a></li><li><a href="tkinter_events_binds.php">Events and Binds</a></li></ul>

</div>

<p>
<br>
<br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
<br>
<h3>Definition</h3>
A dialogue can be a conversation between two or more persons; particularly, a formal conservation 
in theatrical performances or in scholastic exercises. It is also a written composition in which 
two or more persons are represented as conversing or reasoning on some topic; as, the Dialogues of Plato.
<br><br>
In Tkinter or Tk (or more generally in GUI programming) a dialogue is the interaction between the
user of the GUI and the program through special widgets.
<br><br>
Alfred Hitchcock wrote about a different kind of dialogue: 
<i>"Dialogue should simply be a sound among other sounds, just something that comes out 
of the mouths of people whose eyes tell the story in visual terms."</i>
<br>(Alfred Hitchcock)

<hr>
<br>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/tkinter_dialoge.php">Dialoge in Tkinter</a>
<h3>Classroom Trainings</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his live <a href="python_classes.php">Python classes</a>
<br>
If you are interested in an instructor-led classroom training course,
you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python and 
Tkinter courses <br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo


<h3>Quote of the Day:</h3>
<p>

<i>We can only see a short distance ahead, but we can see plenty there that needs to be done.</i>
<br>Alan Turing
<br>
<h3>Graphical User Interface</h3>
A graphical user interface (GUI) is a type of user interface that allows users to interact 
with electronic devices in a graphical way, i.e. with images, rather than text commands.
Originally interactive user interfaces to computers were not graphical, they were text  
oriented and usually consisted of commands, which had to be remembered. 
The DOS operating system from Microsoft and the Bourne shell under Linux are examples
of such user-computer interfaces. 


 </p>

</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="tkinter_text_widget.php">Text Widget</a><br>
<LINK rel="prev" href="tkinter_text_widget.php">Next Chapter: <a href="tkinter_layout_management.php">Layout Management</a><br>
<LINK rel="next" href="tkinter_layout_management.php"></div>
<h2>Dialogues and Message Boxes</h2>
<br>
<h3>Introduction</h3>
<img class="imgright" src="images/dialogues.png" alt="Dialogues" />
Tkinter (and TK of course) provides a set of dialogues (dialogs in American English spelling),
which can be used to display message boxes, showing warning or errors, or widgets to 
select files and colours. There are also simple dialogues, asking the user to enter string, integers 
or float numbers. 
<br><br>
Let's look at a typical GUI Session with Dialogues and Message boxes.
There might be a button starting the dialogue, like the "quit" button in the following window:
<br><br>
<img src="images/dialog1.png" alt="Window with quit and answer button" />
<br><br>
Pushing the "quit" button raises the Verify window:
<br><br>
<img src="images/dialog2.png" alt="Verify Window" />
<br><br>
Let's assume, that we want to warn users, that the "quit" functionality is not yet implemented.
In this case we can use the warning message to inform the user, if he or she pushes 
the "yes" button:
<br><br>
<img src="images/dialog3.png" alt="Warning Dialoque" />
<br><br>
If somebody types the "No" button, the "Cancel" message box is raised:
<br><br>
<img src="images/dialog4.png"  alt="Message box" />
<br><br>
Let's go back to our first Dialogue with the "quit" and "answer" buttons. 
If the "Answer" functionality is not implemented, it might be useful to use the following 
error message box:
<br><br>
<img src="images/dialog5.png"  alt="Error Message box" />
<br><br><br>
Python script, which implements the previous dialogue widges:
<br><br>
<pre>
from Tkinter import *
from tkMessageBox import *

def answer():
    showerror("Answer", "Sorry, no answer available")

def callback():
    if askyesno('Verify', 'Really quit?'):
        showwarning('Yes', 'Not yet implemented')
    else:
        showinfo('No', 'Quit has been cancelled')

Button(text='Quit', command=callback).pack(fill=X)
Button(text='Answer', command=answer).pack(fill=X)
mainloop()
</pre>


<h3>Message Boxes</h3>
The message dialogues are provided by the tkMessageBox module.
<br><br>
The tkMessageBox consists of the following functions, which correspond to dialog windows:
<ul>
<li>askokcancel(title=None, message=None, **options)<br>
Ask if operation should proceed; return true if the answer is ok</li>
<li>askquestion(title=None, message=None, **options)<br>Ask a question</li>
<li>askretrycancel(title=None, message=None, **options)<br>
Ask if operation should be retried; return true if the answer is yes</li>
<li>askyesno(title=None, message=None, **options)<br>
Ask a question; return true if the answer is yes</li>
<li>askyesnocancel(title=None, message=None, **options)<br>
Ask a question; return true if the answer is yes, None if cancelled.</li>
<li>showerror(title=None, message=None, **options)<br>Show an error message</li>
<li>showinfo(title=None, message=None, **options)<br>Show an info message</li>
<li>showwarning(title=None, message=None, **options)<br>Show a warning message</li> 
</ul>

<h3>Open File Dialogue</h3>
There is hardly any serious application, which doesn't need a way to read from a file or write
to a file. Furthermore, such an application might have to choose a directory.
Tkinter provides the module tkFileDialog for these purposes.

<pre>
from Tkinter import *
from tkFileDialog   import askopenfilename      

def callback():
    name= askopenfilename() 
    print name
    
errmsg = 'Error!'
Button(text='File Open', command=callback).pack(fill=X)
mainloop()
</pre>
<br><br>
The code above creates a window with a single button with the text "File Open". If the button is
pushed, the following window appears:
<br><br>
<img src="images/tkinter_file_chooser.png"  alt="Choosing a file" />
<br><br>
The look-and-feel of the file-open-dialog depends on the GUI of the operating system. 
The above example was created using a gnome desktop under Linux. 
If we start the same program under Windows 7, it looks like this:
<br><br>
<img src="images/tkinter_file_chooser_windows_7.png"  alt="Choosing a file the Windows 7 way" />


<h3>Choosing a Colour</h3>

There are applications where the user should have the possibility to select a colour. 
Tkinter provides a pop-up menu to choose a colour. To this purpose we have to import the 
tkColorChooser module and have to use the method askColor:

<pre>
result = tkColorChooser.askColor ( color, option=value, ...)
</pre>

If the user clicks the OK button on the pop-up window, respectively, the return value of askColor() 
is a tuple with two elements, both a representation of the chosen colour, e.g.
((106, 150, 98), '#6a9662') <br>
The first element return[0] is a tuple (R, G, B) with the RGB representation in decimal values (from 0 to 255).
The second element return[1] is a hexadecimal representation of the chosen colour. 
<br>
If the user clicks "Cancel" the method returns the tuple (None, None).
<br><br>
The optional keyword parameters are:

<table>
<tr>
<td width="20%" valign="top">color</td>
<td valign="top">
The variable color is used to set the default colour to be displayed. 
If color is not set, the initial colour will be grey. 
</td>
</tr>
<tr>
<td width="20%" valign="top">title</td>
<td valign="top">The text assigned to the variable title will appear in the pop-up window's title area.
 The default title is "Color".</td>
</tr>
<tr>
<td width="20%" valign="top">parent</td>
<td valign="top">Make the pop-up window appear over window W. 
The default behaviour is that it appears over the root window.</td>
</tr>
</table>
<br><br>
Let's have a look at an example:
<pre>
from Tkinter import *
from tkColorChooser import askcolor                  

def callback():
    result = askcolor(color="#6A9662", 
                      title = "Bernd's Colour Chooser") 
    print result
    
root = Tk()
Button(root, 
       text='Choose Color', 
       fg="darkgreen", 
       command=callback).pack(side=LEFT, padx=10)
Button(text='Quit', 
       command=root.quit,
       fg="red").pack(side=LEFT, padx=10)
mainloop()
</pre>

The look and feel depends on the operating system (e.g. Linux or Windows) and the chosen
GUI (GNOME, KDE and so on). The following windows appear, if you use Gnome:
<br><br>

<img src="images/tkcolor_chooser1.png"  alt="Choosing a Colour Startmenu" />
<br><br>
<img src="images/tkinter_colour_chooser.png"  alt="Choosing a Colour with Tkinter and Python" />

<br><br>
Using the same script under Windows 7 gives us the following result:
<br>
<img src="images/tkinter_colour_chooser_windows_7.png"  alt="Choosing a Colour the Windows 7 way" />


   

     



<br><br>

</div>
<div id="contextlinks">Previous Chapter: <a href="tkinter_text_widget.php">Text Widget</a><br>
<LINK rel="prev" href="tkinter_text_widget.php">Next Chapter: <a href="tkinter_layout_management.php">Layout Management</a><br>
<LINK rel="next" href="tkinter_layout_management.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
