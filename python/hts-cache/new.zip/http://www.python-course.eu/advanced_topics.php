<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Advanced: Advanced Topics</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction into Advanced Topics of Python: Forks, Pipes, Text Processing and Classification, Graphs, Finite State Machines, Turing Machinge, Numpy" />
<meta name="Keywords" content="Python, Introduction, Tutorial, Advanced Topics, Pipe, Pipes, Threads, 
System Programming, Shell, Text Classification, Finite State Machine, NumPy, Matrix Arithmetic" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li class="active"><a id="current" href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/board4_100.jpg" alt="box" />    <h2>Advanced Topics</h2>

<div class="menu">

<ul>
<li><a href="sys_module.php">Introduction into the sys module</a></li><li><a href="os_module_shell.php">Python and the Shell</a></li><li><a href="forking.php">Forks and Forking in Python</a></li><li><a href="threads.php">Introduction into Threads</a></li><li><a href="pipes.php">Pipe, Pipes and "99 Bottles of Beer"</a></li><li><a href="graphs_python.php">Graph Theory and Graphs in Python"</a></li><li><a href="pygraph.php">Graphs: PyGraph"</a></li><li><a href="networkx.php">Graphs: NetworkX"</a></li><li><a href="finite_state_machine.php">Finite State Machine in Python</a></li><li><a href="turing_machine.php">Turing Machine in Python</a></li><li><a href="numpy.php">NumPy Module</a></li><li><a href="matrix_arithmetic.php">Matrix Arithmetic</a></li><li><a href="linear_combinations.php">Linear Combinations</a></li><li><a href="text_classification_introduction.php">Introduction into Text Classification using Naive Bayes</a></li><li><a href="text_classification_python.php">Python Implementation of Text Classification</a></li><li><a href="towers_of_hanoi.php">Example for recursive Programming: Towers of Hanoi</a></li><li><a href="mastermind.php">Mastermind / Bulls and Cows</a></li><li><a href="dynamic_websites_wsgi.php">Creating dynamic websites with WSGI</a></li><li><a href="dynamic_websites.php">Dynamic websites with mod_python</a></li><li><a href="pylons.php">Dynamic websites with Pylons</a></li><li><a href="sql_python.php">Python, SQL, MySQL and SQLite</a></li><li><a href="python_scores.php">Python Scores</a></li></ul>

</div>

<p>
 <i>"If you're talking about Java in particular, Python is about the best fit you can 
 get amongst all the other languages. Yet the funny thing is, from a language point 
 of view, JavaScript has a lot in common with Python, but it is sort of a restricted 
 subset. "</i><br>
(Guido van Rossum, author of the programming language Python)
<br>
He also said: <i>"Yes, I definitely believe that it [ Python ] has some good 
cross-platform properties. Object orientation was one of the techniques I used to make 
Python platform independent. "</i>
<br>
<hr>



<br>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo,
Linux, courses and seminars"
		     src="images/bodenseo_python_training.gif"><br>Linux Courses and Seminars</a>
<hr>
We also like to thank Denise Mitchinson for providing the beautiful stylesheet of 
this website.<br> <a href="http://www.mitchinson.net"> www.mitchinson.net </a>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
These Advanced Topics in German / Deutsche �bersetzung:
     <a href="http://www.python-kurs.eu/system_programmierung.php">Weiterf�hrende Themen</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein with 
material from his live <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training course, you may have a look at the 
<a href="http://ca.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<br>
<font size="1">� kabliczech - Fotolia.com</font>


<br><br>
<h3>Python Tricks</h3>
<i>
"Python tricks" is a tough one, cuz the language is so clean. E.g., C makes an art of confusing 
pointers with arrays and strings, which leads to lotsa neat pointer tricks; APL mistakes 
everything for an array, leading to neat one-liners; and Perl confuses everything period, 
making each line a joyous adventure <wink>.
</i>
(Tim Peters, Pythoneer who formulated the "Zen of Python")
<h3>Python compared to Lisp</h3>
Greenspun's "Tenth Rule of Programming" states:
<br>
<i>
Any sufficiently complicated C or Fortran program contains an ad hoc, informally-specified, 
bug-ridden, slow implementation of half of Common Lisp.
</i>
Sounds complicated? Lisp is complicated. Guido van Rossum compared it - or to be precise 
Common Lisp and Scheme - to Python with the following words:
<i>
"These languages are close to Python in their dynamic semantics, but so different in their approach 
to syntax that a comparison becomes almost a religious argument: is Lisp's lack of syntax an 
advantage or a disadvantage? It should be noted that Python has introspective capabilities 
similar to those of Lisp, and Python programs can construct and execute program fragments on 
the fly. Usually, real-world properties are decisive: Common Lisp is big (in every sense), 
and the Scheme world is fragmented between many incompatible versions, where Python has a 
single, free, compact implementation."
</i>
<br>(excerpt from "Comparing Python to Other Languages" by Guido van Rossum)

<h3>Wizards and Magic</h3>
<i>
"Things in Python are very clear, but are harder to find than the secrets of wizards. 
Things in Perl are easy to find, but look like arcane spells to invoke magic."
</i>

 </p>

</p></div>
<div id="content">

<h2>Advanced Topics with Python</h2>
<p>
<br>
<h3>System Programming with Python</h3>
<img class="imgright" src="images/board3.jpg" alt="Python System Programming" />  
"System focused programming" might be the better term than "System Programming". 
System programming or systems programming means often only the activity of  "programming 
system software", programs which are often part of the operating system.
Our topics in this section of our online course deal with Pipes, Threads and Forks and starting and 
using shell commands and scripts from a Python script.
<br><br>Python has various modules to support system focused programming.
<br><br>
The <a href="sys_module.php">sys module</a> is introduced in the first chapter. A focal point are the data streams (stdin, stdout, stderr) and redirections of strteams.
<br><br>
The interaction between  is the focus 
in the following chapter of our course.
<br>
The interaction between <a href="os_module_shell.php">Python and the Linux Shell</a> is another 
topic of our advanced section. This chapter is followed by <a href="forking.php">Forks and Forking</a>.
<br><br>You can learn more about threads and threading in our <a href="threads.php">Introduction into Threads</a>.
We show how to find the active IP addresses in a local network by using forks.
<br><br>
 The chapter, which is subtitled as <a href="pipes.php">"Pipe, Pipes and '99 Bottles of Beer'"</a> 
 might be interesting to teetotallers as well, because it's not about alcohol but
dealing with alcohol, even though the "99 bottles of beer" in the title give the impression. 
Instead, we show you how to write a program which is construing the famous American song "99 bottles of
beer" by using forked processes and Pipes. So, if you need a good example of pipes and forks working
together you will find it here.
<br><br>

<h3>Graph Theory</h3>
We have three chapters dealing with Graphs. 

<ul>
<li>A general introduction into the Graph theory and the corresponding Python code can be found in
<a href="graphs_python.php">"Graphs in Python"</a>  You will also here the implementations of a graph 
class with essential 
functionalities for graph creation, manipulation and calculations.</li>
<li>Introduction into the module <a href="pygraph.php" name="NetworkX">pygraph</a></li>
<li>Introduction into the module <a href="networkx.php">NetworkX</a></li>
</ul>
</ul>
<br><br>
<h3>Computer Science and Computer Linguistics</h3>
<a href="finite_state_machine.php">Finite State Machines</a> are not only used in computer science but in 
natural language processing as well. We cover the concept of the Finite State Machine in great 
detail, so that even an amateur in Computer Science can understand the examples.
At least we hope so.
<br><br>
Alan Turing's <a href="turing_machine.php">Turing Machines</a> and above all the underlying theory is a must 
for every computer scientist. We show a simple implementation of a Turing Machine.  
<br><br>
If you are interested in Classifying documents, the 
<a href="text_classification_introduction.php">Introduction into Text Classification using Naive Bayes</a>
and our <a href="text_classification_python.php">Python Implementation of Text Classification</a> will be
the right chapters for you.
<br><br>
<h3>Numerical Computations with Python</h3>
If you want to get efficient and fast results with arrays and matrices, 
the <a href="numpy.php">NumPy</a> module of
Python is definitely the right tool collection for you. You will find answers to your questions in
our tutorial, i.e. in our chapters "NumPy Module" and <a href="matrix_arithmetic.php">"Matrix Arithmetic"</a>.
<br><br>
We also provide an introduction into <a href="linear_combinations.php">Linear Combination</a>

<br><br>
<h3>Music</h3>

It's also possible to create scores with Python: You can find a complete working example in  
<a href="python_scores.php">Creating Musical Scores With Python</a>

<br><br>
If you feel that the above topics are to complicated or sophisticated for you, you might
like our course for beginners in Python. You find a documented link list in the following lines:

<br><br>
<h3>Databases with Python</h3>

An introduction into using database interfaces in Python for <a href="sql_python.php">SQL, MySQL and SQLite</a>

<h3>"Games"</h3>

What you find are not real games! We show a recursive solution to 
<a href="towers_of_hanoi.php">Towers of Hanoi</a> and a game 
<a href="mastermind.php">Cows and Bulls</a> better known in a commercial version called "Mastermind".</p>

<div class="intro">

<h3>Online Course</h3>
<div class="textmenu">
<p class="update">
You will find a complete introduction into Python in our online tutorial:
<ul>
<li>In our first chapter you learn how to use the 
<a href="interactive.php">Python Interactive Interpreter</a> 
(<a href="python3_interactive.php">in Python3</a>)
</li>

<li>You will see how easy it is to 
<a href="execute_script.php">Execute a Script in Python</a>.
(<a href="python3_execute_script.php">in Python3</a>)
</li>
<li>Python differs from other programming languages in many ways, but the
most striking one is obviously it's <a href="blocks.php">"Structuring with Indentation"</a>
(<a href="python3_blocks.php">in Python3</a>)

</li>
<li>Variables are easier to be used than in many other programming languages but still there
are some things to point out about "<a href="variables.php">Data Types and Variables</a>"
(<a href="python3_variables.php">in Python3</a>).</li>
<li>Though <a href="operators.php">operators</a>(<a href="python3_operators.php">in Python3</a>) are more or less the same as in other languages, we have to cover them anyway.</li>

<li>Assignments can be quite tricky in Python. When will an object be copied and when 
will we just have a reference? What's the difference between a 
<a href="deep_copy.php">shallow and a deep copy</a>(<a href="python3_deep_copy.php">in Python3</a>)?
</li>
<li><a href="conditional_statements.php">Conditional statements</a>(<a href="python3_conditional_statements.php">in Python3</a>) are straightforward in 
Python</li>
<li>The same is true for the <a href="loops.php">(<a href="python3_loops.php">in Python3</a>) while loops</a>, but there is this special "else" part.</li>
<li>The <a href="for_loop.php">for loops</a> (<a href="python3_for_loop.php">in Python3</a>) seem to be quite strange if you are used to 
C but easy if you know the bash shell</li>
<li>The <a href="python3_formatted_output.php">different ways to format data</a> (Only in our Python 3 tutorial).

<li>In this chapter of our course we will have a closer look at 
<a href="sequential_data_types.php">sequential data types</a> (<a href="python3_sequential_data_types.php">in Python3</a>)</li>
<li><a href="dictionaries.php">Dictionaries</a> (<a href="python3_dictionaries.php">in Python3</a>) are one of the best things 
Python has to offer</li>
<li>It's possible to use sets in Pythons programs as well: We cover both 
<a href="sets_frozensets.php">sets and frozensets</a> (<a href="python3_sets_frozensets.php">in Python3</a>) </li>
<li>Programming without <a href="functions.php">functions</a> (<a href="python3_functions.php">in Python3</a>) would be like cooking without salt and spices.</li>
<li>And a very special spice for your "cooking" can be a 
<a href="recursive_functions.php">recursive function</a> (<a href="python3_recursive_functions.php">in Python3</a>).</li>
<li>To understand functions properly, you need a thorough understanding of arguments and 
<a href="passing_arguments.php">parameter passing</a> (<a href="python3_passing_arguments.php">in Python3</a>).</li>
<li>In the next chapter of our seminar you will find all you have to know about 
<a href="namespaces.php">namespaces</a> (<a href="python3_namespaces.php">in Python3</a>).</li>
</ul>
</p> 
</div></div>

<div class="intro2">

<h3>Further Topics</h3>
<div class="textmenu">
<ul>
<li><a href="global_vs_local_variables.php">Global and local variables</a> (<a href="python3_global_vs_local_variables.php">in Python3</a>) is a topic, 
which can be different for beginners.</li>
<li>A language without the ability to read and write data files would be. So we will introduce you
in our course to the essentials of <a href="file_management.php">file management</a> (<a href="python3_file_management.php">in Python3</a>).</li>
<li>A program, especially a large one, shouldn't be called a program, 
if it isn't <a href="modules_and_modular_programming.php">written in
a modular way</a> (<a href="python3_modules_and_modular_programming.php">in Python3</a>).</li>
<li><a href="python3_memoization.php">Memoisation</a> is a technique used in computing to speed up programs 
by giving functions memory.</li>
<li>Text processing without regular expressions is only piecemeal. That's why we present in 
our tutorial a detailled <a href="re.php">introduction into regular expressions under Python</a> (<a href="python3_re.php">in Python3</a>), continued
by a chapter with <a href="re_advanced.php">advanced regular expressions</a> (<a href="python3_re_advanced.php">in Python3</a>).

</li>
<li>Something very controversial in Python: <a href="lambda.php">Lambda Operator</a> (<a href="python3_lambda.php">in Python3</a>)</li>
<li>It's no secret, that Guido van Rossum doesn't like lambda Operators. Here we give you an introduction 
into his preferred way, i.e. <a href="list_comprehension.php">List Comprehension</a> (<a href="python3_list_comprehension.php">in Python3</a>)</li>
<li><a href="exception_handling.php">Exception Handling</a> (<a href="python3_exception_handling.php">in Python3</a>) is a concept which is comparatively new, i.e. it hasn't been known in programming languages like C and Fortran but in C++ and Java. </li>
<li>Generators are not only good for producing electricity, in Python 
<a href="generators.php">generators</a> (<a href="python3_generators.php">in Python3</a>) are the most
powerful tool to create iterators.</li>
<li>Yes, Python is a fully object oriented language! So we offer a complete online course
into the details of OOP. You suggest working through the following chapters in this order: 
<ul>
  <li><a href="python3_object_oriented_programming.php">General 
  Introduction into Object Oriented Programming (OOP)</a>
  <li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a>
  <li><a href="python3_properties.php">Properties vs. Getters and Setters</a>
  <li><a href="python3_inheritance.php">Inheritance</a>
  <li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a>
  <li><a href="python3_magic_methods.php">Magic Methods and Operator Overlaoding</a>
</ul>


</li>
</ul>
</div>
<p class="update">
</p> </div>

<div class="intro3">

<h4>Our next Training Courses</h4>
<br>Our next open Python classes with Bernd Klein, the author of this website:
<br><b>Toronto</b>:  3<sup>rd</sup> - 7<sup>th</sup> of November, 2014:
<br><a href="http://ca.bodenseo.com/courses.php?topic=Python">Python Training Course in Toronto</a>
<br><b>London</b>:  20<sup>th</sup> - 24<sup>rd</sup> of October, 2014: 
<br><a href="http://www.bodenseo.com/course/python_training_course_intermediate.html">Python Intensive Course in London</a>
<br><b>Berlin</b>:  10<sup>th</sup> - 14<sup>th</sup> of November, 2014: 
<br><a href="http://www.bodenseo.com/course/python_training_course_intermediate.html">Python Intensive Course in Berlin</a>
<br><b>Lake Constance / Zurich</b>:  1<sup>st</sup> - 5<sup>th</sup> of September, 2014:
<br><a href="http://www.bodenseo.com/course/python_training_course_intermediate.html">Python Intensive  Course</a>
<br><b>Paris</b>:  1<sup>st</sup> - 5<sup>th</sup> of December, 2014:
<br><a href="http://www.bodenseo.com/course/python_text_processing_course.html">Python Text Processing Course</a>
<br><b>Munich</b>:  8<sup>th</sup> - 12<sup>th</sup> of December, 2014:
<br><a href="http://www.bodenseo.com/course/python_training_course.html">Python Training Course</a>
<br>

 
<br><br>
<h4>A Course is not a Course</h4>
<p class="update">
The question is ambiguous. First we want to explain, why this website is called
"A Python Course". This website is seen all over the world 
and the expression "course" has varying meanings in the English speaking world.
Both in the United States and Canada, a course is a teaching unit, which might last
e.g. one academic term. The students normally get a grade or some academic credit 
for attending the course, usually after having passed an exam.
<br><br>
 In the United Kingdom and Australia the term "course" usually defines the complete 
 programme of studies required to complete a major or a study path leading to a 
 university degree. The word "unit" is used in the UK to refer to an 
 academic course in the North American sense. 
 <br><br>
On the one hand, we had the US and Canadian sense in mind: Our Python is one teaching
unit and when you have successfully passed it, you are capable of programming 
in Python. On the other hand, we had the original meaning of the word in mind: 
A "course of instruction" as it might be used in book titles like "A Course in 
Programming Python".

</p> </div>


</div>



