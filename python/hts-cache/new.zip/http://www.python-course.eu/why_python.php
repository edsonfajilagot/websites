<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: A Tutorial</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Collection of incentives to use Python. Answers to the question 'Why should I use Python'" />
<meta name="Keywords" content="Python, course, training, tutorial, information" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/python_head.jpg" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<h3>Mythology</h3>
The first great achievement of Apollo was to slay the huge serpent Python. In some texts 
Python is an enormous dragon and not a serpent. 
<br>  
But who was this mythical creature? Python was created out of the slime and mud left after 
the great flood. She was  appointed by Gaia (Mother Earth) to guard the oracle of Delphi, 
known as Pytho. After having defeated Python Apollo remade
her former home and the oracle as his own.
<br>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
<h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>"Don't have good ideas if you aren't willing to be responsible for them. "</i> (Alan Perlis)
<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="history_and_philosophy.php">History and Philosophy of Python</a><br>
<LINK rel="prev" href="history_and_philosophy.php">Next Chapter: <a href="interactive.php">Interactive Mode</a><br>
<LINK rel="next" href="interactive.php"></div>
<h2>Why Python</h2>
<p><img class="imgleft" src="images/python_logo_3_130.jpg" alt="box" />

There are many good reasons to choose Python as your primary programming language. First of all Python is an easy to learn, powerful programming language. Furthermore it has efficient high-level data structures, which allow you to write complex operations in fewer statements than in C, C++ or Java.  
<br>Object-oriented programming is a lot easier than in languages like Java.
<br>
<br>
Python has become one of the most popular programming languages among developers and programmers. They praise it for its clean syntax and code readability. Python is a general-purpose high-level programming language. 
Python is both object oriented and imperative and it can be even used in a functional style as well. Python programs are portable, i.e. they can be ported to other operating systems like Windows, Linux, Unix and Mac OS X, and they can be run on Java and .NET 
virtual machines.
<br><br>
David Beazley says in his foreword to his book "How to Think like a Computer Scientist 
Learning with Python": 
<i>Despite Python's appeal to many different communities, you may still wonder "why Python?" or "why teach programming with Python?" Answering these
questions is no simple task-especially when popular opinion is on the side of more masochistic alternatives such as C++ and Java. However, I think the
most direct answer is that programming in Python is simply a lot of fun and
more productive.</i>

<br><br>
Guido van Rossum, the author of Python, began work on Python at the National Research Institute for Mathematics and Computer Science in the Netherlands (Centrum voor 
Wiskunde en Informatica, CWI).
<br>
When asked, what features of Python he is most pleased with, Guido van Rossum said in an interview with Linux Journal: "The feel of the whole system suits my style of programming well, for obvious reasons. The ability to run the interpreter interactively and the ability to write code from the bottom up and test it piecemeal combine to let me write code quickly. Other people find that it makes them more productive, too." (LJ, no 55)
<br><br>
Python is very fast. The source code is compiled into bytecode, so that executing the same file 
will be faster, if the script will be executed again. The bytecode is an "intermediate language", which is said to run on a virtual machine that executes the machine code corresponding to each bytecode.
</p>
<h2>Comparing Python with Java, Perl and other Programming Languages</h2>
 <p>
Prof. Lutz Prechelt from the University of Karlsruhe compared Python with other programming languages. 
He summarises his results: "80 implementations of the same set of requirements are compared for 
several properties, such as run time, memory consumption, source text length, comment density, 
program structure, reliability, and the amount of effort required for writing them. The results 
indicate that, for the given programming problem, which regards string manipulation and search 
in a dictionary, 'scripting languages' (Perl, Python, Rexx, Tcl) are more productive than 
'conventional languages' (C, C++, Java). In terms of run time and memory consumption, they 
often turn out better than Java and not much worse than C or C++. In general, the differences 
between languages tend to be smaller than the typical differences due to different programmers 
within the same language. (see Lutz Prechelt, An empirical comparison of C, C++, Java, Perl, 
Python, Rexx, and Tcl, IEEE Computer, Vol. 30, (10), p. 23-29, Oct 2000.)
 </p>
 <h2>Other Advantages of Python</h2>
<p>
It's surprisingly easy to embed Python, or better the Python interpreter into C programs. By 
doing this you can add features from Python that could take months to code  in C. Vice versa,
it's possible to extend the Python interpreter by adding a module written in C. 
One reason to do this is if a C library exists that does something which Python doesn't. Another 
good reason is if you need something to run faster than you can manage in Python. 
</p>


 <p>

 The Python Standard Library contains an enormous number of useful modules and is part of every standard Python installation. After having learned the essentials of Python, it is necessary to become familiar with the Python Standard Library because many problems 
 can be solved quickly and easily if you are acquainted with the possibilities that 
 these libraries offer.
 </p>





</div>


<div id="contextlinks">Previous Chapter: <a href="history_and_philosophy.php">History and Philosophy of Python</a><br>
<LINK rel="prev" href="history_and_philosophy.php">Next Chapter: <a href="interactive.php">Interactive Mode</a><br>
<LINK rel="next" href="interactive.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
