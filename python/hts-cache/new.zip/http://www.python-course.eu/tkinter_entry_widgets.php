<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>GUI Programming with Python: Entry Widgets</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial on Tkinter: Communication with the User by using Entry Widgets" />
<meta name="Keywords" content="Python, Tkinter, Tk, Tutorial, Introduction, course, entry widget" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li class="active"><a id="current" href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/entry_widgets_wall.jpg" alt="box" />    <h2>Tkinter Tutorial</h2>

<div class="menu">

<ul>
<li><a href="tkinter_labels.php">Saying Hello with Labels</a></li><li><a href="tkinter_message_widget.php">Message Widget</a></li><li><a href="tkinter_buttons.php">Buttons</a></li><li><a href="tkinter_variable_classes.php">Variable Classes</a></li><li><a href="tkinter_radiobuttons.php">Radiobuttons</a></li><li><a href="tkinter_checkboxes.php">Checkboxes</a></li><li><a href="tkinter_entry_widgets.php">Entry Widgets</a></li><li><a href="tkinter_canvas.php">Canvas Widgets</a></li><li><a href="tkinter_sliders.php">Sliders</a></li><li><a href="tkinter_text_widget.php">Text Widget</a></li><li><a href="tkinter_dialogs.php">Dialogs</a></li><li><a href="tkinter_layout_management.php">Layout Management</a></li><li><a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a></li><li><a href="tkinter_menus.php">Creating Menus</a></li><li><a href="tkinter_events_binds.php">Events and Binds</a></li></ul>

</div>

<p>
<br><hr>
<br>This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
<br>
<h3>Possible Problems</h3>
If you are a beginner in Python, there might be some problems with 
understanding certain Python constructs in the our main tutorial on this page:
<br>
If you have problems understanding about the lambda construct, we recommend our chapter 
<a href="python3_lambda.php">Lambda, filter, reduce and map</a>
Most probably you are familiar with functions, if not we suggest reading the chapter  
<a href="python3_functions.php">Functions</a>
<br><br>
<h3>Entries</h3>
<br>
<i>"Every exit is an entry somewhere else."</i>
Tom Stoppard
<br><br>
<i>"Anybody can win unless there happens to be a second entry."</i>
<br>(George Ade)
<br><br>
<h3>Interfaces</h3>
<br>
Entry widgets are human interfaces to the application. 
Jef Raskin, the human-computer interface expert, who started the Macintosh project for Apple, said:
<i>"A computer shall not harm your work or, through inaction, allow your work to come to harm."</i>
He also said: <i>"A computer shall not waste your time or require you to do more work than is strictly necessary"</i>
and <i>"Once the product's task is known, design the interface first; then implement to the interface design."</i>
<hr>
<br>
<br>


</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/tkinter_entry_widgets.php">Eingabefelder</a>
<h3>Classroom Trainings</h3>Tutorial
<p>
This website contains a free and extensive online tutorial by Bernd Klein. 
You can attend one of his <a href="python_classes.php">Python courses</a> in Paris,
London, Berlin, Munich or Lake Constance.
<br><br>

A fast and efficient approach to learn Python and Tkinter consists in attending a
<a href="http://www.bodenseo.com/courses.php?topic=Python">classroom training courses 
<br><img style="width: 150px;" 
alt="Bodenseo, Python courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.

<h3>Quote of the Day:</h3>
<p>

Man is the best computer we can put aboard a spacecraft...and the only one that can be mass produced with unskilled labor.<br> (Wernher von Braun)
<br>
<br>
<h3>Graphical User Interface</h3>
A graphical user interface (GUI) is a type of user interface that allows users to interact 
with electronic devices in a graphical way, i.e. with images, rather than text commands.
Originally interactive user interfaces to computers were not graphical, they were text  
oriented and usually consisted of commands, which had to be remembered. 
The DOS operating system from Microsoft and the Bourne shell under Linux are examples
of such user-computer interfaces. 


 </p>

</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="tkinter_checkboxes.php">Checkboxes</a><br>
<LINK rel="prev" href="tkinter_checkboxes.php">Next Chapter: <a href="tkinter_canvas.php">Canvas Widgets</a><br>
<LINK rel="next" href="tkinter_canvas.php"></div>
<h2>Entry Widgets</h2>
<br>
<h3>Introduction</h3>
<img class="imgright" src="images/entry_wall.jpg" alt="Entry Fields on Wall" />
<br>
Entry widgets are the basic widgets of Tkinter used to get input, i.e. text strings, from the user 
of an application.  This widget allows the user to enter a single line of text. If the user enters a 
string, which is longer than the available display space of the widget, the content will be scrolled. 
This means, that the string cannot be seen in its entirety. The arrow keys can be used to move to 
the invisible parts of the string. 
If you want to enter multiple lines of text, you have to use the text widget. An entry widget is also limited 
to single font.
<br><br>
The syntax of an entry widget looks like this:
<br><br>
<i>w = Entry(master, option, ... )</i>
<br><br>
"master" represents the parent window, where the entry widget should be placed. Like other widgets, 
it's possible to further influence the rendering of the widget by using options. The comma separated 
list of options can be empty.
<br><br>
The following simple example creates an application with two entry fields. One for entering a last 
name and one for the first name. We use Entry without options.
<br><br>
<pre>
from tkinter import *

master = Tk()
Label(master, text="First Name").grid(row=0)
Label(master, text="Last Name").grid(row=1)

e1 = Entry(master)
e2 = Entry(master)

e1.grid(row=0, column=1)
e2.grid(row=1, column=1)

mainloop( )
</pre>
<br><br>
The window created by the previous script looks like this:
<br><br>
<img src="images/entry_fields.png" alt="Entry Fields for names" />
<br><br>
Okay, we have created Entry fields, so that the user of our program can put in some data. But how 
can our program access this data? How do we read the content of an Entry? 
<br><br>
To put it in a nutshell: The get() method is what we are looking for. 
We extend our little script by two buttons "Quit" and "Show". We bind the 
function show_entry_fields(), which is using the get() method on the Entry objects, to the Show 
button. So, every time this button is clicked, the content of the Entry fields will be printed on the terminal from which
we had called the script.

<pre>
from tkinter import *

def show_entry_fields():
   print("First Name: %s\nLast Name: %s" % (e1.get(), e2.get()))

master = Tk()
Label(master, text="First Name").grid(row=0)
Label(master, text="Last Name").grid(row=1)

e1 = Entry(master)
e2 = Entry(master)

e1.grid(row=0, column=1)
e2.grid(row=1, column=1)

Button(master, text='Quit', command=master.quit).grid(row=3, column=0, sticky=W, pady=4)
Button(master, text='Show', command=show_entry_fields).grid(row=3, column=1, sticky=W, pady=4)

mainloop( )
</pre>
<br>
The complete application looks now like this:
<br><br>
<img src="images/show_entry_content.png" alt="Entry Fields for names plus Show and quit button" />
<br><br>
Let's assume now, that we want to start the Entry fields with default values, e.g. we fill in "Miller" 
or "Baker" as a last name, and "Jack" or "Jill" as a first name. The new version of our Python 
program gets the following two lines, which
can be appended after the Entry definitions, i.e. "e2 = Entry(master)":

<br><br>
<pre>
e1.insert(10,"Miller")
e2.insert(10,"Jill")
</pre>
<br>
What about deleting the input of an Entry object, every time, we are showing the content in our 
function show_entry_fields()? No problem! We can use the delete method. The delete() method has 
the format delete(first, last=None). If only one number is given, it deletes the character at 
index. If two are given, the range from "first" to "last" will be deleted. Use delete(0, END) 
to delete all text in the widget.
<br><br>
<pre>
from tkinter import *

def show_entry_fields():
   print("First Name: %s\nLast Name: %s" % (e1.get(), e2.get()))
   e1.delete(0,END)
   e2.delete(0,END)

master = Tk()
Label(master, text="First Name").grid(row=0)
Label(master, text="Last Name").grid(row=1)

e1 = Entry(master)
e2 = Entry(master)
e1.insert(10,"Miller")
e2.insert(10,"Jill")

e1.grid(row=0, column=1)
e2.grid(row=1, column=1)

Button(master, text='Quit', command=master.quit).grid(row=3, column=0, sticky=W, pady=4)
Button(master, text='Show', command=show_entry_fields).grid(row=3, column=1, sticky=W, pady=4)

mainloop( )
</pre>
<br>
The next example shows, how we can elegantly create lots of Entry field in a more Pythonic way. We use a Python
list to hold the Entry descriptions, which we include as labels into the application. 

<br>
<pre>
#!/usr/bin/python3

from tkinter import *
fields = 'Last Name', 'First Name', 'Job', 'Country'

def fetch(entries):
   for entry in entries:
      field = entry[0]
      text  = entry[1].get()
      print('%s: "%s"' % (field, text)) 

def makeform(root, fields):
   entries = []
   for field in fields:
      row = Frame(root)
      lab = Label(row, width=15, text=field, anchor='w')
      ent = Entry(row)
      row.pack(side=TOP, fill=X, padx=5, pady=5)
      lab.pack(side=LEFT)
      ent.pack(side=RIGHT, expand=YES, fill=X)
      entries.append((field, ent))
   return entries

if __name__ == '__main__':
   root = Tk()
   ents = makeform(root, fields)
   root.bind('&lt;Return&gt;', (lambda event, e=ents: fetch(e)))   
   b1 = Button(root, text='Show',
          command=(lambda e=ents: fetch(e)))
   b1.pack(side=LEFT, padx=5, pady=5)
   b2 = Button(root, text='Quit', command=root.quit)
   b2.pack(side=LEFT, padx=5, pady=5)
   root.mainloop()
</pre>
<br>
If you start this Python script, it will look like this:
<br><br>
<img src="images/name_and_job.png" alt="Name and Job: Bernd Klein, Lecturer, Germany" />
<h3>Calculator</h3>
We are not really writing a calculator, we rather provide a GUI which is capable of
evaluating any mathematical expression and printing the result.

<pre>
from Tkinter import *
from math import *
def evaluate(event):
    res.configure(text = "Ergebnis: " + str(eval(entry.get())))
w = Tk()
Label(w, text="Your Expression:").pack()
entry = Entry(w)
entry.bind("&lt;Return&gt;", evaluate)
entry.pack()
res = Label(w)
res.pack()
w.mainloop()
</pre>
<br><br>
Our widget looks like this:
<br><br>
<img src="images/expression_evaluation.png" alt="Expression evaluation in Python and Tkinter" />
<br><br>
<h3>Interest Calculation</h3>
The following formula can be used to calculate the balance B<sub>k</sub> after k payments 
(balance index), starting with an initial balance (also known as the loan principal) and a 
period rate r:
<br><br> 
<img src="images/balance_after_k_payments.png" height="50" alt="Formula: calculating the monthly payment of a Loan to be paid of in n payment." />
<br>
where
<br>
rate = interest rate in percent, e.g. 3 %<br>
i = rate / 100, annual rate in decimal form<br>
r = period rate = i / 12<br>
B<sub>0</sub> = initial balance, also called loan principal<br>
B<sub>k</sub> = balance after k payments<br>
k = number of monthly payments<br>
p = period (monthly) payment<br>

If we want to find the necessary monthly payment if the loan is to be paid off in n payments 
one sets Bn = 0 and gets the formula:
<br><br>
<img src="images/formula_monthly_payment.png" height="50" alt="Formula: calculating the monthly payment of a Loan to be paid of in n payment." />
<br>
where<br>
n = number of monthly payments to pay back the principal loan
<br><br>
<pre>
#!/usr/bin/python3

from tkinter import *
fields = ('Annual Rate', 'Number of Payments', 'Loan Principle', 'Monthly Payment', 'Remaining Loan')

def monthly_payment(entries):
   # period rate:
   r = (float(entries['Annual Rate'].get()) / 100) / 12
   print("r", r)
   # principal loan:
   loan = float(entries['Loan Principle'].get())
   n =  float(entries['Number of Payments'].get())
   remaining_loan = float(entries['Remaining Loan'].get())
   q = (1 + r)** n
   monthly = r * ( (q * loan - remaining_loan) / ( q - 1 ))
   monthly = ("%8.2f" % monthly).strip()
   entries['Monthly Payment'].delete(0,END)
   entries['Monthly Payment'].insert(0, monthly )
   print("Monthly Payment: %f" % monthly)

def final_balance(entries):
   # period rate:
   r = (float(entries['Annual Rate'].get()) / 100) / 12
   print("r", r)
   # principal loan:
   loan = float(entries['Loan Principle'].get())
   n =  float(entries['Number of Payments'].get()) 
   q = (1 + r)** n
   monthly = float(entries['Monthly Payment'].get())
   q = (1 + r)** n
   remaining = q * loan  - ( (q - 1) / r) * monthly
   remaining = ("%8.2f" % remaining).strip()
   entries['Remaining Loan'].delete(0,END)
   entries['Remaining Loan'].insert(0, remaining )
   print("Remaining Loan: %f" % remaining)

def makeform(root, fields):
   entries = {}
   for field in fields:
      row = Frame(root)
      lab = Label(row, width=22, text=field+": ", anchor='w')
      ent = Entry(row)
      ent.insert(0,"0")
      row.pack(side=TOP, fill=X, padx=5, pady=5)
      lab.pack(side=LEFT)
      ent.pack(side=RIGHT, expand=YES, fill=X)
      entries[field] = ent
   return entries

if __name__ == '__main__':
   root = Tk()
   ents = makeform(root, fields)
   root.bind('&lt;Return&gt;', (lambda event, e=ents: fetch(e)))   
   b1 = Button(root, text='Final Balance',
          command=(lambda e=ents: final_balance(e)))
   b1.pack(side=LEFT, padx=5, pady=5)
   b2 = Button(root, text='Monthly Payment',
          command=(lambda e=ents: monthly_payment(e)))
   b2.pack(side=LEFT, padx=5, pady=5)
   b3 = Button(root, text='Quit', command=root.quit)
   b3.pack(side=LEFT, padx=5, pady=5)
   root.mainloop()
</pre>

<br><br>
Our loan calculator looks like this, if we start it with Python3:
<br><br>
<img src="images/loan_calculator_in_python_and_tkinter.png"  alt="Loan calculator in Python and Tkinter" />


<br><br>
</div>
<div id="contextlinks">Previous Chapter: <a href="tkinter_checkboxes.php">Checkboxes</a><br>
<LINK rel="prev" href="tkinter_checkboxes.php">Next Chapter: <a href="tkinter_canvas.php">Canvas Widgets</a><br>
<LINK rel="next" href="tkinter_canvas.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
