<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>GUI Programming with Python: Python Tkinter Tutorial</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial and introduction into the most commonly used Graphical User Interface of Python: Tkinter" />
<meta name="Keywords" content="Python, Tkinter, Tk, Introduction, course, tutorial" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li class="active"><a id="current" href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/tk_want_to_quit.png" alt="box" />    <h2>Tkinter Tutorial</h2>

<div class="menu">

<ul>
<li><a href="tkinter_labels.php">Saying Hello with Labels</a></li><li><a href="tkinter_message_widget.php">Message Widget</a></li><li><a href="tkinter_buttons.php">Buttons</a></li><li><a href="tkinter_variable_classes.php">Variable Classes</a></li><li><a href="tkinter_radiobuttons.php">Radiobuttons</a></li><li><a href="tkinter_checkboxes.php">Checkboxes</a></li><li><a href="tkinter_entry_widgets.php">Entry Widgets</a></li><li><a href="tkinter_canvas.php">Canvas Widgets</a></li><li><a href="tkinter_sliders.php">Sliders</a></li><li><a href="tkinter_text_widget.php">Text Widget</a></li><li><a href="tkinter_dialogs.php">Dialogs</a></li><li><a href="tkinter_layout_management.php">Layout Management</a></li><li><a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a></li><li><a href="tkinter_menus.php">Creating Menus</a></li><li><a href="tkinter_events_binds.php">Events and Binds</a></li></ul>

</div>

<p>
<br>
<hr>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
<i>"Well, Apple invented the PC as we know it, and then it invented the graphical user
interface as we know it eight years later (with the introduction of the Mac). 
But then, the company had a decade in which it took a nap."</i>
<br>(Steve Jobs)
<hr>

<i>"GUI stuff is supposed to be hard. It builds character."</i>
<br>(Jim Ahlstrom)
<br>
<hr>


</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python_tkinter.php">Einf�hrung in Tkinter</a>
<h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein.
<br>
If you are interested in an instructor-led classroom training, you may have a look 
at the international <a href="python_classes.php">Python courses</a> by Bernd Klein.
<br><br> 
If you are looking for classes in Germany, you can check the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.

<br><br>
<h3>Tkinter in Czech</h3>
Jaroslav Kubias, the translator of Elkner-Downey-Meyers´s "How to think like a computer scientist" into Czech, has translated our tutorial into the Czech language:

<a href="http://tkinter.py.cz">Tkinter Pythonu</a>


 </p>

</p></div>

<div id="content">

<h2>Python Tkinter</h2>
<h3>Introduction</h3>
<p>
<img class="imgright" src="images/tk_widgets.png" alt="Tk widgets" />    
We have often been asked: "Is there no Tk for Python?" or "Is Tkinter the same as Tk?"
Of course, there is Tk for Python. Without Tk Python would be less attractive to many users.
Tk is called Tkinter in Python, or to be precise, Tkinter is the Python interface for Tk.
Tkinter is an acronym for "Tk interface".
<br><br>
Tk was developed as a GUI extension for the Tcl scripting language by John Ousterhout. 
The first release was in 1991. Tk proved as extremely successful in the 1990's, because it is easier 
to learn and to use than other toolkits. So it is no wonder, that many programmers wanted to use Tk 
independently of Tcl. That's why bindings for lots of other programming languages have been developed, 
including Perl, Ada (called TASH), Python (called Tkinter), Ruby, and Common Lisp. 
<br><br>
Tk provides the following widgets:
<ul>
<li>button</li>
<li>canvas</li>
<li>checkbutton</li>
<li>combobox</li>
<li>entry</li>
<li>frame</li>
<li>label</li>
<li>labelframe</li>
<li>listbox</li>
<li>menu</li>
<li>menubutton</li>
<li>message</li>
<li>notebook</li>
<li>tk_optionMenu</li>
<li>panedwindow</li>
<li>progressbar</li>
<li>radiobutton</li>
<li>scale</li>
<li>scrollbar</li>
<li>separator</li>
<li>sizegrip</li>
<li>spinbox</li>
<li>text</li>
<li>treeview</li>
</ul>
It provides the following top-level windows:
<ul>
<li>tk_chooseColor - pops up a dialog box for the user to select a color.</li>
<li>tk_chooseDirectory - pops up a dialog box for the user to select a directory.</li>
<li>tk_dialog - creates a modal dialog and waits for a response.</li>
<li>tk_getOpenFile - pops up a dialog box for the user to select a file to open.</li>
<li>tk_getSaveFile - pops up a dialog box for the user to select a file to save.</li>
<li>tk_messageBox - pops up a message window and waits for a user response.</li>
<li>tk_popup - posts a popup menu.</li>
<li>toplevel - creates and manipulates toplevel widgets.</li>
</ul>
Tk also provides three geometry managers:
<ul>
<li>place - which positions widgets at absolute locations</li>
<li>grid - which arranges widgets in a grid</li>
<li>pack - which packs widgets into a cavity</li>
</ul>

</p>					 


</div>


