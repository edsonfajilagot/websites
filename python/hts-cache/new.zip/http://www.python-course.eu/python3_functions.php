<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Functions</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction to functions in Python with and without parameters. Functions with optional and an arbitrary number of parameters." />
<meta name="Keywords" content="Python, Function, Functions, parameter, optional parameter, 
parameters, Docstring, arbitrary" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/mandelbrot2.gif" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<hr>
<h3>Difference between Arguments and Parameters</h3>
Argument and parameter are often seen and used as synonyms. But there is a difference. In Python
and many other programming languages, parameters are the comma separated identifiers between 
the parenthesis following the function name. While arguments are the comma separated list between
the parenthesis in a function call. 
<br>
<h3>Function</h3>
The word function can mean a lot of things. It can be a mathematical function. It can mean the
purpose, role or use of a thing: The function of a hammer is to hit nails into a wall or wood.
The actions and activities assigned to or required or expected of a person or group; "the function 
of a lecturer". Function can define a relation, like "Wisdom is a function of age!" 
<br>
<hr>
<br><br>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo,
Python courses"
		     src="images/bodenseo_python_training.gif"><br>Linux and Python Courses</a>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_funktionen.php">Funktionen</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="functions.php">Functions in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="functions.php">Functions in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a><br>
<LINK rel="prev" href="python3_formatted_output.php">Next Chapter: <a href="python3_recursive_functions.php">Recursion and Recursive Functions</a><br>
<LINK rel="next" href="python3_recursive_functions.php"></div>
<h2>Functions</h2>
<h3>Syntax</h3>
<p>
<img class="imgright" src="images/functions.png" alt="Functions" />
The concept of a function is one of the most important ones in mathematics. A common usage 
of functions in computer languages is to implement mathematical functions. Such a function
is computing one or more results, which are entirely determined by the parameters passed to 
it.
<br><br>
In the most general sense, a function is a structuring element in programming languages 
to group a set of statements so they can be utilized more than once in a program. The only 
way to accomplish this without functions would be to reuse code by copying it and
adapt it to its different context. Using functions usually enhances the comprehensibility
and quality of the program. It also lowers the cost for development and maintance of the
software.
<br><br>
Functions are known under various names in programming languages, e.g. as subroutines, 
routines, procedures, methods, or subprograms. 
 
<br><br>
A function in Python is defined by a def statement. The general syntax looks like
this:
<pre>
def function-name(Parameter list):
    statements, i.e. the function body
</pre>
The parameter list consists of none or more parameters. Parameters are called 
arguments, if the function is called. The function body consists of indented
statements. The function body gets executed every time the function is called.
<br>
Parameter can be mandatory or optional. The optional parameters (zero or more) must 
follow the mandatory parameters.
<br><br>
Function bodies can contain one or more return statement. They can be situated anywhere in the function
body. A return statement ends the execution of the function call and "returns" the result,
i.e. the value of the expression following the return keyword, to the caller. If the return
statement is without an expression, the special value None is returned.
If there is no return statement in the function code, the function ends, when the 
control flow reaches the end of the function body and the value value will be returned.

<br>Example:
<pre>
def fahrenheit(T_in_celsius):
    """ returns the temperature in degrees Fahrenheit """
    return (T_in_celsius * 9 / 5) + 32

for t in (22.6, 25.8, 27.3, 29.8):
    print(t, ": ", fahrenheit(t))
</pre>

The output of this script looks like this:
<pre>
22.6 :  72.68
25.8 :  78.44
27.3 :  81.14
29.8 :  85.64
</pre>

<br>
<h3>Optional Parameters</h3>
<p>
Functions can have optional parameters, also called default parameters. Default parameters are parameters, which
don't have to be given, if the funtion is called. In this case, the default values are used. We will demonstrate 
the operating principle of default parameters with an example. The following little script, which
isn't very useful, greets a person. If no name is given, it will greet everybody:
<pre>
def Hello(name="everybody"):
    """ Greets a person """
    print("Hello " + name + "!")

Hello("Peter")
Hello()
</pre>
The output looks like this:
<pre>
Hello Peter!
Hello everybody!
</pre>
</p>
<br>
<h3>Docstring</h3>
<p>
The first statement in the body of a function is usually a string, 
which can be accessed with function_name.__doc__

<br>This statement is called <b>Docstring</b>.
<br>Example:<br>
<pre>
def Hello(name="everybody"):
    """ Greets a person """
    print("Hello " + name + "!")

print("The docstring of the function Hello: " + Hello.__doc__)
</pre>
The output:
<pre>
The docstring of the function Hello:  Greets a person 
</pre>
</p>
<br>
<h3>Keyword Parameters</h3>
<p>
Using keyword parameters is an alternative way to make function calls.
The definition of the function doesn't change. 
<br>An example:<br>
<pre>
def sumsub(a, b, c=0, d=0):
    return a - b + c - d

print(sumsub(12,4))
print(sumsub(42,15,d=10))
</pre>
Keyword parameters can only be those, which are not used as positional arguments.
We can see the benefit in the example. If we hadn't keywoard parameters, the second 
call to function would have needed all four arguments, even though the c needs just the
default value:
<pre>
print(sumsub(42,15,0,10))
</pre>
</p>
<br>
<h3>Return Values</h3>
In our previous examples, we used a return statement in the function sumsub but not in Hello.
So, we can see, that it is not mandatory to have a return statement. But what will be returned,
if we don't explicitly give a return statement. Let's see:
<pre>
def no_return(x,y):
    c = x + y

res = no_return(4,5)
print(res)
</pre>

If we start this little script, None will be printed, i.e. the special value None will be returned 
by a return-less function. None will also be returned, if we have just a return in a function 
without an expression:
<pre>
def empty_return(x,y):
    c = x + y
    return

res = empty_return(4,5)
print(res)
</pre>

Otherwise the value of the expression following return will be returned. In the next example
9 will be printed:
<pre>
def return_sum(x,y):
    c = x + y
    return c

res = return_sum(4,5)
print(res)
</pre>
<br>
<h3>Returning Multiple Values</h3>
A function can return exactly one value, or we should better say one object. An object can be 
a numerical value, like an integer or a float. But it can also be e.g. a list or a dictionary.
So, if we have to return for example 3 integer values, we can return a list or a tuple with these three
integer values. This means, that we can indirectly return multiple values. The following example,
which is calculating the Fibonacci boundary for a positve number, returns a 2-tuple. The first element
is the Largest Fibonacci Number smaller than x and the second component is the Smallest Fibonacci Number 
larger than x. The return value is immediately stored via unpacking into the variables lub and sup:

<pre>
def fib_intervall(x):
    """ returns the largest fibonacci
    number smaller than x and the lowest
    fibonacci number higher than x"""
    if x < 0:
        return -1
    (old,new, lub) = (0,1,0)
    while True:
        if new < x:
            lub = new 
            (old,new) = (new,old+new)
        else:
            return (lub, new)
            
while True:
    x = int(input("Your number: "))
    if x <= 0:
        break
    (lub, sup) = fib_intervall(x)
    print("Largest Fibonacci Number smaller than x: " + str(lub))
    print("Smallest Fibonacci Number larger than x: " + str(sup))
</pre>
<br>
<h3>Local and Global Variables in Functions</h3>
Variable names are by default local to the function, in which they get defined. 

<table style="text-align: left; width: 100%;" border="0" cellpadding="2"
cellspacing="2">
<tbody>
<tr>
<td style="vertical-align: middle;">
<pre>def f(): <br>&nbsp;&nbsp;&nbsp; print(s)<br>s = "Python"<br>f()</pre>
</td>
<td style="text-align: center; vertical-align: middle;"><img
style="width: 90px;" alt="arrow"
src="images/arrow.png"><br>
</td>
<td style="vertical-align: middle;">Output:<br>
Python<br>
</td>
</tr>

<tr>
<td style="vertical-align: middle;">
<pre>def f(): <br>&nbsp;&nbsp;&nbsp; s = "Perl"<br>&nbsp;&nbsp;&nbsp; print(s) 
<br></r><br>s = "Python"<br>f()<br>print(s)
</pre>
</td>
<td style="text-align: center; vertical-align: middle;"><img
style="width: 90px;" alt="arrow"
src="images/arrow.png"><br>
</td>
<td style="vertical-align: middle;">Output:<br>
Perl<br>
Python<br>
</td>
</tr>


<tr>
<td style="vertical-align: middle; width: 25%;">
<pre>def f(): <br>&nbsp;&nbsp;&nbsp; print s<br>&nbsp;&nbsp;&nbsp; s = "Perl"<br>&nbsp;&nbsp;&nbsp; print s<br>
<br>s = "Python" <br>f()<br>print s</pre>
</td>
<td style="text-align: center; vertical-align: middle;"><img
style="width: 90px;" alt="arrow"
src="images/arrow.png"><br>
</td>
<td style="vertical-align: middle;">If we execute the previous script, we get the error message:<br>
<code>UnboundLocalError: local variable 's' referenced before assignment</code>
<br>
The variable s is ambigious in f(), i.e. in the first print in f() the global s could be 
used with the value "Python". After this we define a local variable s with the assignment s = "Perl"
</td>
</tr>

<tr>
<td style="vertical-align: middle;">
<pre>def f():<br>&nbsp;&nbsp;&nbsp; global s<br>&nbsp;&nbsp;&nbsp; print s<br>&nbsp;&nbsp;&nbsp; s = "dog"<br>&nbsp;&nbsp;&nbsp; print s <br>s = "cat" <br>f()<br>print s</pre>
</td>
<td style="text-align: center; vertical-align: middle;"><img
style="width: 90px;" alt="arrow"
src="images/arrow.png"><br>
</td>
<td style="vertical-align: middle;">
We made the variable s global inside of the script on the left side. Therefore anything we do to s 
inside of the function body of f 
is done to the global variable s outside of f.<br><br>
Output:<br>
cat<br>
dog<br>
dog
</td>
</tr>


</tbody>
</table>

<h3>Arbitrary Number of Parameters</h3>
<p>
There are many situations in programming, in which the exact number of necessary
parameters cannot be determined a-priori. An arbitrary parameter number can be 
accomplished in Python with so-called tuple references. An asterisk "*" is used in front
of the last parameter name to denote it as a tuple reference. 
This asterisk shouldn't be mistaken with the C syntax, where this notation is connected
with pointers.

<br>Example:<br>
<pre>
def arithmetic_mean(*args):
    sum = 0
    for x in args:
        sum += x
    return sum

print(arithmetic_mean(45,32,89,78))
print(arithmetic_mean(8989.8,78787.78,3453,78778.73))
print(arithmetic_mean(45,32))
print(arithmetic_mean(45))
print(arithmetic_mean())
</pre>
 

<br>Results:
<pre>
244
170009.31
77
45
0
</pre>
</p>
<br><br>
<div id="contextlinks">Previous Chapter: <a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a><br>
<LINK rel="prev" href="python3_formatted_output.php">Next Chapter: <a href="python3_recursive_functions.php">Recursion and Recursive Functions</a><br>
<LINK rel="next" href="python3_recursive_functions.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
