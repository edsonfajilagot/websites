<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: A Tutorial</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Contact form" />
<meta name="Keywords" content="Python, contact form" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li class="active"><a id="current" href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/letterbox100.jpg" alt="box" />    <h2>Contact</h2>

<div class="menu">

<ul>
</ul>

</div>

<p>
<h2>Legal Information</h2>

According to German law (� 3 MDStV and � 3 TDG) we have to name a person, responsible 
for this site:<br>
Dipl.-Inform. Bernd Klein<br>
Pomeziastr. 9,<br>78224 Singen,<br>Telefon: 07731/798180
<br>
<hr>
<br>
Supported by:<br>
<a href="http://www.bodenseo.com"><img style="width: 150px;" alt="Bodenseo, courses and seminars
in Linux and Python"
		     src="images/bodenseo_python_training.gif"><br>Linux and Python courses and seminars</a>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
<h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>"Don't have good ideas if you aren't willing to be responsible for them. "</i> (Alan Perlis)
<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>

<div id="content">
<h2>Contact to python-course.eu</h2>


Please fill in the following number <b>97143</b> 
into the field below: (Spam protection)

<form action="send_email.php"  method="post">
<table border="0">
    <input type="hidden" name="gen_number" value="97143">
    <TR ALIGN=LEFT>
        <TD height="50">Number: <br></TD>
        <TD width="246"> <input name="filled_in_number" type="text" size="5"></TD>
    </TR>


<tr><td class="content" width="10%">Your Name:*</td>
<td><input type="text" name="Name" size="30" class="input" value="" /></td>
</tr>
<tr><td class="content" width="10%">Your Email Address:*</td>
<td><input type="text" name="email" size="30" class="input" value="" /></td>
</tr>
<tr><td class="content" width="10%">Subject:</td>
<td><input type="text" name="subject" size="30" class="input" value="" /></td>
</tr>
<tr><td class="content" colspan="2">Your Message:*</td>
</tr>
<tr><td colspan="2"><textarea name="message" cols="50" rows="15" class="input"
></textarea></td>
</tr>
<tr>
<td colspan="2" align="center">

<!-- ### these two fields are mandatory ### -->
<input type="hidden" name="required" value="Name,email,message">
<input type="hidden" name="action" value="verify">

<input type="SUBMIT" value="Send Email" class="button" >
</td>
</tr>
</table>
</form>
 
<p>


</div>
