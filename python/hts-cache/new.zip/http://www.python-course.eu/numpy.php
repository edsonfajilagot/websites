<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Advanced: Introduction into NumPy</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction into the NumPy module of Python. NumPy is used for scientific computing with Python. It contains among other things a powerful N-dimensional array object." />
<meta name="Keywords" content="Python, introduction, tutorial, NumPy, SciPi, scientific computing" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li class="active"><a id="current" href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/hinton_small.png" alt="box" />    <h2>Advanced Topics</h2>

<div class="menu">

<ul>
<li><a href="sys_module.php">Introduction into the sys module</a></li><li><a href="os_module_shell.php">Python and the Shell</a></li><li><a href="forking.php">Forks and Forking in Python</a></li><li><a href="threads.php">Introduction into Threads</a></li><li><a href="pipes.php">Pipe, Pipes and "99 Bottles of Beer"</a></li><li><a href="graphs_python.php">Graph Theory and Graphs in Python"</a></li><li><a href="pygraph.php">Graphs: PyGraph"</a></li><li><a href="networkx.php">Graphs: NetworkX"</a></li><li><a href="finite_state_machine.php">Finite State Machine in Python</a></li><li><a href="turing_machine.php">Turing Machine in Python</a></li><li><a href="numpy.php">NumPy Module</a></li><li><a href="matrix_arithmetic.php">Matrix Arithmetic</a></li><li><a href="linear_combinations.php">Linear Combinations</a></li><li><a href="text_classification_introduction.php">Introduction into Text Classification using Naive Bayes</a></li><li><a href="text_classification_python.php">Python Implementation of Text Classification</a></li><li><a href="towers_of_hanoi.php">Example for recursive Programming: Towers of Hanoi</a></li><li><a href="mastermind.php">Mastermind / Bulls and Cows</a></li><li><a href="dynamic_websites_wsgi.php">Creating dynamic websites with WSGI</a></li><li><a href="dynamic_websites.php">Dynamic websites with mod_python</a></li><li><a href="pylons.php">Dynamic websites with Pylons</a></li><li><a href="sql_python.php">Python, SQL, MySQL and SQLite</a></li><li><a href="python_scores.php">Python Scores</a></li></ul>

</div>

<p>
<br>
<hr>
<br>
<h3>What is NumPy?</h3>
NumPy is not another programming language but a Python extension module. It provides 
fast and efficient operations on arrays of homogeneous data. 
NumPy extends python into a high-level language for manipulating 
numerical data, similiar to MATLAB.
<h3>Advantages of NumPy</h3>
It's free, i.e. it doesn't cost anything and it's open source. It's an extension on Python
rather than a programming language on it's own. NumPy uses Python syntax. Because NumPy is 
Python, embedding code from other languages like C, C++ and Fortran is very simple.
<br>
<hr>

This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/numpy.php">NumPy-Modul</a><h3>Python Training Courses</h3>
<p>

<p>If you  want to learn Python fast and efficiently, you should consider a 
<a href="http://www.bodenseo.com/courses.php?topic=Python">
<img class="imgright" src="images/radolfzell_segel_bodenseo_logo.jpg" alt="Bodenseo logo" />
<br>Python Training course</a> at Bodenseo. There are also
 special seminars for advanced students like the 
 <a href="http://w ww.bodenseo.com/course/python_xml_training_course.html">Python & XML Training Course</a>.
 If you want to acquire special knowledge in Text Processing and Text Classification, then  
<a href="http://www.bodenseo.com/course/python_text_processing_course.html">"Python Text Processing 
Course"</a> will be the right one for you.
<br>
All the Python seminars are available in German as well: 
<a href="http://www.bodenseo.de/kurse.php?topic=Python">Python-Kurse</a>"
<br><br>
You can also book Bernd Klein for <a href="python_classes.php">onsite training courses</a>



<br><br>
<h3>Python, Java and Javascript</h3>
If you're talking about Java in particular, Python is about the best fit you can get 
amongst all the other languages. Yet the funny thing is, from a language point of view, 
JavaScript has a lot in common with Python, but it is sort of a restricted subset.
(Guido van Rossum) 
<h3>Another Quote</h3>
In my daily work, I work on very large, complex, distributed systems built out of 
many Python modules and packages. The focus is very similar to what you find, for 
example, in Java and, in general, in systems programming languages.
(Guido van Rossum) 
 </p>

</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="turing_machine.php">Turing Machine in Python</a><br>
<LINK rel="prev" href="turing_machine.php">Next Chapter: <a href="matrix_arithmetic.php">Matrix Arithmetic</a><br>
<LINK rel="next" href="matrix_arithmetic.php"></div>
<h2>Introduction into NumPy</h2>
<p>
<img class="imgright" src="images/hinton.png" alt="Visualision of a Matrix using a Hinton diagram" />  
NumPy is an open source extension module for Python.  The module NumPy provides fast
precompiled functions for numerical routines. 

<br>
It adds support to Python for large, multi-dimensional arrays and matrices. Besides that 
it supplies a large library of high-level mathematical functions to operate on these arrays.
<br><br>
SciPy (Scientific Python) extends the functionalites of NumPy with further useful functions for minimization,
regression, Fourier-transformation and many others.
<br><br>
Both NumPy and SciPy are usually not installed by default. NumPy has to be installed before installing SciPy.
Downloading SciPy is possible at this location:<br><br>
http://www.scipy.org/download
<br><br>NumPy and SciPy are a free (meaning "free" as in "free beer" and "free" as in "freedom") alternative to 
MATLAB.  Even though MATLAB has a huge number of additional toolboxes available,NumPy has the advantage 
that Python is a more modern and complete programming language and is open source. 
SciPy adds even more MATLAB-like functionalities to Python. Python is rounded out in the direction of MATLAB with 
the plotting package Matplotlib, which provides MATLAB-like plotting functionality. 
<br><br>
(Comment: The diagram of the image on the top is the graphical vizualisation of a matrix with 14 rows and 20 columns.
It's a so-called Hinton diagram. The size of a square within this diagram corresponds to the size of the value of the
depicted matrix. The colour determines, if the value is positive or negative. In our example: the colour red denotes
negative values and the colour green denotes positive values.) 
<br><br>
NumPy is based on two earlier Python array packages. One of these is Numeric. Numeric is like NumPy a Python module 
for high-performance, numeric computing, but it is obsolete nowadays. Another predecessor of NumPy is Numarray, 
which is a complete rewrite of Numeric but is deprecated as well. NumPy is a merger of those two, i.e. it is build 
on the code of Numeric and the features of Numarray.
<br><br>
One of the main advantages of NumPy is its advantage in time compared to  standard Python.
<br>
Let's look at the following functions:
<pre>
def trad_version():
    t1 = time.time()
    X = range(10000000)
    Y = range(10000000)
    Z = []
    for i in range(len(X)):
        Z.append(X[i] + Y[i])
    return time.time() - t1

def numpy_version():
    t1 = time.time()
    X = numpy.arange(10000000)
    Y = numpy.arange(10000000)
    Z = X + Y
    return time.time() - t1
</pre>
The calls consume the following times:
<pre>
>>> trad_version()
3.167140007019043
>>> numpy_version()
0.19529294967651367
</pre>
<h3>Arrays in NumPy</h3>
Arrays constitute the central component of the module NumPy.
<br>
The main difference to standard Python lists consists in the fact that the elements of a NumPy array
have to be of the same type, usually float or int. NumPy arrays are by far more efficient the lists of
Python. Principially, an array can be seen like a list with the following differences:
<ul>
<li>All elements have to be of the same type, i.e. integer, float (real) or complex numbers</li>
<li>The number of elements have to be known a priori, i.e. when the array is created. It can't be 
changed afterwards.</li>
</ul>
Of course, arrays of NumPy are not limited to one dimension. They are of arbitrary dimension.
<br>
A NumPy Array can be generated from a list or a tuple with the array-method, as shown in the following example:
<br>
<pre>
$ import numpy as np
$ x = np.array([42,47,11], int)
$ x
$ array([42, 47, 11])
</pre>
<br>
The array method transforms sequences of sequences into two dimensional arrays. 
<pre>
>>> x = np.array( ((11,12,13), (21,22,23), (31,32,33)) )
>>> print x
[[11 12 13]
 [21 22 23]
 [31 32 33]]
>>> 
</pre>
Correspondingly, it converts sequences of sequences of sequences into three dimensional arrays:
<pre>
>>> x = np.array( ( ((111,112), (121,122) ), ((211,212),(221,222)) ) )
>>> print x
[[[111 112]
  [121 122]]

 [[211 212]
  [221 222]]]
>>> print x[1][0][1]
212
>>> print x[1][1][1]
222
>>> 
</pre>


<table style="text-align: left; width: 100%;" border="0" cellpadding="2"
cellspacing="2">
<tbody>
<tr>
<td style="vertical-align: top;"><br>
The attribute ndim tells us the number of dimensions of an array:
<pre>
>>> x = np.array( ((11,12,13), (21,22,23) ))
>>> x.ndim
2
</pre>
The method shape() gives us the dimensions:
<pre>
>>> x = np.array( ((7,3,0), (7,11,9), (15,3,7),(12,4,8)  ))
>>> x.ndim
2
>>> x.shape
(4, 3)
>>> x
array([[ 7,  3,  0],
       [ 7, 11,  9],
       [15,  3,  7],
       [12,  4,  8]])
>>> 
</pre>


</td>
<td style="text-align: right; vertical-align: top;"><br>
<img class="imgright" src="images/axis1.jpeg" alt="Axis eines Arrays" />  
</td>
</tr>
</tbody>
</table>
 
 
 
 
<table style="text-align: left; width: 100%;" border="0" cellpadding="4"
cellspacing="6">
<tbody>
<tr>
<td style="vertical-align: top;"><br>
The "shape" of an array denotes a tuple with the number of elements per axis (dimension)
In our example in the picture, the shape is equal to (6,3), i.e. we have 6 lines and 3 columns.
<br>
We can work with arrays like we are used to work with lists:
<br>
<pre>
>>> x = np.array([42,47,11])
>>> x[:2]
array([42, 47])
>>> x = np.array([42,47,11])
>>> x[0]
42
>>> x[:2]
array([42, 47])
>>> x[1] = 49
>>> x
array([42, 49, 11])
>>>
</pre> 
</td>
<td style="text-align: right; vertical-align: top;"><br>
<img class="imgright" src="images/axis.jpeg" alt="Axis eines Arrays" />  
</td>
</tr>
</tbody>
</table>
 
 <br><br>
The following example shows a 2-dimensional float array:<br>
<pre>
>>> x = np.array([[0.314, 0.5,17],[1.4142,0.67, 7]], float)
>>> x[0]
array([  0.314,   0.5  ,  17.   ])
>>> x[1]
array([ 1.4142,  0.67  ,  7.    ])
>>> x[0,2]
17.0
>>>
</pre>
<br>
We can use slices with 2-dimensional arrays as well:
<pre>
>>> x[:,0]
array([ 0.314 ,  1.4142])
>>> x[:,1]
array([ 0.5 ,  0.67])
>>> x[:,2]
array([ 17.,   7.])
>>> 
</pre>
<br>
The attribut dtype contains the type of an array: 
<pre>
>>> x.dtype
dtype('float64')
</pre>

float64 is a numerical data type of NumPy, which stores numbers in double precision, similiar to float in Python. 
<h3>Reshaping Arrays</h3>
There are two methods to flatten a multidimensional array:
<ul>
<li>flatten()</li>
<li>ravel()</li>
</ul> 
<pre>
>>> x = np.array([[[ 0,  1],
...         [ 2,  3],
...         [ 4,  5],
...         [ 6,  7]],
... 
...        [[ 8,  9],
...         [10, 11],
...         [12, 13],
...         [14, 15]],
... 
...        [[16, 17],
...         [18, 19],
...         [20, 21],
...         [22, 23]]])
>>> x.flatten()
array([ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16,
       17, 18, 19, 20, 21, 22, 23])
>>> x
array([[[ 0,  1],
        [ 2,  3],
        [ 4,  5],
        [ 6,  7]],

       [[ 8,  9],
        [10, 11],
        [12, 13],
        [14, 15]],

       [[16, 17],
        [18, 19],
        [20, 21],
        [22, 23]]])
>>> x.ravel()
array([ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16,
       17, 18, 19, 20, 21, 22, 23])
</pre>
The order of the elements in the array returned by ravel() is normally "C-style", i.e. 
the rightmost index "changes the fastest" or in other words: In row-major order, the row 
index varies the slowest, and the column index the quickest, so that a[0,1] follows [0,0].
<br><br>
The method reshape() gives a new shape to an array without changing its data, i.e. it returns a
new array with a new shape.
<pre>
>>> x = np.array(range(24))
>>> y = x.reshape((3,4,2))
>>> y
array([[[ 0,  1],
        [ 2,  3],
        [ 4,  5],
        [ 6,  7]],

       [[ 8,  9],
        [10, 11],
        [12, 13],
        [14, 15]],

       [[16, 17],
        [18, 19],
        [20, 21],
        [22, 23]]])
>>> x
array([ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16,
       17, 18, 19, 20, 21, 22, 23])
>>> 
</pre>
 
We show in the following example, how we can use slices to cut away the "border" of an array, i.e. 
the first and last column and the first and last row of the array:
<pre>
>>> x = np.array(range(100))
>>> y = x.reshape(10,10)
>>> y[1:-1,1:-1]
</pre>

<h3>Concatenating Arrays</h3>
In the following example we concatenate three one-dimensional arrays to one array. The elements
of the second array are appended to the first array. After this the elements of the third array are
appended:
<pre>
>>> x = np.array([11,22])
>>> y = np.array([18,7,6])
>>> z = np.array([1,3,5])
>>> np.concatenate((x,y,z))
array([11, 22, 18,  7,  6,  1,  3,  5])
</pre>
If we are concatenating multidimensional arrays, we can concatenate the arrays according to axis.
Arrays must have the same shape to be concatenated with concatenate(). 
In the case of multidimensional arrays, we can arrange them according to the axis. 
The default value is axis = 0:
<pre>
>>> x = np.array(range(24))
>>> x = x.reshape((3,4,2))
>>> y = np.array(range(100,124))
>>> y = y.reshape((3,4,2))
>>> z = np.concatenate((x,y))
>>> z
array([[[  0,   1],
        [  2,   3],
        [  4,   5],
        [  6,   7]],

       [[  8,   9],
        [ 10,  11],
        [ 12,  13],
        [ 14,  15]],

       [[ 16,  17],
        [ 18,  19],
        [ 20,  21],
        [ 22,  23]],

       [[100, 101],
        [102, 103],
        [104, 105],
        [106, 107]],

       [[108, 109],
        [110, 111],
        [112, 113],
        [114, 115]],

       [[116, 117],
        [118, 119],
        [120, 121],
        [122, 123]]])
>>> 
>>> z = np.concatenate((x,y),axis = 1)
>>> z
array([[[  0,   1],
        [  2,   3],
        [  4,   5],
        [  6,   7],
        [100, 101],
        [102, 103],
        [104, 105],
        [106, 107]],

       [[  8,   9],
        [ 10,  11],
        [ 12,  13],
        [ 14,  15],
        [108, 109],
        [110, 111],
        [112, 113],
        [114, 115]],

       [[ 16,  17],
        [ 18,  19],
        [ 20,  21],
        [ 22,  23],
        [116, 117],
        [118, 119],
        [120, 121],
        [122, 123]]])
>>> z = np.concatenate((x,y),axis = 2)
>>> z
array([[[  0,   1, 100, 101],
        [  2,   3, 102, 103],
        [  4,   5, 104, 105],
        [  6,   7, 106, 107]],

       [[  8,   9, 108, 109],
        [ 10,  11, 110, 111],
        [ 12,  13, 112, 113],
        [ 14,  15, 114, 115]],

       [[ 16,  17, 116, 117],
        [ 18,  19, 118, 119],
        [ 20,  21, 120, 121],
        [ 22,  23, 122, 123]]])
>>> 
</pre>

<h3>Adding New Dimensions</h3>
New dimensions can be added to an array by using slicing and np.newaxis. We illustrate this
technique with an example:
<pre>
>>> x = np.array([2,5,18,14,4])
>>> x
array([ 2,  5, 18, 14,  4])
>>> y = x[:, np.newaxis]
>>> y
array([[ 2],
       [ 5],
       [18],
       [14],
       [ 4]])

</pre>

<h3>Initializing Arrays with Ones and Zeros</h3>
There are two ways of initializing Arrays with Zeros or Ones.
The method ones(t) takes a tuple t with the shape of the array and fills the 
array accordingly with ones. By default it will be filled with Ones of type float. If you need
integer Ones, you have to set the optional parameter dtype to int:
<pre>
>>> np.ones((2,3))
array([[ 1.,  1.,  1.],
       [ 1.,  1.,  1.]])
>>> np.ones((3,4),dtype=int)
array([[1, 1, 1, 1],
       [1, 1, 1, 1],
       [1, 1, 1, 1]])
</pre>
What we have said about the method ones() is valid for the method zeros() analogously, as we can see 
in the following example:
<pre>
>>> np.zeros((2,4))
array([[ 0.,  0.,  0.,  0.],
       [ 0.,  0.,  0.,  0.]])
</pre>

There is another interesting way to create a matrix with Ones or a matrix with Zeros, 
if it has to have the same shape as another existing array. 
Numpy supplies for this purpose the methods ones_like(a) and zeros_like(a).

<pre>
>>> x = np.array([2,5,18,14,4])
>>> np.ones_like(x)
array([1, 1, 1, 1, 1])
>>> np.zeros_like(x)
array([0, 0, 0, 0, 0])
</pre>
 


<div id="contextlinks">Previous Chapter: <a href="turing_machine.php">Turing Machine in Python</a><br>
<LINK rel="prev" href="turing_machine.php">Next Chapter: <a href="matrix_arithmetic.php">Matrix Arithmetic</a><br>
<LINK rel="next" href="matrix_arithmetic.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
