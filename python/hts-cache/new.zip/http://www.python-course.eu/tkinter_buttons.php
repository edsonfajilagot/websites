<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>GUI Programming with Python: Buttons in Tkinter</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tk tutorial: Using Buttons in Tkinter under Python." />
<meta name="Keywords" content="Python, Tkinter, Tk, Introduction, buttons, tutorial" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li class="active"><a id="current" href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/tk_want_to_quit.png" alt="box" />    <h2>Tkinter Tutorial</h2>

<div class="menu">

<ul>
<li><a href="tkinter_labels.php">Saying Hello with Labels</a></li><li><a href="tkinter_message_widget.php">Message Widget</a></li><li><a href="tkinter_buttons.php">Buttons</a></li><li><a href="tkinter_variable_classes.php">Variable Classes</a></li><li><a href="tkinter_radiobuttons.php">Radiobuttons</a></li><li><a href="tkinter_checkboxes.php">Checkboxes</a></li><li><a href="tkinter_entry_widgets.php">Entry Widgets</a></li><li><a href="tkinter_canvas.php">Canvas Widgets</a></li><li><a href="tkinter_sliders.php">Sliders</a></li><li><a href="tkinter_text_widget.php">Text Widget</a></li><li><a href="tkinter_dialogs.php">Dialogs</a></li><li><a href="tkinter_layout_management.php">Layout Management</a></li><li><a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a></li><li><a href="tkinter_menus.php">Creating Menus</a></li><li><a href="tkinter_events_binds.php">Events and Binds</a></li></ul>

</div>

<p>
<br>
<hr>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
<h3>Various Kinds of Buttons</h3>
<i>"We made the buttons on the screen look so good you'll want to lick them."</i>
<br>(Steve Jobs)
<br><br>
<hr>
<br><br>
<i>"Biographies are but the clothes and buttons of the man. 
The biography of the man himself cannot be written."</i>
<br>(Mark Twain)
<br><br>
<hr>
<br><br>
Of course, Keith Richard didn't mean Tk buttons, when he said, that you can't make good music
by just pushing some buttons:<br>
<i>"Good music comes out of people playing together, knowing what they want to do and going 
for it. You have to sweat over it and bug it to death. You can't do it by pushing 
buttons and watching a TV screen."</i>
<br><br>
<hr>
<br><br>
Just one more quotation by a famous musician: "America: It's like Britain, only with buttons."
(Ringo Starr)
<br><br>
<hr>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/tkinter_buttons.php">Buttons / Schaltfl�chen in Tkinter</a>
<h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein.
<br>
If you are interested in an instructor-led classroom training, you may have a look 
at the international <a href="python_classes.php">Python courses</a> by Bernd Klein.
<br><br> 
If you are looking for classes in Germany, you can check the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.

<br>
<font size="1">� kabliczech - Fotolia.com</font>
<h3>Quote of the Day:</h3>
<p>

<i>"But active programming consists of the design of new programs, rather than 
contemplation of old programs. "</i> (Niklaus Wirth)<br>
<h3>Graphical User Interface</h3>
A graphical user interface (GUI) is a type of user interface that allows users to interact 
with electronic devices in a graphical way, i.e. with images, rather than text commands.
Originally interactive user interfaces to computers were not graphical, they were text  
oriented and usually consisted of commands, which had to be remembered. 
The DOS operating system from Microsoft and the Bourne shell under Linux are examples
of such user-computer interfaces. 


 </p>

</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="tkinter_message_widget.php">Message Widget</a><br>
<LINK rel="prev" href="tkinter_message_widget.php">Next Chapter: <a href="tkinter_variable_classes.php">Variable Classes</a><br>
<LINK rel="next" href="tkinter_variable_classes.php"></div>
<h2>Tkinter</h2>
<h3>Tkinter Buttons</h3>
<img class="imgright" src="images/tk_widgets.png" alt="Tk widgets" />    
The Button widget is a standard Tkinter widget, which is used for various kinds of buttons. 
A button is a widget which is designed for the user to interact with, i.e. if the button is
pressed by mouse click some action might be started. They can also contain text and images like labels.
While labels can display text in various fonts, a button can only display text in a single font. The 
text of a button can span more than one line. 
<br><br>
A Python function or method can be associated with a button. This function or method will be executed,
if the button is pressed in some way.  


<h3>Example for the Button Class</h3>
The following script defines two buttons: one to quit the application and another one for the action,
i.e. printing the text "Tkinter is easy to use!" on the terminal.

<br><br>
<pre>
from Tkinter import *
class App:
  def __init__(self, master):
    frame = Frame(master)
    frame.pack()
    self.button = Button(frame, 
                         text="QUIT", fg="red",
                         command=frame.quit)
    self.button.pack(side=LEFT)
    self.slogan = Button(frame,
                         text="Hello",
                         command=self.write_slogan)
    self.slogan.pack(side=LEFT)
  def write_slogan(self):
    print "Tkinter is easy to use!"

root = Tk()
app = App(root)
root.mainloop()
</pre>
<br><br>
The result of the previous example looks like this:
<br><br>
<img src="images/example_button_class.png" alt="Example Button class" />    
<br><br>

<h3>Dynamical Content in a Label</h3>
The following script shows an example, where a label is dynamically incremented by 1
until a stop button is pressed:
<br><br>
<pre>
import Tkinter as tk

counter = 0 
def counter_label(label):
  counter = 0
  def count():
    global counter
    counter += 1
    label.config(text=str(counter))
    label.after(1000, count)
  count()
 
 
root = tk.Tk()
root.title("Counting Seconds")
label = tk.Label(root, fg="dark green")
label.pack()
counter_label(label)
button = tk.Button(root, text='Stop', width=25, command=root.destroy)
button.pack()
root.mainloop()
</pre>

The result of the previous example looks like this:
<br><br>
<img src="images/dynamic_label.png" alt="dynamic label" />    
<br><br>


<h3></h3>

</div>


<div id="contextlinks">Previous Chapter: <a href="tkinter_message_widget.php">Message Widget</a><br>
<LINK rel="prev" href="tkinter_message_widget.php">Next Chapter: <a href="tkinter_variable_classes.php">Variable Classes</a><br>
<LINK rel="next" href="tkinter_variable_classes.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
