<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>GUI Programming with Python: Variable Classes in Tkinter</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial on TKinter under Python: Introducing Variable Classes: StringVar, IntVar, DoubleVar and BooleanVar" />
<meta name="Keywords" content="Python, Tkinter, Tk, Introduction, course, tutorial, radiobuttons, radio, button, buttons" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li class="active"><a id="current" href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/containers100.jpg" alt="box" />    <h2>Tkinter Tutorial</h2>

<div class="menu">

<ul>
<li><a href="tkinter_labels.php">Saying Hello with Labels</a></li><li><a href="tkinter_message_widget.php">Message Widget</a></li><li><a href="tkinter_buttons.php">Buttons</a></li><li><a href="tkinter_variable_classes.php">Variable Classes</a></li><li><a href="tkinter_radiobuttons.php">Radiobuttons</a></li><li><a href="tkinter_checkboxes.php">Checkboxes</a></li><li><a href="tkinter_entry_widgets.php">Entry Widgets</a></li><li><a href="tkinter_canvas.php">Canvas Widgets</a></li><li><a href="tkinter_sliders.php">Sliders</a></li><li><a href="tkinter_text_widget.php">Text Widget</a></li><li><a href="tkinter_dialogs.php">Dialogs</a></li><li><a href="tkinter_layout_management.php">Layout Management</a></li><li><a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a></li><li><a href="tkinter_menus.php">Creating Menus</a></li><li><a href="tkinter_events_binds.php">Events and Binds</a></li></ul>

</div>

<p>
<hr>
<h3>Data</h3>
<i>"The primary purpose of the Data statement is to give names to constants; 
instead of referring to pi as 3.141592653589793 at every appearance, the 
variable Pi can be given that value with a Data statement and used instead 
of the longer form of the constant. This also simplifies modifying the program, 
should the value of pi change."</i>
(Fortran manual for Xerox Computers)
<br>

<h3>Definition of a Variable</h3>
Having the ability or capacity to change or vary. Being capable of alternation in various ways,
such as variable seasons or variable winds, e.g. a shifting wind varying in force.
<br><br>
<hr>
<br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/tkinter_variablen_klassen.php">Tkinter Variablen Klassen</a>
<h3>Classroom Trainings</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his live <a href="python_classes.php">Python classes</a>
<br>
If you are interested in an instructor-led classroom training course,
you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python and 
Tkinter courses <br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo


<h3>Quote of the Day:</h3>
<p>

<i>"I think it is inevitable that people program poorly. Training will not 
substantially help matters. We have to learn to live with it."</i>
 (Alan Perlis)

<br>
<h3>Graphical User Interface</h3>
A graphical user interface (GUI) is a type of user interface that allows users to interact 
with electronic devices in a graphical way, i.e. with images, rather than text commands.
Originally interactive user interfaces to computers were not graphical, they were text  
oriented and usually consisted of commands, which had to be remembered. 
The DOS operating system from Microsoft and the Bourne shell under Linux are examples
of such user-computer interfaces. 


 </p>

</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="tkinter_buttons.php">Buttons</a><br>
<LINK rel="prev" href="tkinter_buttons.php">Next Chapter: <a href="tkinter_radiobuttons.php">Radiobuttons</a><br>
<LINK rel="next" href="tkinter_radiobuttons.php"></div>
<h2>Tkinter</h2>
<h3>Variable Classes</h3>
<br>
Some widgets (like text entry widgets, radio buttons and so on) can be connected directly to application 
variables by using special options: variable, textvariable, onvalue, offvalue, and value. 
This connection works both ways: if the variable changes for any reason, the widget it's connected to 
will be updated to reflect the new value. These Tkinter control variables are used like regular 
Python variables to keep certain values. It's not possible to hand over a regular Python variable 
to a widget through a variable or textvariable option. The only kinds of variables for which this works 
are variables that are subclassed from a class called Variable, defined in the Tkinter module. 
They are declared like this:

<ul>
<li>x = StringVar()   # Holds a string; default value ""</li>
<li>x = IntVar()      # Holds an integer; default value 0</li>
<li>x = DoubleVar()   # Holds a float; default value 0.0</li>
<li>x = BooleanVar()  # Holds a boolean, returns 0 for False and 1 for True</li>
</ul> 

To read the current value of such a variable, call
the method get(). The value of such
a variable can be changed with the set() method.



</div>
<div id="contextlinks">Previous Chapter: <a href="tkinter_buttons.php">Buttons</a><br>
<LINK rel="prev" href="tkinter_buttons.php">Next Chapter: <a href="tkinter_radiobuttons.php">Radiobuttons</a><br>
<LINK rel="next" href="tkinter_radiobuttons.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
