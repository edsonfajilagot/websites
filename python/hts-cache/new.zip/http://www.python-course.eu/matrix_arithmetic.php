<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Advanced: Matrix Arithmetics in NumPy</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction with examples into Matrix-Arithmetics with the NumPy Module" />
<meta name="Keywords" content="Python, Matrix, Arithmetic, arithmetics, Vektor, addition, Multiplikation, 
Skalar product, Matrix multiplication, Cross product, Polynoms, roots of a function, NumPy, SciPi" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li class="active"><a id="current" href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/abacus_small.png" alt="box" />    <h2>Advanced Topics</h2>

<div class="menu">

<ul>
<li><a href="sys_module.php">Introduction into the sys module</a></li><li><a href="os_module_shell.php">Python and the Shell</a></li><li><a href="forking.php">Forks and Forking in Python</a></li><li><a href="threads.php">Introduction into Threads</a></li><li><a href="pipes.php">Pipe, Pipes and "99 Bottles of Beer"</a></li><li><a href="graphs_python.php">Graph Theory and Graphs in Python"</a></li><li><a href="pygraph.php">Graphs: PyGraph"</a></li><li><a href="networkx.php">Graphs: NetworkX"</a></li><li><a href="finite_state_machine.php">Finite State Machine in Python</a></li><li><a href="turing_machine.php">Turing Machine in Python</a></li><li><a href="numpy.php">NumPy Module</a></li><li><a href="matrix_arithmetic.php">Matrix Arithmetic</a></li><li><a href="linear_combinations.php">Linear Combinations</a></li><li><a href="text_classification_introduction.php">Introduction into Text Classification using Naive Bayes</a></li><li><a href="text_classification_python.php">Python Implementation of Text Classification</a></li><li><a href="towers_of_hanoi.php">Example for recursive Programming: Towers of Hanoi</a></li><li><a href="mastermind.php">Mastermind / Bulls and Cows</a></li><li><a href="dynamic_websites_wsgi.php">Creating dynamic websites with WSGI</a></li><li><a href="dynamic_websites.php">Dynamic websites with mod_python</a></li><li><a href="pylons.php">Dynamic websites with Pylons</a></li><li><a href="sql_python.php">Python, SQL, MySQL and SQLite</a></li><li><a href="python_scores.php">Python Scores</a></li></ul>

</div>

<p>
<br>
<hr>
<br>
<h3>What is NumPy?</h3>
NumPy is not another programming language but a Python extension module. It provides 
fast and efficient operations on arrays of homogeneous data. 
NumPy extends python into a high-level language for manipulating 
numerical data, similiar to MATLAB.
<h3>Arithmetics<b></b></h3>
Arithmetic or arithmetics means "number" in old Greek. It is the oldest and most elementary 
branch of mathematics. There is hardly anyone who doesn't use it. It involves the study of 
quantity, especially as the result of combining numbers. In common usage, it refers to the 
simpler properties when using the traditional operations of addition, subtraction, multiplication 
and division with smaller values of numbers. 
<br>
<hr>
Supported by:<br>
<a href="http://www.bodenseo.com/courses.php?topic=Python"><img style="width: 150px;" alt="Bodenseo, Python training courses and
						Seminars"
		     src="images/bodenseo_python_training.gif"><br>Python training courses</a>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/matrix_arithmetik.php">Matrix-Arithmetik</a>

<h3>Python Training Courses</h3>
<p>

<p>If you  want to learn Python fast and efficiently, the right step will be a 
<a href="http://www.bodenseo.com/courses.php?topic=Python">
<br>Python Training course</a> at Bodenseo. There are also
 special seminars for advanced students like the 
 <a href="http://www.bodenseo.com/course/python_xml_training_course.html">Python & XML Training Course</a>.
 If you want to acquire special knowledge in Text Processing and Text Classification, then  
<a href="http://www.bodenseo.com/course/python_text_processing_course.html">"Python Text Processing 
Course"</a> will be the right one for you.
<br>
All the Python seminars are available in German as well: 
<a href="http://www.bodenseo.de/kurse.php?topic=Python">Python-Kurse</a>"

 
<a href="http://www.bodenseo.com/courses.php?topic=Python">
<img class="imgright" src="images/bodenseo_stairs_to_python2.png" alt="Bodenseo step to python" />
<br>Python Courses</a> at Bodenseo.
<br><br>
You can book Bernd Klein for on-site <a href="python_classes.php">Python courses</a> as 
well.

<br><br>
<h3>First Matrices</h3>
Do you know, that the first or one of the first books dealing with matrices is the Jiuzhang suanshu
or the "Nine Chapters on the Mathematical Art"? It's a practical book on mathematics and consists
of 246 problems. Useful problems for solving everyday problems of engineering, surveying, trade, 
and taxation. This book had played a similiar role for mathematics in China than Euclid's Elements 
in the "European" mathematics.
<br>Chapter 8 of this  book deals with "Calculation by Square Tables", solving systems of 
simultaneous linear equations.
<h3>Another Quote</h3>
In my daily work, I work on very large, complex, distributed systems built out of 
many Python modules and packages. The focus is very similar to what you find, for 
example, in Java and, in general, in systems programming languages.
(Guido van Rossum) 
 </p>

</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="numpy.php">NumPy Module</a><br>
<LINK rel="prev" href="numpy.php">Next Chapter: <a href="linear_combinations.php">Linear Combinations</a><br>
<LINK rel="next" href="linear_combinations.php"></div>
<h2>Matrix Arithmetics under NumPy and Python</h2>
<p>
<img class="imgright" src="images/abacus.png" alt="Distorted Abacus" />  
In the previous chapter of our introduction in NumPy we have demonstrated how to create 
and change Arrays. In this chapter we want to show, how we can perform in Python with 
the module NumPy all the basic Matrix Arithmetics like 
<ul>
<li>Matrix addition</li>
<li>Matrix subtraction</li>
<li>Matrix multiplication</li>
<li>Skalar product</li>
<li>Cross product</li>
<li>and lots of other operations on matrices</li>
</ul>

<br><br>
The arithemtic standard Operators 
<ul>
<li>+</li>
<li>-</li>
<li>*</li>
<li>/</li>
<li>**</li>
<li>%</li>
</ul>
are applied on the elements, this means that the arrays have to have the same size.
<br>
<pre class="small300">
>>> x = np.array([1,5,2])
>>> y = np.array([7,4,1])
>>> x + y
array([8, 9, 3])
>>> x * y
array([ 7, 20,  2])
>>> x - y
array([-6,  1,  1])
>>> x / y
array([0, 1, 2])
>>> x % y
array([1, 1, 0]) 
</pre>
 <br><br><br>
<h3>Vector Addition and Subtraction</h3>
<img class="imgright" src="images/vector_addition.png" alt="Graphical Example of Vector Addition" />  
Many people know vector addition and subtraction from physics, to be exact from the 
parallelogram of forces. It is a method for solving (or visualizing) the results of 
applying two forces to an object. 
<br><br>
The addition of two vectors, in our example (see picture) x and y, may be represented 
graphically by placing the start of the arrow y at the tip of the arrow x, and then 
drawing an arrow from the start (tail) of x to the tip (head) of y. 
The new arrow drawn represents the vector x + y

<pre class="small300" >
>>> x = np.array([3,2])
>>> y = np.array([5,1])
>>> z = x + y
>>> z
array([8, 3])
>>> 
</pre>
<img class="imgright" src="images/vector_subtraction.png" alt="Graphical Example of Vector Subtraction" />
Subtracting a vector is the same as adding its negative. So, the difference of the vectors x and y 
is equal to the sum of x and -y: <br>
x - y = x + (-y)
<br>Subtraction of two vectors can be geometrically defined as follows: to subtract y from x, 
we place the end points of x and y at the same point, and then draw an arrow from the tip
of y to the tip of x. That arrow represents the vector x - y, see picture on the right side.
<br><br>Mathematically, we subtract the corresponding components of vector y from the vector x. 
<h3>Scalar Product / Dot Product</h3>
In mathematics, the dot product is an algebraic operation that takes two coordinate vectors of 
equal size and returns a single number. The result is calculated by multiplying corresponding 
entries and adding up those products. 
The name "dot product" stems from the fact, that the centered dot "�" is often used to designate 
this operation. The name "scalar product" focusses on the scalar nature of the result.
 of the result.
<br><br>
Definition of the scalar product:
<br><br>
<img src="images/scalar_product.jpeg" alt="Definition of the Scalar Product" />
<br><br>
We can see from the definition of the scalar product, that it can be used to calculate the cosine 
of the angle between two vectors. 
<br><br>
Calculation of the scalar product:
<br><br>
<img src="images/scalar_product1.jpeg" alt="Calculation of the Scalar Product" />
<br><br>
Finally, we want to demonstrate how to calculate the scalar product in Python:
<pre>
>>> x = np.array([1,2,3])
>>> y = np.array([-7,8,9])
>>> np.dot(x,y)
36
>>> dot = np.dot(x,y)
>>> x_modulus = np.sqrt((x*x).sum())
>>> y_modulus = np.sqrt((y*y).sum())
>>> cos_angle = dot / x_modulus / y_modulus # cosinus of angle between x and y
>>> angle = np.arccos(cos_angle)
>>> angle
0.80823378901082499
>>> angle * 360 / 2 / np.pi # angle in degrees
46.308384970187326
>>>
</pre>

<h3>Matrix Class</h3>
The matrix objects are a subclass of
the numpy arrays (ndarray). The matrix objects inherit all the attributes and methods of ndarry.
Another difference is, that numpy matrices are strictly 2-dimensional, while numpy arrays can be
of any dimension, i.e. they are n-dimensional.
<br><br>
The most important advantage of matrices is that the provide convenient notations for the matrix 
mulitplication. If X and Y are two Matrices than X * Y defines the matrix multiplication. While on
the other hand, if X and Y are ndarrays, X * Y define an element by element multiplication.
<pre>
>>> x = np.array( ((2,3), (3, 5)) )
>>> y = np.array( ((1,2), (5, -1)) )
>>> x * y
array([[ 2,  6],
       [15, -5]])
>>> x = np.matrix( ((2,3), (3, 5)) )
>>> y = np.matrix( ((1,2), (5, -1)) )
>>> x * y
matrix([[17,  1],
        [28,  1]])
</pre>

<h3>Matrix Product</h3>
The matrix product of two matrices can be calculated if the number of columns of the left
matrix is equal to the number of rows of the second or right matrix. 
<br>
The product of a (l x m)-matrix A = (a<sub>ij</sub>)<sub>i=1...l, j= 1..m</sub>  and an 
(m x n)-matrix B = (b<sub>ij</sub>)<sub>i=1...m, j= 1..n</sub>  is a matrix 
C = (c<sub>ij</sub>)<sub>i=1...l, j= 1..n</sub>, which is calculated like this:
<br><br>
<img src="images/matrix_product.jpeg" alt="Matrix Product" />
<br><br>
The following picture illustrates it further:
<br>
<img src="images/matrix_product2.jpeg" alt="Matrix Product Illustration" />
<br><br>
If we want to perform matrix multiplication with two numpy arrays (ndarray), we have to use the 
dot product:
<pre>
>>> x = np.array( ((2,3), (3, 5)) )
>>> y = np.matrix( ((1,2), (5, -1)) )
>>> np.dot(x,y)
matrix([[17,  1],
        [28,  1]])
</pre>
Alternatively, we can cast them into matrix objects and use the "*" operator:
<pre>
>>> np.mat(x) * np.mat(y)
matrix([[17,  1],
        [28,  1]])
</pre>
<h3>Simple Practical Application for Matrix Multiplication</h3>
<img class="imgright" src="images/pralinen.jpg" alt="Chocolates" />
In the following practical example, we come to talk about the sweet things of life. <br>
Let's assume there are four people, and we call them Lucas, Mia, Leon and Hannah. Each of
them has bought chocolates out of a choice of three. The brand are A, B and C, not very
marketable, we have to admit. Lucas bought 100 g of brand A, 175 g of brand B and 210 of C.
Mia choose 90 g of A, 160 g of B and 150 g of C. Leon bought 200 g of A, 50 of B and
100 g of C. Hannah apparantly didn't like brand B, because she hadn't bought any of those. But she
she seems to be a real fan of brand C, because she bought 310 g of them. Furthermore she 
bought 120 g of A.<br><br>
So, what's the price in Euro of these chocolates: A costs 2.98 per 100 g, B costs 3.90 and C only 
1.99 Euro.
<br><br> 
If we have to calculate how much each of them had to pay, we can use Python, NumPy and Matrix 
multiplication:
<br><br>
<pre class="small350">
>>> NumPersons = np.array([[100,175,210],[90,160,150],[200,50,100],[120,0,310]])
>>> Price_per_100_g = np.array([2.98,3.90,1.99])
>>> Price_in_Cent = np.dot(NumPersons,Price_per_100_g)
>>> Price_in_  Euro = Price_in_Cent / np.array([100,100,100,100])
>>> Price_in_Euro
array([ 13.984,  11.907,   9.9  ,   9.745])
>>> 
</pre>
This means that Lucas paid 13.98 Euro, Mia 11.97 Euro, Leon 9.90 and Hannah 9.75.
<br>
<h3>Cross Product</h3>
<img class="imgright" src="images/Cross_product_vector.png" alt="Vector cross product diagram" />
Let's stop consuming delicious chocolates and come back to a more mathematical and less 
high-calorie topic, i.e. the cross product.
<br><br>
The cross product or vector product is a binary operation on two vectors in three-dimensional
space. The result is a vector which is perpendicular to the vectors being multiplied and 
normal to the plane containing them. 
<br><br>
The cross product of two vectors a and b is denoted by a � b.
<br><br>
It's defined as:
<br><br>
<img src="images/cross_product_definition.jpg" alt="Cross Product Definition" />
<br>
where n is a unit vector perpendicular to the plane containing a and b in the direction 
given by the right-hand rule.
<br><br>
If either of the vectors being multiplied is zero or the vectors are parallel then their 
cross product is zero. More generally, the magnitude of the product equals the area of a 
parallelogram with the vectors as sides. If the vectors are perpendicular the parallelogram 
is a rectangle and the magnitude of the product is the product of their lengths. 
<br><br>
<pre class="small350">
>>> x = np.array([0,0,1])
>>> y = np.array([0,1,0])

>>> np.cross(x,y)
array([-1,  0,  0])

>>> np.cross(y,x)
array([1, 0, 0])
</pre>
<br><br>
<div id="contextlinks">Previous Chapter: <a href="numpy.php">NumPy Module</a><br>
<LINK rel="prev" href="numpy.php">Next Chapter: <a href="linear_combinations.php">Linear Combinations</a><br>
<LINK rel="next" href="linear_combinations.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
