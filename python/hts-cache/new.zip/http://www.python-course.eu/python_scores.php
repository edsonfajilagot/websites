<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Advanced: Creating Musical Scores with Python</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Using Python and Lilypond to create music engravings" />
<meta name="Keywords" content="Python, Lilypond, score, scores, engraving, engravings, music, musical, automatically, course" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li class="active"><a id="current" href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/score_left.png" alt="box" />    <h2>Advanced Topics</h2>

<div class="menu">

<ul>
<li><a href="sys_module.php">Introduction into the sys module</a></li><li><a href="os_module_shell.php">Python and the Shell</a></li><li><a href="forking.php">Forks and Forking in Python</a></li><li><a href="threads.php">Introduction into Threads</a></li><li><a href="pipes.php">Pipe, Pipes and "99 Bottles of Beer"</a></li><li><a href="graphs_python.php">Graph Theory and Graphs in Python"</a></li><li><a href="pygraph.php">Graphs: PyGraph"</a></li><li><a href="networkx.php">Graphs: NetworkX"</a></li><li><a href="finite_state_machine.php">Finite State Machine in Python</a></li><li><a href="turing_machine.php">Turing Machine in Python</a></li><li><a href="numpy.php">NumPy Module</a></li><li><a href="matrix_arithmetic.php">Matrix Arithmetic</a></li><li><a href="linear_combinations.php">Linear Combinations</a></li><li><a href="text_classification_introduction.php">Introduction into Text Classification using Naive Bayes</a></li><li><a href="text_classification_python.php">Python Implementation of Text Classification</a></li><li><a href="towers_of_hanoi.php">Example for recursive Programming: Towers of Hanoi</a></li><li><a href="mastermind.php">Mastermind / Bulls and Cows</a></li><li><a href="dynamic_websites_wsgi.php">Creating dynamic websites with WSGI</a></li><li><a href="dynamic_websites.php">Dynamic websites with mod_python</a></li><li><a href="pylons.php">Dynamic websites with Pylons</a></li><li><a href="sql_python.php">Python, SQL, MySQL and SQLite</a></li><li><a href="python_scores.php">Python Scores</a></li></ul>

</div>

<p>
<br>
<hr>
<br>
<h3>Music Engravings</h3>
Music engraving is the art of drawing music notation at high quality for the purpose 
of mechanical reproduction. The term music copying is almost equivalent, though music 
engraving implies a higher degree of skill and quality, usually for publication.

<br>
<hr>
Supported by:<br>
<a href="http://www.bodenseo.com/courses.php?topic=Python"><img style="width: 150px;" alt="Bodenseo, Python training courses"
		     src="images/bodenseo_python_training.gif"><br>Python trainings courses</a>
		     <br><br>
		     See also <a href="http://www.bklein.de/music.php">World of Music</a> and the definition of music.

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
<h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>We can only see a short distance ahead, but we can see plenty there that needs to be done.</i>
<br>Alan Turing
<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="sql_python.php">Python, SQL, MySQL and SQLite</a><br>
<LINK rel="prev" href="sql_python.php"></div>
<h2>Creating Musical Scores With Python</h2>
<br>
<h3>Introduction</h3>
In this chapter of our Python course, we provide a tutorial on music engravings. We use Python
to create an input file for the music engraving program Lilypond. Our Python program will 
translate an arbitrary text into a musical score. Each character of the alphabet is translated 
by our Python program into a one or more notes of a music piece.  
<br><br>
<h3>Lilypond</h3>
<img class="imgright" src="images/lilypond.png" alt="Lilypond Logo" />
Before we can start with the code for our Python implementation, we have to give some information
about Lilypond. What is Lilypond? The makers of Lilypond define it like this on lilypond.org: 
<br><br>
"LilyPond is a music engraving program, devoted to producing 
the highest-quality sheet music possible. It brings the aesthetics of traditionally engraved music 
to computer printouts."
<br><br>
They describe their goal as following: 
<br>"LilyPond came about when two musicians wanted to go beyond the soulless 
look of computer-printed sheet music. Musicians prefer reading beautiful music, so why couldn't 
programmers write software to produce elegant printed parts?
<br><br>
The result is a system which frees musicians from the details of layout, allowing them to focus 
on making music. LilyPond works with them to create publication-quality parts, crafted in the 
best traditions of classical music engraving." 
<br><br>
A simple example to get you started with Lilypond:
<br>
<pre>
\version "2.12.3"
{
  c' e' g' a'
}
</pre>
Saving the Lilypond code above in a file called simple.ly, we can start Lilypond on a command shell:
<pre>
lilypond simple.ly
</pre>
This call creates the following output:
<pre>
GNU LilyPond 2.12.3
Processing `simple.ly'
Parsing...
Interpreting music... 
Preprocessing graphical objects...
Finding the ideal number of pages...
Fitting music on 1 page...
Drawing systems...
Layout output to `simple.ps'...
Converting to `./simple.pdf'...
</pre>

The result is saved in a pdf file "simple.pdf", which looks like this:

<img class="img" src="images/score_example.png" alt="Example Score" />
<br><br>
We do not want to give a complete tutorial. We recomment using the <a href="http://lilypond.org/doc/v2.14/Documentation/learning/index">Learning Manual</a>

<h3>Using Python with Lilypond</h3>
<img class="imgright" src="images/text_to_score.png" alt="Text to Score using Python" />
We write a program, which translates an arbitrary text string into a piece of music, which can be played on the piano.
To this purpose every character of the Latin alphabet is mapped to two quarters of a four-four time, both for the left
and right hand of a piano score. 
<br><br>
The image on the right side illustrates this with the String "Python". We use a pentatonic scale to ensure that the result will not sound too bad.
<br><br>
We implement the mapping with a Python dictionary:
<pre>
char2notes = { 
  ' ':("a4 a4 ", "r2 "),
  'a':("&lt;c a&gt;2 ", "&lt;e' a'&gt;2 "),
  'b':("e2 ", "e'4 &lt;e' g'&gt; "),
  'c':("g2 ", "d'4 e' "),
  'd':("e2 ", "e'4 a' "),
  'e':("&lt;c g&gt;2 ", "a'4 &lt;a' c'&gt; "),
  'f':("a2 ", "&lt;g' a'&gt;4 c'' "),
  'g':("a2 ", "&lt;g' a'&gt;4 a' "),
  'h':("r4 g ", " r4 g' "),
  'i':("&lt;c e&gt;2 ", "d'4 g' "),
  'j':("a4 a ", "g'4 g' "),
  'k':("a2 ", "&lt;g' a'&gt;4 g' "),
  'l':("e4 g ", "a'4 a' "),
  'm':("c4 e ", "a'4 g' "),
  'n':("e4 c ", "a'4 g' "),
  'o':("&lt;c a g&gt;2  ", "a'2 "),
  'p':("a2 ", "e'4 &lt;e' g'&gt; "),
  'q':("a2 ", "a'4 a' "),
  'r':("g4 e ", "a'4 a' "),
  's':("a2 ", "g'4 a' "),
  't':("g2 ", "e'4 c' "),
  'u':("&lt;c e g&gt;2  ", "&lt;a' g'&gt;2"),
  'v':("e4 e ", "a'4 c' "),
  'w':("e4 a ", "a'4 c' "),
  'x':("r4 &lt;c d&gt; ", "g' a' "),
  'y':("&lt;c g&gt;2  ", "&lt;a' g'&gt;2"),
  'z':("&lt;e a&gt;2 ", "g'4 a' "),
  '\n':("r1 r1 ", "r1 r1 "),
  ',':("r2 ", "r2"),
  '.':("&lt;c e a&gt;2 ", "&lt;a c' e'&gt;2")
}

</pre>

<br><br>
The mapping of a string to the notes can be realized by a simple for loop in Python:
<pre>
txt = "Love one another and you will be happy. It is as simple as that."

upper_staff = ""
lower_staff = "" 
for i in txt.lower():
    (l,u) = char2notes[i]
    upper_staff += u
    lower_staff += l
</pre>
The following code sequence embeds the strings upper_staff and lower_staff into a Lilypond 
format, which can be processed by Lilypond:

<pre>
staff = "{\n\\new PianoStaff << \n"
staff += "  \\new Staff {" + upper_staff + "}\n"  
staff += "  \\new Staff { \clef bass " + lower_staff + "}\n"  
staff += ">>\n}\n"

title = """\header {
  title = "Love One Another"
  composer = "Bernd Klein using Python"
  tagline = "Copyright: Bernd Klein"
}"""

print title + staff
</pre>  

Putting the code together and saving it under text_to_music.py, we can create our piano score on the command
with the following command:

<pre>
python text_to_music.py > piano_score.ly
</pre>
This will create a PDF file called <a href="images/piano_score.pdf">piano_score.pdf</a>.



</p>

<div id="contextlinks">Previous Chapter: <a href="sql_python.php">Python, SQL, MySQL and SQLite</a><br>
<LINK rel="prev" href="sql_python.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
