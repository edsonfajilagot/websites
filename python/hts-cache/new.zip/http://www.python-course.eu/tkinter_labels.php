<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>GUI Programming with Python: Labels in Tkinter</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial and introduction into Tkinter: Simple Examples Using Labels" />
<meta name="Keywords" content="Python, Tkinter, Tk, Introduction, course, tutorial" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li class="active"><a id="current" href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/tk_want_to_quit.png" alt="box" />    <h2>Tkinter Tutorial</h2>

<div class="menu">

<ul>
<li><a href="tkinter_labels.php">Saying Hello with Labels</a></li><li><a href="tkinter_message_widget.php">Message Widget</a></li><li><a href="tkinter_buttons.php">Buttons</a></li><li><a href="tkinter_variable_classes.php">Variable Classes</a></li><li><a href="tkinter_radiobuttons.php">Radiobuttons</a></li><li><a href="tkinter_checkboxes.php">Checkboxes</a></li><li><a href="tkinter_entry_widgets.php">Entry Widgets</a></li><li><a href="tkinter_canvas.php">Canvas Widgets</a></li><li><a href="tkinter_sliders.php">Sliders</a></li><li><a href="tkinter_text_widget.php">Text Widget</a></li><li><a href="tkinter_dialogs.php">Dialogs</a></li><li><a href="tkinter_layout_management.php">Layout Management</a></li><li><a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a></li><li><a href="tkinter_menus.php">Creating Menus</a></li><li><a href="tkinter_events_binds.php">Events and Binds</a></li></ul>

</div>

<p>
<br>

<h3>Labelling People</h3>
<i>"Once you label me you negate me."</i>
<br>(Soren Kierkegaard)
<br><br>
<hr>
<br><br>
<i>"When we label anyone 'bad', we will have more trouble dealing 
with him than if we could have settled for a lesser label."</i>
<br>(William Glasser)
<br><br>
<hr>
<br><br>
The German-born American composer and conductor Lukas Foss wrote about labelling
artists:<br>
<i>"Why do we pigeonhole and label an artist? It is a sure way of missing the important, 
the contradictory, the things that make him or her unique."</i>
<br><br>
<hr>
<br>
Supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo, courses and 
seminars in Linux and Python"
		     src="images/bodenseo_python_training.gif"><br>Linux and Python Courses and Seminars </a>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/tkinter_labels.php">Hello Tkinter Label</a>
<h3>Classroom Trainings</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his live <a href="python_classes.php">Python classes</a>
<br>
If you are interested in an instructor-led classroom training course,
you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python and 
Tkinter courses <br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo


<h3>Quote of the Day:</h3>
<p>

<i>"Any program is only as good as it is useful."</i> (Linus Torvalds)<br>
<h3>Graphical User Interface</h3>
A graphical user interface (GUI) is a type of user interface that allows users to interact 
with electronic devices in a graphical way, i.e. with images, rather than text commands.
Originally interactive user interfaces to computers were not graphical, they were text  
oriented and usually consisted of commands, which had to be remembered. 
The DOS operating system from Microsoft and the Bourne shell under Linux are examples
of such user-computer interfaces. 


 </p>

</p></div>

<div id="content">

<div id="contextlinks">Next Chapter: <a href="tkinter_message_widget.php">Message Widget</a><br>
<LINK rel="next" href="tkinter_message_widget.php"></div>
<h2>Tkinter</h2>
<h3>Hello Tkinter Label</h3>
<img class="imgright" src="images/hello_tkinter_cartoon.png" alt="Hello Tkinter with Python" />
<br>We will start our tutorial with one of the easiest widgets of Tk (Tkinter), i.e. a label. 
A Label is a Tkinter Widget class, which is used to display text or an image. The label is a widget
that the user just views but not interact with. 
<br><br> 
There is hardly any book or introduction into a programming language, which doesn't start with
the "Hello World" example. We will draw on tradition but will slightly modify the output to "Hello Tkinter" 
instead of "Hello World".
<br><br>
The following Python script uses Tkinter to create a window with the text "Hello Tkinter". You can use the
Python interpretor to type this script line after line, or you can save it in a file, for example "hello.py":
<br><br>
<pre>
from Tkinter import *
# if you are working under Python 3, comment the previous line and comment out the following line
#from tkinter import *

root = Tk()

w = Label(root, text="Hello Tkinter!")
w.pack()

root.mainloop()
</pre>

<h3>Starting our example</h3>
If we save the script under the name hello.py, we can start it like this:
<pre>
$ python hello.py
</pre>
If you run the command under the Gnome and Linux, the window the window will look like this:
<br><br>
<img src="images/hello_tkinter.png" alt="Tk widgets" />    
<br><br>
Under Windows it appears in the Windows look and feel:
<br><br>
<img src="images/hello_tkinter_windows.png" alt="Hello Tkinter Windows" />    


<h3>Explanation</h3>
The Tkinter module, containing the Tk toolkit, has always to be imported. 
In our example, we import everything from Tkinter by using the asterisk symbol ("*") into our module's namespace:

<pre>
from Tkinter import *
</pre>



To initialize Tkinter, we have to create a Tk root widget, which is a window with a title bar and 
other decoration provided by the window manager. The root widget has to be created before any other widgets
and there can only be one root widget. 
<pre>
root = Tk()
</pre>

The next line of code contains the Label widget. The first parameter of the Label call is the 
name of the parent window, in our case "root". So our Label widget is a child of the root widget.
The keyword parameter "text" specifies the text to be shown: 

<pre>
w = Label(root, text="Hello Tkinter!")
</pre>

The pack method tells Tk to fit the size of the window  to the given 
text.  
<pre>
w.pack()
</pre>

The window won't appear until we enter the Tkinter event loop:
<pre>
root.mainloop()
</pre>


Our script will remain in the event loop until we close the window. 

<br><br>

<h3>Using Images in Labels</h3>
As we have already mentioned, labels can contain text and images. The following example contains
two labels, one with a text and the other one with an image.
<br><br>
<pre>
from Tkinter import *

root = Tk()
logo = PhotoImage(file="../images/python_logo_small.gif")
w1 = Label(root, image=logo).pack(side="right")
explanation = """At present, only GIF and PPM/PGM
formats are supported, but an interface 
exists to allow additional image file
formats to be added easily."""
w2 = Label(root, 
           justify=LEFT,
           padx = 10, 
           text=explanation).pack(side="left")
root.mainloop()
</pre>
<br><br>

If you start this script, it will look like this using Ubuntu Linux with Gnome desktop:
<br><br>
<img src="images/label_with_image.png" alt="Label with included image" />

<br><br>
The "justify" parameter can be used to justify a text on the LEFT, RIGHT or CENTER. 
padx can be used to add additional horizontal padding around a text label. 
The default padding is 1 pixel. pady is similar for vertical padding.
The previous example without justify (default is centre) and padx looks like this:
<br><br>
<img src="images/label_with_image2.png" alt="Label with included image" />
<br><br>
You want the text drawn on top of the image? No problem! We need just one label and use the image and the text
option at the same time. By default, if an image is given, it is drawn instead of the text. To get the
text as well, you have to use the compound option. If you set the compound option to CENTER 
the text will be drawn on top of the image:
<pre>
from Tkinter import *

root = Tk()
logo = PhotoImage(file="../images/python_logo_small.gif")
explanation = """At present, only GIF and PPM/PGM
formats are supported, but an interface 
exists to allow additional image file
formats to be added easily."""
w = Label(root, 
          compound = CENTER,
          text=explanation, 
          image=logo).pack(side="right")

root.mainloop()
</pre>
<br><br>
<img src="images/text_on_top_of_image.png" alt="Text on top of image in label" />
<br><br>
We can have the image on the right side and the text left justified with a padding of 10 pixel 
on the left and right side by changing the Label command like this:
<br><br>
<pre>
w = Label(root, 
          justify=LEFT,
          compound = LEFT,
          padx = 10, 
          text=explanation, 
          image=logo).pack(side="right")
</pre>
<br><br>
If the compound option is set to BOTTOM, LEFT, RIGHT, or TOP, the image is drawn 
correspondingly to the bottom, left, right or top of the text. 


<br><br>

<h3>Colorized Labels in various fonts</h3>
Some Tk widgets, like the label, text, and canvas widget, allow you to specify the fonts 
used to display text. This can be achieved by setting the attribute "font".
typically via a "font" configuration option. You have to consider, that fonts are one of several 
areas that are not platform-independent.
<br><br>
The attribute fg can be used to have the text in another colour and the attribute bg can be used to
change the background colour of the label.
<br><br> 	 

<pre>
from Tkinter import *

root = Tk()

Label(root, 
		 text="Red Text in Times Font",
		 fg = "red",
		 font = "Times").pack()
Label(root, 
		 text="Green Text in Helvetica Font",
		 fg = "light green",
		 bg = "dark green",
		 font = "Helvetica 16 bold italic").pack()
Label(root, 
		 text="Blue Text in Verdana bold",
		 fg = "blue",
		 bg = "yellow",
		 font = "Verdana 10 bold").pack()

root.mainloop()
</pre>

The result looks like this:
<br><br>

<img src="images/colored_labels.png" alt="Colored Labels with different fonts" />    
<br><br>

<h3>Dynamical Content in a Label</h3>
The following script shows an example, where a label is dynamically incremented by 1
until the stop button is pressed:
<br><br>
<pre>
import Tkinter as tk

counter = 0 
def counter_label(label):
  def count():
    global counter
    counter += 1
    label.config(text=str(counter))
    label.after(1000, count)
  count()
 
 
root = tk.Tk()
root.title("Counting Seconds")
label = tk.Label(root, fg="green")
label.pack()
counter_label(label)
button = tk.Button(root, text='Stop', width=25, command=root.destroy)
button.pack()
root.mainloop()
</pre>
The result of the previous script looks like this:
<br><br>

<img src="images/dynamic_label.png" alt="Dynamic content in Label" />    
<br><br>



</div>


<div id="contextlinks">Next Chapter: <a href="tkinter_message_widget.php">Message Widget</a><br>
<LINK rel="next" href="tkinter_message_widget.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
