<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Courses:  </title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Python Training courses and classes by Bernd Klein in Toronto, Boston, Berlin, Paris, London and other locations." />
<meta name="Keywords" content="Python, course, training, classes, courses,beginners, advanced, Toronto, Boston, Canada, Berlin, Paris, London" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/python_head.jpg" alt="box" />    <h2></h2>

<div class="menu">

<ul>
</ul>

</div>

<p>
<hr>
<h3>Self-Study vs. Live Class</h3>
Lot's of visitors from our website wonder which method of learning Python may be best:
<ol>
<li>studying entirely on one's own with our online tutorial or other textbooks, 
i.e. "self-study"</li>
<li>live classroom trainings or on-site courses</li>
</ol>
We can't provide a general answer this question. It depends on the goals of a student.
One benefit to self-study is that it is the most economical option. 
Although a live class involves expenses, and often requires travelling to the course's 
location, there are significant and numerous benefits by attending a course taught 
by a live lecturer in a classroom setting: First of all, it's a lot faster, because our
experience is that participants in one of our courses learn in just 3 or 5 days more than 
they could have learnt in weeks of self-study. Besides this learning in a classroom setting 
is fun to learn. Travelling might not even be necessary, if you book Bernd Klein for an 
on-site course at your institution or company. 

<hr>
<br><br>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo, Python courses"
		     src="images/bodenseo_python_training.gif"><br>Linux and Python Courses as well as in-house courses</a>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
<h3>Further Open Classes</h3>
<p>
A detailled overview of all the open 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python courses and seminars"
		     src="images/classroom_training_courses.jpg">
		     </a>
		     by Bernd Klein at Bodenseo.

<br><br>
<font size="1">� kabliczech - Fotolia.com</font>
<h3>Quote of the Day:</h3>
<p>

<i>"But active programming consists of the design of new programs, rather than 
contemplation of old programs. "</i> (Niklaus Wirth)<br>


 </p>

</p></div>

<div id="content">

<h2>Python Courses</h2>
<p>
You are here on this website, because you are already convinced, that Python is one of the
best programming languages in the world today, if not the best one! It's designed both to 
optimise the productivity of the software developers and to guarantee software quality.
Maybe you are now looking for a high quality Python course by a renowned Python trainer.

<br> 
</p>

<div class="intro_double">

<h3>Python Courses</h3>

<ul>
<li><h4>Toronto:</h4>
<br>
Python course in Toronto:
<br>
3<sup>rd</sup> - 7<sup>th</sup> of November, 2014<br>
<br>See more at  <a href="http://ca.bodenseo.com/course/python_training_course.html">Python Programming Course for Beginners</a>
</li>
<li><h4>Paris:</h4>
1<sup>st</sup> - 5<sup>th</sup> of December, 2014<br>
</li>
<li><h4>Berlin / Potsdam:</h4>
10<sup>th</sup> - 14<sup>th</sup> of November, 2014<br>
</li>
<li><h4>Munich:</h4>
8<sup>th</sup> - 12<sup>th</sup> of December, 2014<br>
</li>
<li><h4>London:</h4>
20<sup>th</sup> - 24<sup>rd</sup> of October, 2014<br>
</li>
</li>
<li><h4>Lake Constance:</h4>
1<sup>st</sup> - 5<sup>th</sup> of September, 2014<br>
This Python Course takes place at Lake Constance close to Zurich.
<br>
<br>
Alternatively, you can book one of our <a href="http://www.bodenseo.com/courses.php?topic=Python">courses</a> at our site on Lake Constance close to Zurich, Bregenz, Ulm, Freiburg and Stuttgart. There is at least one course per month.
</li>
</ul>


<h3>Contents of our Fundamental Python Course</h3>
The course provides a hands-on introduction to the Python language covering 
object-oriented and functional programming techniques as well.   
<ul> 
<li>Introduction to Python: What is Python? Origin and intentions.  Differences to other 
programming languages. 
<li>Using the interactive Python shell 
<li>Editing and starting Python scripts 
<li>Fundamentals: Variables, basic data types and assignments. Operators and expressions.  
<li>Conditional Statements: The details of the if statement and the conditions 
<li>Loops: While and for-loops 
<li>Data Types: Lists, Tuples and Dictionaries
<li>Lists and stacks 
<li>Functions and recursive functions 
<li>File Handling 
<li>Exception Handling
<li>Regular Expressions
<li>Modules and Packages 
</ul> 
Optional Topics in the 5 days classes: 
<ul> 
<li>Lambda Expressions
<li>List Comprehension
<li>Module Tests
<li>Generators
<li>Object Oriented Programming with Python 
<li>Python GUI's with Tkinter or Qt (optional) 
<li>Extending Python with C (optional) 
</ul> 

<h3>The Costs</h3>
<div class="textmenu">
<p class="update">

The Python courses are reasonably priced. 
An on-site training class costs $ 1,290.00 per day for a highly renowned Python trainer. 
For most areas, the price per day includes the travelling and flight costs for Bernd Klein as well.
<br><br>
Open classes and courses can be booked at prices starting as low as $459,- per day in various locations, Toronto, Berlin, Potsdam, Paris, London, Zurich
and Lake Constance.
<br>



</p> 
</div></div>



<div class="intro3">

<h4>Bernd Klein</h4>

<p class="update">
Bernd Klein enjoys an international reputation as a Python trainer. He offers on-site 
Python courses in Europe (Switzerland, Austria, Germany, England, Belgium, and France) and 
client sites all over the world (US and Canada).
<br><br>
Bernd Klein has a diploma in Computer Science from the Saarland University 
(Saarbr�cken) with emphasis on computer languages. 
He gained teaching experience at the Saarland University, Saarbr�cken, 
and the EWH in Koblenz. 
<br><br>
He is the founder and sole holder of Bodenseo.
</p> 
<h3>The Benefits</h3>
Live classes by Bernd Klein provide intensive, hands-on, and in-depth introductions to the Python
programming language. Additionally, these courses can cover graphical user interfaces like Qt
and Tkinter and the database, internet or text processing facilities of Python. 

<h4>Further Information</h4>
For more information about our classes or booking courses, please 
<a href="contact.php" rel="nofollow">contact us</a>
</div>
</div>



