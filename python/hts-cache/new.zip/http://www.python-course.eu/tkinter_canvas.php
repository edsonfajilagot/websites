<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>GUI Programming with Python: Canvas Widget</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial on Tkinter: Canvas Widgets" />
<meta name="Keywords" content="Python, Tkinter, Tk, Tutorial, Introduction, course,canvas, canvas widget" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li class="active"><a id="current" href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/python_head.png" alt="box" />    <h2>Tkinter Tutorial</h2>

<div class="menu">

<ul>
<li><a href="tkinter_labels.php">Saying Hello with Labels</a></li><li><a href="tkinter_message_widget.php">Message Widget</a></li><li><a href="tkinter_buttons.php">Buttons</a></li><li><a href="tkinter_variable_classes.php">Variable Classes</a></li><li><a href="tkinter_radiobuttons.php">Radiobuttons</a></li><li><a href="tkinter_checkboxes.php">Checkboxes</a></li><li><a href="tkinter_entry_widgets.php">Entry Widgets</a></li><li><a href="tkinter_canvas.php">Canvas Widgets</a></li><li><a href="tkinter_sliders.php">Sliders</a></li><li><a href="tkinter_text_widget.php">Text Widget</a></li><li><a href="tkinter_dialogs.php">Dialogs</a></li><li><a href="tkinter_layout_management.php">Layout Management</a></li><li><a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a></li><li><a href="tkinter_menus.php">Creating Menus</a></li><li><a href="tkinter_events_binds.php">Events and Binds</a></li></ul>

</div>

<p>
<br>

<h3>Canvas in Life</h3>
The American talks show host Oprah Winfrey said: 
<i>"With every experience, you alone are painting your own canvas, 
thought by thought, choice by choice."</i>
<br>
A thought, which is not too far away from a famous quotation by the American comedian, dancer
and singer Danny Kaye:
<i>"Life is a great big canvas; throw all the paint on it you can."</i>
<br>
The philosopher Voltaire sees love as a canvas: 
<i>"Love is a canvas furnished by Nature and embroidered by imagination."</i>
<hr>
<hr>
<br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/tkinter_canvas.php">Canvas-Element</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein. 
<br>
If you are interested in an instructor-led classroom training in Canada or the US, you may have a look at the 
<a href="http://ca.bodenseo.com/courses.php?topic=Python">Python courses
by Bernd Klein at Bodenseo<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
<br>
<font size="1">� kabliczech - Fotolia.com</font>
<br><br>
Overview of <a href="python_classes.php">Python courses</a> by Bernd Klein.


<h3>Quote of the Day:</h3>
<p>

<i>"I think the special thing about Python is that it's a writers' commune. 
The writers are in charge. The writers decide what the material is."</i> (Eric Idle )<br>
<h3>Graphical User Interface</h3>
A graphical user interface (GUI) is a type of user interface that allows users to interact 
with electronic devices in a graphical way, i.e. with images, rather than text commands.
Originally interactive user interfaces to computers were not graphical, they were text  
oriented and usually consisted of commands, which had to be remembered. 
The DOS operating system from Microsoft and the Bourne shell under Linux are examples
of such user-computer interfaces. 


 </p>

</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="tkinter_entry_widgets.php">Entry Widgets</a><br>
<LINK rel="prev" href="tkinter_entry_widgets.php">Next Chapter: <a href="tkinter_sliders.php">Sliders</a><br>
<LINK rel="next" href="tkinter_sliders.php"></div>
<h2>Canvas Widgets</h2>
<br>
<h3>Introduction</h3>
<img class="imgright" src="images/python_cubism.png" alt="Python snake in Canvas" />
<br>
The Canvas widget supplies graphics facilities for Tkinter. Among these graphical objects are lines, circles, images, and even
other widgets. With this widget it's possible to draw graphs and plots, create graphics editors, and implement various kinds of custom widgets.
<br><br>
We demonstrate in our first example, how to draw a line. 
<br>
The method create_line(coords, options) is used to draw a straight line. The coordinates "coords" are
given as four integer numbers: x<sub>1</sub>, y<sub>1</sub>, x<sub>2</sub>, y<sub>2</sub> 
This means that the line goes from the point (x<sub>1</sub>, y<sub>1</sub>) to the point
(x<sub>2</sub>, y<sub>2</sup>) After these coordinates follows a comma separated list of 
additional parameters, which may be empty. We set for example the colour of the line to 
the special green of our website: fill="#476042"
<br><br>
We kept the first example intentionally very simple. We create a canvas and draw a straight horizontal 
line into this canvas. This line vertically cuts the canvas into two areas.
<br><br>
The casting to an integer value in the assignment "y = int(canvas_height / 2)" is superfluous, because
create_line can work with float values as well. They are automatically turned into integer values. 
In the following you can see the code of our first simple script:
<br><br>
<pre>
from tkinter import *
master = Tk()

canvas_width = 80
canvas_height = 40
w = Canvas(master, 
           width=canvas_width,
           height=canvas_height)
w.pack()

y = int(canvas_height / 2)
w.create_line(0, y, canvas_width, y, fill="#476042")


mainloop()
</pre>
<br><br>
If we start this program, using Python 3, we get the following window:
<br><br>
<img src="images/horizontal_line_canvas.png" alt="straight horizontal line in canvas" />


<br><br>
For creating rectangles we have the method create_rectangle(coords, options). Coords is
again defined by two points, but this time the first one is the top left point and the bottom
right point of the rectangle.
<br><br>
<img src="images/canvas_rectangle_lines.png" alt="Canvas with rectangles and lines" />
<br><br>
The window, you see above, is created by the following Python tkinter code:
<pre>
from tkinter import *

master = Tk()

w = Canvas(master, width=200, height=100)
w.pack()

w.create_rectangle(50, 20, 150, 80, fill="#476042")
w.create_rectangle(65, 35, 135, 65, fill="yellow")
w.create_line(0, 0, 50, 20, fill="#476042", width=3)
w.create_line(0, 100, 50, 80, fill="#476042", width=3)
w.create_line(150,20, 200, 0, fill="#476042", width=3)
w.create_line(150, 80, 200, 100, fill="#476042", width=3)

mainloop()
</pre>

The following image with the coordinates will simplify the understanding of application 
of create_lines and create_rectangle in our previous example.
<br><br>
<img src="images/canvas_rectangle_lines_coordinates.png" alt="Canvas with rectangles and lines plus coordinates" />

<h3>Text on Canvas</h3>

We demonstrate now how to print text on a canvas. We will extend and modify the previous example
for this purpose. The method create_text() can be applied to a canvas object to write text on it.
The first two parameters are the x and the y positions of the  text object. By default, the text 
is centred on this position. You can override this with the anchor option. For example, if the 
coordinate should be the upper left corner, set the anchor to NW. 
With the keyword parameter text, we can define the actual text to be displayed on the canvas.

<pre>
from tkinter import *

canvas_width = 200
canvas_height = 100

colours = ("#476042", "yellow")
box=[]

for ratio in ( 0.2, 0.35 ):
   box.append( (canvas_width * ratio,
                canvas_height * ratio,
                canvas_width * (1 - ratio),
                canvas_height * (1 - ratio) ) )

master = Tk()

w = Canvas(master, 
           width=canvas_width, 
           height=canvas_height)
w.pack()

for i in range(2):
   w.create_rectangle(box[i][0], box[i][1],box[i][2],box[i][3], fill=colours[i])

w.create_line(0, 0,                 # origin of canvas
              box[0][0], box[0][1], # coordinates of left upper corner of the box[0]
              fill=colours[0], 
              width=3)
w.create_line(0, canvas_height,     # lower left corner of canvas
              box[0][0], box[0][3], # lower left corner of box[0]
              fill=colours[0], 
              width=3)
w.create_line(box[0][2],box[0][1],  # right upper corner of box[0] 
              canvas_width, 0,      # right upper corner of canvas
              fill=colours[0], 
              width=3)
w.create_line(box[0][2], box[0][3], # lower right corner pf box[0]
              canvas_width, canvas_height, # lower right corner of canvas
              fill=colours[0], width=3)

w.create_text(canvas_width / 2,
              canvas_height / 2,
              text="Python")
mainloop()
</pre>

<br>Though the code of our example program is changed drastically, the graphical result looks still the
same except for the text "Python":
<br><br>
<img src="images/canvas_with_text.png" alt="Canvas with Text" />
<br><br>
You can understand the benefit of our code changes, if you change for example the height of 
the canvas to 190 and the width to 90 and modify the ratio for the first box to 0.3. Image 
doing this in the code of our first example. It would be a lot tougher. The result looks like
this:
<br><br>
<img src="images/easily_adaptable.png" alt="Easily adaptable after code modifications" />
<br><br>
<h3>Oval Objects</h3>
An oval (or an ovoid) is any curve resembling an egg (ovum means egg in Latin). It resembles an ellipse,
but it is not an ellipse. The term "oval" is not well-defined. Many different curves are 
called ovals, but they all have in common:
<ul>
<li>They are differentiable, simple (not self-intersecting), convex, closed, plane curves</li>
<li>They are very similar in shape to ellipses</li>
<li>There is at least one axis of symmetry</li>
</ul>

The word oval stems from Latin ovum meaning "egg" and that's what it is: A figure which resembles the
form of an egg. An oval is constructed from two pairs of arcs, with two different radii 
A circle is a special case of an oval.
<br><br>
<img src="images/canvas_oval.png" alt="Eclipses in a Canvas" />
<br><br>
We can create an oval on a canvas c with the following method:
<br><br>
<pre>
id = C.create_oval ( x0, y0, x1, y1, option, ... )
</pre>
This method returns the object ID of the new oval object on the canvas C. 
<br><br>
The following script draws a circle around the point (75,75) with the radius 25:
<br><br>
<pre>
from tkinter import *

canvas_width = 190
canvas_height =150

master = Tk()

w = Canvas(master, 
           width=canvas_width, 
           height=canvas_height)
w.pack()

w.create_oval(50,50,100,100)

mainloop()
</pre>
<br><br>
We can define a small function drawing circles by using the create_oval() method.

<pre>
def circle(canvas,x,y, r):
   id = canvas.create_oval(x-r,y-r,x+r,y+r)
   return id
</pre>

<br><br>

<h3>Painting Interactively into a Canvas</h3> 
We want to write an application for painting or writing into a canvas. Unfortunately, there is
no way to paint just one dot into a canvas. But we can overcome this problem by using a small oval:

<pre>
from tkinter import *

canvas_width = 500
canvas_height = 150

def paint( event ):
   python_green = "#476042"
   x1, y1 = ( event.x - 1 ), ( event.y - 1 )
   x2, y2 = ( event.x + 1 ), ( event.y + 1 )
   w.create_oval( x1, y1, x2, y2, fill = python_green )

master = Tk()
master.title( "Painting using Ovals" )
w = Canvas(master, 
           width=canvas_width, 
           height=canvas_height)
w.pack(expand = YES, fill = BOTH)
w.bind( "<B1-Motion>", paint )

message = Label( master, text = "Press and Drag the mouse to draw" )
message.pack( side = BOTTOM )
    
mainloop()
</pre>




<br><br>
<img src="images/Painting_on_canvas.png" alt="Painting / Writing Python on Canvas" />

<br><br>

<h3>Drawing Polygons</h3>

If you want to draw a polygon, you have to provide at least three coordinate points:
<br>create_polygon(x0,y0, x1,y1, x2,y2, ...)
<br><br>
In the following example we draw a triangle using this method:

<br><br>
<pre>
from tkinter import *

canvas_width = 200
canvas_height =200
python_green = "#476042"

master = Tk()

w = Canvas(master, 
           width=canvas_width, 
           height=canvas_height)
w.pack()

points = [0,0,canvas_width,canvas_height/2, 0, canvas_height]
w.create_polygon(points, outline=python_green, 
            fill='yellow', width=3)

mainloop()
</pre>
<br>
It looks like this:
<br><br>
<img src="images/canvas_polygon.png" alt="Polygon on a canvas" />

<br><br>
When you read this, there may or not be Christmas soon, but we present a way to improve your
next Christmas with some stars, created by Python and Tkinter. The first star is straight forward with
hardly any programming skills involved:

<br><br>
<pre>
from tkinter import *

canvas_width = 200
canvas_height =200
python_green = "#476042"

master = Tk()

w = Canvas(master, 
           width=canvas_width, 
           height=canvas_height)
w.pack()

points = [100, 140, 110, 110, 140, 100, 110, 90, 100, 60, 90, 90, 60, 100, 90, 110]

w.create_polygon(points, outline=python_green, 
            fill='yellow', width=3)

mainloop()
</pre>
<br>
<img src="images/star_1.png" alt="Star created with create_polygon of tkinter" />
<br><br>
As we have mentioned, this approach is very unskilful. What if we have to change the size 
or the thickness of the star? We have to change all the points manually, which is of course
an error-prone and tedious task to do. So, we present a new version of
the previous script which involves more "programming" and programming skills. First, we put
the creation of the star in a function, and we use an origin point and two lengths  p and t to
create the star:
<br><br>
<img src="images/star_notations.png" alt="star notation" />
<br><br>
Our new improved program looks like this now:

<br><br>
<pre>
from tkinter import *

canvas_width = 400
canvas_height =400
python_green = "#476042"

def polygon_star(canvas, x,y,p,t, outline=python_green, fill='yellow', width = 1):
   points = []
   for i in (1,-1):
      points.extend((x,	      y + i*p))
      points.extend((x + i*t, y + i*t))
      points.extend((x + i*p, y))
      points.extend((x + i*t, y - i * t))

   print(points)

   canvas.create_polygon(points, outline=outline, 
                         fill=fill, width=width)

master = Tk()

w = Canvas(master, 
           width=canvas_width, 
           height=canvas_height)
w.pack()

p = 50
t = 15

nsteps = 10
step_x = int(canvas_width / nsteps)
step_y = int(canvas_height / nsteps)

for i in range(1, nsteps):
   polygon_star(w,i*step_x,i*step_y,p,t,outline='red',fill='gold', width=3)
   polygon_star(w,i*step_x,canvas_height - i*step_y,p,t,outline='red',fill='gold', width=3)

mainloop()
</pre>
<br><br>
The result looks even more like Xmas and we are sure, that nobody doubts, that it would be hell to
define the polygon points directly, as we did in our first star example:
<br><br>
 <img src="images/stars.png" alt="stars" />
 
<br><br>
<h3>Bitmaps</h3>
The method create_bitmap() can be be used to include a bitmap on a canvas.
The following bitmaps are available on all platforms:<br>
"error", "gray75", "gray50", "gray25", "gray12", "hourglass", "info", "questhead", "question", "warning"
<br><br>
The following script puts all of these bitmaps on a canvas:
<br><br>
<pre>
from tkinter import *

canvas_width = 300
canvas_height =80

master = Tk()
canvas = Canvas(master, 
           width=canvas_width, 
           height=canvas_height)
canvas.pack()

bitmaps = ["error", "gray75", "gray50", "gray25", "gray12", "hourglass", "info", "questhead", "question", "warning"]
nsteps = len(bitmaps)
step_x = int(canvas_width / nsteps)

for i in range(0, nsteps):
   canvas.create_bitmap((i+1)*step_x - step_x/2,50, bitmap=bitmaps[i])

mainloop()
</pre>
<br><br>
The result looks like this:
<br><br>
<img src="images/bitmap_on_canvas.png" alt="Bitmap on Canvas" />
<br><br>
<h3>The Canvas Image Item</h3> 
The Canvas method create_image(x0,y0, options ...) is used to draw an image on a canvas. 
create_image doesn't accept an image directly. It uses an object which is created by the 
PhotoImage() method. The PhotoImage class can only read GIF and PGM/PPM images from files

<br><br>
<pre>
from tkinter import *

canvas_width = 300
canvas_height =300

master = Tk()

canvas = Canvas(master, 
           width=canvas_width, 
           height=canvas_height)
canvas.pack()

img = PhotoImage(file="rocks.ppm")
canvas.create_image(20,20, anchor=NW, image=img)

mainloop()
</pre>
<br>
The window created by the previous Python script looks like this:
<br><br>
<img src="images/rocks.png" alt="Rocks on Canvas" />


<br><br>
<h3>Exercise</h3>
Write a function, which draws a checkered pattern into a canvas. The function gets called with
checkered(canvas, line_distance). "canvas" is the Canvas object, which will be drawn into. line_distance
is the distance between the vertical and horizontal lines.
<br><br>
<img src="images/line_distance.png" alt="Explaining the parameter line distance" />
<br><br>
<h3>Solution</h3>
<br>
<pre>
from tkinter import *

def checkered(canvas, line_distance):
   # vertical lines at an interval of "line_distance" pixel
   for x in range(line_distance,canvas_width,line_distance):
      canvas.create_line(x, 0, x, canvas_height, fill="#476042")
   # horizontal lines at an interval of "line_distance" pixel
   for y in range(line_distance,canvas_height,line_distance):
      canvas.create_line(0, y, canvas_width, y, fill="#476042")


master = Tk()
canvas_width = 200
canvas_height = 100 
w = Canvas(master, 
           width=canvas_width,
           height=canvas_height)
w.pack()

checkered(w,10)

mainloop()
</pre>

<br><br>

The result of the previous script looks like this:
<br>
<br>
<img src="images/checkered_canvas.png" alt="Checkered canvas" />


<br><br>
</div>
<div id="contextlinks">Previous Chapter: <a href="tkinter_entry_widgets.php">Entry Widgets</a><br>
<LINK rel="prev" href="tkinter_entry_widgets.php">Next Chapter: <a href="tkinter_sliders.php">Sliders</a><br>
<LINK rel="next" href="tkinter_sliders.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
