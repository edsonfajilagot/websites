<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: Interactive Mode</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction into the interactive mode in Python and the Interpreter" />
<meta name="Keywords" content="Python, interactiv, interactive mode, interpreter" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/python_head.jpg" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<h3>Mythology</h3>
The first great achievement of Apollo was to slay the huge serpent Python. In some texts 
Python is an enormous dragon and not a serpent. 
<br>  
But who was this mythical creature? Python was created out of the slime and mud left after 
the great flood. She was  appointed by Gaia (Mother Earth) to guard the oracle of Delphi, 
known as Pytho. After having defeated Python Apollo remade
her former home and the oracle as his own.
<br>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/interaktiv.php">Der Interpreter</a><h3>Python 2.7</h3>This tutorial deals with Python Version 2.7<br>This chapter from our course is available in a version for Python3: <a href="python3_interactive.php">Interactive Mode</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>"If you want to accomplish something in the world, idealism is not enough - you need to 
choose a method that works to achieve the goal."</i> (Richard Stallmann)<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="why_python.php">Why Python</a><br>
<LINK rel="prev" href="why_python.php">Next Chapter: <a href="execute_script.php">Execute a Script</a><br>
<LINK rel="next" href="execute_script.php"></div>
<h2>Using the Python Interpreter</h2>
<p>
With the Python interactive interpreter it is easy to check Python commands. 
The Python interpreter can be invoked by typing the command "python" without any 
parameter followed by the "return" key at the shell prompt:
<pre>
python
</pre>
</p>
<p>Python comes back with the following information:
<pre>
Python 2.5.2 (r252:60911, Oct  5 2008, 19:29:17) 
[GCC 4.3.2] on linux2
Type "help", "copyright", "credits" or "license" for more information.
>>> 
</pre>
</p>

<p>
Once the Python interpreter is started, you can issue any command at the command 
prompt ">>>". 
<br>
The first thing we will do is write the mandatory "Hello World" statement:
<pre>
>>> print "Hello World"
Hello World
</pre>
It couldn't have been easier, could it? Oh yes, it can be written in a even simpler
way. In the interactive Python interpretor the print is not necessary:
<pre>
>>> "Hello World"
'Hello World'
>>> 3
3
>>> 
</pre>
 
<br>In the following example we use the interpreter as a simple calculator by typing an
arithmetic expression:

  >>> 4.567 * 8.323 * 17
646.18939699999999
>>> 
  </pre>
You might be surprised, if you type in the following:
<pre>
>>> 12 / 7
1
>>> 
</pre>
Python assumes, that you are interested in integer division, because both divisor and 
divident are integers. So the result is an integer again. The easiest way to get an exact
result is by making one of the values a float by adding a ".0":
<pre>
>>> 12.0 / 7
1.7142857142857142
>>> 
</pre>
Alternatively you can cast one or both arguments:
<pre>
>>> float(12) / 7
1.7142857142857142
>>> 
</pre>
Python follows the usual order of operation in expression. The standard order of operations 
is expressed in the following enumeration:
<ol>
	<li>exponents and roots</li>
	<li>multiplication and division</li>
	<li>addition and subtraction</li>
</ol>
This means, that we don't need paranthesis in the expression "3 + (2 * 4):
<pre>
>>> 3 + 2 * 4
11
>>> 
</pre>
The most recent output value is automatically stored by the interpreter in a special
variable with the name "_". So we can print the output from the recent example again by 
typing an underscore after the prompt:
<pre>
>>> _
11
>>> 
</pre>
The underscore can be used in other expressions like any other variable:
<pre>
>>> _ * 3
33
>>> 
</pre>
</p> 

<p>
To close the Python interactive interpreter in Linux type Ctrl-D
<br>
</p>



</div>


<div id="contextlinks">Previous Chapter: <a href="why_python.php">Why Python</a><br>
<LINK rel="prev" href="why_python.php">Next Chapter: <a href="execute_script.php">Execute a Script</a><br>
<LINK rel="next" href="execute_script.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
