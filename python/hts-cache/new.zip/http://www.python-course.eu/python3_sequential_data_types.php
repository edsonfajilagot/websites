<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Sequential Data Types</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="This chapter of our online python 3 tutorial deals with Sequential Data Types: introduction into strings, lists and tuples with many examples." />
<meta name="Keywords" content="Python, introduction, sequential, data types, sequence,
lists, slicing" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/infinite_python.jpg" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<h3>Mythology</h3>
The first great achievement of Apollo was to slay the huge serpent Python. In some texts 
Python is an enormous dragon and not a serpent. 
<br>  
But who was this mythical creature? Python was created out of the slime and mud left after 
the great flood. She was  appointed by Gaia (Mother Earth) to guard the oracle of Delphi, 
known as Pytho. After having defeated Python Apollo remade
her former home and the oracle as his own.
<br>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_sequentielle_datentypen.php">Sequentielle Datentypen</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="sequential_data_types.php">Sequential Data Types in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="sequential_data_types.php">Sequential Data Types in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_operators.php">Operators</a><br>
<LINK rel="prev" href="python3_operators.php">Next Chapter: <a href="python3_deep_copy.php">Shallow and Deep Copy</a><br>
<LINK rel="next" href="python3_deep_copy.php"></div>
<h2>Sequential Data Types</h2>
<h3>Introduction</h3>
<img class="imgright" src="images/green_tree_python3_250.jpg" alt="Python endless"/>
Sequences are one of the principal built-in data tpyes besides numerics, mappings, files,
instances and exceptions. Python provides for six sequence (or sequential) data types:
<ul>
<li>strings</li>
<li>byte sequences</li>
<li>byte arrays</li>
<li>lists</li>
<li>tuples</li>
<li>range objects</li>
</ul>

Strings, lists, tuples, bytes and range objects may look like utterly different things, but
nevertheless they have some underlying concepts in common:
<ul>
<li>The items or elements of strings, lists and tuples are ordered in a defined sequence</li>
<li>The elements can be accessed via indices<br>
<pre>
>>> text = "Lists and Strings can be accessed via indices!"
>>> print(text[0], text[10], text[-1])
L S !
>>> 
</pre>
Accessing lists:
<pre>
>>> l = ["London", "Paris", "Strasbourg", "Zurich"]
>>> print(l[1], l[2])
Paris Strasbourg
>>> 
</pre>
</li>
</ul>

Unlike other programming languages Python uses the same syntax and function names to work 
on sequential data types. For example, the length of a string, a list, and a tuple can be 
determined with a function called len():
<pre>
>>> countries = ["Germany","Switzerland","Austria","France","Belgium", "Netherlands", "England"]
>>> len(countries)
7
>>> fib = [1,1,2,3,5,8,13,21,34,55]
>>> len(fib)
10
>>> 
</pre> 

<h3>Bytes</h3>
The bytes object is a sequence of small integers. The elements of a byte object are in the range 
0 through 255, corresponding to ASCII characters and they are printed as such. 

<h3>Python Lists</h3>
So far we had already used some lists, but we haven't introduced them properly.
Lists are related to arrays of programming languages like C, C++ or Java,
but Python lists are by far more flexible and powerful than "classical" arrays.
For example items in a list need not all have the same type. Furthermore 
lists can grow in a program run, while in C the size of an array has to be 
fixed at compile time.
<br><br>
Generally speaking a list is an collection of objects. To be more precise: 
A list in Python is an ordered group of items or elements. It's important to notice, that these 
list elements don't have to be of the 
same type. It can be an arbitrary mixture of elements like numbers, strings, other lists and so
on. The list type is essential for Python scripts and programs, this means, that you will
hardly find any serious Python code without a list. 
<br><br>
The main properties of Python lists:
<ul>
<li>They are ordered</li>
<li>The contain arbitrary objects</li>
<li>Elements of a list can be accessed by an index</li>
<li>They are arbitrarily nestable, i.e. they can contain other lists as sublists</li>
<li>Variable size</li>
<li>They mutable, i.e. they elements of a list can be changed</li>
</ul>

<h4>List Notation and Examples</h4>
List objects are enclosed by square brackets and separated by commas. The following table contains
some examples of lists:
<br><br>
<table
style="text-align: left; width: 60%; background-color: rgb(255, 255, 102);"
border="1" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<th style="vertical-align: top;">List
</th>
<th style="vertical-align: top;">Description
</th>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">[]</FONT></td>
<td style="vertical-align: top;">An empty list</td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">[1,1,2,3,5,8]</FONT></td>
<td style="vertical-align: top;">A list of integers</td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">[42, "What's the question?", 3.1415]</FONT></td>
<td style="vertical-align: top;">A list of mixed data tpyes</td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
["Stuttgart", "Freiburg", "M�nchen", "N�rnberg", "W�rzburg", "Ulm","Friedrichshafen", Z�rich", "Wien"]</FONT></td>
<td style="vertical-align: top;">A list of Strings</td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
[["London","England", 7556900], ["Paris","France",2193031], ["Bern", "Switzerland", 123466]]
</FONT></td>
<td style="vertical-align: top;">A nested list</td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">["High up", ["further down", 
["and down", ["deep down", "the answer", 42]]]]</FONT></td>
<td style="vertical-align: top;">A deeply nested list</td>
</tr>

</tbody>
</table>

<h4>Accessing List elements</h4>

Assigning a list to a variable:
<pre>
languages = ["Python", "C", "C++", "Java", "Perl"]
</pre>

There are different ways of accessing the elements of a list. 
Most probably the easiest way for C programmers will be through indices, i.e.
the numbers of the lists are enumerated starting with 0:
<pre>
>>> languages = ["Python", "C", "C++", "Java", "Perl"]
>>> print(languages[0] + " and " + languages[1] + " are quite different!") 
Python and C are quite different!
>>> print("Accessing the last element of the list: " + languages[-1]) 
Accessing the last element of the list: Perl
>>> 
</pre>
The previous example of a list has been a list with elements of equal data types. 
But as we had before, lists can have various data types. The next example shows this:
<pre>
group = ["Bob", 23, "George", 72, "Myriam", 29]
</pre>

<h3>Sublists</h3>
Lists can have sublists as elements. These Sublists may contain sublists as well, i.e.
 lists can be recursively constructed by sublist structures.
<pre>
>>> person = [["Marc","Mayer"],["17, Oxford Str", "12345","London"],"07876-7876"]
>>> name = person[0]
>>> print(name)
['Marc', 'Mayer']
>>> first_name = person[0][0]
>>> print(first_name)
Marc
>>> last_name = person[0][1]
>>> print(last_name)
Mayer
>>> address = person[1]
>>> street = person[1][0]
>>> print(street)
17, Oxford Str
</pre>
The next example shows a more complex list with a deeply structured list:
<pre>
>>> complex_list = [["a",["b",["c","x"]]]]
>>> complex_list = [["a",["b",["c","x"]]],42]
>>> complex_list[0][1]
['b', ['c', 'x']]
>>> complex_list[0][1][1][0]
'c'
</pre>

<h3>Tuples</h3>
A tuple is an immutable list, i.e. a tuple cannot be changed in any way once it has
been created. A tuple is defined analogously to lists, except that the set of 
elements is enclosed in parentheses instead of square brackets. The rules for 
indices are the same as for lists. Once a tuple has been created, you can't add elements
to a tuple or remove elements from a tuple.
<br><br>
Where is the benefit of tuples?
<ul>
<li>Tuples are faster than lists.</li>
<li>If you know, that some data doesn't have to be changed, you should use tuples
instead of lists, because this protect your data against accidental changes to these
data.</li>
<li>Tuples can be used as keys in dictionaries, while lists can't.</li>
</ul> 
 The following example shows how to define a tuple and how to access a tuple. 
 Furthermore we can see, that we raise an error, if we try to assign a new value
 to an element of a tuple:
<pre>
>>> t = ("tuples", "are", "immutable")
>>> t[0]
'tuples'
>>> t[0]="assignments to elements are not possible"
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
TypeError: 'tuple' object does not support item assignment
</pre>




</p>
<h3>Slicing</h3>
<p>
In many programming languages it can be quite tough to slice a part of a string and
even tougher, if you like to address a "subarray". Python make it very easy with its
slice operator. Slicing is often better known as substring or substr.
<br><br>
When you want to extract part of a string, or some part of a list, you use in Python
the slice operator. The syntax is simple. Actually it looks a little bit like accessing
a single element with an index, but instead of just one number we have more, separated 
with a colon ":". We have a start and an end index, one or both of them may be missing.
It's best to study the mode of operation of slice by having a look at examples:
<pre>
>>> str = "Python is great"
>>> first_six = str[0:6]
>>> first_six
'Python'
>>> starting_at_five = str[5:]
>>> starting_at_five
'n is great'
>>> a_copy = str[:]
>>> without_last_five = str[0:-5]
>>> without_last_five
'Python is '
>>> 
</pre>

Syntactically, there is no difference on lists:
<pre>
>>> languages = ["Python", "C", "C++", "Java", "Perl"]
>>> some_languages = languages[2:4]
>>> some_languages
['C++', 'Java']
>>> without_perl = languages[0:-1]
>>> without_perl
['Python', 'C', 'C++', 'Java']
>>> 
</pre> 

<br>
Slicing works with three arguments as well. If the third argument is for example 3, 
only every third element of the list, string or tuple from the range of the first
two arguments will be taken. 
<br><br>
If s is a sequential data tpye, it works like this:<br>
<pre>
s[begin: end: step]
</pre>

The resulting sequence consists of the following elements:
<pre>
s[begin], s[begin + 1 * step], ... s[begin + i * step] for all (begin + i * step) < end.
</pre>
In the following example we define a string and we print every third character of
this string:
<br>
<pre>
>>> str = "Python under Linux is great"
>>> str[::3]
'Ph d n  e'
</pre>

The following string, which looks like letter salad, contains two sentences. One of them contains
covert advertising of my Python courses in Canada:

<pre>
"TPoyrtohnotno  ciosu rtshees  lianr gTeosrto nCtiot yb yi nB oCdaennasdeao"
</pre>

Try to figure it out using slicing with the step argument.

The solution is: You have to set step to 2

<pre>
>>> s
'TPoyrtohnotno  ciosu rtshees  lianr gTeosrto nCtiot yb yi nB oCdaennasdeao'
>>> s[::2]
'Toronto is the largest City in Canada'
>>> s[1::2]
'Python courses in Toronto by Bodenseo'
>>> 
</pre>

You may be interested in how we created the string. You have to understand list comprehension to understand the following:

<pre>
>>> s = "Toronto is the largest City in Canada"
>>> t = "Python courses in Toronto by Bodenseo"
>>> s = "".join(["".join(x) for x in zip(s,t)])
>>> s
'TPPyotyhrotno hcnooutrnsoe s  ciino sTuo rrotnsthoe ebsy   Bloidaennrs ego'
>>> 
</pre>

</p>
<h3>Length</h3>
<p>
<img class="imgleft" src="images/metermass.gif" alt="Length of a sequence"/>
The length of a sequence, i.e. a list, a string or a tuple, can be determined with the 
function len(). For strings it counts the number of characters and for lists or tuples
the number of elements are counted, whereas a sublist counts as 1 element.

<pre>
>>> txt = "Hello World"
>>> len(txt)
11
>>> a = ["Swen", 45, 3.54, "Basel"]
>>> len(a)
4
</pre>

</p>

<h3>Concatenation of Sequences</h3>
Combining two sequences like strings or lists is as easy as adding two numbers.
Even the operator sign is the same.
<br>
The following example shows how to concatenate two strings into one:
<pre>
>>> firstname = "Homer"
>>> surname = "Simpson"
>>> name = firstname + " " + surname
>>> print(name)
Homer Simpson
>>>  
</pre>

It's as simple for lists:
<pre>
>>> colours1 = ["red", "green","blue"]
>>> colours2 = ["black", "white"]
>>> colours = colours1 + colours2
>>> print(colours)
['red', 'green', 'blue', 'black', 'white']
</pre>
The augmented assignment "+=" which is well known for arithmetic assignments work 
for sequences as well. 
 
<pre>
s += t
</pre>
is syntactically the same as:
<pre>
s = s + t
</pre>
But it is only syntactically the same. The implementation is different:
In the first case the left side has to be evaluated only once. 
Augment assignments may be applied for mutable objects as an optimization.
<h3>Checking if an Element is Contained in List</h3>
<p>
It's easy to check, if an item is contained in a sequence. We can use the 
"in" or the "not in" operator for this purpose.
<br>
The following example shows how this operator can be applied:
<pre>
>>> abc = ["a","b","c","d","e"]
>>> "a" in abc
True
>>> "a" not in abc
False
>>> "e" not in abc
False
>>> "f" not in abc
True
>>> str = "Python is easy!"
>>> "y" in str
True
>>> "x" in str
False
>>> 
</pre>
 </p>

<h3>Repetitions</h3>
<p>
So far we had a "+" operator for sequences. There is a "*" operator available as well.
Of course there is no "multiplication" between two sequences possible. "*" is defined
for a sequence and an integer, i.e. s * n or  n * s.
<br>
It's a kind of abbreviation for an n-times concatenation, i.e.
<pre>
str * 4
</pre>
is the same as
<pre>
str + str + str + str
</pre>
Further examples:
<pre>
>>> 3 * "xyz-"
'xyz-xyz-xyz-'
>>> "xyz-" * 3
'xyz-xyz-xyz-'
>>> 3 * ["a","b","c"]
['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']
</pre>

The augmented assignment for "*" can be used as well:
<br>
s *= n	is the same as  s = s * n.
<br><br><br>
</p>
<h3>The Pitfalls of Repetitions</h3>
In our previous examples we applied the repetition operator on strings and flat lists. We can apply 
it to nested lists as well:
<pre>
>>> x = ["a","b","c"]
>>> y = [x] * 4
>>> y
[['a', 'b', 'c'], ['a', 'b', 'c'], ['a', 'b', 'c'], ['a', 'b', 'c']]
>>> y[0][0] = "p"
>>> y
[['p', 'b', 'c'], ['p', 'b', 'c'], ['p', 'b', 'c'], ['p', 'b', 'c']]
>>> 
</pre>
<img class="imgleft" src="images/repetitions.png" alt="Repetitions with references"/>
This result is quite astonishing for beginners of Python programming. We have assigned a new value to 
the first element of the first sublist of y, i.e. y[0][0] and we have "automatically" changed the first
elements of all the sublists in y, i.e. y[1][0], y[2][0], y[3][0]
 <br>The reason is, that the repetition operator "* 4" creates 4 references to the list x:
and so it's clear that every element of y is changed, if we apply a new 
 value to y[0][0].
<div id="contextlinks">Previous Chapter: <a href="python3_operators.php">Operators</a><br>
<LINK rel="prev" href="python3_operators.php">Next Chapter: <a href="python3_deep_copy.php">Shallow and Deep Copy</a><br>
<LINK rel="next" href="python3_deep_copy.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
