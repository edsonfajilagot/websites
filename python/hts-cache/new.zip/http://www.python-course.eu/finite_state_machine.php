<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Advanced: Finite State Machine in Python</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction into Finite State Machines and a simple example implementation in Python" />
<meta name="Keywords" content="Python, Introduction, Finite State Machine, example, implementation" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li class="active"><a id="current" href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/Flying_machine_small.jpg" alt="box" />    <h2>Advanced Topics</h2>

<div class="menu">

<ul>
<li><a href="sys_module.php">Introduction into the sys module</a></li><li><a href="os_module_shell.php">Python and the Shell</a></li><li><a href="forking.php">Forks and Forking in Python</a></li><li><a href="threads.php">Introduction into Threads</a></li><li><a href="pipes.php">Pipe, Pipes and "99 Bottles of Beer"</a></li><li><a href="graphs_python.php">Graph Theory and Graphs in Python"</a></li><li><a href="pygraph.php">Graphs: PyGraph"</a></li><li><a href="networkx.php">Graphs: NetworkX"</a></li><li><a href="finite_state_machine.php">Finite State Machine in Python</a></li><li><a href="turing_machine.php">Turing Machine in Python</a></li><li><a href="numpy.php">NumPy Module</a></li><li><a href="matrix_arithmetic.php">Matrix Arithmetic</a></li><li><a href="linear_combinations.php">Linear Combinations</a></li><li><a href="text_classification_introduction.php">Introduction into Text Classification using Naive Bayes</a></li><li><a href="text_classification_python.php">Python Implementation of Text Classification</a></li><li><a href="towers_of_hanoi.php">Example for recursive Programming: Towers of Hanoi</a></li><li><a href="mastermind.php">Mastermind / Bulls and Cows</a></li><li><a href="dynamic_websites_wsgi.php">Creating dynamic websites with WSGI</a></li><li><a href="dynamic_websites.php">Dynamic websites with mod_python</a></li><li><a href="pylons.php">Dynamic websites with Pylons</a></li><li><a href="sql_python.php">Python, SQL, MySQL and SQLite</a></li><li><a href="python_scores.php">Python Scores</a></li></ul>

</div>

<p>
<br>
<h3>Wisdom</h3>
"The infinite is in the finite of every instant" (Zen proverb)
<br> <br> 
***
<br><br>
"No finite point has meaning without an infinite reference point" (Jean-Paul Sartre)
<br> <br> 
***
<br><br>
"Ask what Time is, it is nothing else but something of eternal duration become 
finite, measurable and transitory." (William Law)
<br><br>
<hr>
<br>
"The machine does not isolate us from the great problems of nature but plunges 
us more deeply into them" (Antoine de Saint-Exupery)
<br> <br> 
***
<br><br>
"A tool is but the extension of a man's hand, and a machine is but a complex tool. 
And he that invents a machine augments the power of a man and the well-being of mankind."
(Henry Ward Beecher)
<br>
<br>
<hr>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo,
courses and seminars in Linux and Python"
		     src="images/bodenseo_python_training.gif"><br>Python Training Courses</a>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/endlicher_automat.php">Endliche Automaten in Python</a>

<h3>Python Training Courses</h3>
<p>

<p>If you  want to learn Python fast and efficiently, the right step will be a 
<a href="http://www.bodenseo.com/courses.php?topic=Python">
<br>Python Training course</a> at Bodenseo. There are also
 special seminars for advanced students like the 
 <a href="http://www.bodenseo.com/course/python_xml_training_course.html">Python & XML Training Course</a>.
 If you want to acquire special knowledge in Text Processing and Text Classification, then  
<a href="http://www.bodenseo.com/course/python_text_processing_course.html">"Python Text Processing 
Course"</a> will be the right one for you.
<br>
All the Python seminars are available in German as well: 
<a href="http://www.bodenseo.de/kurse.php?topic=Python">Python-Kurse</a>"

 
<a href="http://www.bodenseo.com/courses.php?topic=Python">
<img class="imgright" src="images/bodenseo_stairs_to_python2.png" alt="Bodenseo step to python" />
<br>Python Courses</a> at Bodenseo.
<br><br>
You can book Bernd Klein for on-site <a href="python_classes.php">Python courses</a> as 
well.

<br><br>
<h3>Text Classification</h3>
Though the automated classification (categorization) of texts has been flourishing 
in the last decade, it has a history, which dates back to about 1960. The incredible 
increase in online documents, which has been mostly due to the expanding internet, has 
renewed the interst in automated document classification and data mining. While text 
classification in the beginning was based mainly on heuristic methods, i.e. applying 
a set of rules based on expert knowledge, nowadays the focus has turned to fully 
automatic learning and even clustering methods. 

 </p>

</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="networkx.php">Graphs: NetworkX"</a><br>
<LINK rel="prev" href="networkx.php">Next Chapter: <a href="turing_machine.php">Turing Machine in Python</a><br>
<LINK rel="next" href="turing_machine.php"></div>
<h2>Finite State Machine (FSM)</h2>
<p>
<img class="imgright" src="images/Leonardo_da_vinci_Flying_machine.jpg" alt="Leonardo Da Vinci Flying Machine" />  
A "Finite State Machine" (abbreviated FSM), also called "State Machine" or "Finite State Automaton"
is an abstract machine which consists of a set of states (including the initial state and one or more
end states), a set of input events, a set of output events, and a state transition function. 
A transition function takes the current state and an input event as an input and returns 
the new set of output events and the next (new) state. 
Some of the states are used as "terminal states". 
<br><br>
The operation of an FSM begins with a special state, called the start state, proceeds through transitions 
depending on input to different states and normally ends in terminal or end states. A state which marks a
successful flow of operation is known as an accept state.
<br><br>
<b>Mathematical Model:</b><br>
A deterministic finite state machine or acceptor deterministic finite state machine is a quintuple<br>
(&Sigma;,S,s<sub>0</sub>,&delta;,F), 
<br>
where: <br>
&Sigma; is the input alphabet (a finite, non-empty set of symbols).<br>
S is a finite, non-empty set of states.<br>
s<sub>0</sub> is an initial state, an element of S.<br>
&delta; is the state-transition function: &delta; : S x &Sigma; &rarr; S
<br>(in a nondeterministic finite state machine it 
would be &delta; : S x &Sigma; &rarr; &weierp;(S),  i.e., &delta; would return 
a set of states). (&weierp;(S) is the Power set of S)<br>
F is the set of final states, a (possibly empty) subset of S.
<br><br>
<b>A Simple Example</b>
<br>
We want to recognize the meaning of very small sentences with an extremely limited vocabulary and syntax:<br>
These sentences should start with "Python is" followed by 
<ul>
<li>an adjective or</li>
<li>the word "not" followed by an adjective.</li>
</ul>
e.g.<br>
"Python is great" 		&rarr; positive meaning<br>
"Python is stupid" 		&rarr; negative meaning<br>
"Python is not ugly" 	&rarr; positive meaning<br>

<img src="images/finite_state_machine_example.png" width="600" border="0" alt="">
<br>
<h3>A Finite State Machine in Python</h3>
To implement the previous example, we program first a general Finite State Machine in Python.
We save this class as statemachine.py:

<pre>
class StateMachine:
    def __init__(self):
        self.handlers = {}
        self.startState = None
        self.endStates = []

    def add_state(self, name, handler, end_state=0):
        name = name.upper()
        self.handlers[name] = handler
        if end_state:
            self.endStates.append(name)

    def set_start(self, name):
        self.startState = name.upper()

    def run(self, cargo):
        try:
            handler = self.handlers[self.startState]
        except:
            raise InitializationError("must call .set_start() before .run()")
        if not self.endStates:
            raise  InitializationError("at least one state must be an end_state")
    
        while True:
            (newState, cargo) = handler(cargo)
            if newState.upper() in self.endStates:
                print("reached ", newState)
                break 
            else:
                handler = self.handlers[newState.upper()]              
</pre>

This general FSM is used in the next program:
<pre>
from statemachine import StateMachine

positive_adjectives = ["great","super", "fun", "entertaining", "easy"]
negative_adjectives = ["boring", "difficult", "ugly", "bad"]

def start_transitions(txt):
    splitted_txt = txt.split(None,1)
    word, txt = splitted_txt if len(splitted_txt) > 1 else (txt,"")
    if word == "Python":
        newState = "Python_state"
    else:
        newState = "error_state"
    return (newState, txt)

def python_state_transitions(txt):
    splitted_txt = txt.split(None,1)
    word, txt = splitted_txt if len(splitted_txt) > 1 else (txt,"")
    if word == "is":
        newState = "is_state"
    else:
        newState = "error_state"
    return (newState, txt)

def is_state_transitions(txt):
    splitted_txt = txt.split(None,1)
    word, txt = splitted_txt if len(splitted_txt) > 1 else (txt,"")
    if word == "not":
        newState = "not_state"
    elif word in positive_adjectives:
        newState = "pos_state"
    elif word in negative_adjectives:
        newState = "neg_state"
    else:
        newState = "error_state"
    return (newState, txt)

def not_state_transitions(txt):
    splitted_txt = txt.split(None,1)
    word, txt = splitted_txt if len(splitted_txt) > 1 else (txt,"")
    if word in positive_adjectives:
        newState = "neg_state"
    elif word in negative_adjectives:
        newState = "pos_state"
    else:
        newState = "error_state"
    return (newState, txt)

def neg_state(txt):
    print("Hallo")
    return ("neg_state", "")

if __name__== "__main__":
    m = StateMachine()
    m.add_state("Start", start_transitions)
    m.add_state("Python_state", python_state_transitions)
    m.add_state("is_state", is_state_transitions)
    m.add_state("not_state", not_state_transitions)
    m.add_state("neg_state", None, end_state=1)
    m.add_state("pos_state", None, end_state=1)
    m.add_state("error_state", None, end_state=1)
    m.set_start("Start")
    m.run("Python is great")
    m.run("Python is difficult")
    m.run("Perl is ugly")
</pre>

If we save the application of our general Finite State Machine in statemachine_test.py and 
call it with <br>
<pre>
python statemachine_test.py
</pre>
we get the following results:
<pre>
$ python statemachine_test.py 
reached  pos_state which is an end state
reached  neg_state which is an end state
reached  error_state which is an end state
</pre>
</p>

The code of the finite state machine is compatible with Python3 as well!
<div id="contextlinks">Previous Chapter: <a href="networkx.php">Graphs: NetworkX"</a><br>
<LINK rel="prev" href="networkx.php">Next Chapter: <a href="turing_machine.php">Turing Machine in Python</a><br>
<LINK rel="next" href="turing_machine.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
