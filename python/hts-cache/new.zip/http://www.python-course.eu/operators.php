<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: Operators</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Overview with examples of Arithmetic and Comparison Operators in Python" />
<meta name="Keywords" content="Python, course, overview, arithmetic, comparison operators" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/containers100.jpg" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<hr>
<br>
<h3>Arithmetic</h3>
<i>"Arithmetic is where the answer is right and everything is nice and you can look out of the 
window and see the blue sky - or the answer is wrong and you have to start over and try 
again and see how it comes out this time."</i><br>
(Carl Sandburg)
<hr>

<h3>Thanks</h3>

This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
We also like to thank Denise Mitchinson for providing the stylesheet of this website.<br> <a href="http://www.mitchinson.net"> www.mitchinson.net </a>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/operatoren.php">Ausdr�cke und Operatoren</a><h3>Python 2.7</h3>This tutorial deals with Python Version 2.7<br>This chapter from our course is available in a version for Python3: <a href="python3_operators.php">Operators</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

"The question of whether a computer can think is no more interesting than the 
question of whether a submarine can swim." (Edsger Wybe Dijkstra)<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="variables.php">Data Types and Variables</a><br>
<LINK rel="prev" href="variables.php">Next Chapter: <a href="input.php">input and raw_input via the keyboard</a><br>
<LINK rel="next" href="input.php"></div>
<h2>Arithmetic and Comparison Operators</h2>

<h3>Introduction</h3>
This chapter covers the various built-in operators, which Python has to offer.



<h3>Operators</h3>

These operations (operators) can be applied to all numeric types: <br><br>
<table
style="text-align: left; width: 100%; background-color: rgb(255, 255, 102);"
border="1" cellpadding="2" cellspacing="2">
<tbody>

<tr>
<th style="vertical-align: top;">Operator
</th>
<th style="vertical-align: top;">Description
</th>
<th style="vertical-align: top;">Example
</th>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
+, -
</FONT></td>
<td style="vertical-align: top;">Addition, Subtraction
</td>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
10 -3 
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
*, /, %
</FONT></td>
<td style="vertical-align: top;">
Multiplication, Division, Modulo</td>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
27 % 7<br>Result: 6
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
//
</FONT></td>
<td style="vertical-align: top;">
Truncation Division (also known as floordivision)<br>The result of the division 
is truncated to an integer. Works for integers and floating-point numbers as well</td>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
27 % 7<br>Result: 6
</FONT></td>
</tr>


<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
+x, -x
</FONT></td>

<td style="vertical-align: top;">
Unary minus and Unary plus (Algebraic signs)</td>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
-3
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
~x
</FONT></td>
<td style="vertical-align: top;">
Bitwise negation</td>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
~3 - 4<br>Result: -8
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
**
</FONT></td>
<td style="vertical-align: top;">Exponentiation
</td>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
10 ** 3<br>Result: 1000
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
or, and, not
</FONT></td>
<td style="vertical-align: top;">
Boolean Or, Boolean And, Boolean Not</td>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
(a or b) and c
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
in
</FONT></td>
<td style="vertical-align: top;">
"Element of"
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
1 in [3, 2, 1]
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
<, <=, >, >=, !=, ==
</FONT></td>
<td style="vertical-align: top;">
The usual comparison operators
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
2 <= 3
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
|, &, ^
</FONT></td>
<td style="vertical-align: top;">
Bitwise Or, Bitwise And, Bitwise XOR
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
6 ^ 3
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
<<, >>
</FONT></td>
<td style="vertical-align: top;">
Shift Operators
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
6 << 3
</FONT></td>
</tr>
</tbody>
</table>





<br>
<br>


<div id="contextlinks">Previous Chapter: <a href="variables.php">Data Types and Variables</a><br>
<LINK rel="prev" href="variables.php">Next Chapter: <a href="input.php">input and raw_input via the keyboard</a><br>
<LINK rel="next" href="input.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
