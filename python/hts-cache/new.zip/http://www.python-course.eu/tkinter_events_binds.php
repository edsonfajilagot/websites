<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>GUI Programming with Python: Events and Binds</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial and Introduction on Tkinter: Using Events and Binds" />
<meta name="Keywords" content="Python, Tkinter, Tk, Introduction, course, tutorial, events, binds" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li class="active"><a id="current" href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/bind.jpg" alt="box" />    <h2>Tkinter Tutorial</h2>

<div class="menu">

<ul>
<li><a href="tkinter_labels.php">Saying Hello with Labels</a></li><li><a href="tkinter_message_widget.php">Message Widget</a></li><li><a href="tkinter_buttons.php">Buttons</a></li><li><a href="tkinter_variable_classes.php">Variable Classes</a></li><li><a href="tkinter_radiobuttons.php">Radiobuttons</a></li><li><a href="tkinter_checkboxes.php">Checkboxes</a></li><li><a href="tkinter_entry_widgets.php">Entry Widgets</a></li><li><a href="tkinter_canvas.php">Canvas Widgets</a></li><li><a href="tkinter_sliders.php">Sliders</a></li><li><a href="tkinter_text_widget.php">Text Widget</a></li><li><a href="tkinter_dialogs.php">Dialogs</a></li><li><a href="tkinter_layout_management.php">Layout Management</a></li><li><a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a></li><li><a href="tkinter_menus.php">Creating Menus</a></li><li><a href="tkinter_events_binds.php">Events and Binds</a></li></ul>

</div>

<p>
<br>

<h3>Event Computing</h3>
In computing an event is an action that is usually initiated outside the scope of a program and that is handled by a piece of code inside the program. Events include for example mouse clicks, mouse movements or a keystroke of a user, i.e. he or she presses a key on the keyboard. Another source can be a hardware device such as a timer. 
<br><br>
A program or a script whose behaviour depends on events is said to be event-driven.
<hr>
<br>
This website is created by Bernd Klein from:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo,
Python, courses and seminars"
		     src="images/bodenseo_python_training.gif"><br>Python Training Courses</a>
<hr>
<h3>Events Philosophically</h3>
An Event is an occurrence regarded as a bare instant of space-time as contrasted with an object which fills space and has endurance. It can also be an occurrence regarded in isolation from, or contrasted with, human agency Compare act.
<br><br>
<hr>
<br>
We also like to thank Denise Mitchinson for providing the tylesheet of this website.<br><br>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>

<h3>Classroom Trainings</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his live <a href="python_classes.php">Python classes</a>
<br>
If you are interested in an instructor-led classroom training course,
you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python and 
Tkinter courses <br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo


<h3>Quote of the Day:</h3>
<p>

Computers are like bikinis. They save people a lot of guesswork.<br>
(Sam Ewing)
<br>
<h3>Graphical User Interface</h3>
A graphical user interface (GUI) is a type of user interface that allows users to interact 
with electronic devices in a graphical way, i.e. with images, rather than text commands.
Originally interactive user interfaces to computers were not graphical, they were text  
oriented and usually consisted of commands, which had to be remembered. 
The DOS operating system from Microsoft and the Bourne shell under Linux are examples
of such user-computer interfaces. 


 </p>

</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="tkinter_menus.php">Creating Menus</a><br>
<LINK rel="prev" href="tkinter_menus.php"></div>
<h2>Events and Binds</h2>
<br>
<h3>Introduction</h3>
<img class="imgright" src="images/binds.jpg" alt="Binds" />
A Tkinter application runs most of its time inside an event loop, which is entered via the mainloop method. It waiting for
events to happen. Events can be key presses or mouse operations by the user.
<br><br>
Tkinter provides a mechanism to let the programmer deal with events. For each widget, it's possible to bind Python 
functions and methods to an event.
<br><br>
<i>widget.bind(event, handler)</i>
<br><br>
If the defined event occurrs in the widget, the "handler" function is called with an event object. 
describing the event.
<br><br>
<pre>
#!/usr/bin/python3
# write tkinter as Tkinter to be Python 2.x compatible
from tkinter import *
def hello(event):
    print("Single Click, Button-l") 
def quit(event):                           
    print("Double Click, so let's stop") 
    import sys; sys.exit() 

widget = Button(None, text='Mouse Clicks')
widget.pack()
widget.bind('&lt;Button-1&gt;', hello)
widget.bind('&lt;Double-1&gt;', quit) 
widget.mainloop()
</pre>
<br>
Let's have another simple example, which shows how to use the motion event, i.e. if the mouse is 
moved inside of a widget:
<pre>
from tkinter import *

def motion(event):
  print("Mouse position: (%s %s)" % (event.x, event.y))
  return

master = Tk()
whatever_you_do = "Whatever you do will be insignificant, but it is very important that you do 
it.\n(Mahatma Gandhi)"
msg = Message(master, text = whatever_you_do)
msg.config(bg='lightgreen', font=('times', 24, 'italic'))
msg.bind('&lt;Motion&gt;',motion)
msg.pack()
mainloop()
</pre>
<br>
Every time we move the mouse in the Message widget, the position of the mouse pointer will 
be printed. When we leave this widget, the function motion() is not called anymore.
<br><br>
<h3>Events</h3>
Tkinter uses so-called event sequences for allowing the user to define which events, both 
specific and general, he or she wants to bind to handlers. 
It is the first argument "event" of the bind method. The event sequence is given as a string, 
using the following syntax:
<br>
<pre>
&lt;modifier-type-detail&gt;
</pre>
The type field is the essential part of an event specifier, whereas the "modifier" and 
"detail" fields are not obligatory and are left out in many cases. They are used to 
provide additional information for the chosen "type". The event "type" 
describes the kind of event to be bound, e.g. actions like mouse clicks, key presses or 
the widget got the input focus.  
<br><br>
<table border="4" bordercolor="#6A9662" style="background-color:#DDFFDD" cellpadding="6" cellspacing="1">
	<tr>
		<th>Event</th>
		<th>Description</th>
	</tr>

<tr><td valign="top">&lt;Button&gt;
</td>
<td valign="top">A mouse button is pressed with the mouse pointer over the widget. 
The detail part specifies which button, e.g.
The left mouse button is defined by the event &lt;Button-1&gt;, the middle button 
by &lt;Button-2&gt;, and the rightmost mouse button by &lt;Button-3&gt;. 
<br>
&lt;Button-4&gt; defines the scroll up event on mice with wheel support and 
and &lt;Button-5&gt; the scroll down.
<br> 
If you press down a mouse button over a widget and keep it pressed, Tkinter will 
automatically "grab" the mouse pointer. Further mouse events like Motion and Release events will be sent to the current widget, even if the mouse is moved outside the current widget. The current position, relative to the widget, of the mouse pointer  is provided in the x and y members of the event object passed to the callback. You can use ButtonPress instead of Button, or even leave it out completely: <Button-1>, <ButtonPress-1>, and <1> are all synonyms.
</td></tr>
<tr><td valign="top">&lt;Motion&gt;
</td>
<td valign="top"> The mouse is moved with a mouse button being held down. 
To specify the left, middle or right mouse button use
&lt;B1-Motion&gt;, &lt;B2-Motion&gt; and &lt;B3-Motion&gt; respectively. 
The current position of the mouse pointer is provided in the x and y members 
of the event object passed to the callback, i.e. event.x, event.y
</td></tr>
<tr><td valign="top">&lt;ButtonRelease&gt;
</td>
<td valign="top">Event, if a button is released. To specify the left, middle 
or right mouse button use
&lt;ButtonRelease-1&gt;, &lt;ButtonRelease-2&gt;, and &lt;ButtonRelease-3&gt; 
respectively. The current position of the mouse pointer is provided in the 
x and y members of the event object passed to the callback,  i.e. event.x, event.y
</td></tr>
<tr><td valign="top">&lt;Double-Button&gt;
</td>
<td valign="top">Similar to the Button event, see above, but the button is 
doubble clicked instead of a single click. 
To specify the left, middle or right mouse button use &lt;Double-Button-1&gt;, 
&lt;Double-Button-2&gt;, and 
&lt;Double-Button-3&gt; respectively.<br>
You can use Double or Triple as prefixes. Note that if you bind to both a single 
click (&lt;Button-1&gt;) and a double click (&lt;Double-Button-1&gt;), both 
bindings will be called.
</td></tr>
<tr><td valign="top">&lt;Enter&gt;
</td>
<td valign="top">The mouse pointer entered the widget.<br>Attention: This 
doesn't mean that the user pressed the Enter key!.
&lt;Return&gt; is used for this purpose.
</td></tr>
<tr><td valign="top">&lt;Leave&gt;
</td>
<td valign="top">The mouse pointer left the widget.
</td></tr>
<tr><td valign="top">&lt;FocusIn&gt;
</td>
<td valign="top">    Keyboard focus was moved to this widget, or to a 
child of this widget.
</td></tr>
<tr><td valign="top">&lt;FocusOut&gt;
</td>
<td valign="top">    Keyboard focus was moved from this widget to 
another widget.
</td></tr>
<tr><td valign="top">&lt;Return&gt;
</td>
<td valign="top">The user pressed the Enter key. You can bind to virtually 
all keys on the keyboard: The special keys are Cancel (the Break key), 
BackSpace, Tab, Return(the Enter key), Shift_L (any Shift key), Control_L 
(any Control key), Alt_L (any Alt key), Pause, Caps_Lock, Escape, Prior 
(Page Up), Next (Page Down), End, Home, Left, Up, Right, Down, Print, 
Insert, Delete, F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12, 
Num_Lock, and Scroll_Lock.
</td></tr>
<tr><td valign="top">&lt;Key&gt;
</td>
<td valign="top">    The user pressed any key. The key is provided in the 
char member of the event object passed to the callback (this is an empty string 
for special keys).
</td></tr>
<tr><td valign="top">a
</td>
<td valign="top">    The user typed an "a" key. Most printable characters can be 
used as is. The exceptions are space (&lt;space&gt;) and less than (&lt;less&gt;). 
Note that 1 is a keyboard binding, while &lt;1&gt; is a button binding.
</td></tr>
<tr><td valign="top">&lt;Shift-Up&gt;
</td>
<td valign="top">    The user pressed the Up arrow, while holding the Shift key 
pressed. You can use prefixes like Alt, Shift, and Control.
</td></tr>
<tr><td valign="top">&lt;Configure&gt;
</td>
<td valign="top">    The size of the widget changed. The new size is provided 
in the width and height attributes of the event object passed to the callback. 
On some platforms, it can mean that the location changed.
</td></tr>

</table>
<br><br>



<br><br>
</div>
<div id="contextlinks">Previous Chapter: <a href="tkinter_menus.php">Creating Menus</a><br>
<LINK rel="prev" href="tkinter_menus.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
