<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Advanced: Graphs in Python: NetworkX</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Using Graphs in Python: Introduction with examples into the Python-Modul NetworkX" />
<meta name="Keywords" content="Python, introduction, examples, graph, module, networkx" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li class="active"><a id="current" href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/hamiltonian_path_lava.png" alt="box" />    <h2>Advanced Topics</h2>

<div class="menu">

<ul>
<li><a href="sys_module.php">Introduction into the sys module</a></li><li><a href="os_module_shell.php">Python and the Shell</a></li><li><a href="forking.php">Forks and Forking in Python</a></li><li><a href="threads.php">Introduction into Threads</a></li><li><a href="pipes.php">Pipe, Pipes and "99 Bottles of Beer"</a></li><li><a href="graphs_python.php">Graph Theory and Graphs in Python"</a></li><li><a href="pygraph.php">Graphs: PyGraph"</a></li><li><a href="networkx.php">Graphs: NetworkX"</a></li><li><a href="finite_state_machine.php">Finite State Machine in Python</a></li><li><a href="turing_machine.php">Turing Machine in Python</a></li><li><a href="numpy.php">NumPy Module</a></li><li><a href="matrix_arithmetic.php">Matrix Arithmetic</a></li><li><a href="linear_combinations.php">Linear Combinations</a></li><li><a href="text_classification_introduction.php">Introduction into Text Classification using Naive Bayes</a></li><li><a href="text_classification_python.php">Python Implementation of Text Classification</a></li><li><a href="towers_of_hanoi.php">Example for recursive Programming: Towers of Hanoi</a></li><li><a href="mastermind.php">Mastermind / Bulls and Cows</a></li><li><a href="dynamic_websites_wsgi.php">Creating dynamic websites with WSGI</a></li><li><a href="dynamic_websites.php">Dynamic websites with mod_python</a></li><li><a href="pylons.php">Dynamic websites with Pylons</a></li><li><a href="sql_python.php">Python, SQL, MySQL and SQLite</a></li><li><a href="python_scores.php">Python Scores</a></li></ul>

</div>

<p>
<hr>
<h3>Modules Implementing Graphs</h3>

NetworkX is not the only module implementing graph theory into Python, but belongs to the best ones.
Other approaches include python-graph and PyGraph.


<br>
<hr>
<br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>


<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
<h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

Man is the best computer we can put aboard a spacecraft...and the only one that can be mass produced with unskilled labor.<br> (Wernher von Braun)
<br>
<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="pygraph.php">Graphs: PyGraph"</a><br>
<LINK rel="prev" href="pygraph.php">Next Chapter: <a href="finite_state_machine.php">Finite State Machine in Python</a><br>
<LINK rel="next" href="finite_state_machine.php"></div><h2>NetworkX</h2>

<h3>Overview</h3>

<new>This chapter is still not finished. We are working on it.</new>
<br><br>

NetworkX is a Python language software package for the creation, manipulation, and study of the structure, dynamics, and functions of complex networks.
Pygraphviz is a Python interface to the Graphviz graph layout and
 visualization package.

<ul>
<li>     Python language data structures for graphs, digraphs, and multigraphs.
<li>     Nodes can be "anything" (e.g. text, images, XML records)
<li>     Edges can hold arbitrary data (e.g. weights, time-series)
<li>     Generators for classic graphs, random graphs, and synthetic networks
<li>     Standard graph algorithms
<li>     Network structure and analysis measures
<li>     Basic graph drawing
<li>     Open source BSD license
<li>     Well tested: more than 1500 unit tests
<li>     Additional benefits from Python: fast prototyping, easy to teach, multi-platform
</ul>

<br><br>
<h3>Creating a Graph</h3>

<h4>Create an empty Graph</h4>
Our first example of a graph will be an empty graph. To see the proper mathematical definition of a graph, you can have a look at our previous chapter <a href="graphs_python.php">Graphs in Python</a>.

The following little Python script uses NetworkX to create an empty graph:

<pre>
import networkx as nx

G=nx.Graph()

print(G.nodes())
print(G.edges())

print(type(G.nodes()))
print(type(G.edges()))
</pre>

If we save this script as "empty.py" and start it, we get the following output:

<pre>
$ python3 empyty.py 
[]
[]
&lt;class 'list'&gt;
&lt;class 'list'&gt;
</pre>

We can see, that the result from the graph methods nodes() and edges() are lists.

<h4>Adding Nodes to our Graph</h4>

Now we will add some nodes to our graph. We can add one node with the method add_node() and a list of nodes with the method add_nodes_from():

<pre>
import networkx as nx

G=nx.Graph()

# adding just one node:
G.add_node("a")
# a list of nodes:
G.add_nodes_from(["b","c"])

print("Nodes of graph: ")
print(G.nodes())
print("Edges of graph: ")
print(G.edges())
</pre>

<h4>Adding Edges to our Graph</h4>

G can also be created or increased by adding one edge at a time by the method add_edge(), which has the two nodes of the edge as the two parameters. If we have a tuple or a list as the edge, we can use the asterisk operator to unpack the tupel or the list:

<pre>
import networkx as nx

G=nx.Graph()
G.add_node("a")
G.add_nodes_from(["b","c"])

G.add_edge(1,2)
edge = ("d", "e")
G.add_edge(*edge)
edge = ("a", "b")
G.add_edge(*edge)

print("Nodes of graph: ")
print(G.nodes())
print("Edges of graph: ")
print(G.edges()
</pre>

In our previous example, the first edge consists of the nodes 1 and 2, which had not been included in our graph so far. The same is true for the second edge with the tuple <code>("d", "e")</code>. We can see, that the nodes will be automatically included as well into the graph, as we can see from the output:

<pre>
Nodes of graph: 
['a', 1, 'c', 'b', 'e', 'd', 2]
Edges of graph: 
[('a', 'b'), (1, 2), ('e', 'd')]
</pre>

We can add a bunch of edges as a list of edges in the form of 2 tuples. 

<pre>
# adding a list of edges:
G.add_edges_from([("a","c"),("c","d"), ("a",1), (1,"d"), ("a",2)])
</pre>

We can also print the resulting graph by using matplotlib:

<pre>
nx.draw(G)
plt.savefig("simple_path.png") # save as png
plt.show() # display
</pre>


<img src="images/simple_path.png" width="90%" alt="Image of a simple graph" />


<h4>Generate Path Graph</h4>

We can create a Path Graph with linearly connected nodes with the method path_graph(). The Python code code uses matplotlib.pyplot to plot the graph. We will give detailled information on matplotlib at a later stage of the tutorial:

<pre>
import networkx as nx
import matplotlib.pyplot as plt

G=nx.path_graph(4)

print("Nodes of graph: ")
print(G.nodes())
print("Edges of graph: ")
print(G.edges())
nx.draw(G)
plt.savefig("path_graph1.png")
plt.show()
</pre>

The created graph is an undirected linearly connected graph, connecting the integer numbers 0 to 3 in their natural order:
<img src="images/path_graph1.png" width="90%" alt="Image of a linearly connected graph" />

<h4>Renaming Nodes</h4>

Sometimes it is necessary to to rename or relabel the nodes of an existing graph. For this purpose the function relabel_nodes is the ideal tool. 
<br><br>
<code>
networkx.relabel.relabel_nodes(G, mapping, copy=True)
</code>
<br><br>
The parameter G is a Graph, the mapping has to be a dictionary and the last paramater is optional. If copy is set to True, - which is the default - a copy will be returned, otherwise, i.e. if it is set to False, the nodes of the graph will be relabeled in place. 
<br>
In the following example we create again the Path graph with the node labels from 0 to 3. After this we define a dictionary, in which we map each node label into a new value, i.e. city names:

<pre>
import networkx as nx
import matplotlib.pyplot as plt

G=nx.path_graph(4)
cities = {0:"Toronto",1:"London",2:"Berlin",3:"New York"}

H=nx.relabel_nodes(G,cities)
 
print("Nodes of graph: ")
print(H.nodes())
print("Edges of graph: ")
print(H.edges())
nx.draw(H)
plt.savefig("path_graph_cities.png")
plt.show()

</pre>

The Python program returns the following output:

<pre>
Nodes of graph: 
['Toronto', 'Berlin', 'New York', 'London']
Edges of graph: 
[('Toronto', 'London'), ('Berlin', 'New York'), ('Berlin', 'London')]
</pre>

The visualized graph looks liks this:

<img src="images/path_graph_cities.png" width="90%" alt="Graph with new node labels: Toronto, London, Berlin, New York" />
<br>
When we relabelled the graph G in our previous Python exampls, we create a new graph H, while the oringinal graph G was not changed. By setting the copy parameter flag to False, we can relabel the nodes in place without copying the graph. In this case the line
<br>
<code>H=nx.relabel_nodes(G,cities)</code><br>
will be changed to <br>
<code>nx.relabel_nodes(G,cities, copy=False)</code>
<br>
This approach might lead to problems, if the mapping is circular, while copying is always safe.

The mapping from the nodes of the original node labels to the new node labels doesn't have to be complete. An example of a partial in-place mapping:

<pre>
import networkx as nx

G=nx.path_graph(10)
mapping=dict(zip(G.nodes(),"abcde"))
nx.relabel_nodes(G, mapping, copy=False)
 
print("Nodes of graph: ")
print(G.nodes())
</pre>

Only the nodes 0 to 4 are nenamed, while the other nodes keep the numerical value, as we can see in the output from the program:

<pre>
$ python3 partial_relabelling.py 
Nodes of graph: 
[5, 6, 7, 8, 9, 'c', 'b', 'a', 'e', 'd']
</pre>

The mapping for the nodes can be a function as well:

<pre>
import networkx as nx

G=nx.path_graph(10)

def mapping(x):
    return x + 100

nx.relabel_nodes(G, mapping, copy=False)
 
print("Nodes of graph: ")
print(G.nodes())
</pre>

The result:

<pre>
$ python3 relabelling_with_function.py 
Nodes of graph: 
[107, 106, 103, 108, 109, 104, 105, 100, 102, 101]
</pre>

<div id="contextlinks">Previous Chapter: <a href="pygraph.php">Graphs: PyGraph"</a><br>
<LINK rel="prev" href="pygraph.php">Next Chapter: <a href="finite_state_machine.php">Finite State Machine in Python</a><br>
<LINK rel="next" href="finite_state_machine.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
