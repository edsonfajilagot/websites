<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Operators</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Detailled Introduction on Arithmetic and Comparison Operators in Python for Beginners" />
<meta name="Keywords" content="Python, course, overview, arithmetic, comparison operators" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/containers100.jpg" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<h3>Mythology</h3>
The first great achievement of Apollo was to slay the huge serpent Python. In some texts 
Python is an enormous dragon and not a serpent. 
<br>  
But who was this mythical creature? Python was created out of the slime and mud left after 
the great flood. She was  appointed by Gaia (Mother Earth) to guard the oracle of Delphi, 
known as Pytho. After having defeated Python Apollo remade
her former home and the oracle as his own.
<br>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_operatoren.php">Ausdr�cke und Operatoren</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="operators.php">Operators in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="operators.php">Operators in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_variables.php">Data Types and Variables</a><br>
<LINK rel="prev" href="python3_variables.php">Next Chapter: <a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a><br>
<LINK rel="next" href="python3_sequential_data_types.php"></div>
<h2>Arithmetic and Comparison Operators</h2>

<h3>Introduction</h3>
This chapter covers the various built-in operators, which Python has to offer.



<h3>Operators</h3>

These operations (operators) can be applied to all numeric types: <br><br>
<table
style="text-align: left; width: 100%; background-color: rgb(255, 255, 102);"
border="1" cellpadding="2" cellspacing="2">
<tbody>

<tr>
<th style="vertical-align: top;">Operator
</th>
<th style="vertical-align: top;">Description
</th>
<th style="vertical-align: top;">Example
</th>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
+, -
</FONT></td>
<td style="vertical-align: top;">Addition, Subtraction
</td>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
10 -3 
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
*, %
</FONT></td>
<td style="vertical-align: top;">
Multiplication,  Modulo</td>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
27 % 7<br>Result: 6
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
/
</FONT></td>
<td style="vertical-align: top;">
Division
<br>This operation results in different results for Python 2.x (like floor division) and Python 3.x</td>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
Python3:
<br>
<pre>
>>> 10  / 3
3.3333333333333335
</pre>
and in Python 2.x:
<pre>
>>> 10  / 3
3
</pre>
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
//
</FONT></td>
<td style="vertical-align: top;">
Truncation Division (also known as floor division)<br>The result of the division 
is truncated to an integer. Works for integers and floating-point numbers as well</td>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
27 // 7<br>Result: 3
</FONT></td>
</tr>


<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
+x, -x
</FONT></td>

<td style="vertical-align: top;">
Unary minus and Unary plus (Algebraic signs)</td>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
-3
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
~x
</FONT></td>
<td style="vertical-align: top;">
Bitwise negation</td>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
~3 - 4<br>Result: -8
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
**
</FONT></td>
<td style="vertical-align: top;">Exponentiation
</td>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
10 ** 3<br>Result: 1000
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
or, and, not
</FONT></td>
<td style="vertical-align: top;">
Boolean Or, Boolean And, Boolean Not</td>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
(a or b) and c
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
in
</FONT></td>
<td style="vertical-align: top;">
"Element of"
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
1 in [3, 2, 1]
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
<, <=, >, >=, !=, ==
</FONT></td>
<td style="vertical-align: top;">
The usual comparison operators
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
2 <= 3
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
|, &, ^
</FONT></td>
<td style="vertical-align: top;">
Bitwise Or, Bitwise And, Bitwise XOR
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
6 ^ 3
</FONT></td>
</tr>

<tr>
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
<<, >>
</FONT></td>
<td style="vertical-align: top;">
Shift Operatoren
<td style="vertical-align: top;"><FONT FACE="Courier 10 Pitch">
6 << 3
</FONT></td>
</tr>
</tbody>
</table>





<br>
<br>


<div id="contextlinks">Previous Chapter: <a href="python3_variables.php">Data Types and Variables</a><br>
<LINK rel="prev" href="python3_variables.php">Next Chapter: <a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a><br>
<LINK rel="next" href="python3_sequential_data_types.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
