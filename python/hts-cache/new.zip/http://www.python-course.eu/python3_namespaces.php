<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Namespaces</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction into Namespaces and Scopes in Python" />
<meta name="Keywords" content="Python, python3, namespace, namespaces, scope, scopes, lifetime" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/atom.png" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<hr>
<h3>Lifetime</h3>
<i>"Give me a fish and I eat for a day. Teach me to fish and I eat for a lifetime."</i>
<br>Chinese proverb
<br>
<br>
<i>"Music is enough for a lifetime, but a lifetime is not enough for music"</i>
Sergei Rachmaninov
<br>
<hr>
<br>
<h3>Scope</h3>
<i>"Scholars are pleased to meet people who are learned because there is a scope for 
mutual benefit by exchange of views."</i>
<br>
(Rig Veda)

<br><br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="namespaces.php">Namespaces in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="namespaces.php">Namespaces in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_passing_arguments.php">Parameter Passing in Functions</a><br>
<LINK rel="prev" href="python3_passing_arguments.php">Next Chapter: <a href="python3_global_vs_local_variables.php">Global and Local Variables</a><br>
<LINK rel="next" href="python3_global_vs_local_variables.php"></div>
<h2>Namespaces and Scopes</h2>
<h3>Namespaces</h3>
<p>
<img class="imgright" src="images/names_as_namespaces.png" alt="Names as Namespaces" />
Generally speaking, a <b>namespace</b> (sometimes also called a context) is a naming system 
for making names unique to avoid ambiguity. Everybody knows a namespacing system from daily
life, i.e. the naming of people in firstname and familiy name (surname). Another example is 
a network: each network device 
(workstation, server, printer, ...) needs a unique name and address. Yet another example is the directory
structure of filesystems. The same filename can be used in different directories, the files can be 
uniquely accessed via the pathnames. 
<br>
Many programming languages use namespaces or contexts for identifiers. An identifier defined in a 
namespace is associated with that namespace. This way, the same identifier can be independently 
defined in multiple namespaces. (Like the same filenames in different directories) 
Programming languages, which  support namespaces may have different rules that determine to which 
namespace an identifier belongs.
<br>
 Namespaces in Python are implemented as Python dictionaries, this means that they are defined by a mapping from names, i.e. the keys of the dictionary, to objects, i.e. the values. The user doesn't have to know this to write a Python program and when
 using namespaces. 
 <br>Some namespaces in Python:
<ul>
<li><b>global names</b> of a module</li>
<li><b>local names</b> in a function or method invocation</li>
<li><b>built-in names</b>: this namespace contains built-in fuctions (e.g. abs(), cmp(), ...) and built-in 
exception names</li>
</ul> 
 <br>
<h3>Lifetime of a Namespace</h3>
Not every namespace, which may be used in a script or program is accessible (or alive) at any moment during
the execution of the script. Namespaces have different lifetimes, because they are often created at different
points in time. There is one namespace which is present from beginning to end: The namespace containing the 
built-in names is created when the Python interpreter starts up, and is never deleted. The global namespace 
of a module is generated when the module is read in. Module namespaces normally last until the script ends, 
i.e. the interpreter quits. When a function is called, a local namespace is created for this function. This 
namespace is deleted either if the function ends, i.e. returns, or if the function raises an exception, which
is not dealt with within the function.
<br>
<h3>Scopes</h3>
A scope refers to a region of a program where a namespace can be directly accessed, i.e. without using a 
namespace prefix. In other words: The scope of a name is the area of a program where this name can be 
unambiguously used, for example inside of a function. A name's namespace is identical to it's scope. Scopes are 
defined statically, but they are used dynamically. 
<br>
During program execution there are the following nested scopes available:
<ul>
<li>the innermost scope is searched first and it contains the local names</li>
<li>the scopes of any enclosing functions, which are searched starting with 
the nearest enclosing scope
<li> the next-to-last scope contains the current module's global names
<li> the outermost scope, which is searched last, is the namespace containing the built-in names
</ul>

</p>

<div id="contextlinks">Previous Chapter: <a href="python3_passing_arguments.php">Parameter Passing in Functions</a><br>
<LINK rel="prev" href="python3_passing_arguments.php">Next Chapter: <a href="python3_global_vs_local_variables.php">Global and Local Variables</a><br>
<LINK rel="next" href="python3_global_vs_local_variables.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
