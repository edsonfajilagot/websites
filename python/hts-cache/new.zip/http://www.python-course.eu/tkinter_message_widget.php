<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>GUI Programming with Python: Message widget in Tkinter</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="This chapter deals with the tkinter message widget under Python." />
<meta name="Keywords" content="Python, Tkinter, Tk, Introduction, course, tutorial, message, widget, button, buttons" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li class="active"><a id="current" href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/ti_amo.jpg" alt="box" />    <h2>Tkinter Tutorial</h2>

<div class="menu">

<ul>
<li><a href="tkinter_labels.php">Saying Hello with Labels</a></li><li><a href="tkinter_message_widget.php">Message Widget</a></li><li><a href="tkinter_buttons.php">Buttons</a></li><li><a href="tkinter_variable_classes.php">Variable Classes</a></li><li><a href="tkinter_radiobuttons.php">Radiobuttons</a></li><li><a href="tkinter_checkboxes.php">Checkboxes</a></li><li><a href="tkinter_entry_widgets.php">Entry Widgets</a></li><li><a href="tkinter_canvas.php">Canvas Widgets</a></li><li><a href="tkinter_sliders.php">Sliders</a></li><li><a href="tkinter_text_widget.php">Text Widget</a></li><li><a href="tkinter_dialogs.php">Dialogs</a></li><li><a href="tkinter_layout_management.php">Layout Management</a></li><li><a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a></li><li><a href="tkinter_menus.php">Creating Menus</a></li><li><a href="tkinter_events_binds.php">Events and Binds</a></li></ul>

</div>

<p>
<br><br>

<h3>More about Message</h3>
We used a saying by Mahatma Gandhi for our example of a message widget. He also said:
<i>"My life is my message."</i>
<br>(Mohandas Gandhi)
<br><br>
"The police" sent an SOS to the world in a bottle and they hoped that someone gets their message in a bottle.
We recommend using Python and Tkinter and the internet, because it will be definitely more efficient.



<hr>
<br>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo,
Linux and Python, courses and seminars"
		     src="images/bodenseo_python_training.gif"><br>Python Training Courses and Seminars</a>
<hr>
We also like to thank Denise Mitchinson for providing the stylesheet of this website.<br>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/tkinter_message_widget.php">Message widgets in Tkinter</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>"But active programming consists of the design of new programs, rather than 
contemplation of old programs. "</i> (Niklaus Wirth)<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="tkinter_labels.php">Saying Hello with Labels</a><br>
<LINK rel="prev" href="tkinter_labels.php">Next Chapter: <a href="tkinter_buttons.php">Buttons</a><br>
<LINK rel="next" href="tkinter_buttons.php"></div>
<h2>Tkinter</h2>
<h3>Message Widget</h3>
<img class="imgright" src="images/Love_message.jpg" alt="Love Message, Public Domain" />
<br>
The widget can be used to display short text messages. The message widget is similar in its functionality 
to the Label widget, but it is more flexible in displaying text, e.g. the font can be changed 
while the Label widget can only display text in a single font. It provides a multiline object, 
that is the text may span more than one line. 
The text is automatically broken into lines and justified. We were ambiguous, when we said, 
that the font of the message widget can be changed. This means, that we can choose arbitrarily 
a font for one widget, but the text of this widget will be rendered solely in this font. This means
that we can't change the font within a widget. So it's not possible
to have a text in more than one font. If you need to display text in multiple fonts, we suggest 
to use a Text widget.
<br><br>
The syntax of a message widget:
<br><br>
<i>w = Message ( master, option, ... )</i> 
<br><br>
Let's have a look at a simple example. The following script creates a message with a 
famous saying by Mahatma Gandhi:
<br><br>
<pre>
from Tkinter import *
master = Tk()
whatever_you_do = "Whatever you do will be insignificant, but it is very important that you do 
it.\n(Mahatma Gandhi)"
msg = Message(master, text = whatever_you_do)
msg.config(bg='lightgreen', font=('times', 24, 'italic'))
msg.pack( )
mainloop( )
</pre>
<br><br>
The widget created by the script above looks like this:
<br><br>
<img  src="images/whatever_you_do.png" alt="Whatever you do" />
<br><br>
If you want to run this script under Python3, the only thing you have to change is the import line. 
Instead of 
<pre>
from Tkinter import *
</pre>
you have to write
<pre>
from tkinter import *
</pre>

<br>
<h3>The Options in Detail</h3>
<table border="4" bordercolor="#6A9662" style="background-color:#DDFFDD" cellpadding="6" cellspacing="1">
	<tr>
		<th>Option</th>
		<th>Meaning</th>
	</tr>
<tr><td valign="top">anchor</td>
<td valign="top">    The position, where the text should be placed in the message widget:  
N, NE, E, SE, S, SW, W, NW, or CENTER. The Default is CENTER.  
</td></tr>
<tr><td valign="top">aspect</td>
<td valign="top">    Aspect ratio, given as the width/height relation in percent. 
The default is 150, which means that the message will be 50% wider than it is high. Note that if the width is explicitly set, this option is ignored.  
</td></tr>
<tr><td valign="top">background</td>
<td valign="top">    The background color of the message widget. The default value is system specific.
</td></tr>
<tr><td valign="top">bg</td>
<td valign="top">    Short for background. 
</td></tr>
<tr><td valign="top">borderwidth</td>
<td valign="top">    Border width. Default value is 2. 
</td></tr>
<tr><td valign="top">bd</td>
<td valign="top">    Short for borderwidth. 
</td></tr>
<tr><td valign="top">cursor</td>
<td valign="top">    Defines the kind of cursor to show when the mouse is moved over the message widget. By default the standard cursor is used.
</td></tr>
<tr><td valign="top">font</td>
<td valign="top">    Message font. The default value is system specific.
</td></tr>
<tr><td valign="top">foreground</td>
<td valign="top">    Text color. The default value is system specific. 
</td></tr>
<tr><td valign="top">fg</td>
<td valign="top">    Same as foreground. 
</td></tr>
<tr><td valign="top">highlightbackground</td>
<td valign="top">    Together with highlightcolor and highlightthickness, 
this option controls how to draw the highlight region.
</td></tr>
<tr><td valign="top">highlightcolor</td>
<td valign="top">    See highlightbackground.
</td></tr>
<tr><td valign="top">highlightthickness</td>
<td valign="top">    See highlightbackground. 
</td></tr>
<tr><td valign="top">justify</td>
<td valign="top">    Defines how to align multiple lines of text. Use LEFT, RIGHT, or 
CENTER. Note that to position the text inside the widget, use the anchor option. Default is LEFT.
</td></tr>
<tr><td valign="top">padx</td>
<td valign="top">    Horizontal padding. Default is -1 (no padding).
</td></tr>
<tr><td valign="top">pady</td>
<td valign="top">    Vertical padding. Default is -1 (no padding).
</td></tr>
<tr><td valign="top">relief</td>
<td valign="top">    Border decoration. The default is FLAT. Other possible values are 
SUNKEN, RAISED, GROOVE, and RIDGE. 
</td></tr>
<tr><td valign="top">takefocus</td>
<td valign="top">    If true, the widget accepts input focus. The default is false.
</td></tr>
<tr><td valign="top">text</td>
<td valign="top">    Message text. The widget inserts line breaks if necessary to get 
the requested aspect ratio. (text/Text)
</td></tr>
<tr><td valign="top">textvariable</td>
<td valign="top">    Associates a Tkinter variable with the message, which is usually 
a StringVar. If the variable is changed, the message text is updated. 
</td></tr>
<tr><td valign="top">width</td>
<td valign="top">    Widget width given in character units. A suitable width based on 
the aspect setting is automatically chosen, if this option is not given. 
</td></tr>
</table>
<br><br>


</div>
<div id="contextlinks">Previous Chapter: <a href="tkinter_labels.php">Saying Hello with Labels</a><br>
<LINK rel="prev" href="tkinter_labels.php">Next Chapter: <a href="tkinter_buttons.php">Buttons</a><br>
<LINK rel="next" href="tkinter_buttons.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
