<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>GUI Programming with Python: Menus in Tkinter</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial and Introduction on Tkinter: Designing and creating Menus" />
<meta name="Keywords" content="Python, Tkinter, Tk, Introduction, course, tutorial, menues, menu" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li class="active"><a id="current" href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/menu_of_your_life_130.jpg" alt="box" />    <h2>Tkinter Tutorial</h2>

<div class="menu">

<ul>
<li><a href="tkinter_labels.php">Saying Hello with Labels</a></li><li><a href="tkinter_message_widget.php">Message Widget</a></li><li><a href="tkinter_buttons.php">Buttons</a></li><li><a href="tkinter_variable_classes.php">Variable Classes</a></li><li><a href="tkinter_radiobuttons.php">Radiobuttons</a></li><li><a href="tkinter_checkboxes.php">Checkboxes</a></li><li><a href="tkinter_entry_widgets.php">Entry Widgets</a></li><li><a href="tkinter_canvas.php">Canvas Widgets</a></li><li><a href="tkinter_sliders.php">Sliders</a></li><li><a href="tkinter_text_widget.php">Text Widget</a></li><li><a href="tkinter_dialogs.php">Dialogs</a></li><li><a href="tkinter_layout_management.php">Layout Management</a></li><li><a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a></li><li><a href="tkinter_menus.php">Creating Menus</a></li><li><a href="tkinter_events_binds.php">Events and Binds</a></li></ul>

</div>

<p>
<br><br>

<h3>Menus in Life</h3>

<i>"I am not interested in picking up crumbs of compassion thrown from the table of someone who 
considers himself my master. I want the full menu of rights."</i>
<br>(Desmond Tutu)
<br><br>
<i>"Flops are a part of life's menu and I've never been a girl to miss out on any of the courses."</i>
<br>(Rosalind Russell)


<hr>
<br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
<hr>
<h3>Menu in a Restaurant</h3>
A menu is a presentation of food and beverage offerings. A menu may be a la carte - which guests use 
to choose from a list of options - or table d'h�te, in which case a pre-established sequence of 
courses is served.

<hr>
We also like to thank Denise Mitchinson for providing the stylesheet of this website.<br>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/tkinter_menus.php">Men�s in Tkinter</a>
<h3>Classroom Trainings</h3>Tutorial
<p>
This website contains a free and extensive online tutorial by Bernd Klein. 
You can attend one of his <a href="python_classes.php">Python courses</a> in Paris,
London, Berlin, Munich or Lake Constance.
<br><br>

A fast and efficient approach to learn Python and Tkinter consists in attending a
<a href="http://www.bodenseo.com/courses.php?topic=Python">classroom training courses 
<br><img style="width: 150px;" 
alt="Bodenseo, Python courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.

<h3>Quote of the Day:</h3>
<p>

<i>"A programming language is for thinking about programs, not for expressing programs 
you've already thought of. It should be a pencil, not a pen. "</i> (Paul Graham)<br>
<h3>Graphical User Interface</h3>
A graphical user interface (GUI) is a type of user interface that allows users to interact 
with electronic devices in a graphical way, i.e. with images, rather than text commands.
Originally interactive user interfaces to computers were not graphical, they were text  
oriented and usually consisted of commands, which had to be remembered. 
The DOS operating system from Microsoft and the Bourne shell under Linux are examples
of such user-computer interfaces. 


 </p>

</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a><br>
<LINK rel="prev" href="tkinter_mastermind.php">Next Chapter: <a href="tkinter_events_binds.php">Events and Binds</a><br>
<LINK rel="next" href="tkinter_events_binds.php"></div>
<h2>Menus</h2>
<br>
<h3>Introduction</h3>
<img class="imgright" src="images/menu_of_your_life.jpg" alt="Menu of your Life by Frits Ahlefeldt" />
Most people, if confronted with the word "menu", will immediately think of a menu in a restaurant.
Even though the menu of a restaurant and the menu of a computer program have at first glance
nothing in common, we can see, that yet the have a lot in common. In a restaurant, a menu is a 
presentation of all their food and beverage offerings, while in a computer application 
it presents all the commands and functions of the application, which are available to the
user via the grafical user interface.
<br><br<
The choices offered by a menu may be selected by a user in various ways, e.g. 
typing a keys or a combination of keys on a keyboard,
clicking mouse buttons, or touching the display screen with the fingers.
<br><br>
Menus in GUIs are presented with a combination of text and symbols to represent the choices. 
Selecting with the mouse (or finger on touch screens) on one of the symbols or text, an action will be started.
Such an action or operation can for example be the opening or saving of a file, or the quitting or exiting
of an application. 
<br><br>
A context menu is a menu in which the choices presented to the user are modified 
according to the current context in which the user is located.
<br><br>
We introduce in this chapter of our Python Tkinter tutorial the pull-down menus of Tkinter, i.e. the lists at the 
top of the windows, which appear (or pull down), if you click on an item like for example  "File", "Edit" or "Help". 
<br><br>
<h3>A Simple Menu Example</h3>
The following Python script creates a simple application window with menus. 
<pre>
from Tkinter import *
from tkFileDialog   import askopenfilename

def NewFile():
    print "New File!"
def OpenFile():
    name = askopenfilename()
    print name
def About():
    print "This is a simple example of a menu"
    
root = Tk()
menu = Menu(root)
root.config(menu=menu)
filemenu = Menu(menu)
menu.add_cascade(label="File", menu=filemenu)
filemenu.add_command(label="New", command=NewFile)
filemenu.add_command(label="Open...", command=OpenFile)
filemenu.add_separator()
filemenu.add_command(label="Exit", command=root.quit)

helpmenu = Menu(menu)
menu.add_cascade(label="Help", menu=helpmenu)
helpmenu.add_command(label="About...", command=About)

mainloop()
</pre>
<br><br>
It looks like this, if started:
<br><br>
<img src="images/tkinter_menu.png" alt="Tkinter Menus" />    




<br><br>
</div>
<div id="contextlinks">Previous Chapter: <a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a><br>
<LINK rel="prev" href="tkinter_mastermind.php">Next Chapter: <a href="tkinter_events_binds.php">Events and Binds</a><br>
<LINK rel="next" href="tkinter_events_binds.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
