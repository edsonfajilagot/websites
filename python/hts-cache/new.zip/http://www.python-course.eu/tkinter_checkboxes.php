<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>GUI Programming with Python: Checkboxes in Tkinter</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial and Introduction on Tkinter: Checkboxes with example applications" />
<meta name="Keywords" content="Python, Tkinter, Tk, Introduction, Kurs, Tutorial, checkboxes" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li class="active"><a id="current" href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/checkbox.png" alt="box" />    <h2>Tkinter Tutorial</h2>

<div class="menu">

<ul>
<li><a href="tkinter_labels.php">Saying Hello with Labels</a></li><li><a href="tkinter_message_widget.php">Message Widget</a></li><li><a href="tkinter_buttons.php">Buttons</a></li><li><a href="tkinter_variable_classes.php">Variable Classes</a></li><li><a href="tkinter_radiobuttons.php">Radiobuttons</a></li><li><a href="tkinter_checkboxes.php">Checkboxes</a></li><li><a href="tkinter_entry_widgets.php">Entry Widgets</a></li><li><a href="tkinter_canvas.php">Canvas Widgets</a></li><li><a href="tkinter_sliders.php">Sliders</a></li><li><a href="tkinter_text_widget.php">Text Widget</a></li><li><a href="tkinter_dialogs.php">Dialogs</a></li><li><a href="tkinter_layout_management.php">Layout Management</a></li><li><a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a></li><li><a href="tkinter_menus.php">Creating Menus</a></li><li><a href="tkinter_events_binds.php">Events and Binds</a></li></ul>

</div>

<p>
<br><br>
<h3>Possible Problems</h3>
If you are a beginner in Python, there might be some problems with 
understanding certain Python constructs in the our main tutorial on this page:
<br>
If you have problems understanding about the lambda construct, we recommend our chapter 
<a href="python3_lambda.php">Lambda, filter, reduce and map</a>
Most probably you are familiar with functions, if not we suggest reading the chapter  
<a href="python3_functions.php">Functions</a>
<br>
Some people have problems understanding our example using a class to create checkboxes. 
In this case, you will be better of to read our tutorial on <a href="python3_object_oriented_programming.php">Object Oriented Programming</a>.
<br><br>
<h3>Checkboxes and Choices</h3>
<i>"If you limit your choices only to what seems possible or reasonable, you disconnect yourself from what you truly want, and all that is left is a compromise."</i><br>
(Robert Fritz, author of the book "The Path of Least Resistance", in which he developed the theory and application of Structural Dynamics and the creative process.)


<hr>
<br>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo,
Python Training courses"
		     src="images/bodenseo_python_training.gif"><br>Python Training Courses</a>
<hr>
<h3>Choosing more than one Choice</h3>
<i>"A pessimist, confronted with two bad choices, chooses both."</i><br>
(Jewish Proverb)
<br>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/tkinter_checkboxes.php">Tkinter Checkboxes / Auswahlboxen</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using 
material from his <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://ca.bodenseo.com/courses.php?topic=Python">Python trainings courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<br>
<font size="1">� kabliczech - Fotolia.com</font>


<h3>Quote of the Day:</h3>
<p>

<i>"It is easier to write an incorrect program than understand a correct one. "</i> (Alan Perlis)<br>
<h3>Graphical User Interface</h3>
A graphical user interface (GUI) is a type of user interface that allows users to interact 
with electronic devices in a graphical way, i.e. with images, rather than text commands.
Originally interactive user interfaces to computers were not graphical, they were text  
oriented and usually consisted of commands, which had to be remembered. 
The DOS operating system from Microsoft and the Bourne shell under Linux are examples
of such user-computer interfaces. 


 </p>

</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="tkinter_radiobuttons.php">Radiobuttons</a><br>
<LINK rel="prev" href="tkinter_radiobuttons.php">Next Chapter: <a href="tkinter_entry_widgets.php">Entry Widgets</a><br>
<LINK rel="next" href="tkinter_entry_widgets.php"></div>
<h2>Checkboxes</h2>
<br>
<h3>Introduction</h3>
<img class="imgright" src="images/python_perl_java_checkboxes.png" alt="Python Perl Java Checkboxes" />
Checkboxes, also known as tickboxes or tick boxes or check boxes, are widgets that permit the user to
make multiple selections from a number of different options. This is different to a radio button, 
where the user can make only one choice. 
<br><br>
Usually, checkboxes are shown on the screen as square boxes 
that can contain white spaces (for false, i.e not checked) or a tick mark or X (for true, i.e. checked).
<br><br>
A caption describing the meaning of the checkbox is usually shown adjacent to the checkbox. 
The state of a checkbox is changed by clicking the mouse on the box. Alternatively it can be done 
by clicking on the caption, or by using a keyboard shortcut, for example the space bar.
<br><br>
A Checkbox has two states: on or off. 
<br><br>
The Tkinter Checkbutton widget can contain text, but only in a single font, or images, and a button 
can be associated with a Python function or method. When a button is pressed, Tkinter calls 
the associated function or method. The text of a button can span more than one line. 
<br><br>
<h3>Simple Example</h3>
The following example presents two checkboxes "male" and "female". Each checkbox needs a different 
variable name (IntVar()).
<pre>
from tkinter import *
master = Tk()
var1 = IntVar()
Checkbutton(master, text="male", variable=var1).grid(row=0, sticky=W)
var2 = IntVar()
Checkbutton(master, text="female", variable=var2).grid(row=1, sticky=W)
mainloop()
</pre>
If we start this script, we get the following window:
<br><br>
<img src="images/male_female.png" alt="Male Female Checkboxes" />
<br><br>
We can improve this example a little bit. First we add a Label to it. Furthermore we add two 
Buttons, one to leave the application and the other one to view the values var1 and var2. 

<pre>
from tkinter import *
master = Tk()

def var_states():
   print("male: %d,\nfemale: %d" % (var1.get(), var2.get()))

Label(master, text="Your sex:").grid(row=0, sticky=W)
var1 = IntVar()
Checkbutton(master, text="male", variable=var1).grid(row=1, sticky=W)
var2 = IntVar()
Checkbutton(master, text="female", variable=var2).grid(row=2, sticky=W)
Button(master, text='Quit', command=master.quit).grid(row=3, sticky=W, pady=4)
Button(master, text='Show', command=var_states).grid(row=4, sticky=W, pady=4)
mainloop()
</pre>
<br><br>
The result of the previous script looks like this:
<br><br>
<img src="images/improved_version.png" alt="Get Sex" />
<br><br>
If we check "male" and click on "Show", we get the following output:
<br><br>
<pre>
male: 1,
female: 0
</pre>
<br><br>
<h3>Another Example with Checkboxes</h3>
We write an application, which depicts a list of programming languages, e.g. 
['Python', 'Ruby', 'Perl', 'C++'] and a list of natural languages, e.g. ['English','German']
as checkboxes. So it's possible to choose programming languages and natural languages.
Furthermore, we have two buttons: A "Quit" button for ending the application and a "Peek" button
for checking the state of the checkbox variables.

<pre>
#!/usr/bin/python3

from tkinter import *
class Checkbar(Frame):
   def __init__(self, parent=None, picks=[], side=LEFT, anchor=W):
      Frame.__init__(self, parent)
      self.vars = []
      for pick in picks:
         var = IntVar()
         chk = Checkbutton(self, text=pick, variable=var)
         chk.pack(side=side, anchor=anchor, expand=YES)
         self.vars.append(var)
   def state(self):
      return map((lambda var: var.get()), self.vars)
if __name__ == '__main__':
   root = Tk()
   lng = Checkbar(root, ['Python', 'Ruby', 'Perl', 'C++'])
   tgl = Checkbar(root, ['English','German'])
   lng.pack(side=TOP,  fill=X)
   tgl.pack(side=LEFT)
   lng.config(relief=GROOVE, bd=2)

   def allstates(): 
      print(list(lng.state()), list(tgl.state()))
   Button(root, text='Quit', command=root.quit).pack(side=RIGHT)
   Button(root, text='Peek', command=allstates).pack(side=RIGHT)
   root.mainloop()
</pre>
<br><br>
The window looks like this:
<br><br>
<img src="images/programming_languages.png" alt="Programming Languages and Natural Languages as Checkboxes" />

<br><br>
</div>
<div id="contextlinks">Previous Chapter: <a href="tkinter_radiobuttons.php">Radiobuttons</a><br>
<LINK rel="prev" href="tkinter_radiobuttons.php">Next Chapter: <a href="tkinter_entry_widgets.php">Entry Widgets</a><br>
<LINK rel="next" href="tkinter_entry_widgets.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
