<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: History and Philosophy of Python</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="A brief History of Python, the origin of the name and the underlying philosophy." />
<meta name="Keywords" content="Python, Python3, Guido van Rossum, history, abc, Monty Python, origin, programming language, philosophy" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/hieroglyphen2_100.jpg" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<hr>
<h3>Learning From History</h3>
<img class="imgright" src="images/moebius_ring.png" alt="Ring as a Symbol of the for loop" />
"Hegel was right when he said that we learn from history that man can never learn anything from history."
<br>
(George Bernard Shaw)
<hr>
<br>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo,
Python Training courses"
		     src="images/bodenseo_python_training.gif"><br>Python Training Courses</a>
<br>
<hr>
<h3>Freedom in Programming</h3>
<i>
"Python is an experiment in how much freedom programmers need. Too much freedom and 
nobody can read another's code; too little and expressiveness is endangered."
<br>
</i>
(Guido van Rossum, 13 Aug 1996)
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_entstehung_python.php">Geschichte und Philosophie von Python</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="history_and_philosophy.php">History and Philosophy of Python in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="history_and_philosophy.php">History and Philosophy of Python in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Next Chapter: <a href="python3_interactive.php">Starting with Python: The Interactive Shell</a><br>
<LINK rel="next" href="python3_interactive.php"></div>
<h2>History of Python</h2>
<p>
<h3>Easy as ABC</h3>
<img class="imgright" src="images/Monty_Python_history.jpg" alt="Origin of the name Monty Python" />
What do the alphabet and the programming language Python have in common? Right, both start with ABC. If we are talking about ABC in the Python context, it's clear that the programming language ABC is meant. ABC is a general-purpose programming language and programming environment, which had been developed in the Netherlands, Amsterdam, at the CWI 
(Centrum Wiskunde & Informatica).  
The greatest achievement of ABC was to influence the design of Python. 
<br><br>
Python was conceptualized in the late 1980s. Guido van Rossum worked that time in a project at the CWI, called
Amoeba, a distributed operating system. In an interview with Bill Venners<sup>1</sup>, 
Guido van Rossum said: "In the early 1980s, I worked as an implementer on a team building a language called ABC at Centrum voor Wiskunde en Informatica (CWI). I don't know how well people know ABC's influence on Python. I try to mention ABC's influence because I'm indebted to everything I learned during that project and to the people who worked on it."
<br><br>Later on in the same Interview, Guido van Rossum continued: "I remembered all my experience and some of my frustration with ABC. I decided to try to 
design a simple scripting language that possessed some of ABC's better properties, but without its problems. So I started typing. I created a simple virtual machine, a simple parser, and a simple runtime. I made my own version of the various ABC parts that I liked. I created a basic syntax, used indentation for statement grouping instead of curly braces or begin-end blocks, and developed a small number of powerful data types: a hash table (or dictionary, as we call it), a list, strings, and numbers."
<br><br>
<h3>Comedy, Snake or Programming Language</h3>
So, what about the name "Python": Most people think about snakes, and even the logo depicts two snakes, but the origin of the name has its root in British humour. Guido van Rossum, the creator of Python, wrote in 1996 about the origin of the name of his programming
language<sup>1</sup>: "Over six years ago, in December 1989, I was looking for a 'hobby' programming project that would keep me occupied during the week around
Christmas. My office ... would be closed, but I had a home computer,
and not much else on my hands. I decided to write an interpreter for
the new scripting language I had been thinking about lately: a
descendant of ABC that would appeal to Unix/C hackers. I chose Python
as a working title for the project, being in a slightly irreverent
mood (and a big fan of Monty Python's Flying Circus)."
<br><br>
<h3>The Zen of Python</h3>
<cite>
<ul>
<li>Beautiful is better than ugly.
<li>Explicit is better than implicit.
<li>Simple is better than complex.
<li>Complex is better than complicated.
<li>Flat is better than nested.
<li>Sparse is better than dense.
<li>Readability counts.
<li>Special cases aren't special enough to break the rules.
<li>Although practicality beats purity.
<li>Errors should never pass silently.
<li>Unless explicitly silenced.
<li>In the face of ambiguity, refuse the temptation to guess.
<li>There should be one -- and preferably only one -- obvious way to do it.
<li>Although that way may not be obvious at first unless you're Dutch.
<li>Now is better than never.
<li>Although never is often better than *right* now.
<li>If the implementation is hard to explain, it's a bad idea.
<li>If the implementation is easy to explain, it may be a good idea.
<li>Namespaces are one honking great idea -- let's do more of those!
</ul>
</cite>
<br>
<h3>Development Steps of Python</h3>
Guido Van Rossum published the first version of Python code (version 0.9.0) at alt.sources in February 1991.
This release included already exception handling, functions, and the core datatypes of list, dict, str and 
others. It was also object oriented and had a module system.
<br><br>
Python version 1.0 was released in January 1994. The major new features included in this release were 
the functional programming tools lambda, map, filter and reduce, which Guido Van Rossum never liked.
<br><br>
Six and a half years later in October 2000, Python 2.0 was introduced. This release included list comprehensions,
a full garbage collector and it was supporting unicode.
<br><br>
Python flourished for another 8 years in the versions 2.x before the next majaor release as Python 3.0 
(also known as "Python 3000" and "Py3K") was released. Python 3 is not backwards compatible with Python 2.x.
The emphasis in Python 3 had been on the removal of duplicate programming constructs and modules, thus 
fulfilling or coming close to fulfilling the 13th law of the Zen of Python: "There should be one -- and 
preferably only one -- obvious way  to do it."
<br><br>
Some changes in Python 3.0:
<ul>

<li>Print is now a function</li>
<li>Views and iterators instead of lists</li>
<li>The rules for ordering comparisons have been simplified. E.g. a heterogeneous list cannot be sorted, 
because all the elements of a list must be comparable to each other.</li>
<li>There is only one integer type left, i.e. int. long is int as well.</li>
<li>The division of two integers returns a float instead of an integer. "//" can be used to 
hae the "old" behavious.</li>
<li>Text Vs. Data Instead Of Unicode Vs. 8-bit</li>
</ul>
</p>
<br>
<hr>
<br>
<sup>1</sup> January 13, 2003, http://www.artima.com/intv/pythonP.html
<sup>2</sup> Foreword for "Programming Python" (1st ed.) by Mark Lutz, O'Reilly

<div id="contextlinks">Next Chapter: <a href="python3_interactive.php">Starting with Python: The Interactive Shell</a><br>
<LINK rel="next" href="python3_interactive.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
