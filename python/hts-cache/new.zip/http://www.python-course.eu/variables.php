<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: A Tutorial</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial and Introduction for Beginners on Data Types and Variables in Python" />
<meta name="Keywords" content="Python, data, types, variables, strings" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/containers100.jpg" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<hr>
An infinite loop is a piece of code in a computer program which loops endlessly.
There can be various reason: either a terminating condition is missing, 
or the terminating condition is never met.  
<br>
<hr>
<br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
We have seen that there are different data types. There are different types of people as well. 
Frederick L. Collins thinks there are exactly two types: "There are two types of people - those 
who come into a room and say, 'Well, here I am!' and those who come in and say, 'Ah, there you are.'
<br><hr><br>
Or is it more the way Terry Pratchett sees it in "The Truth": <i>There are, it has been said, 
two types of people in the world. There are those who, when presented with a glass that is exactly 
half full, say: this glass is half full. And then there are those who say: this glass is half empty. 
The world belongs, however, to those who can look at the glass and say: What's up with this glass? 
Excuse me? Excuse me? This is my glass? I don't think so. My glass was full! And it was a bigger 
glass!</i>
<hr>
We also like to thank Denise Mitchinson for providing the stylesheet of this website.<br> <a href="http://www.mitchinson.net"> www.mitchinson.net </a>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung: 
    <a href="http://www.python-kurs.eu/variablen.php">Variablen und Datentypen</a><h3>Python 2.7</h3>This tutorial deals with Python Version 2.7<br>This chapter from our course is available in a version for Python3: <a href="python3_variables.php"></a>

<h3>Python Training Courses</h3>
<p>

<p>If you  want to learn Python fast and efficiently, the right step will be a 
<a href="http://www.bodenseo.com/courses.php?topic=Python">
<br>Python Training course</a> at Bodenseo. There are also
 special seminars for advanced students like the 
 <a href="http://www.bodenseo.com/course/python_xml_training_course.html">Python & XML Training Course</a>.
 If you want to acquire special knowledge in Text Processing and Text Classification, then  
<a href="http://www.bodenseo.com/course/python_text_processing_course.html">"Python Text Processing 
Course"</a> will be the right one for you.
<br>
All the Python seminars are available in German as well: 
<a href="http://www.bodenseo.de/kurse.php?topic=Python">Python-Kurse</a>"

 
<a href="http://www.bodenseo.com/courses.php?topic=Python">
<img class="imgright" src="images/bodenseo_stairs_to_python2.png" alt="Bodenseo step to python" />
<br>Python Courses</a> at Bodenseo.
<br><br>
You can book Bernd Klein for on-site <a href="python_classes.php">Python courses</a> as 
well.

<hr>
<h3>Variables and Data Types</h3>
A remarkable aspect of Python is that not only the value of variable can change during 
program execution but the type as well. This means that there can't be no type declaration 
for variables.
<h3>Variable Declaration</h3>
There is no variable declaration in Python! You just assign a value to a variable and it comes 
into existence. But never use a variable name without having assigned a value beforehand.
<h3>Complex Numbers</h3>
Complex numbers are part of the core language of Python. 
 </p>

</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="blocks.php">Structuring with Indentation</a><br>
<LINK rel="prev" href="blocks.php">Next Chapter: <a href="operators.php">Operators</a><br>
<LINK rel="next" href="operators.php"></div>
<h2>Data Types and Variables</h2>
<h3>Introduction</h3>
So, you know already a lot about data types and variables, because you have programmed lower level 
languages like C, C++ or other similar programming languages? In this case, it will be a good idea 
to continue reading this chapter on data types and variables in Python. There are integers, 
floating point numbers, strings, and many more, but things are not the same as in C or C++.
If you want to use lists in C e.g., you will have to construe the data type list from scratch, i.e.
design memory structure and the allocation management. You will have to implement the necessary search 
and access methods as well.   Python provides power data types like lists as a genuine part of the 
language.

<h3>Variables</h3>
      <p>
<img class="imgleft" src="images/containers300.jpg" alt="variables seen as containers" />
As the name implies, a variable is something which can change. A variable is a way of referring 
to a memory location used by a computer program. 
A variable is a symbolic name for this physical location. This memory location contains values, 
like numbers, text or more complicated types.
<br>
A variable can be seen as a container (or some say a pigeonhole) to store certain values. 
While the program is running,
variables are accessed and sometimes changed, i.e. a new value will be assigned to the variable.
<br>
One of the main differences between Python and strongly-typed languages like C, C++ or Java
is the way it deals with types. In strongly-typed languages every variable must have a unique 
data type. E.g. if a variable is of type integer, solely integers can be saved in the variable.
In Java or C, every variable has to be declared before it can be used. Declaring a variable means
binding it to a data type.
<br>
Declaration of variables is not required in Python. If there is need of a variable, you think of 
a name and start using it as a variable.
<br>
Another remarkable aspect of Python: Not only the value of a variable may change during program 
execution but the type as well. You can assign an integer value to a variable, use it as an integer
for a while and then assign a string to the variable.
<br>In the following line of code, we assign the value 42 to a variable i:
<pre>
i = 42
</pre>
The equal "=" sign in the assignment shouldn't be seen as an "equal sign". It should be "read" or
interpreted as "is set to", meaning in our example "the variable i is set to 42". Now we will increase
the value of this variable by 1: 
<br>
<pre>
>>> i = i + 1
>>> print i
43
>>> 
</pre>

<br>
<h3>Variables vs. Identifiers</h3>
Variables and identifiers are very often mistaken as synonyms. In simple terms:
The name of a variable is an identifier, but a variable is "more than a name". 
A variable has a name, in most cases a type, a scope, and above all a value.
Besides this, an identifier is not only used for variables. An identifier can
denote various entities like variables, types, labels, subroutines or functions,
packages and so on. 

<h3>Naming Identifiers of Variables</h3>
Every language has rules for naming identifiers. The rules in Python are the
following:
<br><br>
A valid identifier is a non-empty sequence of characters of any length with:
<ul>
<li>
the start character can be the underscore "_" or a capital or lower case letter 
</li>
<li>
the letters following the start character can be anything which is permitted 
as a start character plus the digits.
</li>
<li>
Just a warning for Windows-spoilt users: Identifiers are case-sensitive
</li>
<li>
Python keywords are not allowed as identifier names
</li>
</ul>

<h3>Python Keywords</h3>

No  identifier can have the same name as one of the Python keywords:
<br>
<i>
and, as, assert, break, class, continue, def, del, elif, else, except, finally, 
for, from, global, if, import, in, is, lambda, nonlocal, not, or, pass, raise, 
return, try, while, with, yield
</i>



<h3>Changing Data Types and Storage Locations</h3>
As we have said above, the type of a variable can change during the execution of the script. We 
illustrate this in our following example: <br> 
<br>

<pre>
i = 42			# data type is implicitely set to integer
i = 42 + 0.11		# data type is changed to float
i = "fourty"		# and now it will be a string  
</pre>

Python automatically takes care of the physical representation for the different data types, i.e.
an integer values will be stored in a different memory location than a float or a string.
<br><br>
What's happening, when we make assignments. Let's look at the following piece of code:
<pre>
>>> x = 3
>>> y = x
>>> y = 2
</pre>
<img class="imgright" src="images/variable_memory.gif" alt="Variables and memory locations" />
The first assignment is unproblematic: Python chooses a memory location for x and saves the 
integer value 3. The second assignment is more worthwhile: Intuitively, you may assume that
Python will find another location for the variable y and will copy the value of 3 in this 
place. But Python goes his own way, which differs from our intuition and the ways of C and C++.
As both variables will have the same value after the assignment, Python lets y point to the
memory location of x.<br>
The critical question arises in the next line of code. Y will be set to the integer value 2. 
What will happen to the value of x? C programmers will assume, that x will be changed to 2 as well,
because we said before, that y "points" to the location of x. But this is not a C-pointer.
Because x and y will not share the same value anymore, y gets his or her own memory location,
containing 2 and x sticks to 3, as can be seen in the animated graphics on the right side.
<br><br>
But what we said before can't be determined by typing in those three lines of code. But how can
we prove it? The identity function id() can be used for this purpose. Every instance (object or 
variable) has an identity, i.e. an integer which is unique within the script or program, i.e. 
other objects have different identities.
<br>So, let's have a look at our previous example and how the identities will change:
<pre>
>>> x = 3
>>> print id(x)
157379912
>>> y = x
>>> print id(y)
157379912
>>> y = 2
>>> print id(y)
157379924
>>> print id(x)
157379912
>>> 
</pre>
<br>

 
<h3>Numbers</h3>
<p>
Python's built-in core data types are in some cases also called object tpyes.  
There are four built-in data types for numbers:
<ul>
<li>Integer
<ul>
<li>Normal integers<br>e.g. 4321
<li>Octal literals (base 8)<br>A number prefixed by a 0 (zero) will be interpreted 
as an octal number<br>example:<br>
<code>
<font size="3" color="#4D711B">
>>> a = 010<br>
>>> print a<br>
8
</font>
</code>
Alternatively, an octal number can be defined with "0o" as a prefix:
<code>
<font size="3" color="#4D711B">
>>> a = o10<br>
>>> print a<br>
8
</font>
</code>


</li>
<li>Hexadecimal literals (base 16)<br>
Hexadecimal literals have to be prefixed either by "0x" or "0X".<br>
example:<br>
<code>
<font size="3" color="#4D711B">
>>> hex_number = 0xA0F<br>
>>> print hex_number<br>
2575
</font>
</code>
</li>
</li>
</ul>
<li>Long integers<br>these numbers are of unlimeted size<br>e.g.42000000000000000000L</li>
<li>Floating-point numbers<br>for example: 42.11, 3.1415e-10</li>
<li>Complex numbers<br>
Complex numbers are written as <code>
<font size="3" color="#4D711B"> 
<i>&lt;real part&gt;</i> + <i>&lt;imaginary part&gt;</i>j</i><br>
examples:<br>
<code><font size="3" color="#4D711B"> 
>>> x = 3 + 4j<br>
>>> y = 2 - 3j<br>
>>> z = x + y<br>
>>> print z<br>
(5+1j)
</font></code>
</li>
</font>
</code>
<br>  
    </ul>

 </p>
<h3>Strings</h3>
<p>
Another important data type besides numbers are strings. 
<br>
Strings are marked by quotes:
<ul>
<li>single quotes (')<br>
'This is a string with single quotes'
<li>double quotes (")<br>
"Obama's dog is called Bo""
<li>triple quotes, both single (''') and (""")<br>
'''String in triple quotes can extend <br>
over multiple lines, like this one, and can contain<br>
'single' and "double" quotes.'''  
</ul>

A string in Python consists of a series or sequence of characters - letters, numbers, 
and special characters. Strings can be subscripted or indexed. Similar to C, the first 
character of a string has has the index 0. There exists no character type in Python. A 
character is simply a string of size one. 
 
<br><br>
<img class="img" src="images/string_indices.gif" width="200" alt="String Indexing or subscripting" /> 
<br>
It's possible to start counting the indices from the right. In this case negative numbers are used, 
starting with -1 for the most right character.
<br><br>
<img class="img" src="images/string_indices_negative.png" width="200" alt="Negative String indices from the right" /> 

<br><br>

<br>
Some operators and functions for strings:
<ul>
<li><b>Concatenation</b><br>
Strings can be glued together (concatenated) with the + operator:<br>
     "Hello" + "World" -> "HelloWorld"
<li><b>Repetition</b><br>
String can be repeated or repeatedly concatenated with the asterisk operator "*":<br>
"*-*" * 3        -> "*-**-**-*"
<li><b>Indexing</b><br>
     "Python"[0]         -> "P"
<li><b>Slicing</b><br>
Substrings can be created with the slice or slicing notation, i.e. two indices in square 
brackets separated by a colon:
<br>
     "Python"[2:4]       -> "th"
     <br><br>
     <img class="img" src="images/string_slicing.png" width="200" alt="String Slicing" />
     <br><br>
<li><b>Size</b><br>
     len("Python")       -> 6
</ul>

<h3>Immutable Strings</h3>
Like strings in Java and unlike C or C++, Python strings cannot be changed. Trying to change
an indexed position will raise an error:
<pre>
>>> s = "Some things are immutable!"
>>> s[-1] = "."
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
TypeError: 'str' object does not support item assignment
>>> 
</pre>

<h3>A String Pecularity</h3>
Strings show a special effect, which we will illustrate in the following example. 
We will need the "is"-Operator. If both a and b are strings, "a is b" checks 
if they have the same identity, i.e. share the same memory location. If "a is b" is True,
then is trivially follows  that "a == b" has to be True as well. 
But "a == b" True doesn't imply that "a is b" is True as well!
<br>
Let's have a look at how strings are stored in Python:
<pre>
>>> a = "Linux"
>>> b = "Linux"
>>> a is b
True
</pre>
Okay, but what happens, if the strings are longer? We use the longest village name in the world in the 
following example. It's a small village with about 3000 inhabitants in the South of the island of 
Anglesey in the Nort-West of Wales:
<pre>
>>> a = "Llanfairpwllgwyngyllgogerychwyrndrobwllllantysiliogogogoch"
>>> b = "Llanfairpwllgwyngyllgogerychwyrndrobwllllantysiliogogogoch"
>>> a is b
True
</pre>
Nothing has changed to our first "Linux" example. But what works for Wales doesn't work e.g. for  
Baden-W�rttemberg in Germany:
<pre>
>>> a = "Baden-W�rttemberg"
>>> b = "Baden-W�rttemberg"
>>> a is b
False
>>> a == b
True
</pre>
You are right, it has nothing to do with geographical places. The special character, i.e. the hyphen, is 
to "blame".

<pre>
>>> a = "Baden!"
>>> b = "Baden!"
>>> a is b
False
>>> a = "Baden1"
>>> b = "Baden1"
>>> a is b
True
</pre>
 
</p>
 
 <h3>Escape Sequences</h3>

The backslash (\) character is used to escape characters, i.e. to "escape" the special meaning, 
which this character would otherwise have. Examples for such characters are newline, backslash itself, 
or the quote character. String literals may optionally be prefixed with a letter 'r' or 'R'; 
these strings are called raw strings. Raw strings use different rules for interpreting backslash 
escape sequences.
<br><br>
<table  cellpadding="6" cellspacing="0" border="1" bgcolor="#F5F5F5">
<th>Escape Sequence</th><th>Meaning 	Notes</td></th>
<tr></tr>
<tr><td>\newline</td><td>Ignored </td></tr>	 
<tr><td>\\</td><td> 	Backslash (\) 	</td></tr> 
<tr><td>\'</td><td> 	Single quote (') 	</td></tr> 
<tr><td>\"</td><td> 	Double quote (") 	</td></tr> 
<tr><td>\a </td><td>	ASCII Bell (BEL) 	 </td></tr>
<tr><td>\b </td><td>	ASCII Backspace (BS) </td></tr>	 
<tr><td>\f </td><td>	ASCII Formfeed (FF) 	</td></tr> 
<tr><td>\n </td><td>	ASCII Linefeed (LF) 	</td></tr> 
<tr><td>\N{name} </td><td>	Character named name in the Unicode database (Unicode only)</td></tr> 	 
<tr><td>\r </td><td>	ASCII Carriage Return (CR) 	</td></tr> 
<tr><td>\t </td><td>	ASCII Horizontal Tab (TAB) 	</td></tr> 
<tr><td>\uxxxx </td><td>	Character with 16-bit hex value xxxx (Unicode only)</td></tr>
<tr><td>\Uxxxxxxxx </td><td>	Character with 32-bit hex value xxxxxxxx (Unicode only)</td></tr>
<tr><td>\v </td><td>	ASCII Vertical Tab (VT) 	</td></tr> 
<tr><td>\ooo </td><td>	Character with octal value ooo </td></tr>
<tr><td>\xhh </td><td>	Character with hex value hh</td></tr>
</table>
<br>



</p>


<br>
<br>


<div id="contextlinks">Previous Chapter: <a href="blocks.php">Structuring with Indentation</a><br>
<LINK rel="prev" href="blocks.php">Next Chapter: <a href="operators.php">Operators</a><br>
<LINK rel="next" href="operators.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
