<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Generators</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial and practical introducing on Generators and Iterators in Python" />
<meta name="Keywords" content="Python, Python 3, Generators, Generator, example, examples, introduction, usage, 
permutations, Fibonacci numbers, Fibonacci sequence, iterator, iterators" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/wind_generators_small.png" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<h3>Mythology</h3>
The first great achievement of Apollo was to slay the huge serpent Python. In some texts 
Python is an enormous dragon and not a serpent. 
<br>  
But who was this mythical creature? Python was created out of the slime and mud left after 
the great flood. She was  appointed by Gaia (Mother Earth) to guard the oracle of Delphi, 
known as Pytho. After having defeated Python Apollo remade
her former home and the oracle as his own.
<br>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_generatoren.php">Generatoren</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="generators.php">Generators in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="generators.php">Generators in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_list_comprehension.php">List Comprehension</a><br>
<LINK rel="prev" href="python3_list_comprehension.php">Next Chapter: <a href="python3_exception_handling.php">Exception Handling</a><br>
<LINK rel="next" href="python3_exception_handling.php"></div>
<h2>Generators</h2> 
<br>
<h3>Introduction</h3>
<p>
<img class="imgright" src="images/wind_generators_posterize.png" alt="Windkraft-Generatoren" />
An iterator can be seen as a pointer to a container, e.g. a list structure, that can iterate over all
the elements of this container. The iterator is an abstraction, which enables the programmer to access
all the elements of a container (a set, a list and so on) without any deeper knowledge of the data
structure of this container object.
In some object oriented programming languages, like Perl, Java and Python, iterators are implicitly 
available and can be used in foreach loops, corresponding to for loops in Python.
<br><br>
Generators are a special kind of function, which enable us to implement or generate iterators.
<br><br>
Iterators are a fundamental concept of Python.
<br>
Mostly, iterators are implicitly used, like in the for loop of Python, as can be seen in the 
following example:
<br><br>
<pre>
>>> towns = ["Paris","Berlin","London","Vienna"]
>>> for location in towns:
...     print("location: " + location)
... 
location: Paris
location: Berlin
location: London
location: Vienna
>>> 
</pre>
The sequential base types as well as the majority of the classes of the standard library of Python
support iteration. The dictionary data type dict supports iterators as well. In this case the
iteration runs over the keys of the dictionary:
<pre>
>>> capitals = { "France":"Paris", "Netherlands":"Amsterdam", "Germany":"Berlin", "Switzerland":"Bern" }
>>> for country in capitals:
...     print("The capital city of " + country + " is " + capitals[country])
... 
The capital city of Switzerland is Bern
The capital city of Netherlands is Amsterdam
The capital city of Germany is Berlin
The capital city of France is Paris
>>> 
</pre>

<h3>Generators</h3>
Generators are a simple and powerful possibility to create or to generate iterators. On the surface
they look like functions, but there is both a syntactical and a semantical difference.
Instead of return statements you will find inside of the body of a generator only yield statements,
i.e. one or more yield statements.
<br><br>
Another important feature of generators is that the local variables and the execution start is 
automatically saved between calls. This is necessary, because unlike an ordinary function 
successive calls to a generator function don't start execution at the beginning of the function. 
Instead, the new call to a generator function will resume execution right
after the yield statement in the code, where the last call exited. In other words: When the Python
interpreter finds a yield statement inside of an iterator generated by a generator, it records 
the position of this statement and the local variables, and returns from the iterator. The next time 
this iterator is called, it will resume execution at the line following the previous yield statement. 
There may be more than one yield statement in the code of a generator or the yield statement might be 
inside the body of a loop. If there is a return statement in the code of a generator, the execution 
will stop with a StopIteration exception error if this code is executed by the Python interpreter. 
<br>
<br>
Everything what can be done with a generator can be implemented with a class based iterator as well.
But the crucial advantage of generators consists in automatically creating the methods 
__iter__() and next().
<br>
Generators provide a very neat way of producing data which is huge or infinite.
<br>
<br>The following is a simple example of a generator, which is capable of producing four city names:
<pre>
def city_generator():
    yield("Konstanz")
    yield("Zurich")
    yield("Schaffhausen")
    yield("Stuttgart")
</pre>
It's possible to create an iterator with this generator, which generates one after the other 
the four cities Konstanz, Zurich, Schaffhausen and Stuttgart.
<br>
<pre>
>>> from city_generator import city_generator
>>> x = city_generator()
>>> print(next(x))
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
AttributeError: 'generator' object has no attribute 'next'
>>> print(next(x))
Konstanz
>>> print(next(x))
Zurich
>>> print(next(x))
Schaffhausen
>>> print(next(x))
Stuttgart
>>> print(next(x))
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
StopIteration
</pre>
As we can see, we have generated an iterator x in the interactive shell. Every call of the method 
next() returns another city. After the last city, i.e. Stuttgart, has been created, another call of
next(x) raises an error, saying that the iteration has stopped, i.e. "StopIteration".
<br>Can we send a reset to an iterator is a frequently asked question, so that it can start the iteration
all over again. There is no reset, but it's possible to create another generator. This can be done e.g. by
 having the statement "x = city_generator()" again.
<br>Thought at first sight the yield statement looks like the return statement of a function, we can see
in this example, that there is a big difference. If we had a return statement instead of a yield in the
previous example, it would be a function. But this function would always return "Konstanz" and never any 
of the other cities, i.e. Zurich, Schaffhausen or Stuttgart.

</p>
<h3>Method of Operation</h3>
<p>
As we have elaborated in the introduction of this chapter, the generators offer a comfortable
method to generate iterators, and that's why they are called generators.
<br>
<br>Method of working:
<ul>
  <li>A generator is called like a function. It's return value is an iterator object. The code
  of the generator will not be executed in this stage.
  <li>The iterator can be used by calling the next method. The first time the execution 
  starts like a function, i.e. the first line of code within the body of the iterator.
  The code is executed until a yield statement is reached.
  <li>yield returns the value of the expression, which is following the keyword yield. 
  This is like a function, but Python keeps track of the position of this yield and the
  state of the local variables is stored for the next call. At the next call, the execution
  continues with the statement following the yield statement and the variables have the same
  values as they had in the previous call.
  <li>The iterator is finished, if the generator body is completely worked through or
  if the program flow encounters a return statement without a value. 
</ul>
We will illustrate this behaviour in the following example of a generator which generates
the Fibonacci numbers. 
<br>
The Fibonacci sequence is named after Leonardo of Pisa, who was known as Fibonacci 
(a contraction of filius Bonacci, "son of Bonaccio"). 
In his textbook Liber Abaci, which appeared in the year 1202) he had an exercise about 
the rabbits and their breeding: It starts with a newly-born pair of rabbits, i.e. a male
and a female animal. It takes one month until they can mate. At the end of the second month
the female gives birth to a new pair of rabbits. Now let's suppose that every female rabbit
will bring forth another pair of rabbits every month after the end of the first month.
We have to mention, that Fibonacci's rabbits never die. They question is how large the
population will be after a certain period of time.
<br><br>
This produces a sequence of numbers:  0,1,1,2,3,5,8,13 
<br><br>
This sequence can be defined in mathematical terms like this:
<br><br>
F<sub>n</sub> = F<sub>n - 1</sub> + F<sub>n - 2</sub>
<br>with the seed values:<br>
F<sub>0</sub> = 0 and F<sub>1</sub> = 1
<pre>
def fibonacci(n):
    """Ein Fibonacci-Zahlen-Generator"""
    a, b, counter = 0, 1, 0
    while True:
        if (counter > n): 
            return
        yield a
        a, b = b, a + b
        counter += 1
f = fibonacci(5)
for x in f:
	 # no linefeed is enforced by  end="":
    print(x, " ", end="") # 
print()
</pre>
The generator above can be used to create the first n Fibonacci numbers, or better
(n+1) numbers because the 0th number is also included. 
<br>In the next example we show you a version which is capable of returing an endless
iterator. We have to take care when we use this iterator, that a termination criterium
is used:

<pre>
def fibonacci():
    """Ein Fibonacci-Zahlen-Generator, unendlich"""
    a, b = 0, 1
    while True:
        yield a
        a, b = b, a + b

f = fibonacci()

counter = 0
for x in f:
    print(x, " ", end="")
    counter += 1
    if (counter > 10): 
        break 
print()
</pre>
</p>
<br>
<h3>Recursive Generators</h3>
<p>
<img class="imgright" src="images/permutationen.png" alt="Permutations" />
Like functions generators can be recursively programmed.  
The following example is a generator to create all the permutations of a given list 
of items.
<br><br>
For those who don't know what permutations are, we have a short introduction:<br><br>
Formal Definition:<br>
A permutation is a rearrangement of the elements of an ordered list. In other words: Every 
arrangement of n elements is called a permutation.
<br>
<br>
In the following lines we show you all the permutations of the letter a, b and c:
<br><br>
a b c<br>
a c b<br>
b a c<br>
b c a<br>
c a b<br>
c b a<br>
<br>
The number of permutations on a set of n elements is given by n!
<br
<pre>
n! = n*(n-1)*(n-2) ... 2 * 1
</pre>
<br>
n! is called the factorial of n.
<br><br>
The permutation generator can be called with an arbitrary list of objects. 
The iterator returned by this generator generates all the possible permutations:
<pre>
def permutations(items):
    n = len(items)
    if n==0: yield []
    else:
        for i in range(len(items)):
            for cc in permutations(items[:i]+items[i+1:]):
                yield [items[i]]+cc

for p in permutations(['r','e','d']): print(''.join(p))
for p in permutations(list("game")): print(''.join(p) + ", ", end="")
</pre>

The previous example can be hard to understand for newbies. As often, Python offers a convenient
solution. We need the module itertools for this purpose. Itertools is a very handy tool to create
and operate on iterators.
<br><br>
Creating permutations with itertools:
<pre>
>>> import itertools
>>> perms = itertools.permutations(['r','e','d'])
>>> perms
&lt;itertools.permutations object at 0x7fb0da3e4a70&gt;
>>> list(perms)
[('r', 'e', 'd'), ('r', 'd', 'e'), ('e', 'r', 'd'), ('e', 'd', 'r'), ('d', 'r', 'e'), ('d', 'e', 'r')]
>>> 
</pre>

The term "permutations" can sometimes be used in a weaker meaning. Permutations can denote in this weaker
meaning a sequence of elements, where each element occurs just once, but without the requirement to contain
all the elements of a given set. So in this sense (1,3,5,2) is a permutation of the set of digits {1,2,3,4,5,6}.
We can build for example all the sequences of a fixed length k of elements taken from a given set of size n with
k &le; n. 
<br><br>
These are are all the 3-permutations of the set {"a","b","c","d"}:
<br>
<pre>
['a', 'b', 'c']
['a', 'b', 'd']
['a', 'c', 'b']
['a', 'c', 'd']
['a', 'd', 'b']
['a', 'd', 'c']
['b', 'a', 'c']
['b', 'a', 'd']
['b', 'c', 'a']
['b', 'c', 'd']
['b', 'd', 'a']
['b', 'd', 'c']
['c', 'a', 'b']
['c', 'a', 'd']
['c', 'b', 'a']
['c', 'b', 'd']
['c', 'd', 'a']
['c', 'd', 'b']
['d', 'a', 'b']
['d', 'a', 'c']
['d', 'b', 'a']
['d', 'b', 'c']
['d', 'c', 'a']
['d', 'c', 'b']
</pre>
<br>
These atypical permutations are also known as <b>sequences without repetition</b>. 
By using this term we can avoid confusion with the term "permutation". 
The number of such k-permutations of n is denoted by P<sub>n,k</sub> and its value is calculated by the product:
<br>
<i>n &middot; (n - 1) &middot;  &hellip; (n - k + 1) </i>
<br>
By using the factorial notation, the above expression can be written as:
<br>
<pre>P<sub>n,k</sub> = n! / (n - k)!</pre>

A generator for the creation of k-permuations of n objects looks very similar to our previous permutations generator:

<pre>
def k_permutations(items, n):
    if n==0: yield []
    else:
        for i in range(len(items)):
            for ss in k_permutations(items, n-1):
                if (not items[i] in ss):
                    yield [items[i]]+ss
</pre>
<br>
</p>

<h3>A Generator of Generators</h3>
<p>
The second generator of our Fibonacci sequence example generates an iterator, which
can theoretically produce all the Fibonacci numbers, i.e. an infinite number.
But you shouldn't try to produce all these numbers, as we would do in the following
example: 
<pre>
list(fibonacci())
</pre>
This will show you very fast the limits of your computer.
<br>
In most practical applications, we only need the first n elements of an "endless" iterator.
We can use another generator, in our example firstn, to create the first n elements of
a generator g: 
<pre>
def firstn(g, n):
	for i in range(n):
		yield next(g)
</pre>
The following script returns the first 10 elements of the Fibonacci sequence:
<pre>
#!/usr/bin/env python3
def fibonacci():
    """Ein Fibonacci-Zahlen-Generator"""
    a, b = 0, 1
    while True:
        yield a
        a, b = b, a + b

def firstn(g, n):
	for i in range(n):
		yield next(g)

print(list(firstn(fibonacci(), 10)))
</pre>
The output looks like this:
<pre>
[0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
</pre>

</p>

<div id="contextlinks">Previous Chapter: <a href="python3_list_comprehension.php">List Comprehension</a><br>
<LINK rel="prev" href="python3_list_comprehension.php">Next Chapter: <a href="python3_exception_handling.php">Exception Handling</a><br>
<LINK rel="next" href="python3_exception_handling.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
