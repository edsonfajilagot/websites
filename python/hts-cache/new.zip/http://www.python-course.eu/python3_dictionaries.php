<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Dictionaries</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial on Dictionaries in Python: Operators and Methods of the  Dictionary class" />
<meta name="Keywords" content="Python, Tutorial, course, Dictionaries, dictionary, methods, mapping, associative, Operators" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/python_entry.jpg" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<br>
<hr>
<h3>Dictionary</h3>
Definition by Webster 1913: <br>
1. "A book containing the words of a language, arranged
 alphabetically, with explanations of their meanings; a
 lexicon; a vocabulary; a wordbook."
 <br>
 "I applied myself to the perusal of our writers; and
 noting whatever might be of use to ascertain or
 illustrate any word or phrase, accumulated in time
 the materials of a dictionary. --Johnson.
 <br><br>
2. Hence, a book containing the words belonging to any system
 or province of knowledge, arranged alphabetically; as, a
 dictionary of medicine or of botany; a biographical
 dictionary.
</li>
</ol>
<hr>
<br>
Moby Thesaurus words for "dictionary":
<br> biographical dictionary, cant, chemical dictionary,
 desk dictionary, dialect dictionary, dictionary of quotations,
 electronics dictionary, etymological dictionary,
 foreign-language dictionary, gazetteer, general dictionary,
 geological dictionary, gloss, glossary, gradus, jargon, language,
 lexicon, nomenclator, onomasticon, palaver, phrase book,
 polyglot dictionary, promptorium, rhyming dictionary,
 science dictionary, slang dictionary, specialized dictionary,
 synonym dictionary, synonymy, terminology, thesaurus,
 treasury of words, unabridged dictionary, vocabulary, word list,
 wordbook
<br>-- From Moby Thesaurus II by Grady Ward, 1.0
<br><br>
<hr>
<br>
Definition from THE DEVIL'S DICTIONARY:
<br>
A malevolent literary device for cramping the growth
of a language and making it hard and inelastic. This dictionary,
however, is a most useful work.

<br>
<br>
<hr>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_dictionaries.php">Dictionaries</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="dictionaries.php">Dictionaries in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="dictionaries.php">Dictionaries in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_deep_copy.php">Shallow and Deep Copy</a><br>
<LINK rel="prev" href="python3_deep_copy.php">Next Chapter: <a href="python3_sets_frozensets.php">Sets and Frozen Sets</a><br>
<LINK rel="next" href="python3_sets_frozensets.php"></div>
<h2>Dictionaries</h2>
<p>
<h3>Introduction</h3>
<img class="imgright" src="images/webster.jpg" alt="Webster's Dictionary" />

We have already become acquainted with lists in the previous chapter. 
In this chapter of our online Python course we will present the dictionaries 
and the operators and methods on dictionaries. Python programs or scripts without
lists and dictionaries are nearly inconceivable. Dictionaries and their powerful implementations
are part of what makes Python so effective and superior. Like lists they can 
be easily changed, can be shrinked and grown ad libitum at run time. They shrink
and grow without the necessity of making copies. Dictionaries can be contained in 
lists and vice versa. 
<br><br>
But what's the difference between lists and dictionaries? 
A list is an ordered sequence of objects, whereas dictionaries
are unordered sets. But the main difference is that items in dictionaries are accessed
via keys and not via their position. 
<br><br>
More theoretically, we can say, that dictionaries are the Python implementation of an abstract data type, known in computer science as an associative array. Associative arrays consist - like dictionaries of 
(key, value) pairs, such that each possible key appears at most once in the collection. 
Any key of the dictionary is associated (or mapped) to a value. The
values of a dictionary can be any Python data type. So dictionaries are unordered 
key-value-pairs. Dictionaries are implemented as hash tables, and that is the reason why they are known  as "Hashes" in the programming language Perl.
<br><br>
Dictionary don't support the sequence operation of the sequence data types like strings, tuples
and lists. Dictionaries belong to the built-in mapping type, but so far they are the sole
representative of this kind!

<br><br>
At the end of this chapter, we will demonstrate how a dictionary can be turned into one
list, containing (key,value)-tuples or two lists, i.e. one with the keys and one 
with the values. This transformation can be done reversely as well.
<br><br>
<h3>Examples of Dictionaries</h3>    

Our first example is a dictionary with cities located in the US and Canada and their corresponding population:

<pre>
>>> city = {"New York City":8175133, "Los Angeles": 3792621, "Washington":632323, "Chicago": 2695598, "Toronto":2615060, "Montreal":11854442, "Ottawa":883391, "Boston":62600}
</pre>

If we want to get the population of one of those cities, all we have to do is to use the name of the city as an index:

<pre>
>>> city["New York City"]
8175133
>>> city["Toronto"]
2615060
>>> city["Boston"]
62600
</pre>

What happens, if we try to access a key, i.e. a city, which is not contained in the dictionary? We raise a
KeyError:

<pre>
>>> city["Detroit"]
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in <module>
KeyError: 'Detroit'
>>> 
</pre>

If you look at the way, we have defined our dictionary, you might get the impression, that we have an ordering in our dictionary, i.e. the first one "New York City", the second one "Los Angeles" and so on.
But be aware of the fact, that there is no ordering in dictionaries. That's the reason, why the output of the city dictionary, doesn't reflect the "original ordering":

<pre>
>>> city
{'Toronto': 2615060, 'Ottawa': 883391, 'Los Angeles': 3792621, 'Chicago': 2695598, 'New York City': 8175133, 'Boston': 62600, 'Washington': 632323, 'Montreal': 11854442}
</pre>
Therefore it is neither possible to access an element of the dictionary by a number, like we did with lists:
<pre>
>>> city[0]
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in <module>
KeyError: 0
>>> 
</pre>


It is very easy to add another entry to an existing dictionary:

<pre>
>>> city["Halifax"] = 390096
>>> city
{'Toronto': 2615060, 'Ottawa': 883391, 'Los Angeles': 3792621, 'Chicago': 2695598, 'New York City': 8175133, 'Halifax': 390096, 'Boston': 62600, 'Washington': 632323, 'Montreal': 11854442}
>>> 
</pre>

So, it's possible to create a dictionary incementally by starting with an empty dictionary. We haven't mentioned so far, how to define an empty one. It can be done by using a empty pair of brackets. The following defines an empty dictionary, called city:

<pre>
>>> city = {}
>>> city
{}
</pre>

Looking at our first examples with the cities and their population numbers, you might have got the wrong impression, that the values in the dictionaries have to be different. The values can be the same, as you can see in the following example. In honour to the patron saint of Python "Monty Python", we'll have now some special food dictionaries. What's Python without "ham", "egg" and "spam"?
<pre>
>>> food = {"ham" : "yes", "egg" : "yes", "spam" : "no" }
>>> food
{'egg': 'yes', 'ham': 'yes', 'spam': 'no'}
>>> food["spam"] = "yes"
>>> food
{'egg': 'yes', 'ham': 'yes', 'spam': 'yes'}
>>> 
</pre>

Our next example is a simple English-German dictionary:
<br>
<pre>
en_de = {"red" : "rot", "green" : "gr�n", "blue" : "blau", "yellow":"gelb"}
print(en_de)
print(en_de["red"])
</pre>

What about having another language dictionary, let's say German-French?  

<pre>
de_fr = {"rot" : "rouge", "gr�n" : "vert", "blau" : "bleu", "gelb":"jaune"}
</pre>

Now it's even possible to translate from English to French, even though we don't 
have an English-French-dictionary. de_fr[en_de["red"]] gives us the French word
for "red", i.e. "rouge":
<pre>
en_de = {"red" : "rot", "green" : "gr�n", "blue" : "blau", "yellow":"gelb"}
print(en_de)
print(en_de["red"])
de_fr = {"rot" : "rouge", "gr�n" : "vert", "blau" : "bleu", "gelb":"jaune"}
print("The French word for red is: " + de_fr[en_de["red"]])
</pre>

The output of the previous script:
<pre>
{'blue': 'blau', 'green': 'gr�n', 'yellow': 'gelb', 'red': 'rot'}
rot
The French word for red is: rouge
</pre>

We can use arbitrary types as values in a dictionary, but there is a restriction 
for the keys. Only immutable data types can be used as keys, i.e. no lists or
dictionaries can be used: 

<br>If you use a mutable data type as a key, you get an error message:
<pre>
>>> dic = { [1,2,3]:"abc"}
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
TypeError: list objects are unhashable
</pre>
Tuple as keys are okay, as you can see in the following example:
<pre>
>>> dic = { (1,2,3):"abc", 3.1415:"abc"}
>>> dic
{(1, 2, 3): 'abc'}
</pre>

Let's improve our examples with the natural language dictionaries a bit. We create a 
dictionary of dictionaries:
<pre>
en_de = {"red" : "rot", "green" : "gr�n", "blue" : "blau", "yellow":"gelb"}
de_fr = {"rot" : "rouge", "gr�n" : "vert", "blau" : "bleu", "gelb":"jaune"}

dictionaries = {"en_de" : en_de, "de_fr" : de_fr }
print(dictionaries["de_fr"]["blau"])
</pre>

</p>
<h3>Operators on Dictionaries</h3>
<p>
<table
style="text-align: left; width: 100%; background-color: rgb(255, 255, 153);"
border="0" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<th style="vertical-align: top;">Operator<br></th>
<th style="vertical-align: top;">Explanation<br></th>
</tr>
<tr>
<td style="vertical-align: top;">len(d)<br></td>
<td style="vertical-align: top;">returns the number of stored entries, i.e. 
the number of (key,value) pairs.<br></td>
</tr>
<tr>
<td style="vertical-align: top;">del d[k]<br></td>
<td style="vertical-align: top;">deletes the key k together with his value<br></td>
</tr>
<tr>
<td style="vertical-align: top;">k in d<br></td>
<td style="vertical-align: top;">True, if a key k exists in the dictionary d<br></td>
</tr>

<tr>
<td style="vertical-align: top;">k not in d<br></td>
<td style="vertical-align: top;">True, if a key k doesn't exist in the dictionary d<br></td>
</tr>

</tbody>
</table>
<br><br>
<b>Examples:</b>
<br>
The following dictionary contains a mapping from latin characters to morsecode.

<pre>
morse = {
"A" : ".-", 
"B" : "-...", 
"C" : "-.-.", 
"D" : "-..", 
"E" : ".", 
"F" : "..-.", 
"G" : "--.", 
"H" : "....", 
"I" : "..", 
"J" : ".---", 
"K" : "-.-", 
"L" : ".-..", 
"M" : "--", 
"N" : "-.", 
"O" : "---", 
"P" : ".--.", 
"Q" : "--.-", 
"R" : ".-.", 
"S" : "...", 
"T" : "-", 
"U" : "..-", 
"V" : "...-", 
"W" : ".--", 
"X" : "-..-", 
"Y" : "-.--", 
"Z" : "--..", 
"0" : "-----", 
"1" : ".----", 
"2" : "..---", 
"3" : "...--", 
"4" : "....-", 
"5" : ".....", 
"6" : "-....", 
"7" : "--...", 
"8" : "---..", 
"9" : "----.", 
"." : ".-.-.-", 
"," : "--..--"
}
</pre>

If you save this dictionary as morsecode.py, you can easily follow the following examples. 
At first you have to import this dictionary:

<pre>
from morsecode import morse
</pre>

The numbers of characters contained in this dictionary can be determined by calling the len function:


<pre>
>>> len(morse)
38
</pre>

The dictionary contains only upper case characters, so that "a" returns False for example:

<pre>
>>> "a" in morse
False
>>> "A" in morse
True
>>> "a" not in morse
True
</pre>



</p>

<h3>pop() and popitem()</h3>
<p>
<h4>pop</h4>
Lists can be used as stacks and the operator pop() is used to take an element from the stack.
So far, so good, for lists, but does it make sense to have a pop() method for dictionaries. After all
a dict is not a sequence data type, i.e. there is no ordering and no indexing. Therefore, 
pop() is defined differently with dictionaries. Keys and values are implemented in an arbitrary order,
which is not random, but depends on the implementation. 
<br>If D is a dictionary, then D.pop(k) removes the key k with its value from the dictionary D
and returns the corresponding value as the return value, i.e. D[k].
<br>
If the key is not found a KeyError is raised:
<br>
<pre>
>>> en_de = {"Austria":"Vienna", "Switzerland":"Bern", "Germany":"Berlin", "Netherlands":"Amsterdam"}
>>> capitals = {"Austria":"Vienna", "Germany":"Berlin", "Netherlands":"Amsterdam"}>>> capital = capitals.pop("Austria")
>>> print(capital)
Vienna
>>> print(capitals)
{'Netherlands': 'Amsterdam', 'Germany': 'Berlin'}
>>> capital = capitals.pop("Switzerland")
Traceback (most recent call last):
  File "&lt;stdin&gt", line 1, in &lt;module&gt;
KeyError: 'Switzerland'
>>> 
</pre>

If we try to find out the capital of Switzerland in the previous example, we raise a KeyError. 
To prevent these errors, there is an elegant way. The method pop() has an optional second parameter,
which can be used as a default value:

<pre>
>>> capital = capitals.pop("Switzerland", "Bern")
>>> print(capital)
Bern
>>> capital = capitals.pop("France", "Paris")
>>> print(capital)
Paris
>>> capital = capitals.pop("Germany", "M�nchen")
>>> print(capital)
Berlin
>>> 
</pre>

<h4>popitem</h4>

popitem() is a method of dict, which doesn't take any parameter and removes and returns an arbitrary
(key,value) pair as a 2-tuple. If popitem() is applied on an empty dictionary, a KeyError will be raised.

<pre>
>>> capitals = {"Springfield":"Illinois", "Augusta":"Maine", "Boston": "Massachusetts", "Lansing":"Michigan", "Albany":"New York", "Olympia":"Washington", "Toronto":"Ontario"}
>>> (city, state) = capitals.popitem()
>>> (city, state)
('Olympia', 'Washington')
>>> print(capitals.popitem())
('Albany', 'New York')
>>> print(capitals.popitem())
('Boston', 'Massachusetts')
>>> print(capitals.popitem())
('Lansing', 'Michigan')
>>> print(capitals.popitem())
('Toronto', 'Ontario')
>>> 
</pre>

</p> 



<h3>Accessing non Existing Keys</h3>
<p>
If you try to access a key which doesn't exist, you will get an error message:
<pre>
>>> locations = {"Toronto" : "Ontario", "Vancouver":"British Columbia"}
>>> locations["Ottawa"]
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
KeyError: 'Ottawa'
</pre>
You can prevent this by using the "in" operator:
<pre>
>>> if "Ottawa" in locations: print(locations["Ottawa"])
... 
>>> if "Toronto" in locations: print(locations["Toronto"])
...  
Ontario
</pre>

Another method to access the values via the key consists in using the get() method. get() is not raising an error, if an index doesn't exist. In this case it will return None. It's also possible to set a default value, which will be returned, if an index doesn't exit:

<pre>
>>> proj_language = {"proj1":"Python", "proj2":"Perl", "proj3":"Java"}
>>> proj_language["proj1"]
'Python'
>>> proj_language["proj4"]
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in <module>
KeyError: 'proj4'
>>> proj_language.get("proj2")
'Perl'
>>> proj_language.get("proj4")
>>> print(proj_language.get("proj4"))
None
>>> # setting a default value:
>>> proj_language.get("proj4", "Python")
'Python'
>>> 
</pre>


</p>
<h3>Important Methods</h3>
A dictionary can be copied with the method copy():
<pre>
>>> w = words.copy()
>>> words["cat"]="chat"
>>> print(w)
{'house': 'Haus', 'cat': 'Katze'}
>>> print(words)
{'house': 'Haus', 'cat': 'chat'}
</pre>
This copy is a shallow and not a deep copy. If a value is a complex data type like
a list for example, in-place changes in this object have effects on the copy as well:

<pre>
# -*- coding: utf-8 -*-

trainings = { "course1":{"title":"Python Training Course for Beginners", 
                         "location":"Frankfurt", 
                         "trainer":"Steve G. Snake"},
              "course2":{"title":"Intermediate Python Training",
                         "location":"Berlin",
                         "trainer":"Ella M. Charming"},
              "course3":{"title":"Python Text Processing Course",
                         "location":"M�nchen",
                         "trainer":"Monica A. Snowdon"}
              }

trainings2 = trainings.copy()

trainings["course2"]["title"] = "Perl Training Course for Beginners"
print(trainings2)
</pre>

If we check the output, we can see, that the title of course2 has been changed not only in the
dictionary training but in trainings2 as well:

<pre>
{'course2': {'trainer': 'Ella M. Charming', 'name': 'Perl Training Course for Beginners', 'location': 'Berlin'}, 'course3': {'trainer': 'Monica A. Snowdon', 'name': 'Python Text Processing Course', 'location': 'M�nchen'}, 'course1': {'trainer': 'Steve G. Snake', 'name': 'Python Training Course for Beginners', 'location': 'Frankfurt'}}
</pre> 


Everything works the way you expect it, if you assign a new value, i.e. a new object, to a key:
<pre>
trainings = { "course1":{"title":"Python Training Course for Beginners", 
                         "location":"Frankfurt", 
                         "trainer":"Steve G. Snake"},
              "course2":{"title":"Intermediate Python Training",
                         "location":"Berlin",
                         "trainer":"Ella M. Charming"},
              "course3":{"title":"Python Text Processing Course",
                         "location":"M�nchen",
                         "trainer":"Monica A. Snowdon"}
              }

trainings2 = trainings.copy()

trainings["course2"] = {"title":"Perl Seminar for Beginners",
                         "location":"Ulm",
                         "trainer":"James D. Morgan"}
print(trainings2["course2"])
</pre>
The statements <i>print(trainings2["course2"])</i> outputs still the original Python course:
<pre>
{'trainer': 'Ella M. Charming', 'location': 'Berlin', 'title': 'Intermediate Python Training'}
</pre>

<br><br>


If we want to understand the reason for this behaviour, we recommend our chapter 
"Shallow and Deep Copy".
<br><br>
The content of a dictionary can be cleared with the method clear().
The dictionary is not deleted, but set to an empty dictionary:
<pre>
>>> w.clear()
>>> print(w)
{}
</pre>
</p>
<h3>Update: Merging Dictionaries</h3>
<p>
What about concatenating dictionaries, like we did with lists? There is someting 
similar for dictionaries: the update methode<br>
update() merges the keys and values of one dictionary into
another, overwiting values of the same key:

<pre>
>>> knowledge = {"Frank": {"Perl"}, "Monica":{"C","C++"}}
>>> knowledge2 = {"Guido":{"Python"}, "Frank":{"Perl", "Python"}}
>>> knowledge.update(knowledge2)
>>> knowledge
{'Frank': {'Python', 'Perl'}, 'Guido': {'Python'}, 'Monica': {'C', 'C++'}}
</pre>


</p>
<h3>Iterating over a Dictionary</h3>
<p>
No method is needed to interate over a dictionary:
<pre>
for key in d:
	print(key)
</pre>
But it's possible to use the method iterkeys():
<pre>
for key in d.iterkeys():
	print(key)
</pre>
The method itervalues() is a convenient way for iterating directly over the values:
<pre>
for val in d.itervalues():
	print(val)
</pre>
The above loop is of course equivalent to the following one:
<pre>
for key in d:
	print(d[key])
</pre>
</p>
<br>
<h3>Connection between Lists and Dictionaries</h3>
<p>
<img class="imgright" src="images/zipper_sphere.gif" 
alt="zipper on a ball"/>

If you have worked for a while with Python, nearly inevitably the moment will come,
when you want or have to convert lists into dictionaries or vice versa.
It wouldn't be too hard to write a function doing this. But Python wouldn't be Python, 
if it didn't provide such functionalities. 

<br><br>
If we have a dictionary <br><br>
<FONT FACE="courier">D = {"list":"Liste", "dictionary":"W�rterbuch", "function":"Funktion"}
</FONT>
<br><br>
we could turn this into a list with two-tuples: <br><br>
<FONT FACE="courier">L = [("list","Liste"), ("dictionary","W�rterbuch"), ("function","Funktion")]
</FONT>
<br><br>
The list L and the dictionary D contain the same content, i.e. the information content, or to express ot  
sententiously "The entropy of L and D is the same". Of course, the information is harder to retrieve
from the list L than from the dictionary D. To find a certain key in L, we would have to browse through
the tuples of the list and compare the first components of the tuples with the key we are looking for.
This search is implicitly and extremely efficiently implemented for dictionaries.

</p>


<h3>Lists from Dictionaries</h3>
<p>
It's possible to create lists from dictionaries  by using the methods items(), 
keys() und values(). As the name implies the method keys() creates a list, 
which consists solely of the keys of the dictionary. While values() produces a list
constisting of the values.  items() can be used to create a list consisting of 
2-tuples of (key,value)-pairs:
<pre>
>>> w = {"house":"Haus", "cat":"", "red":"rot"}
>>> items_view = w.items()
>>> items = list(items_view)
>>> items
[('house', 'Haus'), ('cat', ''), ('red', 'rot')]
>>> 
>>> keys_view = w.keys()
>>> keys = list(keys_view)
>>> keys
['house', 'cat', 'red']
>>> 
>>> values_view = w.values()
>>> values = list(values_view)
>>> values
['Haus', '', 'rot']
>>> values_view
dict_values(['Haus', '', 'rot'])
>>> items_view
dict_items([('house', 'Haus'), ('cat', ''), ('red', 'rot')])
>>> keys_view
dict_keys(['house', 'cat', 'red'])
>>> 
</pre>


If we apply the method items() to a dictionary, we don't get a list back, as it used
to be the case in Python 2, but a so-called items view. The items view can be turned 
into a list by applying the list function. We have no information loss by turning a 
dictionary into an item view or an items list, i.e. it
is possible to recreate the original dictionary from the view created by items().
Even though this list of 2-tuples has the same entropy, i.e. the information content
is the same, the efficiency of both approaches is completely different. The dictionary
data type provides highly efficient methods to access, delete and change elements of the
dictionary, while in the case of lists these functions have to be implemented by the 
programmer.

<br>
<h3>Turn Lists into Dictionaries</h3>

Now we will turn out attention to the art of cooking, but don't be afraid, this
remain a python course and not a cooking course. 
We want to show you, how to turn lists into dictionaries, if these lists satisfy
certain conditions.
<br>
We have two lists, one containing the dishes and the other one the corresponding
countries:
<pre>
>>> dishes = ["pizza", "sauerkraut", "paella", "hamburger"]
>>> countries = ["Italy", "Germany", "Spain", "USA"]
</pre>
Now we will create a dictionary, which assigns a dish, a country-specific dish, to a country; 
please forgive us for resorting to the common prejudices. 
For this purpose we need the function zip(). The name zip was well chosen, because
the two lists get combined like a zipper. The result is a list iterator. This means that
we have to wrap a list() casting function around the zip call to get a list:
<br>
<pre>
>>> country_specialities = list(zip(countries, dishes))
>>> print(country_specialities)
[('Italy', 'pizza'), ('Germany', 'sauerkraut'), ('Spain', 'paella'), ('USA', 'hamburger')]
>>> 
</pre>

Now our country-specific dishes are in a list form, - i.e. a list of two-tuples, where the 
first components are seen as keys and the second components as values - 
which can be automatically turned into a dictionary by casting it with dict(). 

<pre>
>>> country_specialities_dict = dict(country_specialities)
>>> print(country_specialities_dict)
{'Germany': 'sauerkraut', 'Italy': 'pizza', 'USA': 'hamburger', 'Spain': 'paella'}
>>> 
</pre>


<br><br>
There is still one question concerning the function zip(). What happens, if one
of the two argument lists contains more elements than the other one? 
<br><br>
It's easy to answer: The superfluous elements, which cannot be paired, will be ignored: 
<pre>
>>> dishes = ["pizza", "sauerkraut", "paella", "hamburger"]
>>> countries = ["Italy", "Germany", "Spain", "USA"," Switzerland"]
>>> country_specialities = list(zip(countries, dishes))
>>> country_specialities_dict = dict(country_specialities)
>>> print(country_specialities_dict)
{'Germany': 'sauerkraut', 'Italy': 'pizza', 'USA': 'hamburger', 'Spain': 'paella'}
>>> 
</pre>
So in this course, we will not answer the burning question, what the national dish of
Switzerland is.
<br><br>
<h4>Everything in One Step</h4>
Normally, we recommend not to implement too many steps in one programming expression, though 
it looks more impressive and the code is more compact. Using "talking" variable names in intermediate
steps can enhance legibility. Though it might be alluring to create our previous dictionary just in one go:

<pre>
>>> country_specialities_dict = dict(list(zip(["pizza", "sauerkraut", "paella", "hamburger"], ["Italy", "Germany", "Spain", "USA"," Switzerland"])))
>>> print(country_specialities_dict)
{'paella': 'Spain', 'hamburger': 'USA', 'sauerkraut': 'Germany', 'pizza': 'Italy'}
>>> 
</pre>

On the other hand, the code in the previous script is gilding the lily:

<pre>
dishes = ["pizza", "sauerkraut", "paella", "hamburger"]
countries = ["Italy", "Germany", "Spain", "USA"]
country_specialities_zip = zip(dishes,countries)
print(list(country_specialities_zip))
country_specialities_list = list(country_specialities_zip)
country_specialities_dict = dict(country_specialities_list)
print(country_specialities_dict)
</pre>

We get the same result, as if we would have called it in one go.

<h4>Danger Lurking</h4>
Especialy for those migrating from Python 2.x to Python 3.x: zip() used to return a list, now it's
returning an iterator. You have to keep in mind, that iterators exhaust themselves, if they are used.
You can see this in the follwing interactive session:

<pre>
>>> l1 = ["a","b","c"]
>>> l2 = [1,2,3]
>>> c = zip(l1, l2)
>>> for i in c:
...     print(i)
... 
('a', 1)
('b', 2)
('c', 3)
>>> for i in c:
...     print(i)
... 
</pre>
This effect can be seen by calling the list casting operator as well:

<pre>
>>> l1 = ["a","b","c"]
>>> l2 = [1,2,3]
>>> c = zip(l1,l2)
>>> z1 = list(c)
>>> z2 = list(c)
>>> print(z1)
[('a', 1), ('b', 2), ('c', 3)]
>>> print(z2)
[]
</pre>

As an exercise, you may muse about the following script. 
<pre>
dishes = ["pizza", "sauerkraut", "paella", "hamburger"]
countries = ["Italy", "Germany", "Spain", "USA"]
country_specialities_zip = zip(dishes,countries)
print(list(country_specialities_zip))
country_specialities_list = list(country_specialities_zip)
country_specialities_dict = dict(country_specialities_list)
print(country_specialities_dict)
</pre>
If you start this script, you will see, that the dictionary you want to create will be empty:
<pre>
$ python3 tricky_code.py 
[('pizza', 'Italy'), ('sauerkraut', 'Germany'), ('paella', 'Spain'), ('hamburger', 'USA')]
{}
$
</pre>
<br>
<h4>Skipping the Intermediate List</h4>
We wanted to show that there is a one to one relationship between this list of 2-tuples and the dictionary, so
we produced this kind of list. This is not necessary. We can create the "culinary" dictionary directly from the
iterator:

<pre>
>>> countries = ["Italy", "Germany", "Spain", "USA"]
>>> country_specialities_zip = zip(dishes,countries)
>>> country_specialities_dict = dict(country_specialities_zip)
>>> print(country_specialities_dict)
{'paella': 'Spain', 'hamburger': 'USA', 'sauerkraut': 'Germany', 'pizza': 'Italy'}
>>>
</pre> 


<br><br>
<div id="contextlinks">Previous Chapter: <a href="python3_deep_copy.php">Shallow and Deep Copy</a><br>
<LINK rel="prev" href="python3_deep_copy.php">Next Chapter: <a href="python3_sets_frozensets.php">Sets and Frozen Sets</a><br>
<LINK rel="next" href="python3_sets_frozensets.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
