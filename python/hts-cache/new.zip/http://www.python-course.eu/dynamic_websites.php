
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: A Tutorial</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial on how to create a dynamic website with Python" />
<meta name="Keywords" content="Python, dynamic, website, mod_python, WSGI, Python, Django, tutorial" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li class="active"><a id="current" href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/filmstrip1.jpg" alt="box" />    <h2>Advanced Topics</h2>

<div class="menu">

<ul>
<li><a href="sys_module.php">Introduction into the sys module</a></li><li><a href="os_module_shell.php">Python and the Shell</a></li><li><a href="forking.php">Forks and Forking in Python</a></li><li><a href="threads.php">Introduction into Threads</a></li><li><a href="pipes.php">Pipe, Pipes and "99 Bottles of Beer"</a></li><li><a href="graphs_python.php">Graph Theory and Graphs in Python"</a></li><li><a href="pygraph.php">Graphs: PyGraph"</a></li><li><a href="networkx.php">Graphs: NetworkX"</a></li><li><a href="finite_state_machine.php">Finite State Machine in Python</a></li><li><a href="turing_machine.php">Turing Machine in Python</a></li><li><a href="numpy.php">NumPy Module</a></li><li><a href="matrix_arithmetic.php">Matrix Arithmetic</a></li><li><a href="linear_combinations.php">Linear Combinations</a></li><li><a href="text_classification_introduction.php">Introduction into Text Classification using Naive Bayes</a></li><li><a href="text_classification_python.php">Python Implementation of Text Classification</a></li><li><a href="towers_of_hanoi.php">Example for recursive Programming: Towers of Hanoi</a></li><li><a href="mastermind.php">Mastermind / Bulls and Cows</a></li><li><a href="dynamic_websites_wsgi.php">Creating dynamic websites with WSGI</a></li><li><a href="dynamic_websites.php">Dynamic websites with mod_python</a></li><li><a href="pylons.php">Dynamic websites with Pylons</a></li><li><a href="sql_python.php">Python, SQL, MySQL and SQLite</a></li><li><a href="python_scores.php">Python Scores</a></li></ul>

</div>

<p>
<br>
<hr>
<br>
<h3>Dynamic Websites</h3>
Not about the web neither on the dynamic websites, but it fits anyway:
<br><br>
<i>"Sometimes one creates a dynamic impression by saying something, and sometimes one creates as significant 
an impression by remaining silent."</i>
<br>
(Dalai Lama)
<br><br><br>
<img src="images/filmstrip.jpg" alt="A strip of film from the animated film Katsudō Shashin (1907)" />
<br><br>
<hr>
Supported by:<br>
<a href="http://www.bodenseo.com"><img style="width: 150px;" alt="Bodenseo, seminars and training courses"
		     src="images/bodenseo_python_training.gif"><br>Python seminars and trainings courses all over the world</a>
		     <br><br>		     
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
<h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

A computer would deserve to be called intelligent if it could deceive a human into believing that it was human.
<br>
Alan Turing
<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="dynamic_websites_wsgi.php">Creating dynamic websites with WSGI</a><br>
<LINK rel="prev" href="dynamic_websites_wsgi.php">Next Chapter: <a href="pylons.php">Dynamic websites with Pylons</a><br>
<LINK rel="next" href="pylons.php"></div>
<h2>Creating dynamic websites with Python with mod_python and WSGI</h2>

<h3>Introduction</h3>

<span style="color:red;background-color:light-grey;">
Please notice:
<br>Work on this topic is under process. (August 2014)
</span>
<br><br>

mod_python is an Apache HTTP Server module. It's purpose is to integrate Python programming 
with the Apache web server, or in other words a Python language binding for the Apache HTTP Server. 
The official website of mod_python says, that it possible to write "with mod_python web-based 
applications in Python that run many times faster than traditional CGI and will have access 
to advanced features such as ability to retain database connections and other data between hits 
and access to Apache internals." mod_python has been pronounced dead some years ago. So it didn't 
look to be a good idea to use it for new projects. It never died, it was only "sleeping". It came to
life again in 2013!

<h3>Python and mod_python</h3>

If we want to use Python on am Apache web server, we need the mod_python module for Apache.
This module provides a Python language binding so that we can integrate Python. It's a more 
efficient approach than using CGI, because CGI will start a new Python process for every 
request.
<br><br>
Mod_python consists of two components: The dynamically loadable module mod_python.so for 
Apache and the Python package mod_python. If you are using Debian or Ubuntu Linux, it's 
satisfying to install the package libapache2-mod-python for this purpose, assuming 
apache2 is already installed:
<br>
<pre>
sudo apt-get install libapache2-mod-python
</pre>
If apache2 has to be installed as well, do the following installation first:

<pre>
sudo apt-get install apache2
</pre>

You have to 
add the following lines into /etc/apache2/sites-enabled/000-default:
<br><br> 
<pre>
   AddHandler mod_python .py
 	PythonHandler mod_python.publisher
 	PythonDebug On
</pre>
It may look like this:

<VirtualHost *:80>
	ServerAdmin webmaster@localhost
	DocumentRoot /var/www/html

        AddHandler mod_python .py
 	PythonHandler mod_python.publisher
 	PythonDebug On
</VirtualHost>
</pre>

Now we have to restart the Apache server:

<pre>
sudo /etc/init.d/apache2 restart
</pre>

<h3>A Simple Dynamic Page with mod_python</h3>

We will create a subdirectory "tests" in the documents root of the Apache server. In case of Debian
and Ubuntu, this will be /var/www/html/. We save the following Python program as "hello.py" in the
previously created subdirectory:

<pre>
def index():
    return "Hello Python!"
</pre>

We have to start a browser and go to the location "localhost/tests/hello.py/index". It works with "localhost/tests/hello.py" as well. We get the following output in the browser window:
<br><br>
<img src="images/hello_python.png" alt="Hello Python, View in Browser" />
<br>
<br>
<h3>Another more "Useful" webpage</h3>

We save the following website as timesite.py. It will print out the current date and time, as well
as the timezone:

<pre>
import time
def index():
        html = """
&lt;html&gt;&lt;head&gt;
&lt;title&gt;mod_python.publisher first html page&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;h1&gt;This page was generated by mod_python.publisher&lt;/h1&gt;&lt;hr&gt;
The local time of this server is:  %s
&lt;br&gt;The timezone of this server is  :  %s
&lt;/body&gt;
&lt;/html&gt;
""" % (time.ctime(time.time()), time.timezone/3600)
        return html
&lt;/pre&gt;

</pre>
<br>
We get the following output:

<br><br>
<img src="images/timesite.png" alt="Time and Date plus Time Zone website" />
<br>
<br>

<h3>Another Page Name</h3>
So far we used index as the default website name. We can also define other functions and by 
doing so create websites with other names. We write the get_time function in following example and modify the index function:

<pre>

import time
def index():
        return "index().. nothing here, but you will find some info at get_time .."
def get_time():
        html = """
&lt;html&gt;&lt;head&gt;
&lt;title&gt;get_time function&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;h1&gt;get_time function&lt;/h1&gt;
&lt;hr&gt;
The local time of this server is:  %s &lt;br&gt;
The timezone of this server is  :  %s &lt;br&gt;
&lt;/body&gt;
&lt;/html&gt;""" % (time.ctime(time.time()), time.timezone/3600)
        return html

</pre>
<br><br>
Calling the location "http://localhost/tests/timesite2.py/get_time", returns the
following output:

<br><br>
<img src="images/timesite2_get_time.png" alt="Time and Date plus Time Zone website" />
<br>
<br>

Using the address "http://localhost/tests/timesite2.py/index", supplies this:
<br><br>
<img src="images/timesite2.png" alt="Time and Date plus Time Zone website" />
<br>
<br>

<h3>Using Forms</h3>

HTML forms are used to pass data to a server. We can do this with mod_python as well.
The following html form inside our Python program "form.py" contains fields for the first name, last name email address and radio buttons for the gender:
<br><br>
<pre>
def index():

	return """
&lt;html&gt;&lt;head&gt;
&lt;title&gt;Formular&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;FORM value="form" action="get_info" method="post"&gt;
  &lt;P&gt;
	&lt;LABEL for="firstname"&gt;First Name: &lt;/LABEL&gt;
	&lt;INPUT type="text" name="firstname"&gt;&lt;BR&gt;
	&lt;LABEL for="lastname"&gt;Last Name: &lt;/LABEL&gt;
	&lt;INPUT type="text" name="lastname"&gt;&lt;BR&gt;
	&lt;LABEL for="email"&gt;email: &lt;/LABEL&gt;
	&lt;INPUT type="text" name="email"&gt;&lt;BR&gt;
	&lt;INPUT type="radio" name="gender" value="Male"&gt;Male&lt;BR&gt;
	&lt;INPUT type="radio" name="gender" value="Female"&gt;Female&lt;BR&gt;
	&lt;INPUT type="submit" value="Send"&gt; &lt;INPUT type="reset"&gt;
  &lt;/P&gt;
&lt;/FORM&gt;
&lt;/body&gt;
&lt;/html&gt;
"""

def get_info(req):
	info = req.form
	first = info['firstname']
	last = info['lastname']
	email = info['email']
	gender = info['gender']
	return """
&lt;html&gt;&lt;head&gt;
&lt;title&gt;POST method using mod_python&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;h1&gt;POST Method using mod_python&lt;/h1&gt;
&lt;hr&gt;
Thanks for using our service:&lt;br&gt;
Your first name: %s &lt;br&gt;
Your last name: %s &lt;br&gt;
Your email address: %s &lt;br&gt;
Your gender: %s &lt;br&gt;
&lt;/body&gt;
&lt;/html&gt;
""" %(first, last.upper(), email, gender.lower())

</pre>

Calling the above program with the URL "http://localhost/tests/form.py/index" gives us the following
entry form:

<br><br>
<img src="images/form1.png" alt="Form for filling in data" />
<br>
<br>

To see the result page, i.e. the result of the function get_info, we have to push the "send" button:
<br><br>
<img src="images/form3.png" alt="Receiving Data from form" />
<br>
<br>

<h2>WSGI</h2>

<h3>What is WSGI?</h3>

WSGI is the Web Server Gateway Interface. It is a specification that describes how web servers
communicate with web applications. It is a framework for the Python. It was originally specified in 2003.
WSGI has become a standard for Python web application development. WSGI has been specified in 
<a href="http://legacy.python.org/dev/peps/pep-3333/">PEP 3333</a>. The abstract says "This document 
specifies a proposed standard interface between web servers and Python web applications or frameworks, 
to promote web application portability across a variety of web servers."







<br><br>


<div id="contextlinks">Previous Chapter: <a href="dynamic_websites_wsgi.php">Creating dynamic websites with WSGI</a><br>
<LINK rel="prev" href="dynamic_websites_wsgi.php">Next Chapter: <a href="pylons.php">Dynamic websites with Pylons</a><br>
<LINK rel="next" href="pylons.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
