<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: Passing Arguments</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="The passing of parameters and arguments in Python. Difference in Python to call by value and call by name." />
<meta name="Keywords" content="Python, Parameter, Parameters, Arguments, passing, references, call, value, reference" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/relay-race_small.jpg" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<hr>
<h3>Other Arguments</h3>
<i>"If you can't answer a man's arguments, all is not lost; you can still call him vile names."</i>
<br>
(Elbert Hubbard, writer, 1856 - 1915)
<br>
<i>"Discussion is an exchange of knowledge; an argument an exchange of ignorance."</i>
<br>
(Robert Quillen, American humorist and journalist, 1887 - 1948)
<br><br>
<hr>
<br>
Oscar Wilde lived before the age of computers, so he had no Python arguments in mind, when he said:
<br>
<i>"I dislike arguments of any kind. They are always vulgar, and often convincing."</i>
<h3>Function</h3>
<i>"Success is more a function of consistent common sense than it is of genius"</i>
<br>(An Wang, Computer engineer and inventor, 1920 - 1990)
<br>
<hr>
<br><br>

This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/parameter.php">Parameter�bergabe</a><h3>Python 2.7</h3>This tutorial deals with Python Version 2.7<br>This chapter from our course is available in a version for Python3: <a href="python3_passing_arguments.php">Passing Arguments</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>"It is easier to write an incorrect program than understand a correct one. "</i> (Alan Perlis)<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="memoization.php">Memoization and Decorators</a><br>
<LINK rel="prev" href="memoization.php">Next Chapter: <a href="namespaces.php">Namespaces</a><br>
<LINK rel="next" href="namespaces.php"></div>
<h2>Parameter Passing</h2>
<h3>"call by value" and "call by name"</h3>
<p>
<img class="imgright" src="images/relay-race.jpg" alt="Parameter�bergabe als Staffellauf" />
The most common evaluation strategy when passing arguments to a function has been call by value and call by reference:
<ul>
    <li><b>Call by Value</b>
    <br>
The most common strategy is the call-by-value evaluation, sometimes also called pass-by-value. This strategy is used in C and C++ for example.  In call-by-value, the argument expression is evaluated, and the result of this evaluation is bound to the corresponding variable in the function. 
So, if the expression is a variable, a local copy of its value will be used, i.e. the variable in the caller's scope will be unchanged when the function returns.

    <li><b>Call by Reference</b><br>
In call-by-reference evaluation, which is also known as pass-by-reference, a function gets an 
implicit reference  to the argument, rather than a copy of its value. As a consequence, the 
function can modify the argument, i.e. the value of the variable in the caller's scope can 
be changed. The advantage of call-by-reference consists in the advantage of greater time- 
and space-efficiency, because arguments do not need to be copied.
On the other hand this harbours the disadvantage that variables can be "accidentally" 
changed in a function call. So special care has to be taken to "protect" the values, which shouldn't be changed.
<br>Many programming language support call-by-reference, like C or C++, but Perl uses it as default.
</ul>
In ALGOL 60 and COBOL has been known a different concept, which was called call-by-name, which isn't used 
anymore in modern languages. 
</p>
<br>
<h3>and what about Python?</h3>
<img class="imgleft" src="imag
es/HumptyDumpty.jpg" alt="Humpty Dumpty" />
There are books which call the strategy of Python call-by-value and others call it call-by-reference. You may ask yourself, what is right.
<br><br>
Humpty Dumpty supplies the explanation:
<br><br>
<i>
--- "When I use a word," Humpty Dumpty said, in a rather a scornful tone, "it means just what I choose it to mean - neither more nor less."<br>
--- "The question is," said Alice, "whether you can make words mean so many different things."<br>
--- "The question is," said Humpty Dumpty, "which is to be master - that's all."
<br>
</i>Lewis Carroll, Through the Looking-Glass<br>
<br>
To come back to our initial question what is used in Python: The authors who call the mechanism call-by-value 
and those who call it call-by-reference are stretching the definitions until they fit.
<br>Correctly speaking, Python uses a mechanism, which is known as "Call-by-Object", sometimes also called 
"Call by Object Reference" or "Call by Sharing".<br>
<br><img class="imgright" src="images/parameter_uebergabe1.png" alt="Paramter�bergabe" />
If you pass immutable arguments like integers, strings or tuples to a function, the passing acts 
like call-by-value. The object reference is passed to the function parameters. They can't be 
changed within the function, because they can't be changed at all, 
i.e. they are immutable. 
It's different, if we pass mutable arguments. They are also passed by object reference, but they can be changed
in place in the function. If we pass a list to a function, we have to consider two cases: Elements of a list can be
changed in place, i.e. the list will be changed even in the caller's scope. If a new list is assigned to the name, 
the old list will not be affected, i.e. the list in the caller's scope will remain untouched.
<br><br>
First, let's have a look at the integer variables. The parameter inside of the function remains a reference to the
arguments variable, as long as the parameter is not changed. As soon as a new value will be assigned to it, Python
creates a separate local variable. The caller's variable will not be changed this way:
<br>
<pre>
def ref_demo(x):
    print "x=",x," id=",id(x)
    x=42
    print "x=",x," id=",id(x)
</pre>
<img class="imgright" src="images/parameter_uebergabe2.png" alt="Paramter�bergabe" />
In the example above, we used the id() function, which takes an object as a parameter. 
id(obj) returns the "identity" of the object "obj". This identity, the return value of
the function, is an integer which is unique and constant for this object during its lifetime.
Two different objects with non-overlapping lifetimes may have the same id() value.
<br><br>
If you call the function ref_demo() - like we do in the green block further down - 
we can check with the id() function what happens to x.
We can see that in the main scope, x has the identity 41902552. In the first print statement
of the ref_demo() function, the x from the main scope is used, because we can see that we
get the same identity. After we have assigned the value 42 to x, x gets a new identity 41903752, i.e. 
a separate memory location from the global x. So, when we are back in the main scope x has still
the original value 9.
<br><br>
This means, that Python initially behaves like call-by-reference, but as soon as we are changing the
value of such a variable, Python "switches" to call-by-value.
<pre>
>>> x = 9
>>> id(x)
41902552
>>> ref_demo(x)
x= 9  id= 41902552
x= 42  id= 41903752
>>> id(x)
41902552
>>> 
</pre>
<br>
<h3>Side effects</h3>
A function is said to have a side effect if, in addition to producing a value, it modifies the caller's environment
in other ways. For example, a function might modify a global or static variable, modify one of its arguments, 
raise an exception, write data to a display or file and so on. 
<br><br>
In many cases these side effects are wanted, i.e. they are part of the functions specification. But in other cases, 
they are not wanted , they are hidden side effects. In this chapter we are only interested in the side effects,
which change global variables, which have been passed as arguments to a function.
<br>
Let's assume, we are passing a list to a function. We expect, that the 
function is not changing this list. First let's have a look at a function
which has no side effects. As a new list is assigned to the parameter list in func1(), 
a new memory location is created for list and list becomes a local variable.
<pre>
>>> def func1(list):
...     print list
...     list = [47,11]
...     print list
... 
>>> fib = [0,1,1,2,3,5,8]
>>> func1(fib)
[0, 1, 1, 2, 3, 5, 8]
[47, 11]
>>> print fib
[0, 1, 1, 2, 3, 5, 8]
>>> 
</pre>
This changes drastically, if we include something in the list by using +=.
To show this, we have a different function func2() in the following example:

<pre>
>>> def func2(list):
...     print list
...     list += [47,11]
...     print list
... 
>>> fib = [0,1,1,2,3,5,8]
>>> func2(fib)
[0, 1, 1, 2, 3, 5, 8]
[0, 1, 1, 2, 3, 5, 8, 47, 11]
>>> print fib
[0, 1, 1, 2, 3, 5, 8, 47, 11]
>>> 
</pre>

The user of the function can prevent this by passing a copy to the function. 
In this case a shallow copy is sufficient:

<pre>
>>> def func2(list):
...     print list
...     list += [47,11]
...     print list
... 
>>> fib = [0,1,1,2,3,5,8]
>>> func2(fib[:])
[0, 1, 1, 2, 3, 5, 8]
[0, 1, 1, 2, 3, 5, 8, 47, 11]
>>> print fib
[0, 1, 1, 2, 3, 5, 8]
>>> 
</pre>
<br>
<h3>Command Line Arguments</h3>
It's possible to write Python scripts using command line arguments. If you call
a Python script from a shell, the arguments are placed after the script name. 
The arguments are separated by spaces. Inside of the script these argumetns are 
accessible through the list variable sys.argv. The name of the script is included
in this list sys.argv[0]. sys.argv[1] contains the first parameter, sys.argv[2] the
second and so on. 
<br>
The following script (arguments.py) prints all arguments:
<br>
<pre>
 # Module sys has to be imported:
import sys                

# Iteration over all arguments:
for eachArg in sys.argv:   
        print eachArg
</pre>
Example call to this script:
<pre>
python argumente.py python course for beginners
</pre>
This call creates the following output:
<pre>
argumente.py
python
course
for
beginners
</pre>
<br>
<h3>Variable Length of Parameters</h3>
We will introduce now functions, which can take an arbitrary number of arguments.
Those who have some programming background in C or C++ know this from the varargs feature 
of these languages. The asterisk "*" is used in Python to define a variable number
of arguments. The asterisk character has to precede a variable identifier in the 
parameter list. 

<pre>
>>> def varpafu(*x): print(x)
... 
>>> varpafu()
()
>>> varpafu(34,"Do you like Python?", "Of course")
(34, 'Do you like Python?', 'Of course')
>>> 
</pre>

We learn from the previous example, that the arguments passed to the function call of 
varpafu() are collected in a tuple, which can be accessed as a "normal" variable x
within the body of the function. If the function is called without any arguments, the
value of x is an empty tuple.
<br><br>
Sometimes, it's necessary to use positional parameters followed by an arbitrary number of
parameters in a function definition. This is possible, but the positional parameters always
have to precede the arbitrary parameters. In the following example, we have a positional
parameter "city", - the main location, - which always have to be given, followed by an arbitrary
number of other locations:
<br>

<pre>
>>> def locations(city, *other_cities): print(city, other_cities)
... 
>>> locations("Paris")
('Paris', ())
>>> locations("Paris", "Strasbourg", "Lyon", "Dijon", "Bordeaux", "Marseille")
('Paris', ('Strasbourg', 'Lyon', 'Dijon', 'Bordeaux', 'Marseille'))
>>> 
</pre>

<h4>Exercise</h4>
Write a function which calculates the arithmetic mean of a variable number of values.

<h4>Solution</h4>

<pre>
def arithmetic_mean(x, *l):
    """ The function calculates the arithmetic mean of a non-empty
        arbitrary number of numbers """
    sum = x
    for i in l:
        sum += i

    return sum / (1.0 + len(l))
</pre>

You might ask yourself, why we used both a positional parameter "x" and the variable 
parameter "*l" in our function definition. We could have only used *l to contain all
our numbers. The idea is, that we wanted to enforce, that we always have a non-empty list
of numbers. This is necessary to prevent a division by zero error, because the average
of a non-empty list of numbers is not defined. 
<br><br>
In the following interactive Python session, we can learn how to use this function.
We assume that the function arithmetic_mean is saved in a file called statistics.py.

<pre>
>>> from statistics import arithmetic_mean
>>> arithmetic_mean(4,7,9)
6.666666666666667
>>> arithmetic_mean(4,7,9,45,-3.7,99)
26.71666666666667
</pre>

This works fine, but there is a catch. What if somebody wants to call the function
with a list, instead of a variable number of numbers, as we have shown above? We can
see in the following, that we raise an error, as most hopefully, you might expect:

<pre>
>>> l = [4,7,9,45,-3.7,99]
>>> arithmetic_mean(l)
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
  File "statistics.py", line 8, in arithmetic_mean
    return sum / (1.0 + len(l))
TypeError: unsupported operand type(s) for /: 'list' and 'float'
</pre>

The rescue is using another asterisk:

<pre>
>>> arithmetic_mean(*l)
26.71666666666667
>>> 
</pre>
<br><br>
<h3>* in Function Calls</h3>
A * can appear in function calls as well, as we have just seen in the previous exercise:
The semantics is in this case "inverse" to a star in a function definition. An argument 
will be unpacked and not packed. In other words, the elements of the list or tuple are
singularized: 

<pre>
>>> def f(x,y,z):
...     print(x,y,z)
... 
>>> p = (47,11,12)
>>> f(*p)
(47, 11, 12)
</pre>

There is hardly any need to mention that this way of calling our function
is more comfortable the the following one:

<pre>
>>> f(p[0],p[1],p[2])
(47, 11, 12)
>>> 
</pre>

Additionally to being less comfortable, the previous call (f(p[0],p[1],p[2])) 
doesn't work in the general case, i.e. lists of unknown lengths. "Unknown" mean,
that the length is only known at runtime and not when we are writing the script.

<h3>Arbitrary Keyword Parameters</h3>
There is also a mechanism for an arbitrary number of keyword parameters.
To do this, we use the double asterisk "**" notation:

<pre>
>>> def f(**args):
...     print(args)
... 
>>> f()
{}
>>> f(de="Germnan",en="English",fr="French")
{'fr': 'French', 'de': 'Germnan', 'en': 'English'}
>>> 
</pre>

<h3>Double Asterisk in Function Calls</h3>
The following example demonstrates the usage of  ** in a
function call:

<pre>
>>> def f(a,b,x,y):
...     print(a,b,x,y)
...
>>> d = {'a':'append', 'b':'block','x':'extract','y':'yes'}
>>> f(**d)
('append', 'block', 'extract', 'yes')
</pre>
and now in combination with *: 
<pre>
>>> t = (47,11)
>>> d = {'x':'extract','y':'yes'}
>>> f(*t, **d)
(47, 11, 'extract', 'yes')
>>> 
</pre>


<br><br>

<div id="contextlinks">Previous Chapter: <a href="memoization.php">Memoization and Decorators</a><br>
<LINK rel="prev" href="memoization.php">Next Chapter: <a href="namespaces.php">Namespaces</a><br>
<LINK rel="next" href="namespaces.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
