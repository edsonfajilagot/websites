<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: Sets and Frozen Sets</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Detailled introduction on sets and frozen sets in Python with examples." />
<meta name="Keywords" content="Python, course, sets, frozen sets" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/blocks100.jpg" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<h3>Russell's paradox</h3>
The set of all sets that are not members of themselves". This is a contradiction 
since this set must be both a member of itself, and not a member of itself. 
<hr>
<br>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo,
Python courses"
		     src="images/bodenseo_python_training.gif"><br>Python Courses and In-House courses</a>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/sets_mengen.php">Mengen</a><h3>Python 2.7</h3>This tutorial deals with Python Version 2.7<br>This chapter from our course is available in a version for Python3: <a href="python3_sets_frozensets.php">Sets and Frozen Sets</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>"I think it is inevitable that people program poorly. Training will not 
substantially help matters. We have to learn to live with it."</i>
 (Alan Perlis)

<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="dictionaries.php">Dictionaries</a><br>
<LINK rel="prev" href="dictionaries.php">Next Chapter: <a href="deep_copy.php">Shallow and Deep Copy</a><br>
<LINK rel="next" href="deep_copy.php"></div>
<h2>Sets and Frozensets</h2>
<br><br>
<p>
<h3>Introduction</h3>
<img class="imgright" src="images/sets_with_notations.png" alt="Graphical Depiction of Sets as Circles" />
The philosopher Wittgenstein didn't like the set theory and complained mathematics is "ridden 
through and through with the pernicious idioms of set theory,"
He dismissed the set theory as "utter nonsense", as being "laughable" and "wrong". His criticism
appeared years after the death of the German mathematician Georg Cantor, the founder of the set
theory.
<br><br>
Cantor defined a set at the beginning of his "Beitr�ge zur Begr�ndung der transfiniten 
Mengenlehre":
<br>
<i>"A set is a gathering together into a whole of definite, distinct objects of our perception
 and of our thought - which are called elements of the set."</i>
Nowadays, we can say in "plain" English: A set is a well defined collection of objects.
<br><br>
The elements or members of a set can be anything: numbers, characters, words, names, 
letters of the alphabet, even other sets, and so on. 
Sets are usually denoted with capital letters. This is not the exact methematical
definition, but it is good enough for the following.
<br><br>
<h3>Sets in Python</h3>
The data tpye "set", which is a collection type, has been part of Python since 
version 2.4. A set contains an unordered collection of unique and immutable objects.
The set data type is, as the name implies, a Python implementation of the sets as
they are known from mathematics. This explains, why sets unlike lists or tuples can't 
have multiple occurrences of the same element.
<br>
<h3>Creating Sets</h3>    
If we want to create a set, we can call the built-in set function with a sequence or
another iterable object.

<br><br>
In the following example, a string is singularised into its characters to build the resulting
set x: 

<pre>
>>> x = set("A Python Tutorial")
>>> x
set(['A', ' ', 'i', 'h', 'l', 'o', 'n', 'P', 'r', 'u', 't', 'a', 'y', 'T'])
>>> type(x)
&lt;type 'set'&gt;
>>> 
</pre>
<br><br>
We can pass a list to the built-in set function, as we can see in the following:
<br><br>
<pre>
>>> x = set(["Perl", "Python", "Java"])
>>> x
set(['Python', 'Java', 'Perl'])
>>> 
</pre>
<br>
<br>
We want to show now, what happens, if we pass a tuple with reappearing elements to the
set function - in our
example the city "Paris":
<br><br>
<pre>
>>> cities = set(("Paris", "Lyon", "London","Berlin","Paris","Birmingham"))
>>> cities
set(['Paris', 'Birmingham', 'Lyon', 'London', 'Berlin'])
>>> 
</pre>
<br><br>
As we have expected, no doublets are in the resulting set of cities.

<h3>Immutable Sets</h3>
Sets are implemented in a way, which doesn't allow mutable objects. The following
example demonstrates, that we cannot include for example lists as elements:

<pre>
>>> cities = set((("Python","Perl"), ("Paris", "Berlin", "London")))
>>> cities = set((["Python","Perl"], ["Paris", "Berlin", "London"]))
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
TypeError: unhashable type: 'list'
>>> 
</pre>
<br><br>
<h3>Frozensets</h3>
Though sets can't contain mutable objects, sets are mutable:
<br>
<pre>
>>> cities = set(["Frankfurt", "Basel","Freiburg"])
>>> cities.add("Strasbourg")
>>> cities
set(['Freiburg', 'Basel', 'Frankfurt', 'Strasbourg'])
>>> 
</pre> 
<br>
Frozensets are like sets except, that they cannot be changed, i.e. they are immutable:
<pre>
>>> cities = frozenset(["Frankfurt", "Basel","Freiburg"])
>>> cities.add("Strasbourg")
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
AttributeError: 'frozenset' object has no attribute 'add'
>>> 
</pre>
<br><br>
<h3>Simplified Notation</h3>
We can define sets (since Python2.6) without using the built-in set function. We can use
curly braces instead:
<br>
<pre>
>>> adjectives = {"cheap","expensive","inexpensive","economical"}
>>> adjectives
set(['inexpensive', 'cheap', 'expensive', 'economical'])
>>> 
</pre>
<br>
<h3>Set Operations</h3>

<dl>
	<dt><h4>add(element)</h4></dt>
	<dd>A method which adds an element, which has to be immutable, to a set.
<pre>
>>> colours = {"red","green"}
>>> colours.add("yellow")
>>> colours
set(['green', 'yellow', 'red'])
>>> colours.add(["black","white"])
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
TypeError: unhashable type: 'list'
>>> 
</pre>	
Of course, an element will only be added, if it is not already contained in the set. If it is
already contained, the method call has no effect.
	</dd>

	<dt><h4>clear()</h4></dt>
	<dd>All elements will removed from a set.
<pre>
>>> cities = {"Stuttgart", "Konstanz", "Freiburg"}
>>> cities.clear()
>>> cities
set([])
>>> 
</pre>	
	</dd>
	
   <dt><h4>copy</h4></dt>
	<dd>
	Creates a shallow copy, which is returned.
	<pre>
>>> more_cities = {"Winterthur","Schaffhausen","St. Gallen"}
>>> cities_backup = more_cities.copy()
>>> more_cities.clear()
>>> cities_backup
set(['St. Gallen', 'Winterthur', 'Schaffhausen'])
>>> 
</pre>
<br>
Just in case, you might think, an assignment might be enough:
<pre>
>>> more_cities = {"Winterthur","Schaffhausen","St. Gallen"}
>>> cities_backup = more_cities
>>> more_cities.clear()
>>> cities_backup
set([])
>>> 
	</pre>	
The assignment "cities_backup = more_cities" just creates a pointer, i.e. another name,
to the same data structure.
	</dd>

	<dt><h4>difference()</h4></dt>
	<dd>
This method returns the difference of two or more sets as a new set.	
	<pre>
>>> x = {"a","b","c","d","e"}
>>> y = {"b","c"}
>>> z = {"c","d"}
>>> x.difference(y)
set(['a', 'e', 'd'])
>>> x.difference(y).difference(z)
set(['a', 'e'])
>>> 
</pre>
Instead of using the method difference, we can use the operator "-":
<pre>
>>> x - y
set(['a', 'e', 'd'])
>>> x - y - z
set(['a', 'e'])
>>> 	
	</pre>
	</dd>
	
	<dt><h4>difference_update()</h4></dt>
	<dd>
	The method difference_update removes all elements of another set from this set.
   x.difference_update() is the same as "x = x - y"	

	<pre>
>>> x = {"a","b","c","d","e"}
>>> y = {"b","c"}
>>> x.difference_update(y)
>>> 
>>> x = {"a","b","c","d","e"}
>>> y = {"b","c"}
>>> x = x - y
>>> x
set(['a', 'e', 'd'])
>>> 	
	</pre>
	</dd>

	<dt><h4>discard(el)</h4></dt>
	<dd>An element el will be removed from the set, if it is contained in the set.
	If el is not a member of the set, nothing will be done.
	<pre>
>>> x = {"a","b","c","d","e"}
>>> x.discard("a")
>>> x
set(['c', 'b', 'e', 'd'])
>>> x.discard("z")
>>> x
set(['c', 'b', 'e', 'd'])
>>> 	
	</pre>	
	</dd>
	
	<dt><h4>remove(el)</h4></dt>
	<dd>works like discard(), but if el is not a member of the set, a KeyError will be
	raised.
	<pre>
	>>> x = {"a","b","c","d","e"}
>>> x.remove("a")
>>> x
set(['c', 'b', 'e', 'd'])
>>> x.remove("z")
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
KeyError: 'z'
>>> 	
	</pre>	
	 </dd>
	
	<dt><h4>intersection(s)</h4></dt>
	<dd>
	Returns the intersection of the instance set and the set s as a new set. In other
	words: A set with all the elements which are contained in both sets is returned.
<pre>
>>> x = {"a","b","c","d","e"}
>>> y = {"c","d","e","f","g"}
>>> x.intersection(y)
set(['c', 'e', 'd'])
>>> 
</pre>	
This can be abbreviated with the ampersand operator "&":
<pre>
>>> x = {"a","b","c","d","e"}
>>> y = {"c","d","e","f","g"}
>>> x.intersection(y)
set(['c', 'e', 'd'])
>>> 
>>> x = {"a","b","c","d","e"}
>>> y = {"c","d","e","f","g"}
>>> x  & y
set(['c', 'e', 'd'])
>>> 
</pre>	
	</dd>
	
	<dt><h4>isdisjoint()</h4></dt>
	<dd>This method returns True if two sets have a null intersection.	
	</dd>
	
	<dt><h4>issubset()</h4></dt>
	<dd>
	x.issubset(y) returns True, if x is a subset of y. "<=" is an abbreviation for "Subset of"	and ">="
	for "superset of" 
<br>"<" is used to check if a set is a proper subset of a set.
	<pre>
>>> x = {"a","b","c","d","e"}
>>> y = {"c","d"}
>>> x.issubset(y)
False
>>> y.issubset(x)
True
>>> x < y
False
>>> y < x # y is a proper subset of x
True
>>> x < x # a set can never be a proper subset of oneself.
False
>>> x <= x 
True
>>> 
	</pre>
	</dd>

	<dt><h4>issuperset()</h4></dt>
	<dd>
x.issuperset(y) returns True, if x is a superset of y. ">=" is an abbreviation for "issuperset of" 
<br>">" is used to check if a set is a proper superset of a set.
<br>
<pre>
>>> x = {"a","b","c","d","e"}
>>> y = {"c","d"}
>>> x.issuperset(y)
True
>>> x > y
True
>>> x >= y
True
>>> x >= x
True
>>> x > x
False
>>> x.issuperset(x)
True
>>> 
</pre>		


</dd>
	
	<dt><h4>pop()</h4></dt>
	<dd>pop() removes and returns an arbitrary set element. The method raises a KeyError
	if the set is empty

<pre>
>>> x = {"a","b","c","d","e"}
>>> x.pop()
'a'
>>> x.pop()
'c'
</pre>	
	
	</dd>

</dl>

<br><br>
<div id="contextlinks">Previous Chapter: <a href="dictionaries.php">Dictionaries</a><br>
<LINK rel="prev" href="dictionaries.php">Next Chapter: <a href="deep_copy.php">Shallow and Deep Copy</a><br>
<LINK rel="next" href="deep_copy.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
