<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: Conditional Statements</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="The chapter about conditional statements in our course on Python." />
<meta name="Keywords" content="Python, course, conditionals, conditional statement, if statement, example, examples" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/arrow.jpg" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<hr><br> 
 <i>"I think that we're now inescapably in an age where the large statements of mathematics are 
 so complex that we may never know for sure whether they're true or false."
</i><br>
Keith Devlin, British mathematician
<br>
<hr>
<i>"Truth does not need argument, agreement, theories or beliefs. 
There is only one test for it and that is to ask yourself 'Is the 
statement true  or false in my experience?"</i>
Barry Long, Australian author and teacher
<br>
<br>
<hr>
<br>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo,
Linux, courses and seminars"
		     src="images/bodenseo_python_training.gif"><br>Python Courses and Seminars</a>
<br><br>
Please see also <a href="http://www.python-training-courses.com">Python Training International</a>

<hr>
We also like to thank Denise Mitchinson for providing the tylesheet of this website.<br> <a href="http://www.mitchinson.net"> www.mitchinson.net </a>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/bedingte_anweisungen.php">bedingte Anweisungen</a><h3>Python 2.7</h3>This tutorial deals with Python Version 2.7<br>This chapter from our course is available in a version for Python3: <a href="python3_conditional_statements.php">Conditional Statements</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>We can only see a short distance ahead, but we can see plenty there that needs to be done.</i>
<br>Alan Turing
<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="input.php">input and raw_input via the keyboard</a><br>
<LINK rel="prev" href="input.php">Next Chapter: <a href="loops.php">While Loops</a><br>
<LINK rel="next" href="loops.php"></div>
<h2>Conditional Statements</h2>
<h3>Some decisions are inevitable</h3>
<p>
<img class="imgleft" src="images/decision_300.jpg" alt="inevitable decisions" />
Under certain conditions some decisions are sometimes in normal live inevitable, 
as we can can see in our photo.
It's the same for every program, which has to solve some useful problem.
There is hardly a way to program without having branches in the flow of code. 
<br><br>
In programming and scripting languages, conditional statements or conditional 
constructs are used to perform different computations or actions depending on 
whether a condition evaluates to true or false. (Please note that true and false are always
written as True and False in Python.) 
<br><br>
The condition usually uses comparisons and arithmetic expressions with variables.  
These expressions are evaluated to the Boolean 
values True or False. The statements for the decision taking are called conditional 
statements, alternatively they are also known as conditional expressions or 
conditional constructs.
<br><br>
The if-then construct (sometimes called if-then-else) is common across many programming 
languages, but the syntax varies from language to language.

</p>


<h3>The if Statement</h3>
      <p>
      The general form of the if statement in Python looks like this:

<pre>
if condition_1:
    statement_block_1
elif condition_2:
    statement_block_2
else:
    statement_block_3
</pre>
If the condition "condition_1" is True, the statements in the block statement_block_1 will
be executed. If not, condition_2 will be executed. If condition_2 evaluates to True, statement_block_2
will be executed, if condition_2 is False, the statements in statement_block_3 will be executed.

<br>
</p>
<h3>Example Dog Years</h3>
<p>
It's a generally accepted belief, to assume, that one year in the life a dog corresponds to
seven years in the life of a human being. But apparently there are other more subtle methods to 
calculate this haunting problem, haunting at least for some dog owners.
<br>
Another subtler method works like this:
<ul>
<li>A one year old dog roughly corresponds to a fourteen year old child
<li>A dog who is two years old corresponds to a 22 year old human
<li>Every further dog year corresponds to five human years 
</ul>
The following Python script implements this "dog years algorithm": 
<pre>
age = input("Age of the dog: ")
print
if age < 0:
	print "This can hardly be true!"
elif age == 1:
	print "about 14 human years"
elif age == 2:
	print "about 22 human years"
elif age > 2:
	human = 22 + (age -2)*5
	print "Human years: ", human

### 
raw_input('press Return>')
  </pre>
There is one drawback to the script. I works only for integers, i.e. full years. 
</p>

<h3>True or False</h3>
<p>
Unfortunately it is not as easy in real life as it is in Python to differentiate between 
true and false:

<br>
The following objects are evaluated by Python as False: 
<ul>
<li>numerical zero values (0, 0L, 0.0, 0.0+0.0j), 
<li>the Boolean value False, 
<li>empty strings, 
<li>empty lists and empty tuples, 
<li>empty dictionaries.
<li>plus the special value None.   
</ul>
<br>All other values are considered to be True. 
</p>
<h3>Abbreviated IF statement</h3>
<p>
C programmers usually know the following abbreviated notation for the if construct: 
<pre>
max = (a > b) ? a : b; 
</pre>
This is an abbreviation for the following C code:
<pre>
if (a > b)
   max=a;
else
   max=b;  
  </pre>
C programmers have to get used to a different notation in Python:
<pre>
max = a if (a > b) else b;
  </pre>
</p>
<h3>German tax calculator in Python</h3>

Taxable income (zvE) has to be assigned to a tarif zone.<sup>1</sup>
After this the amount of tax (StB) (for so-called "Einzelveranlagung")
can be calculated with the corresponding formula:

<ul>
  <li>First zone (Grundfreibetrag): up to 8004,- &euro; no tax has to be paid
  <li>Second zone: zvE between 8.005 &euro;  and 13.469 &euro; <br>
				  StB = (912,17 * y + 1400)*y<br>
     with:<br>
      y = (zvE - 8004) / 10000
  <li>Third Zone:  zvE between 13470 &euro;  and 52881 &euro; <br>
				  StB = (228,74 * z + 2397)*z<br>
      with:<br>
      z = (zvE - 13469) / 10000
  <li>Fourth Zone: zvE betwenn 52882 &euro;  and 250730 &euro; <br>
				  StB = 0,42 * zvE - 8172			 
  <li>Fifth Zone: zvE starting with 250731 &euro; <br>
				  StB = 0,44 * zvE - 15694			 </ul>



<br>
A Python function calculating the tax from the income tarif looks 
like this: (No limit or warranty!!!)
 <pre>
def taxes(income):
    """Calculation of taxes to be paid for a taxable income x"""
    if income <= 8004:
        tax = 0
    elif income <= 13469:
        y = (income -8004.0)/10000.0
        tax = (912.17 * y + 1400)*y
    elif income <= 52881:
        z = (income -13469.0)/10000.0
        tax = (228.74 * z +2397.0)*z +1038.0
    elif income <= 250730:
        tax = income * 0.42 - 8172.0
    else:
        tax = income * 0.44 - 15694
    return tax

</pre>
If "Ehegattensplitting" applies, the amount can be calculated like this:
<pre>
taxes = 2 * taxes(income / 2)
</pre>
<br>
<h3>Footnotes</h3>
<sup>1</sup> Corresponding German legislative text:<br>
Einkommensteuergesetz, � 52 Anwendungsvorschriften
<br>
(41) &sect; 32a Absatz 1 ist ab dem Veranlagungszeitraum 2010 in der
folgenden Fassung anzuwenden:<br>
&nbsp;"(1) <sup>1</sup>Die tarifliche Einkommensteuer
bemisst sich nach dem zu versteuernden Einkommen. <sup class="Rec">2</sup>Sie
betr&auml;gt vorbehaltlich der &sect;&sect; 32b, 32d, 34, 34a, 34b und
34c jeweils in Euro f&uuml;r zu versteuernde Einkommen

<table>
<tr>
<td style="vertical-align: top;">1.</td>
<td style="vertical-align: top;"><div>bis 8&nbsp;004 Euro (Grundfreibetrag):</div>
<div>0;</div></td>
</tr>
<tr>
<td style="vertical-align: top;">2.</td>
<td style="vertical-align: top;"><div>von 8&nbsp;005 Euro bis 13&nbsp;469 Euro:</div>
<div>(912,17 * y + 1&nbsp;400) * y;</div></td>
</tr>
<tr>
<td style="vertical-align: top;">3.</td>
<td style="vertical-align: top;"><div>von 13&nbsp;470 Euro bis 52&nbsp;881 Euro:</div>
<div>(228,74 * z + 2&nbsp;397) * z + 1&nbsp;038;</div></td>
</tr>
<tr>
<td style="vertical-align: top;">4.</td>
<td style="vertical-align: top;"><div>von 52&nbsp;882 Euro bis 250&nbsp;730 Euro:</div>
<div>0,42 * x - 8&nbsp;172;</div></td>
</tr>
<tr>
<td style="vertical-align: top;">5.</td>
<td style="vertical-align: top;"><div>von 250&nbsp;731 Euro an:</div>
<div>0,45 * x - 15&nbsp;694.</div></td>
</tr>
</table>

<sup>3</sup>"y" ist ein Zehntausendstel des 8&nbsp;004 Euro
&uuml;bersteigenden Teils des auf einen vollen Euro-Betrag abgerundeten
zu versteuernden Einkommens. <sup>4</sup>"z" ist ein
Zehntausendstel des 13&nbsp;469 Euro &uuml;bersteigenden Teils des auf
einen vollen Euro-Betrag abgerundeten zu versteuernden Einkommens. 
<sup>5</sup>"x" ist das auf einen vollen Euro-Betrag
abgerundete zu versteuernde Einkommen. <sup>6</sup>Der
sich ergebende Steuerbetrag ist auf den n&auml;chsten vollen
Euro-Betrag abzurunden."
<br><br>
<div id="contextlinks">Previous Chapter: <a href="input.php">input and raw_input via the keyboard</a><br>
<LINK rel="prev" href="input.php">Next Chapter: <a href="loops.php">While Loops</a><br>
<LINK rel="next" href="loops.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
