<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Memoization and Decorators</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction into memoization techniques using Fibonacci sequences as an example." />
<meta name="Keywords" content="Python, python3, recursive, recursion, function, memoization, memoisation, techniques" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/brain_small.jpg" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<hr>
<h3>Memory</h3>
Some funny or interesting things about memory, i.e. "our" memory not the one from the computer:
<br>
<i>"Why is it that our memory is good enough to retain the least triviality that happens to us, 
and yet not good enough to recollect how often we have told it to the same person?"</i>
<br>(Francois de La Rochefoucauld, 1613 - 1680)
<br><br>
<i>"Nothing fixes a thing so intensely in the memory as the wish to forget it."</i>
(Michel de Montaigne, 1533 - 1592)
<br><br>
<i>"It's a poor sort of memory that only works backward."</i> (Lewis Carrol, 1879 - 1898)
<br><br>
<h3>Bachet</h3>
Claude Gaspard Bachet de M�ziriac was a French Jesuit and a poet, scholar and mathematician. 
He was born at Bourg in 1581, and died in 1638. He wrote the 
Probl�mes plaisants, of which the first edition was issued in 1612, a second and enlarged 
edition was brought out in 1624; this contains an interesting collection of arithmetical 
tricks and questions.
<br><br>
In his collection of "Amusing and Delightful Number Problems" ("Probl�mes plaisants & d�lectables qui se 
font par les nombres") he had the puzzle (number154), which we use in our main text:
<br>
"Etant donn�e telle quantit� qu'on voudra pesant un nombre de livres depuis 1 jusques � 40 
inclusivement (sans toutefois admettre les fractions), on demande combien de poids pour le 
moins il faudrait employer � cet effet"
<br>
(English translation: "We are looking for the minimum number of weights to be used on a scale to weigh an 
arbitrary number of pounds from 1 to 40 inclusive, without admitting fractions.)

<hr>
<br>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo,
Linux, courses and seminars"
		     src="images/bodenseo_python_training.gif"><br>Linux and Python Courses and Seminars</a>
<br>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_memoisation.php">Memoisation und Dekorateure</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="memoization.php">Memoization and Decorators in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="memoization.php">Memoization and Decorators in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_tests.php">Tests, DocTests, UnitTests</a><br>
<LINK rel="prev" href="python3_tests.php">Next Chapter: <a href="python3_passing_arguments.php">Parameter Passing in Functions</a><br>
<LINK rel="next" href="python3_passing_arguments.php"></div>
<h2>Memoization and Decorators</h2>
<br>
<h3>Definition of Memoization</h3>
<img class="imgright" src="images/brain.jpg" alt="Brain" />
The term "memoization" was introduced by Donald Michie in the year 1968. It's based on the Latin word memorandum, meaning "to be remembered". It's not a misspelling of the word memorization, though in a way it has something in common. Memoisation is a technique used in computing to speed up programs. This is accomplished by memorizing the calculation results of processed input such as the
results of function calls. If the same input or a function call with the same parameters is used, the previously stored results can be used again and unnecessary calculation are avoided. In many cases a simple array is used for storing the results, but lots of other structures can be used as well, such as associative arrays, called hashes in Perl or dictionaries in Python.
<br><br>
Memoization can be explicitly programmed by the programmer, but some programming languages like Python provide mechanisms to automatically memoize functions.

<br><br>

<h3>Memoization with Function Decorators</h3>
In our previous chapter about <a href="python3_recursive_functions.php">recursive functions</a>, we worked out an iterative and a recursive version to calculate the Fibonacci numbers. We have shown that a direct implementation of the mathematical definition into
a recursive function like the following has an exponential runtime behaviour:
<br>
<pre>
def fib(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib(n-1) + fib(n-2)
</pre>
<br>
We also presented a way to improve the runtime behaviour of the recursive version by adding a 
dictionary to memorize previously calculated values of the function. This is an example of 
explicitly using the technque of memoization, but we didn't call it like this. 
The disadvantage of this method is, that the clarity and the beauty of the original 
recursive implementation is lost. 
<br><br>
The "problem" is, that we changed the code of the recursive fib function. The following code 
doesn't change our fib function, so that its clarity and legibility isn't touched. To this
purpose, we use function which we call memoize.
memoize() takes a function as an argument. The function memoize uses a dictionary "memo" 
to store the function results. Though the variable "memo" as well as the function "f" are 
local to memoize, they captured by a closure through the helper function which is returned 
as a reference by memoize(). So, the call memoize(fib) returns a reference to the helper() 
which is doing what fib() would have done plus a wrapper which is saving the results, which 
are still not stored, in the memo dictionary and is preventing recalculation of results, 
which are already in memo.  


<br><br>
<pre>
def memoize(f):
    memo = {}
    def helper(x):
        if x not in memo:            
            memo[x] = f(x)
        return memo[x]
    return helper
    

def fib(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib(n-1) + fib(n-2)

fib = memoize(fib)

print(fib(40))
</pre>

<br><br>
Now we come to what's called the decorator.
Let's look at the line in our code were we assign memoize to fib:
<pre>fib = memoize(fib)</pre>
One says, that the fib function is decorated by the the memoize() function.
<br>
<h3>Memoize as a Class</h3>
We can encapsulate the caching of the results in a class as well, as you can see in the 
following example:

<pre>
class Memoize:
    def __init__(self, fn):
        self.fn = fn
        self.memo = {}
    def __call__(self, *args):
        if args not in self.memo:
				self.memo[args] = self.fn(*args)
        return self.memo[args]
</pre>
<br>
As we are using a dictionary, we can't use mutable arguments, i.e. the arguments have 
to be immutable.

<br><br>
<h3>Decorators in Python</h3>
A decorator in Python is a callable Python object that is used to modify a function, 
method or class definition. The original object, the one which is going to be modified, 
is passed to a decorator as an argument. The decorator returns a modified object, e.g. a 
modified function, which is bound to the name used in the definition. 
Python decorators have a similar syntax than Java annotations.
The decorator syntax in Python can be seen as pure syntactic sugar, using @ as the keyword.
<br><br>
<h3>Example: Using a Decorator for Memoization</h3>
We already had used a decorator without saying so. The memoize function in the example 
at the beginning of this chapter is a decorator. We used it to memorize the results from 
the fib function. 
<br><br>
What we hadn't used was the special decorator syntax of Python, i.e. the at character "@"
<br>
Instead of writing the statement
<pre>fib = memoize(fib)</pre>
we can write 
<pre>@memoize</pre>
But this line has to be directly in front of the decorated function, in our example fib():
<pre>
def memoize(f):
    memo = {}
    def helper(x):
        if x not in memo:            
            memo[x] = f(x)
        return memo[x]
    return helper
    
@memoize
def fib(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib(n-1) + fib(n-2)

#fib = memoize(fib)

print(fib(40))
</pre>



<br>
<h3>Checking Arguments with a Decorator</h3>
In our chapter about recursive functions we introduced the factorial function. We wanted to 
keep the function as simple as possible and we didn't want to obscure the underlying idea, 
so we hadn't incorporated any argument checks. So, if somebody had called our function with 
a negative argument or with a float argument, our function
would have got into an endless loop.
<br><br>
The following program uses a decorator function to ensure that the argument passed to the 
function factorial is a positive integer:
<pre>
def argument_test_natural_number(f):
    def helper(x):
        if type(x) == int and x > 0:
        		return f(x)
        else:
        		raise Exception("Argument is not an integer")
    return helper
    
@argument_test_natural_number
def factorial(n):
    if n == 1:
        return 1
    else:
        return n * factorial(n-1)

for i in range(1,10):
	print(i, factorial(i))

print(factorial(-1))
</pre>
<br><br>
<h3>Exercise</h3>
<ol>
<li>
<img class="imgright" src="images/scales_small.jpg" alt="Scales, Public Domai" />
Our exercise is an old riddle, going back to 1612. The French Jesuit Claude-Gaspar 
Bachet phrased it. We have to weigh quantities (e.g. sugar or flour) from 1 to 40 pounds. 
What is the least number of weights that can be used on a balance scale to way any of 
these quantities.

<br><br>
The first idea might be to use weights of 1, 2, 4, 8, 16 and 32 pounds. This is a 
minimal number, if we restrict ourself to put weights on one side and the stuff, e.g. 
the sugar, on the other side. But it is possible to put weights on both pans of the scale. 
Now, we need only for weights, i.e. 1,3,9,27
<br><br>
Write a Python function weigh(), which calculates the weights needed and their 
distribution on the pans to weigh any amount from 1 to 40.
</li>
</ol>

<h3>Solution</h3>

<ol>
<li>
We need the function linear_combination() from our chapter 
"<a href="linear_combinations.php">Linear Combinations</a>".

<pre>
def factors_set():
    factors_set = ( (i,j,k,l) for i in [-1,0,1] 
                          for j in [-1,0,1]
                          for k in [-1,0,1]
                          for l in [-1,0,1])
    for factor in factors_set:
        yield factor

def memoize(f):
    results = {}
    def helper(n):
        if n not in results:
            results[n] = f(n)
        return results[n]
    return helper

@memoize
def linear_combination(n):
    """ returns the tuple (i,j,k,l) satisfying
        n = i*1 + j*3 + k*9 + l*27      """
    weighs = (1,3,9,27)
      
    for factors in factors_set():
       sum = 0
       for i in range(len(factors)):
          sum += factors[i] * weighs[i]
       if sum == n:
          return factors
</pre>

With this, it is easy to write our function weigh().

<pre>
def weigh(pounds):
    weights = (1,3,9,27)
    scalars = linear_combination(pounds)
    left = ""
    right = ""
    for i in range(len(scalars)):
        if scalars[i] == -1:
            left += str(weights[i]) + " "
	elif scalars[i] == 1:
            right += str(weights[i]) + " "
    return (left,right)

for i in [2,3,4,7,8,9,20,40]:
	pans = weigh(i)
	print("Left  pan: " + str(i) + " plus " + pans[0])
	print("Right pan: " + pans[1] + "\n")
</pre>
</li>
</ol>


<br><br>
</div>
</p>
<div id="contextlinks">Previous Chapter: <a href="python3_tests.php">Tests, DocTests, UnitTests</a><br>
<LINK rel="prev" href="python3_tests.php">Next Chapter: <a href="python3_passing_arguments.php">Parameter Passing in Functions</a><br>
<LINK rel="next" href="python3_passing_arguments.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
