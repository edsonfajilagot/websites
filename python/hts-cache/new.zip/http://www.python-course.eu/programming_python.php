<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Books on Python: Programming Python by Mark Lutz</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Python Books: Mark Lutz, Programming Python; apllied Python programming" />
<meta name="Keywords" content="Python, Python3, books, programming python, mark lutz" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li class="active"><a id="current" href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/python_books_left.jpg" alt="box" />    <h2>Python Books</h2>

<div class="menu">

<ul>
<li><a href="learning_python.php">Mark Lutz: Learning Python</a></li><li><a href="programming_python.php">Mark Lutz: Programming Python</a></li><li><a href="dive_into_python.php">Dive into Python</a></li><li><a href="natural_language_processing_with_python.php">Natural Language Processing with Python</a></li><li><a href="rapid_gui_programming_with_python.php">Rapid GUI Programming with Python and Qt</a></li><li><a href="python_in_a_nutshell.php">Python in a Nutshell</a></li></ul>

</div>

<p>
<br>
<hr>
<i>"The man who doesn't read good books has no advantage over the man who can't read them."</i>
<br>(Mark Twain)
<br>
<hr>
<br>
<i>"There is no such thing as a moral or an immoral book. Books are well written or badly written."</i>
<br>(Oscar Wilde)
<br>
<hr>
<i>"I think it is good that books still exist, but they do make me sleepy."</i>
<br>(Frank Zappa)
<br>
<hr>
<br>

This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
<h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>"But active programming consists of the design of new programs, rather than 
contemplation of old programs. "</i> (Niklaus Wirth)<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="learning_python.php">Mark Lutz: Learning Python</a><br>
<LINK rel="prev" href="learning_python.php">Next Chapter: <a href="dive_into_python.php">Dive into Python</a><br>
<LINK rel="next" href="dive_into_python.php"></div>
<h2>Python Books: Programming Python</h2>
<h3>The Blurb</h3>
<p>
<img class="imgright" src="images/programming_python.jpg" alt="Mark Lutz, Programming Python" />    

If you've mastered Python's fundamentals, you're ready to start using it to get real work done. 
Programming Python will show you how, with in-depth tutorials on the language's primary application domains: 
system administration, GUIs, and the Web. You'll also explore how Python is used in databases, networking, 
front-end scripting layers, text processing, and more. This book focuses on commonly used tools and 
libraries to give you a comprehensive understanding of Python's many roles in practical, real-world 
programming.
<br>
<br>
You'll learn language syntax and programming techniques in a clear and concise manner, with lots of 
examples that illustrate both correct usage and common idioms. Completely updated for version 3.x, 
Programming Python also delves into the language as a software development tool, with many code examples 
scaled specifically for that purpose.
<br><br>
Topics include:
<ul>
<li>Quick Python tour: Build a simple demo that includes data representation, object-oriented 
programming, object persistence, GUIs, and website basics</li>
<li>System programming: Explore system interface tools and techniques for command-line scripting, 
    processing files and folders, running programs in parallel, and more</li>
<li>GUI programming: Learn to use Python's tkinter widget library</li>
<li>Internet programming: Access client-side network protocols and email tools, use CGI 
    scripts, and learn website implementation techniques</li>
<li> More ways to apply Python: Implement data structures, parse text-based information, 
    interface with databases, and extend and embed Python</li>       
</ul>


<br>

<h3>Details</h3>
Title:    Programming Python, 4th Edition <br>
By:    Mark Lutz <br>
Publisher:    O'Reilly Media <br>
Formats:        Print,        Ebook,        Safari Books Online<br>
<br>
Print:    December 2010 <br>
Ebook:    December 2010 <br>
Pages:    1632 <br>
Print ISBN:    978-0-596-15810-1<br>
ISBN 10:    0-596-15810-6<br>
Ebook ISBN:    978-1-4493-0183-5<br>
ISBN 10:    1-4493-0183-5 <br>

<h3>About the Author</h3>
Mark Lutz is the world leader in Python training, the author of Python's earliest and best-selling texts, 
and a pioneering figure in the Python community since 1992. He has been a software developer for 
25 years, and is the author of O'Reilly's Programming Python, 3rd Edition and Python Pocket Reference, 
3rd Edition.
</p>					 


</div>


<div id="contextlinks">Previous Chapter: <a href="learning_python.php">Mark Lutz: Learning Python</a><br>
<LINK rel="prev" href="learning_python.php">Next Chapter: <a href="dive_into_python.php">Dive into Python</a><br>
<LINK rel="next" href="dive_into_python.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
