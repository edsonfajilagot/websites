<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: Recursive Functions</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Introduction into recursion and recursive functions in Python" />
<meta name="Keywords" content="Python, recursion, recursive, recursive function, Function, Functions, parameter" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/natural_language_recursion_small.png" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<h3>Recursive Acronyms</h3>
Recursive acronyms and abbreviations refer to themselves. Acronyms are supposed to 
be an MIT tradition. Once, they had written an editor, which they called "EINE" (which 
means a/one in German). It's an acronym for "EINE Is Not Emacs", but this editor is Emacs-like
editor. Its successor was called "ZWEI" (German for two). 
<br><br>
Another very famous acronym is GNU, which stands for "GNU's Not Unix".
<br><br>Have you every heard about the Windows emulator Wine? It means "Wine Is Not an Emulator"!

<br>
<br>
<hr>
<br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/rekursive_funktionen.php">Rekursion und Rekursive Funktionen</a><h3>Python 2.7</h3>This tutorial deals with Python Version 2.7<br>This chapter from our course is available in a version for Python3: <a href="python3_recursive_functions.php">Recursive Functions</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>"Clearly, programming courses should teach methods of design and construction, and 
the selected examples should be such that a gradual development can be nicely 
demonstrated."</i> (Niklaus Wirth)<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="functions.php">Functions</a><br>
<LINK rel="prev" href="functions.php">Next Chapter: <a href="tests.php">Tests, DocTests, UnitTests</a><br>
<LINK rel="next" href="tests.php"></div>
<h2>Recursive Functions</h2>
<h3>Definition</h3>
<p>
<img class="imgright" src="images/natural_language_recursion.png" alt="Recursion in natural language" />
<i>
Recursion has something to do with infinity. I know recursion has something to do with infinity. 
I think I know recursion has something to do with infinity. He is sure I think I know recursion 
has something to do with infinity. We doubt he is sure I think ...
</i>
 We think, we convinced you now,
that we can go on forever with this example of a recursion from natural language. Recursion is not
only a fundamental feature of natural language, but of the human cognitive capacity. Our way of thinking 
is based on recursive thinking processes. Even with a very simple grammar, like "An English sentence
contains a subject and a predicate. A predicate contains a verb, an object and a complement", we can 
demonstrate the infinite possibilites of the natural language. Stephen Pinker phrases it like this:
"With a few thousand nouns that can fill the subject slot and a few thousand verbs that can fill the 
predicate slot, one already has several million ways to open a sentence. The possible combinations 
quickly multiply out to unimaginably large numbers. Indeed, the repertoire of sentences is theoretically 
infinite, because the rules of language use a trick called recursion. A recursive rule allows a phrase 
to contain an example of itself, as in <i>She thinks that he thinks that they think that he knows</i> 
and so on, ad infinitum. And if the number of sentences is infinite, the number of possible thoughts 
and intentions is infinite too, because virtually every sentence expresses a different thought or 
intention."<sup>1</sup>
<br><br>
We have to stop our short excursion to recursion in natural languages to come back to recursion in computer
science and finally to recursion in the programming language Python. 
<br><br> 
The adjective "recursive" originates from the Latin verb "recurrere", which means "to run back". 
And this is what a recursive definition or a recursive function does: It is "running back" or returning
to itself. Most people who have done some mathematics, computer science or read a book about programming
will have encountered the factorial, which is defined in mathematical terms as 
<br><br>
<code>n! = n * (n-1)!, if n &gt; 1 and f(1) = 1</code>
<br><br>
<h3>Definition of Recursion</h3>
Recursion is a way of programming or coding a problem, in which a function calls itself one or more times
in its body. Usually, it is returning the return value of this function call. If a function definition 
fulfills the condition of recursion, we call this function a recursive function.
<br><br>
Termination condition:<br>
A recursive function has to terminate to be used in a program. A recursive function terminates, if with every 
recursive call the solution of the problem is downsized and moves towards a base case. A base case is a case,
where the problem can be solved without further recursion. A recursion can lead to an infinite loop, if
the base case is not met in the calls.
<br><br>
Example:
<br>
<code>4! = 4 * 3!<br>3! = 3 * 2!<br>2! = 2 * 1</code>
<br>Replacing the calculated values gives us the following expression
<br>
<code>4! = 4 * 3 * 2 * 1</code>

<br><br>
Generally we can say: Recursion in computer science is a method where the solution to a problem is based 
on solving smaller instances of the same problem.

<br>
<h3>Recursive Functions in Python</h3>
Now we come to implement the factorial in Python. It's as easy and elegant as the mathematical definition.
<pre>
def factorial(n):
    if n == 1:
        return 1
    else:
        return n * factorial(n-1)
</pre>

We can track how the function works by adding two print() function to the previous function
definition:

<pre>
def factorial(n):
    print("factorial has been called with n = " + str(n))
    if n == 1:
        return 1
    else:
        res = n * factorial(n-1)
        print("intermediate result for ", n, " * factorial(" ,n-1, "): ",res)
        return res	

print(factorial(5))
</pre>

This Python script outputs the following results:
<pre>
factorial has been called with n = 5
factorial has been called with n = 4
factorial has been called with n = 3
factorial has been called with n = 2
factorial has been called with n = 1
intermediate result for  2  * factorial( 1 ):  2
intermediate result for  3  * factorial( 2 ):  6
intermediate result for  4  * factorial( 3 ):  24
intermediate result for  5  * factorial( 4 ):  120
120
</pre>

Let's have a look at an iterative version of the factorial function.
<pre>
def iterative_factorial(n):
    result = 1
    for i in range(2,n+1):
        result *= i
    return result
</pre>

<br>
<h3>The Pitfalls of Recursion</h3>
This subchapter of our tutorial on recursion deals with the Fibonacci numbers. 
What do have sunflowers, the Golden ratio, fur tree cones,  The Da Vinci Code and the song
"Lateralus" by Tool in common. Right, the Fibonacci numbers.
<br><br>
The Fibonacci numbers are the numbers of the following sequence of integer values:
<br><br>
<code>0,1,1,2,3,5,8,13,21,34,55,89, ...</code>
<br><br>
The Fibonacci numbers are defined by:
<br>
<code>F<sub>n</sub> = F<sub>n-1</sub> + F<sub>n-2</sub></code> 
<br>with <code>F<sub>0</sub> = 0 
and F<sub>1</sub> = 1</code>
<br><br>
The Fibonacci sequence is named after the mathematician Leonardo of Pisa, who is better known as Fibonacci.
In his book "Liber Abaci" (publishes 1202) he introduced the sequence as an exercise dealing with bunnies.
His sequence of the Fibonacci numbers begins with F<sub>1</sub> = 1, while in modern mathematics the sequence 
starts with F<sub>0</sub> = 0. But this has no effect on the other members of the sequence.
<br><br>
The Fibonacci numbers are the result of an artificial rabbit population, satisfying the following conditions:
<br>
<ul>
<li>a newly born pair of rabbits, one male, one female, build the initial population</li>
<li>these rabbits are able to mate at the age of one month so that at the end of its 
second month a female can bring forth another pair of rabbits</li>
<li>these rabbits are immortal</li>
<li>a mating pair always produces one new pair (one male, one female) every month from the 
second month onwards</li>
</ul> 
 
 The Fibonacci numbers are the numbers of rabbit pairs after n months, i.e. after 10 months we will have
 F<sub>10</sub> rabits.
<br><br>
The Fibonacci numbers are easy to write as a Python function. It's more or less a one to one mapping from
the mathematical definition:
<pre>
def fib(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib(n-1) + fib(n-2)
</pre>

An iterative solution for the problem is also easy to write, though the recursive solution looks more like the mathematical definition:
<pre>
def fibi(n):
    a, b = 0, 1
    for i in range(n):
        a, b = b, a + b
    return a
</pre>

If you check the functions fib() and fibi(), you will find out, that the iterative version fibi() 
is a lot faster than the recursive version fib(). To get an idea of how much this "a lot faster" can be,
we have written a script where we you the timeit module to measure the calls:
<br><br>
<pre>
from timeit import Timer
from fibo import fib

t1 = Timer("fib(10)","from fibo import fib")

for i in range(1,41):
	s = "fib(" + str(i) + ")"
	t1 = Timer(s,"from fibo import fib")
	time1 = t1.timeit(3)
	s = "fibi(" + str(i) + ")"
	t2 = Timer(s,"from fibo import fibi")
	time2 = t2.timeit(3)
	print("n=%2d, fib: %8.6f, fibi:  %7.6f, percent: %10.2f" % (i, time1, time2, time1/time2))
</pre> 

time1 is the time in seconds it takes for 3 calls to fib(n) and time2 respectively the time for fibi().
If we look at the results, we can see, that calling fib(20) three times needs about 14 milliseconds.
fibi(20) needs just 0.011 milliseconds for 3 calls. So fibi(20) is about 1300 times faster then fib(20).
<br>fib(40) needs already 215 seconds for three calls, while fibi(40) can do it in 0.016 milliseconds.
fibi(40) is more than 13 millions times faster than fib(40).
<br><br>
<pre>
n= 1, fib: 0.000004, fibi:  0.000005, percent:       0.81
n= 2, fib: 0.000005, fibi:  0.000005, percent:       1.00
n= 3, fib: 0.000006, fibi:  0.000006, percent:       1.00
n= 4, fib: 0.000008, fibi:  0.000005, percent:       1.62
n= 5, fib: 0.000013, fibi:  0.000006, percent:       2.20
n= 6, fib: 0.000020, fibi:  0.000006, percent:       3.36
n= 7, fib: 0.000030, fibi:  0.000006, percent:       5.04
n= 8, fib: 0.000047, fibi:  0.000008, percent:       5.79
n= 9, fib: 0.000075, fibi:  0.000007, percent:      10.50
n=10, fib: 0.000118, fibi:  0.000007, percent:      16.50
n=11, fib: 0.000198, fibi:  0.000007, percent:      27.70
n=12, fib: 0.000287, fibi:  0.000007, percent:      41.52
n=13, fib: 0.000480, fibi:  0.000007, percent:      69.45
n=14, fib: 0.000780, fibi:  0.000007, percent:     112.83
n=15, fib: 0.001279, fibi:  0.000008, percent:     162.55
n=16, fib: 0.002059, fibi:  0.000009, percent:     233.41
n=17, fib: 0.003439, fibi:  0.000011, percent:     313.59
n=18, fib: 0.005794, fibi:  0.000012, percent:     486.04
n=19, fib: 0.009219, fibi:  0.000011, percent:     840.59
n=20, fib: 0.014366, fibi:  0.000011, percent:    1309.89
n=21, fib: 0.023137, fibi:  0.000013, percent:    1764.42
n=22, fib: 0.036963, fibi:  0.000013, percent:    2818.80
n=23, fib: 0.060626, fibi:  0.000012, percent:    4985.96
n=24, fib: 0.097643, fibi:  0.000013, percent:    7584.17
n=25, fib: 0.157224, fibi:  0.000013, percent:   11989.91
n=26, fib: 0.253764, fibi:  0.000013, percent:   19352.05
n=27, fib: 0.411353, fibi:  0.000012, percent:   34506.80
n=28, fib: 0.673918, fibi:  0.000014, percent:   47908.76
n=29, fib: 1.086484, fibi:  0.000015, percent:   72334.03
n=30, fib: 1.742688, fibi:  0.000014, percent:  123887.51
n=31, fib: 2.861763, fibi:  0.000014, percent:  203442.44
n=32, fib: 4.648224, fibi:  0.000015, percent:  309461.33
n=33, fib: 7.339578, fibi:  0.000014, percent:  521769.86
n=34, fib: 11.980462, fibi:  0.000014, percent:  851689.83
n=35, fib: 19.426206, fibi:  0.000016, percent: 1216110.64
n=36, fib: 30.840097, fibi:  0.000015, percent: 2053218.13
n=37, fib: 50.519086, fibi:  0.000016, percent: 3116064.78
n=38, fib: 81.822418, fibi:  0.000015, percent: 5447430.08
n=39, fib: 132.030006, fibi:  0.000018, percent: 7383653.09
n=40, fib: 215.091484, fibi:  0.000016, percent: 13465060.78
</pre>
<br>
What's wrong with our recursive implementation?
<br><br>
Let's have a look at the calculation tree, i.e. the order in which the functions are called. fib() is
substituted by fib(). 
<br><br>
<img src="images/fib_calculation_tree.png" alt="fib() calculation tree" />
<br><br>
We can see, that the subtree f(2) appears 3 times and the subtree for the calculation of f(3) two times.
If you imagine extending this tree for f(6), you will understand, that f(4) will be called two times, f(3)
three times and so on. This means, our recursion doesn't remember previously calculated values.
<br><br>
We can implement a "memory" for our recusive version by using a dictionary to save the previously calculated
values.
<pre>
memo = {0:0, 1:1}
def fibm(n):
    if not n in memo:
        memo[n] = fibm(n-1) + fibm(n-2)
    return memo[n]
</pre>
We time it again to compare it with fibi():

<pre>
from timeit import Timer
from fibo import fib

t1 = Timer("fib(10)","from fibo import fib")

for i in range(1,41):
	s = "fibm(" + str(i) + ")"
	t1 = Timer(s,"from fibo import fibm")
	time1 = t1.timeit(3)
	s = "fibi(" + str(i) + ")"
	t2 = Timer(s,"from fibo import fibi")
	time2 = t2.timeit(3)
	print("n=%2d, fib: %8.6f, fibi:  %7.6f, percent: %10.2f" % (i, time1, time2, time1/time2))
</pre>
<br>
We can see, that it is even faster than the iterative version. Of course, the larger the arguments
the greater the benefit of our memoisation:
<br>
<pre>
n= 1, fib: 0.000011, fibi:  0.000015, percent:       0.73
n= 2, fib: 0.000011, fibi:  0.000013, percent:       0.85
n= 3, fib: 0.000012, fibi:  0.000014, percent:       0.86
n= 4, fib: 0.000012, fibi:  0.000015, percent:       0.79
n= 5, fib: 0.000012, fibi:  0.000016, percent:       0.75
n= 6, fib: 0.000011, fibi:  0.000017, percent:       0.65
n= 7, fib: 0.000012, fibi:  0.000017, percent:       0.72
n= 8, fib: 0.000011, fibi:  0.000018, percent:       0.61
n= 9, fib: 0.000011, fibi:  0.000018, percent:       0.61
n=10, fib: 0.000010, fibi:  0.000020, percent:       0.50
n=11, fib: 0.000011, fibi:  0.000020, percent:       0.55
n=12, fib: 0.000004, fibi:  0.000007, percent:       0.59
n=13, fib: 0.000004, fibi:  0.000007, percent:       0.57
n=14, fib: 0.000004, fibi:  0.000008, percent:       0.52
n=15, fib: 0.000004, fibi:  0.000008, percent:       0.50
n=16, fib: 0.000003, fibi:  0.000008, percent:       0.39
n=17, fib: 0.000004, fibi:  0.000009, percent:       0.45
n=18, fib: 0.000004, fibi:  0.000009, percent:       0.45
n=19, fib: 0.000004, fibi:  0.000009, percent:       0.45
n=20, fib: 0.000003, fibi:  0.000010, percent:       0.29
n=21, fib: 0.000004, fibi:  0.000009, percent:       0.45
n=22, fib: 0.000004, fibi:  0.000010, percent:       0.40
n=23, fib: 0.000004, fibi:  0.000010, percent:       0.40
n=24, fib: 0.000004, fibi:  0.000011, percent:       0.35
n=25, fib: 0.000004, fibi:  0.000012, percent:       0.33
n=26, fib: 0.000004, fibi:  0.000011, percent:       0.34
n=27, fib: 0.000004, fibi:  0.000011, percent:       0.35
n=28, fib: 0.000004, fibi:  0.000012, percent:       0.32
n=29, fib: 0.000004, fibi:  0.000012, percent:       0.33
n=30, fib: 0.000004, fibi:  0.000013, percent:       0.31
n=31, fib: 0.000004, fibi:  0.000012, percent:       0.34
n=32, fib: 0.000004, fibi:  0.000012, percent:       0.33
n=33, fib: 0.000004, fibi:  0.000013, percent:       0.30
n=34, fib: 0.000004, fibi:  0.000012, percent:       0.34
n=35, fib: 0.000004, fibi:  0.000013, percent:       0.31
n=36, fib: 0.000004, fibi:  0.000013, percent:       0.31
n=37, fib: 0.000004, fibi:  0.000014, percent:       0.29
n=38, fib: 0.000004, fibi:  0.000014, percent:       0.29
n=39, fib: 0.000004, fibi:  0.000013, percent:       0.31
n=40, fib: 0.000004, fibi:  0.000014, percent:       0.29
</pre>

<br><br>
<h3>Exercises</h3>
<ol>
<li>Think of a recusive version of the function f(n) = 3 * n, i.e. the multiples of 3</li>
<li>Write a recursive Python function that returns the sum of the first <code>n</code> integers.
<br>(Hint: The function will be similiar to the factorial function!)</li>
<li>Write a function which implements the Pascal's triangle:<br>
<code>
<center>
                   1<br>
                 1 &nbsp;&nbsp; 1<br>
               1 &nbsp;&nbsp;  2 &nbsp;&nbsp;  1<br>
             1  &nbsp;&nbsp; 3 &nbsp;&nbsp;  3  &nbsp;&nbsp; 1<br>
           1  &nbsp;&nbsp; 4 &nbsp;&nbsp;  6 &nbsp;&nbsp;  4 &nbsp;&nbsp;  1<br>
         1 &nbsp;&nbsp;  5 &nbsp;&nbsp;  10 &nbsp;&nbsp; 10 &nbsp;&nbsp;  5 &nbsp;&nbsp; 1<br>  
</center>
</code>

</li>
<br>
<li>You find further exercises on our <a href="python3_recursive_functions.php">Python3 version of recursive functions</a>, e.g. creating the Fibonacci numbers out of 
Pascal's triangle or producint the prime numbers recursively, using the
Sieve of Eratosthenes.</li>


</ol>


<h3>Solutions to our Exercises</h3>
<ol>
<li> 
Solution to our first exercise on recursion:
<br>
Mathematically, we can write it like this:
<br>
<code>
f(1) = 3, 
<br>
f(n+1) = f(n) + 3
</code>
<br><br>
A Python function can be written like this:
<pre>
def mult3(n):
    if n == 1:
        return 3
    else:
        return mult3(n-1) + 3

for i in range(1,10):
    print(mult3(i))
</pre>
</li>
<li>
Solution to our second exercise:
<pre>
def sum_n(n):
    if n== 0:
        return 0
    else:
        return n + sum_n(n-1)
</pre>
</li>
<li>
Solution for creating the Pacal triangle:
<br>
<pre>
def pascal(n):
    if n == 1:
        return [1]
    else:
        line = [1]
        previous_line = pascal(n-1)
        for i in range(len(previous_line)-1):
            line.append(previous_line[i] + previous_line[i+1])
        line += [1]
    return line

print(pascal(6))
</pre>
Alternatively, we can write a function using list comprehension:
<br>
<pre>
def pascal(n):
    if n == 1:
        return [1]
    else:
        p_line = pascal(n-1)
        line = [ p_line[i]+p_line[i+1] for i in range(len(p_line)-1)]
        line.insert(0,1)
        line.append(1)
    return line

print(pascal(6))
</pre>

</li>

</ol>




<br><br>
<hr>
<br>
<sup>1</sup> Stephen Pinker, The Blank Slate, 2002

</p>

<div id="contextlinks">Previous Chapter: <a href="functions.php">Functions</a><br>
<LINK rel="prev" href="functions.php">Next Chapter: <a href="tests.php">Tests, DocTests, UnitTests</a><br>
<LINK rel="next" href="tests.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
