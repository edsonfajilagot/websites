<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Modular Programming and Modules</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Modular Programming in Python by using modules and packages." />
<meta name="Keywords" content="Python, modular programming, module, modules, package, packages" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/lego.jpg" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<hr>
<h3>Design</h3>
The engineer's or programmer's first problem in any design situation is to 
discover what the problem really is.
<br><br>
<i>"Luck is the residue of design."</i>
<br>
(Branch Rickey)
<br>
<i>"Design is not just what it looks like and feels like. Design is how it works."</i>
<br>
(Steve Jobs)
<br>
<i>"See first that the design is wise and just: that ascertained, pursue it resolutely; 
do not for one repulse forego the purpose that you resolved to effect."</i>
(William Shakespeare)
<br><br>
<h3>Poetry and Music in Programming</h3>
<i>"The process of preparing programs for a digital computer is especially attractive, 
not only because it can be economically and scientifically rewarding, but also because 
it can be an aesthetic experience much like composing poetry or music."</i>
<br>
(Donald E. Knuth)
<br><br>
<hr>
<br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_modularisierung.php">Modularisierung mit Modulen und Paketen</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="modules_and_modular_programming.php">Modular Programming and Modules in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="modules_and_modular_programming.php">Modular Programming and Modules in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_file_management.php">Read and Write Files</a><br>
<LINK rel="prev" href="python3_file_management.php">Next Chapter: <a href="python3_re.php">Regular Expressions</a><br>
<LINK rel="next" href="python3_re.php"></div>
<h2>Modular Programming and Modules</h2>
<br>
<h3>Modular Programming</h3>
<p>
<img class="imgright" src="images/legos.jpg" alt="Legos als Module" />
Modular programming is is a software design technique, which is based on the general principal 
of modular design. Modular design is an approach which has been proven as indespensible in engineering
even long before the first computers. Modular design means, that a complex system is broken down
into smaller parts or components, i.e. modules. These components can be independently created and 
tested. In many cases, they can be even used in other systems as well.  
<br><br>
There is hardly any product nowadays, which doesn't heavily rely on modularisation, like cars, mobile
phones. Computers belong to those products which are modularised to the utmost. So, what's a must for the 
hardware is an unavoidable necessity for the software running on the computers. 
<br><br> 
If you want to develop programs which are readable, reliable and maintainable without too much effort, 
you have use some kind of modular software design. Especially if your application has a certain size.
There exists a variety of concepts to design software in modular form.
Modular programming is a software design technique to split your code into separate parts. These parts
are called modules.  The focus for this separation should be to have modules with no or just few dependencies
upon other modules. In other words: Minimization of dependencies is the goal. 
When creating a modular system, several modules are built separately and more or less independently. 
The executable application will be created by putting them together.
<br><br>But how do we create modules in Python? A module in Python is just a file containing Python 
definitions and statements. The module name is moulded out of the file name by removing the suffix .py. 
For example, if the file name is fibonacci.py, the module name is fibonacci.
<br><br>
Let's turn our Fibonacci functions into a module. 
There is hardly anything to be done, we just save the following code in the file fibonacci.py:
<br><br>
<pre>
def fib(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib(n-1) + fib(n-2)
def ifib(n):
    a, b = 0, 1
    for i in range(n):
        a, b = b, a + b
    return a
</pre>
The newly created module "fibonacci" is ready for use now. We can import this module like any other
other module in a program or script. We will demonstrate this in the following interactive Python shell:
<pre>
>>> import fibonacci
>>> fibonacci.fib(7)
13
>>> fibonacci.fib(20)
6765
>>> fibonacci.ifib(42)
267914296
>>> fibonacci.ifib(1000)
43466557686937456435688527675040625802564660517371780402481729089536555417949051890403879840079255169295922593080322634775209689623239873322471161642996440906533187938298969649928516003704476137795166849228875
>>> 
</pre>
<br>
Don't try to call the recursive version of the Fibonacci function with large arguments like we did with 
the iterative version. A value like 42 is already too large. You will have to wait for a long time!
<br><br>
As you can easily imageine: It's a pain if you have to use those functions often in your program and you
always have to type in the fully qualified name, i.e. fibonacci.fib(7). One solution consists in 
assigning a local name to a module function to get a shorte name:
<pre>
>>> fib = fibonacci.ifib
>>> fib(10)
55
>>>
</pre>
<br>
But it's better, if you import the necessary functions directly into your module, as we will 
demonstrate further down in this chapter.
<br><br>
<h3>More on Modules</h3>
Usually, modules contain functions, but there can be statements in them as well. 
These statements can be used to initialize the module. 
They are only executed when the module is imported.
<br><br>
Let's look at a module, which only consists of just one statement:
<pre>
print("The module is imported now!")
</pre>
<br>
We save with the name "one_time.py" and import it two times in an interactive session:
<pre>
>>> import one_time
The module is imported now!
>>> import one_time
>>> 
</pre>

We can see, that it was only imported once. Each module can only be imported once per interpreter session
or in a program or script. If you change a module and if you want to reload it, you must restart the 
interpreter again. 
In Python 2.x, it was possible to reimport the module by using the built-in reload, i.e.reload(modulename):
<br><br>
<pre>
$ python
Python 2.6.5 (r265:79063, Apr 16 2010, 13:57:41) 
[GCC 4.4.3] on linux2
Type "help", "copyright", "credits" or "license" for more information.
>>> import one_time
The module is imported now!
>>> reload(one_time)
The module is imported now!
<module 'one_time' from 'one_time.pyc'>
>>> 
</pre>

This is not possible anymore in Python 3.x. 
<br>
You will cause the following error:
<pre>
>>> import one_time
The module is imported now!
>>> reload(one_time)
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
NameError: name 'reload' is not defined
>>> 
</pre>
<br>
Since Python 3.0 the reload built-in function has been moved into the
imp standard library module. So it's still possible to reload files as before, but the functionality
has to be imported. You you have to execute an "import imp" and use
imp.reload(my_module). Alternatively, you can use "imp import reload" and use reload(my_module). 
<br><br>
Example with reloading the Python3 way:
<br>
<pre>
$ python3
Python 3.1.2 (r312:79147, Sep 27 2010, 09:57:50) 
[GCC 4.4.3] on linux2
Type "help", "copyright", "credits" or "license" for more information.
>>> from imp import reload
>>> import one_time
The module is imported now!
>>> reload(one_time)
The module is imported now!
<module 'one_time' from 'one_time.py'>
>>> 
</pre>


A module has a private symbol table, which is used as the global symbol table by all functions defined 
in the module. This is a way to prevent that a global variable of a module accidentally clashes with a 
user's global variable with the same name. Global variables of a module can be accessed with the same 
notation as functions, i.e.
<i>modname.name</i>
<br>
A module can import other modules. It is customary to place all import statements at the beginning of a 
module or a script.
<h3>Importing Names from a Module Directly</h3>
Names from a module can directly be imported into the importing module's symbol table:
<pre>
>>> from fibonacci import fib, ifib
>>> ifib(500)
1 1 2 3 5 8 13 21 34 55 89 144 233 377
</pre>
This does not introduce the module name from which the imports are taken in the local symbol table.
It's possible but not recommended to import all names defined in a module, except those beginning with an 
underscore "_":
<pre>
>>> from fibonacci import *
>>> fib(500)
1 1 2 3 5 8 13 21 34 55 89 144 233 377
</pre>
This shouldn't be done in scripts but it's possible to use it in interactive sessions to save typing. 
<br><br>
<h3>Executing Modules as Scripts</h3>
Essentially a Python module is a script, so it can be run as a script:
<pre>
python fibo.py <arguments>
</pre>
The module which has been startet as a script will be executed as if it had been imported, but with 
one exception: The system variable __name__ is set to "__main__". So it's possible to program different
behaviour into a module for the two cases. With the following conditional statement the file can be 
used as a module or as a script, but only if it is run as a script the method fib will be started with
a command line argument:
<pre>
if __name__ == "__main__":
    import sys
    fib(int(sys.argv[1]))
</pre>
If it is run as a script, we get the following output:
<pre>
$ python fibo.py 50
1 1 2 3 5 8 13 21 34 
</pre>
If it is imported, the code in the if block will not be executed:
<pre>
>>> import fibo
>>>
</pre>
<br><br>

<h3>Renaming a Namespace</h3>
<p>
While importing a module, the name of the namespace can be changed: 
<pre>
>>> import math as mathematics
>>> print(mathematics.cos(mathematics.pi))
-1.0
</pre>
After this import there exists a namespace  mathematics but no namespace math.
<br>
It's possible to import just a few methods from a module:
<pre>
>>> from math import pi,pow as power, sin as sinus
>>> power(2,3)
8.0
>>> sinus(pi)
1.2246467991473532e-16
</pre>
</p>
<h3>Kinds of Modules</h3>
<p>
There are different kind of modules:
<ul>
  <li>Those written in Python<br>
They have the suffix: .py

  <li>Dynamically linked C modules<br>
Suffixes are: .dll, .pyd, .so, .sl, ...

  <li>C-Modules linked with the Interpreter:<br>
It's possible to get a complete list of these modules:
<pre>
import sys
print(sys.builtin_module_names)
</pre>
An error message is returned for Built-in-Modules.
</ul>
</p>

<h3>Module Search Path</h3>
<p>
If you import a module, let's say "import abc", the interpreter searches for this
module in the following locations and in the order given:
<ol>
  <li>The directory of the top-level file, i.e. the file being executed.
  <li>The directories of PYTHONPATH, if this global variable is set.
  <li>standard installation path Linux/Unix e.g. in /usr/lib/python2.5.
</ol>
It's possible to find out where a module is located after it has been imported:
<pre>
>>> import math
>>> math.__file__
'/usr/lib/python2.5/lib-dynload/math.so'
>>> import random
>>> random.__file__
'/usr/lib/python2.5/random.pyc'
</pre>
</p>

<h3>Content of a Module</h3>
<p>
With the built-in function dir() and the name of the module as an argument,
you can list all valid attributes and methods for that module.
<pre>
>>> dir(math)
['__doc__', '__file__', '__name__', 'acos', 'asin',
'atan', 'atan2', 'ceil', 'cos', 'cosh', 'degrees', 
'e', 'exp', 'fabs', 'floor', 'fmod', 'frexp', 'hypot',
'ldexp', 'log', 'log10', 'modf', 'pi', 'pow', 'radians', 
'sin', 'sinh', 'sqrt', 'tan', 'tanh']
>>> 
</pre>
Calling dir() without an argument, a list with the names in the current local scope is returned:
<pre>
>>> import math
>>> col = ["red","green","blue"]
>>> dir()
['__builtins__', '__doc__', '__name__', 'col', 'math']
</pre>
</p>
It's possible to get a list of the built-in functions:
<pre>
>>> import __builtin__
>>> dir(__builtin__)
['ArithmeticError', 'AssertionError', 'AttributeError', 'BaseException', 'DeprecationWarning', 'EOFError', 'Ellipsis', 'EnvironmentError', 'Exception', 'False', 'FloatingPointError', 'FutureWarning', 'GeneratorExit', 'IOError', 'ImportError', 'ImportWarning', 'IndentationError', 'IndexError', 'KeyError', 'KeyboardInterrupt', 'LookupError', 'MemoryError', 'NameError', 'None', 'NotImplemented', 'NotImplementedError', 'OSError', 'OverflowError', 'PendingDeprecationWarning', 
...
</pre>
<h3>Module Packages</h3>
It's possible to put several modules into a Package. A directory of Python code is said to be a package. 
<br>
A package is imported like a "normal" module.
<br>
Each directory named within the path of a package must also contain a file named
 __init__.py, 
or else your package import will fail.
<br><br> 
</p>
<div id="contextlinks">Previous Chapter: <a href="python3_file_management.php">Read and Write Files</a><br>
<LINK rel="prev" href="python3_file_management.php">Next Chapter: <a href="python3_re.php">Regular Expressions</a><br>
<LINK rel="next" href="python3_re.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
