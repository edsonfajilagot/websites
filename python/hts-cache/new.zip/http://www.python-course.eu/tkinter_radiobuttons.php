<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>GUI Programming with Python: Radiobuttons in Tkinter</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="This chapter deals with Radiobuttons in Tk and Tkinter under Python." />
<meta name="Keywords" content="Python, Tkinter, Tk, Introduction, course, tutorial, radiobuttons, radio, button, buttons" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li class="active"><a id="current" href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/old_radio_buttons.png" alt="box" />    <h2>Tkinter Tutorial</h2>

<div class="menu">

<ul>
<li><a href="tkinter_labels.php">Saying Hello with Labels</a></li><li><a href="tkinter_message_widget.php">Message Widget</a></li><li><a href="tkinter_buttons.php">Buttons</a></li><li><a href="tkinter_variable_classes.php">Variable Classes</a></li><li><a href="tkinter_radiobuttons.php">Radiobuttons</a></li><li><a href="tkinter_checkboxes.php">Checkboxes</a></li><li><a href="tkinter_entry_widgets.php">Entry Widgets</a></li><li><a href="tkinter_canvas.php">Canvas Widgets</a></li><li><a href="tkinter_sliders.php">Sliders</a></li><li><a href="tkinter_text_widget.php">Text Widget</a></li><li><a href="tkinter_dialogs.php">Dialogs</a></li><li><a href="tkinter_layout_management.php">Layout Management</a></li><li><a href="tkinter_mastermind.php">Bulls and Cows / Mastermind in TK</a></li><li><a href="tkinter_menus.php">Creating Menus</a></li><li><a href="tkinter_events_binds.php">Events and Binds</a></li></ul>

</div>

<p>
<br>
<h3>Possible Problems</h3>
If you are a beginner in Python, there might be some problems with 
understanding certain Python constructs in the main text, you can read our tutorial.
<br>
Most probably you are familiar with functions, if not we suggest reading the chapter  
<a href="python3_functions.php">Functions</a>
<br><hr><br>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
<hr>
<h3>Buttons and Radios</h3>
<i>"You may not like the humor, but that is why every radio has an on-off button."</i>
<br>(Mel Karmazin)
<br><br>
<hr>
<br><br>
<i>"Biographies are but the clothes and buttons of the man. 
The biography of the man himself cannot be written."</i>
<br>(Mark Twain)
<br><br>
<hr>
<br><br>
Of course, Keith Richard didn't mean Tk buttons, when he said, that you can't make good music
by just pushing some buttons:<br>
<i>"Good music comes out of people playing together, knowing what they want to do and going 
for it. You have to sweat over it and bug it to death. You can't do it by pushing 
buttons and watching a TV screen."</i>
<br><br>
<hr>
<br><br>
Just one more quotation by a famous musician: "America: It's like Britain, only with buttons."
(Ringo Starr)
<br><br>
Let's stick with the Beatles. George Harrison once said: "Gossip is the Devil's radio!"
<br><br>
<hr>
<br>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/tkinter_radiobuttons.php">Tkinter Radiobuttons</a>
<h3>Classroom Trainings</h3>Tutorial
<p>
This website contains a free and extensive online tutorial by Bernd Klein. 
You can attend one of his <a href="python_classes.php">Python courses</a> in Paris,
London, Berlin, Munich or Lake Constance.
<br><br>

A fast and efficient approach to learn Python and Tkinter consists in attending a
<a href="http://www.bodenseo.com/courses.php?topic=Python">classroom training courses 
<br><img style="width: 150px;" 
alt="Bodenseo, Python courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.

<h3>Quote of the Day:</h3>
<p>

"The question of whether a computer can think is no more interesting than the 
question of whether a submarine can swim." (Edsger Wybe Dijkstra)<br>
<h3>Graphical User Interface</h3>
A graphical user interface (GUI) is a type of user interface that allows users to interact 
with electronic devices in a graphical way, i.e. with images, rather than text commands.
Originally interactive user interfaces to computers were not graphical, they were text  
oriented and usually consisted of commands, which had to be remembered. 
The DOS operating system from Microsoft and the Bourne shell under Linux are examples
of such user-computer interfaces. 


 </p>

</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="tkinter_variable_classes.php">Variable Classes</a><br>
<LINK rel="prev" href="tkinter_variable_classes.php">Next Chapter: <a href="tkinter_checkboxes.php">Checkboxes</a><br>
<LINK rel="next" href="tkinter_checkboxes.php"></div>
<h2>Tkinter</h2>
<br><br>
<h3>Radio Buttons</h3>
<img class="imgright" src="images/old_radio.png" alt="Old Radio, Image is Public Domain" />
<br>
A radio button, sometimes called option button, is a graphical user interface element of Tkinter, which allows
the user to choose (exactly) one of a predefined set of options. Radio buttons can contain text or images.
The button can only display text in a single font. A Python function or method can be associated with a 
radio button. This function or method will be called, if you press this radio button.
<br><br>
Radio buttons are named after the physical buttons used on old radios to select wave bands or preset radio 
stations. If such a button was pressed, other buttons would pop out, leaving the pressed button the only 
pushed in button.
<br><br>
Each group of Radio button widgets has to be associated with the same variable. Pushing a button 
changes the value of this variable to a predefined certain value.
<br><br>

<h3>Simple Example With Radio Buttons</h3>

<pre>
from Tkinter import *

root = Tk()

v = IntVar()

Label(root, 
      text="""Choose a 
programming language:""",
      justify = LEFT,
      padx = 20).pack()
Radiobutton(root, 
            text="Python",
            padx = 20, 
            variable=v, 
            value=1).pack(anchor=W)
Radiobutton(root, 
            text="Perl",
            padx = 20, 
            variable=v, 
            value=2).pack(anchor=W)

mainloop()
</pre>
<br>
The result of the previous example looks like this:
<br><br>
<img src="images/radio_buttons1.png" alt="Radio Buttons, Simple Example" />    
<br><br>

<h3>Improving the Example</h3>
In many cases, there are more than two radio buttons. It would be cumbersome, if we have to
define and write down each button. The solution is shown in the following example. We have a list
"languages", which contains the button texts and the corresponding values. We can use a for loop to 
create all the radio buttons.


<pre>
from Tkinter import *

root = Tk()

v = IntVar()
v.set(1)  # initializing the choice, i.e. Python

languages = [
    ("Python",1),
    ("Perl",2),
    ("Java",3),
    ("C++",4),
    ("C",5)
]

def ShowChoice():
    print v.get()

Label(root, 
      text="""Choose your favourite 
programming language:""",
      justify = LEFT,
      padx = 20).pack()

for txt, val in languages:
    Radiobutton(root, 
                text=txt,
                padx = 20, 
                variable=v, 
                command=ShowChoice,
                value=val).pack(anchor=W)

mainloop()
</pre>
<br>
The result of the previous example looks like this:
<br><br>
<img src="images/tkinter_radio_buttons.png" alt="Radio Buttons, Extended Example" />    
<br><br>
<h3>Indicator</h3>

Instead of having radio buttons with circular holes containing white space, we can have radio buttons
with the complete text in a box. We can do this by setting the indicatoron option to 0, which means, that
there will be no separate radio button indicator.
<br><br>
We exchange the definition of the Radiobutton in the previous example with the following one:
<br><br>
<pre>
    Radiobutton(root, 
                text=txt,
                indicatoron = 0,
                width = 20,
                padx = 20, 
                variable=v, 
                command=ShowChoice,
                value=val).pack(anchor=W)
</pre>
<br><br>
We have added the option indicatoron and the option width.  
<br><br>
<img src="images/indicatoron.png" alt="Radio buttons with indicatoron option" />    

<br><br>
</div>
<div id="contextlinks">Previous Chapter: <a href="tkinter_variable_classes.php">Variable Classes</a><br>
<LINK rel="prev" href="tkinter_variable_classes.php">Next Chapter: <a href="tkinter_checkboxes.php">Checkboxes</a><br>
<LINK rel="next" href="tkinter_checkboxes.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
