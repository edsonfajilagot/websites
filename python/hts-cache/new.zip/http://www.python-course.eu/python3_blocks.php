<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Structuring with Indentation</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Python uses indentation instead of braces to structure its programs and scripts into blocks." />
<meta name="Keywords" content="Python,structuring, structure,blocks,indentation" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/blocks100.jpg" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<hr>
<h3>Structures</h3>
<i>"A World is not an ideology nor a scientific institution, nor is it even a 
system of ideologies; rather, it is a structure of unconscious relations and 
symbiotic processes."</i>
(William Irwin Thompson)
<br>
<i>
"Begin at the beginning and go on till you come to the end; then stop."</i>
(Lewis Carrol)
<hr>
<br>

This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_bloecke.php">Strukturierung und Bl�cke</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="blocks.php">Structuring with Indentation in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="blocks.php">Structuring with Indentation in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_execute_script.php">Executing a Script</a><br>
<LINK rel="prev" href="python3_execute_script.php">Next Chapter: <a href="python3_variables.php">Data Types and Variables</a><br>
<LINK rel="next" href="python3_variables.php"></div>
<h2>Structuring with Indentation</h2>
<p>

<h3>Blocks</h3>
<img class="imgright" src="images/blocks_300.jpg" alt="Blocks" />  
<br>
A block is group of statements in a program or script. Usually it consists of at least one stements 
and of declarations for the block, depending on the programming or scripting language. A language, 
which allows grouping with blocks, is called a block structured language. Generally, blocks can contain
blocks as well, so we get a nested block structure. A block in a script or program functions as a mean to
group statements to be treated as if they were one statement. In many cases, it also serves as a way 
to limit the lexical scope of variables and functions.

<br><br>
Initially, in simple languages like Basic and Fortran, there was no way of explicitly using block
structures. Programmers had to rely on "go to" structures, nowadays frowned upon, because "Go to programs"
turn easily into spaghetti code, i.e. tangled and inscrutable control structures.
<br><br>
The first time, block structures had been formalized was in ALGOL, called a compound statement. 
<br><br>
Programming languages usually use certain methods to group statements into blocks:
<br>
<ul>
<li>begin ... end<br>
ALGOL, Pascal and others
<br>
An code snippet in Pascal to show this usage of blocks:
<br>
<pre>
with ptoNode^ do
begin
  x := 42;
  y := 'X';
end;
</pre>

</li>
<li>do ... done<br>
e.g. Bourne and Bash shell</li>
<li>Braces (also called curly brackets): { ... }<br>
By far the most common approach, used by C, C++, Perl, Java, and many other programming languages are braces.<br>
The following examples shows a conditional statement in C:<br>
<pre>
if (x==42) {
    printf("The Answer to the Ultimate Question of Life, the Universe, and Everything\n");
} else {
    printf("Just a number!\n");
}
</pre>
The indentations in this code fragment are not necessary. So the code could be written - offending
common decency - as
<pre>
if (x==42) {printf("The  Answer to the Ultimate Question of Life, the Universe, and Everything\n");} else {printf("Just a number!\n");}
</pre>
Please, keep this in mind to understand the advantages of Python!
</li>
<li>if ... fi<br>
e.g. Bourne and Bash shell</li>
</ul>    
<br>
<h3>Indenting Code</h3>
<img class="imgright" src="images/blocks.png" alt="Blocks in Python through indentation" />
Python uses a different principle. Python programs get structured through indentation, i.e. Code blocks
are defined by their indentation. Okay, that's what we expect from any program code, isn't it? 
Yes, but in the case of Python it's a language requirement not a matter of style. This principle 
makes it easier to read and understand other people's Python code. 
<br><br>
So, how does it work? All statements with the same distance to the right belong 
to the same block of code, i.e. the statements within a block line up vertically. 
The block ends at a line less indented or the end of the file. If a block has to 
be more deeply nested, it is simply indented further to the right.
<br><br>
Beginners are not supposed to understand the following example, because we haven't instroduced 
most of the used structured, like conditional statements and loops. Please confer the following 
chapters about loops and conditional statements for explanations:
<pre>
from math import sqrt
n = input("Maximal Number? ")
n = int(n)+1
for a in range(1,n):
    for b in range(a,n):
        c_square = a**2 + b**2
        c = int(sqrt(c_square))
        if ((c_square - c**2) == 0):
            print(a, b, c)
</pre> 
<br>
There is another aspect of structuring in Python, which we haven't mentioned so far, which you can see
in the example. Loops and Conditional statements end with a colon ":" - the same is true for functions and other structures 
introducing blocks. So, we should have said Python structures by colons and indentation.
<br><br>
</p>

<div id="contextlinks">Previous Chapter: <a href="python3_execute_script.php">Executing a Script</a><br>
<LINK rel="prev" href="python3_execute_script.php">Next Chapter: <a href="python3_variables.php">Data Types and Variables</a><br>
<LINK rel="next" href="python3_variables.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
