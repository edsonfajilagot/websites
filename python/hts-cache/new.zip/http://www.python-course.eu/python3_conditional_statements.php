<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Conditional Statements</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="The chapter about conditional statements in our course on Python 3. Conditional statements are executed only if a condition is true" />
<meta name="Keywords" content="Python, Python 3, course, tutorial, conditionals, conditional statement, if statement, example, examples" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/arrow.jpg" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<hr><br> 
 <i>"The truth is that we can learn to condition our minds, bodies, and emotions to link pain or 
 pleasure to whatever we choose. By changing what we link pain and pleasure to, we will instantly 
 change our behaviors."</i>
 <br>
 Anthony Robbins, self-help author and success coach
 <br><br>
<i>"I think that we're now inescapably in an age where the large statements of mathematics are 
 so complex that we may never know for sure whether they're true or false."
</i><br>
Keith Devlin, British mathematician
<br>
<hr>
<i>"Truth does not need argument, agreement, theories or beliefs. 
There is only one test for it and that is to ask yourself 'Is the 
statement true  or false in my experience?"</i>
Barry Long, Australian author and teacher
<br>
<br>
<hr>
<br>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo,
Linux, courses and seminars"
		     src="images/bodenseo_python_training.gif"><br>Linux and Python Training Courses and Seminars</a>
<hr>
We also like to thank Denise Mitchinson for providing the stylesheet of this website.<br> 
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_bedingte_anweisungen.php">bedingte Anweisungen</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="conditional_statements.php">Conditional Statements in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="conditional_statements.php">Conditional Statements in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_input.php">input via the keyboard</a><br>
<LINK rel="prev" href="python3_input.php">Next Chapter: <a href="python3_loops.php">Loops, while Loop</a><br>
<LINK rel="next" href="python3_loops.php"></div>

<h2>Conditional Statements</h2>
<h3>What if there were no Decisions to be made?</h3>
<p>
<img class="imgright" src="images/decision_300.jpg" alt="inevitable decisions" />

Our subtitle is a purely rhetorical question, because there are always decisions to be made, 
both in real live and of course in programming. Under certain conditions some 
decisions are inevitable in normal live, e.g. man and women just have 
to go separate ways from time to time, as the image indicates. 
<br><br>
Conditionals, - mostly in the form of if statements - 
are one of the essential features of a programming language and Python is no exception.
You will find hardly any programming language without an if statement.<sup>1</sup>
There is hardly a way to program without having branches in the flow of code. At least,
if the code has to solve some useful problem. 
<br><br>
A decision has to be taken when the script or program comes to a point where 
it has a choice of actions, i.e. different computations, to choose from. 
<br><br>
The decision depends in most cases on the value of variables or arithmetic expressions. 
These expressions are evaluated to the Boolean values True or False. The statements 
for the decision taking are called conditional statements. Alternatively they are also 
known as conditional expressions or conditional constructs.
<br><br>
So this chapter deals with conditionals. But to code them in Python, we have to 
know how to combine statements into a block. It also seems to be an ideal moment to 
introduce the Python block principle in combination with conditional statements. 

<h3>Blocks and Indentations</h3>
<img class="imgright" src="images/Mainz_psalter_detail.jpg" alt="Mainz Psalter, example for indentation in books" />


The concept of block building is also known in natural languages, as we can deduce from the following text:

<blockquote>
If it rains tomorrow, I will tidy up the cellar. After this I will paint the walls. If there is 
some time left, I will do my tax declaration.
</blockquote>

As we all know, there will be no time left to deal with the tax declaration. Joking apart, we can see a sequence 
of actions in the previous text, which have to be performed in a chronological order.
If you have a closer look at the text, you will notice that it is ambiguous: Is the action of painting the 
walls also linked to the event of rain? Especially, doing the tax declaration, does it depend on the rain as well?
What will this person do, if it doesn't rain? We extend the text by creating further ambiguities:

<blockquote>
If it rains tomorrow, I will tidy up the cellar. After this I will paint the walls. If there is 
some time left, I will do my tax declaration. Otherwise, I will go swimming. In the evening, I will 
go to the cinema with my wife!
</blockquote>

Can his wife hope to be invited to the cinema? Does she have to pray or hope for rain? To disambiguate the
text we can phrase it in a way, which is closer to programming code and Python code and hopefully, a happy ending for 
his wife:

<pre>
If it rains tomorrow, I will do the following:
    - tidy up the cellar 
    - paint the walls
    - If there is some time left, I will 
          - do my tax declaration
Otherwise, I will do the following:
    - go swimming
go to the cinema with my wife in the evening
</pre>

Such a work flow is often formulated in the programming environment as a so-called flow chart or programming flowchart:
<br><br>

<img src="images/flowchart.png" width=400 alt="flowchart in programming" />

<br><br>

Blocks are used in programming to enable groups of statements to be seen or treated as if they were one statement.
A block consists of one or more statements. A program can be seen as a block, which consists of statements and 
other nested blocks. There have been different approaches in programming languages to syntactically describe blocks:
ALGOL 60 and Pascal for example use "begin" and "end", while C and similar languages use curly braces "{" and "}". 
Bash has yet another design by using do ... done and if ... fi or case ... esac constructs.
<br><br>
There is a big disadvantage for all of these approaches: The code may be all right for the interpreter or the 
compiler of the language, but it can be written in a way, which is badly structured for humans. We want to 
illustrate this in the following "pseudo" C-Code snippet:

<pre>
if (raining_tomorrow) {
    tidy_up_the_cellar(); 
    paint_the_walls();
    if (time_left) 
          do_taxes();
} else
    enjoy_swimming();
go_cinema();
</pre>

Let us include some blanks in front of the go_cinema call:

<pre>
if (raining_tomorrow) {
    tidy_up_the_cellar(); 
    paint_the_walls();
    if (time_left) 
          do_taxes();
} else
    enjoy_swimming();
    go_cinema();
</pre>

The execution of the program will not change: They will go to the cinema whether it rains or not!
The way the code is written misleadingly connotes the meaning, that they will only go to cinema, if it 
does not rain. This example demonstrates the possible ambiguity in interpreting C-Code by humans. This means, 
that people write code, which will lead to a program which will not "behave" in the intended way.
<br>
There is even another danger lurking in this example. What if the programmer has forgotten to include the last two 
statements into braces? 

Should the code be like this:


<pre>
if (raining_tomorrow) {
    tidy_up_the_cellar(); 
    paint_the_walls();
    if (time_left) 
          do_taxes();
} else {
    enjoy_swimming();
    go_cinema();
}
</pre>

Now, they will only go to cinema, if it is not a rainy day, which makes sense, if it is an open air cinema.
The following code is the correct code, if they want to go to the cinema regardless of the weather:

<pre>
if (raining_tomorrow) {
    tidy_up_the_cellar(); 
    paint_the_walls();
    if (time_left) 
          do_taxes();
} else {
    enjoy_swimming();
}
go_cinema();}
</pre>

The problem in C is, that the way we indent code has no meaning for the compiler and it might suggest the wrong 
interpretation for humans, if they try to understand the code.
<br><br>
This is different in Python. Blocks are created with indentations. We could say "What you see is what you get!"
<br>
The example above may look in a Python program like this:

<pre>
if raining_tomorrow:
    tidy_up_the_cellar() 
    paint_the_walls()
    if time_left: 
          do_taxes()
else:
    enjoy_swimming()
go_cinema()
</pre>

There is no ambiguity in the Python version. The couples visit to the cinema is bound to occur, regardless 
of the weather. Moving the go_cinema() call to the same indentation level as the enjoy_swimming(), changes a lot.
In this case there will be no cinema, if it rains. 

<br><br>
We have just seen, that it is useful to use indentation in C or C++ programs to increase or ensure the 
legibility of a program for the programmer but not for the C compiler. The Compiler relies solely
on the structuring determined by the braces. 
Code in Python can only and has to be structured by using the correct indentation. This means, that
Python forces the programmer to use the indentation that he or she is supposed to use anyway to
write nice code. So, Python does not allow to obfuscate the structure of a program by using 
bogus or misleading indentations. 
<br><br>
A block of code in Python has to be indented by the same amount of blanks or tabs.
We will further deepen this in the next subsection on the conditional statements in Python.
 
 
<h3>Conditional Statements in Python</h3>

As we have already stated, the if-statements are used to change the flow of control 
in a Python program. This makes it possible to decide at run-time whether or not to 
run one block of code or another. 
<br><br>
The simplest form of an if statement in Python looks like this:

<pre>
if condition:
    statement
    statement
    # ... some more indented statements if necessary
</pre>

<br><br>
The indented block of code is executed only if the condition "condition" is evaluated to True,
meaning that it is logically true.

<br><br>

The following program code asks the user about his or her nationality. The indented print statement
will only be executed, if the nationality is "French".  If the user of
this program uses another nationality, nothing will be printed:

<pre>
person = input("Nationality? ")
if person == "french":
    print("Pr�f�rez-vous parler fran�ais?")
</pre>

Please note, that if somebody types in "French", nothing will be printed either, because we 
solely check the lower case spelling. We can change this by extending the condition with an "or": 

<pre>
person = input("Nationality? ")
if person == "french" or person == "French":
    print("Pr�f�rez-vous parler fran�ais?")
</pre>

Your Italian colleague may protest, that Italian speakers will not be taken into consideration by
our previous little program. We can change this by adding another if:

<pre>
person = input("Nationality? ")
if person == "french" or person == "French" :
    print("Pr�f�rez-vous parler fran�ais?")
if person == "italian" or person == "Italian" :
    print("Preferisci parlare italiano?")
</pre>
    
This small python script has a disadvantage: Let's assume that someone 
inputs "french" as a nationality. In this case, 
the print below the first "if" will be executed, i.e. the text 
"Pr�f�rez-vous parler fran�ais?" will be printed. After this the program will check, if the
value for person is equal to "italian" and "Italian", which cannot be the case, as we assumed "french"
is the input.  
This means that our program performs an unnecessary test, if the input is "french" or "French".
<br><br>

This problem can be solved with an "elif''condition. The expression is only checked after 
"elif", if the expression in the previous "elif'' or  "if" was "false''.



<pre>
person = input("Nationality? ")
if person == "french" or person == "French" :
    print("Pr�f�rez-vous parler fran�ais?")
elif person == "italian" or person == "Italian":
    print("Preferisci parlare italiano?")
else:
    print("You are neither Italian nor French,")
    print("so we have to speak English with each other.")
</pre>





<br><br>
Like in our previous example, if statements have in many cases "elif" and "else" branches as well. 
To be precise: There can be more than one "elif" branch, but only one "else" branch. The else branch 
has to be at the end of the if statement, i.e. it can't be followed by other elif branches.

<br><br>
The general form of the if statement in Python looks like this:

<pre>
if condition_1:
    statement_block_1
elif condition_2:
    statement_block_2

...

elif another_condition:    
    another_statement_block
else:
    else_block
</pre>

<br>
If the condition "condition_1" is True, the statements of the block statement_block_1 will
be executed. If not, condition_2 will be evaluated. If condition_2 evaluates to True, statement_block_2
will be executed, if condition_2 is False, the other conditions of the following elif conditions
will be checked, and finally if none of them has been evaluated to True, the indented block below the 
else keyword will be executed.
<br><br>



<br><br>
</p>
<h3>Example: Dog Years</h3>
<p>
It's a generally accepted belief, to assume, that one year in the life of a dog corresponds to
seven years in the life of a human being. But apparently there are other more subtle methods to 
calculate this haunting problem, haunting at least for some dog owners.
<br>
Another subtler - and some think a preciser method - works like this:
<ul>
<li>A one year old dog roughly corresponds to a fourteen year old child
<li>A dog who is two years old corresponds to a 22 year old human
<li>Every further dog year corresponds to five human years 
</ul>
The following Python script implements this "dog years algorithm": 
<pre>
age = int(input("Age of the dog: "))
print()
if age < 1:
	print("This can hardly be true!")
elif age == 1:
	print("about 14 human years")
elif age == 2:
	print("about 22 human years")
elif age > 2:
	human = 22 + (age -2)*5
	print("Human years: ", human)

### 
input('press Return>')
  </pre>
There is one drawback to the script. I works only for integers, i.e. full years. 
</p>



<h3>True or False</h3>
<p>
Unfortunately it is not as easy in real life as it is in Python to differentiate between 
true and false:

<br>
The following objects are evaluated by Python as False: 
<ul>
<li>numerical zero values (0, 0L, 0.0, 0.0+0.0j), 
<li>the Boolean value False, 
<li>empty strings, 
<li>empty lists and empty tuples, 
<li>empty dictionaries.
<li>plus the special value None.   
</ul>
<br>All other values are considered to be True. 
</p>
<h3>The ternary if</h3>
<p>
C programmers usually know the following abbreviated notation for the if construct: 
<pre>
max = (a > b) ? a : b; 
</pre>
This is an abbreviation for the following C code:
<pre>
if (a > b)
   max=a;
else
   max=b;  
  </pre>
C programmers have to get used to a different notation in Python:
<pre>
max = a if (a > b) else b
</pre>

The Python version is by far more readable. The expression above, can be read as
"max shall be a if a is greater than b else b".

<br><br>

But the ternary if statement is more than an abbreviation. It is an expression, which can be used
within another expression:

<pre>
max = (a if (a > b) else b) * 2.45 - 4
</pre>

</p>

<br><br>
Using if statements within programs can easily lead to complex decision trees, i.e. every if statements can 
be seen like the branches of a tree. 
<br><br>
We will read in three float numbers in the following program and will print out the largest value: 
<br><br>
<pre>
x = float(input("1st Number: "))
y = float(input("2nd Number: "))
z = float(input("3rd Number: "))

if x > y and x > z:
    maximum = x
elif y > x and y > z:
    maximum = y
else:
    maximum = z

print("The maximal value is: " + str(maximum))
</pre>

There are other ways to write the conditions like the following one:
<br><br>
<pre>
x = float(input("1st Number: "))
y = float(input("2nd Number: "))
z = float(input("3rd Number: "))

if x > y:
    if x > z:
        maximum = x
    else:
        maximum = z
else: 
    if y > z:
        maximum = y
    else:
        maximum = z

print("The maximal value is: " + str(maximum))
</pre>

Another way - which is less efficient, because we have to create a tuple or list to compare the numbers - to do it, can be seen 
in the following example. We are using the built-in function max, which calculates the maximum of a list or a tuple:

<pre>
x = float(input("1st Number: "))
y = float(input("2nd Number: "))
z = float(input("3rd Number: "))

maximum = max((x,y,z))

print("The maximal value is: " + str(maximum))
</pre>

<br><br>

If we want to read in an arbitrary number of elements, which we do not want or need to save in a list, we can calculate the 
maximum in the following way:

<pre>
number_of_values = int(input("How many values? "))

maximum = float(input("Value: "))
for i in range(number_of_values - 1):
    value = float(input("Value: "))
    if value > maximum:
        maximum = value

print("The maximal value is: " + str(maximum))
</pre>


<br>
<h3>Footnotes:</h3>

<sup>1</sup>
LOOP is a programming language without conditionals, but this language is purely pedagogical. It has been designed by 
the German computer scientist Uwe Sch�ning. The only operations which are supported by LOOP are assignments, additions and
loopings. But LOOP is of no practical interest and besides this it is only a proper subset of the computable functions.
<br><br>


<br><br>
<div id="contextlinks">Previous Chapter: <a href="python3_input.php">input via the keyboard</a><br>
<LINK rel="prev" href="python3_input.php">Next Chapter: <a href="python3_loops.php">Loops, while Loop</a><br>
<LINK rel="next" href="python3_loops.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
