<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Books on Python: Python in a Nutshell</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="A book not meant for learning Python: Python in a Nutshell" />
<meta name="Keywords" content="Python, Python3, books, learning python, nutshell, python in a nutshell" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li class="active"><a id="current" href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/python_books_left.jpg" alt="box" />    <h2>Python Books</h2>

<div class="menu">

<ul>
<li><a href="learning_python.php">Mark Lutz: Learning Python</a></li><li><a href="programming_python.php">Mark Lutz: Programming Python</a></li><li><a href="dive_into_python.php">Dive into Python</a></li><li><a href="natural_language_processing_with_python.php">Natural Language Processing with Python</a></li><li><a href="rapid_gui_programming_with_python.php">Rapid GUI Programming with Python and Qt</a></li><li><a href="python_in_a_nutshell.php">Python in a Nutshell</a></li></ul>

</div>

<p>
<br>
<hr>
This website is created by:<br><br>
<a href="http://www.python-training-courses.com"><img style="width: 150px;" alt="Python Training Courses"
		     src="images/toronto_building.jpg"><br><br>Python Training Courses in Toronto, Canada</a>
<br>
On site trainings in Europe, Canada and the US.
<br>
<hr>
<i>"The man who doesn't read good books has no advantage over the man who can't read them."</i>
<br>(Mark Twain)
<br>
<hr>
<br>
<i>"There is no such thing as a moral or an immoral book. Books are well written or badly written."</i>
<br>(Oscar Wilde)
<br>
<hr>
<i>"I think it is good that books still exist, but they do make me sleepy."</i>
<br>(Frank Zappa)
<br>
<hr>
<br>


</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
<h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>"If programmers deserve to be rewarded for creating innovative programs, by the same token 
they deserve to be punished if they restrict the use of these programs. "</i> (Richard Stallmann)
<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="rapid_gui_programming_with_python.php">Rapid GUI Programming with Python and Qt</a><br>
<LINK rel="prev" href="rapid_gui_programming_with_python.php"></div>
<h2>Python in a Nutshell</h2>
<p>
<h3>The Blurb</h3><img class="imgright" src="images/python_in_a_nutshell.jpg" alt="Python book shelf" />    

This book offers Python programmers one place to look when they need help remembering or deciphering 
the syntax of this open source language and its many powerful but scantily documented modules. 
This comprehensive reference guide makes it easy to look up the most frequently needed information --
not just about the Python language itself, but also the most frequently used parts of the standard 
library and the most important third-party extensions.
<br><br>
Ask any Python aficionado and you'll hear that Python programmers have
it all: an elegant object-oriented language with readable and maintainable syntax, that allows for
 easy integration with components in C, C++, Java, or C#, and an enormous collection of precoded 
 standard library and third-party extension modules. Moreover, Python is easy to learn, yet powerful 
 enough to take on the most ambitious programming challenges. But what Python programmers used to 
 lack is a concise andclear reference resource, with the appropriate measure of guidance in
 how best to use Python's great power. Python in a
 Nutshell fills this need.
<br>
Python in a Nutshell, Second Edition covers more than the language itself; it also deals with the most
frequently used parts of the standard library, and the most popular and
important third party extensions. Revised and expanded for
Python 2.5, this book now contains the gory details of Python's new
subprocess module and breaking news about Microsoft's new
IronPython project. Our "Nutshell" format fits Python perfectly by
presenting the highlights of the most important modules and functions
in its standard library, which cover over 90% of your practical
programming needs. 

This book includes:

<ul>
<li>A fast-paced tutorial on the syntax of the Python language</li>  
<li>An explanation of object-oriented programming in Python</li>  
<li>Coverage of iterators, generators, exceptions, modules,packages, strings, and regular expressions</li>  
<li>A quick reference for Python's built-in types and functionsand key modules</li>  
<li>Reference material on important third-party extensions,such as Numeric and Tkinter</li>  
<li>Information about extending and embedding Python</li>  
</ul>


Python in a Nutshell provides a solid,no-nonsense quick reference to information that programmers rely on themost. This book will immediately earn its place in any Pythonprogrammer's library.

<br>

<h3>Details</h3>
Title:    Python in a Nutshell, 2nd Edition <br>
By:    Alex Martelli <br>
Publisher:    O'Reilly Media <br>
Formats:   Print, Ebook, Safari Books Online<br>
<br>
Print:    July 2006 
<br>Ebook:    June 2009 
<br>Pages:    736 
<br>Print ISBN:    978-0-596-10046-9
<br>ISBN 10:    0-596-10046-9
<br>Ebook ISBN:    978-0-596-10566-2
<br>ISBN 10:    0-596-10566-5 


<h3>Our Review</h3>


<h3>About the Author</h3>
Alex Martelli spent 8 years with IBM Research, winning three Outstanding Technical Achievement Awards. 
He then spent 13 as a Senior Software Consultant at think3 inc, developing libraries, network protocols, 
GUI engines, event frameworks, and web access frontends. He has also taught programming languages, 
development methods, and numerical computing at Ferrara University and other venues. He's a C++ 
MVP for Brainbench, and a member of the Python Software Foundation. He currently works for AB Strakt, 
a Python-centered software house in G teborg, Sweden, mostly by telecommuting from his home in Bologna,
 Italy. Alex's proudest achievement is the articles that appeared in Bridge World (January/February 2000), 
 which were hailed as giant steps towards solving issues that had haunted contract bridge theoreticians 
 for decades.
</p>					 


</div>


<div id="contextlinks">Previous Chapter: <a href="rapid_gui_programming_with_python.php">Rapid GUI Programming with Python and Qt</a><br>
<LINK rel="prev" href="rapid_gui_programming_with_python.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
