<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Books on Python: Natural Language Processing with Python</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Python Books: Natural Language Processing with Python" />
<meta name="Keywords" content="Python, Python3, book, books, programming, natural language, processing, Steven Bird, Ewan Klein, Edward Loper" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li class="active"><a id="current" href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/python_books_left.jpg" alt="box" />    <h2>Python Books</h2>

<div class="menu">

<ul>
<li><a href="learning_python.php">Mark Lutz: Learning Python</a></li><li><a href="programming_python.php">Mark Lutz: Programming Python</a></li><li><a href="dive_into_python.php">Dive into Python</a></li><li><a href="natural_language_processing_with_python.php">Natural Language Processing with Python</a></li><li><a href="rapid_gui_programming_with_python.php">Rapid GUI Programming with Python and Qt</a></li><li><a href="python_in_a_nutshell.php">Python in a Nutshell</a></li></ul>

</div>

<p>
<h3>Natural Language Procesing</h3>
We have some topics related to natural language processing on our website:
<br>
<ul>
<li>We describe a <a href="finite_state_machine.php">Finite State Machine</a> (FSM) and 
present a Python implementation.</li>
<li>We cover a complete <a href="text_classification_introduction.php">introduction into Text Categorization</a> 
using Naive Bayes, including the mathematical background.</li>
<li>The previous chapter is followed by a 
<a href="text_classification_python.php">Python implementation of the Naive Bayes classifier</a></li>
</ul>

<hr>

<br>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo,
Linux, courses and seminars"
		     src="images/bodenseo_python_training.gif"><br>Python and other Programming Language  Courses</a>
<br>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>


<h3>Python Training Courses</h3>
<p>

<p>If you  want to learn Python fast and efficiently, the right step will be a 
<a href="http://www.bodenseo.com/courses.php?topic=Python">
<br>Python Training course</a> at Bodenseo. There are also
 special seminars for advanced students like the 
 <a href="http://www.bodenseo.com/course/python_xml_training_course.html">Python & XML Training Course</a>.
 If you want to acquire special knowledge in Text Processing and Text Classification, then  
<a href="http://www.bodenseo.com/course/python_text_processing_course.html">"Python Text Processing 
Course"</a> will be the right one for you.
<br>
All the Python seminars are available in German as well: 
<a href="http://www.bodenseo.de/kurse.php?topic=Python">Python-Kurse</a>"

 
<a href="http://www.bodenseo.com/courses.php?topic=Python">
<img class="imgright" src="images/bodenseo_stairs_to_python2.png" alt="Bodenseo step to python" />
<br>Python Courses</a> at Bodenseo.
<br><br>
You can book Bernd Klein for on-site <a href="python_classes.php">Python courses</a> as 
well.

<br>

 
<a href="http://www.bodenseo.com/courses.php?topic=Python">
<img class="imgright" src="images/radolfzell_segel_bodenseo_logo.jpg" alt="Bodenseo logo" />
<br>Python Courses</a> at Bodenseo.
<br><br>
 </p>


<h3>Praise of Python</h3>
"Python is a truly wonderful language. When somebody comes up with a good idea it takes about 1 minute and five lines to program something that almost does what you want. Then it takes only an hour to extend the script to 300 lines, after which it still does almost what you want." Jack Jansen (ported Python to Mac, MacPython)
In my daily work, I work on very large, complex, distributed systems built out of 
many Python modules and packages. The focus is very similar to what you find, for 
example, in Java and, in general, in systems programming languages.
(Guido van Rossum) 
 </p>

</p></div>

<div id="content">

<div id="contextlinks">Previous Chapter: <a href="dive_into_python.php">Dive into Python</a><br>
<LINK rel="prev" href="dive_into_python.php">Next Chapter: <a href="rapid_gui_programming_with_python.php">Rapid GUI Programming with Python and Qt</a><br>
<LINK rel="next" href="rapid_gui_programming_with_python.php"></div>
<h2>Natural Language Processing with Python</h2>
<h3>The Preface from the Book</h3>
<p>
<img class="imgright" src="images/natural_language_processing_with_python" alt="Natural Language Processing with Python" />    
 This is a book about Natural Language Processing. By "natural language" we mean a language that is used 
 for everyday communication by humans; languages like English, Hindi or Portuguese. In contrast to 
 artificial languages such as programming languages and mathematical notations, natural languages 
 have evolved as they pass from generation to generation, and are hard to pin down with explicit 
 rules. We will take Natural Language Processing - or NLP for short - in a wide sense to cover any 
 kind of computer manipulation of natural language. At one extreme, it could be as simple as counting 
 word frequencies to compare different writing styles. At the other extreme, NLP involves "understanding" 
 complete human utterances, at least to the extent of being able to give useful responses to them.
<br><br>
Technologies based on NLP are becoming increasingly widespread. For example, phones and handheld 
computers support predictive text and handwriting recognition; web search engines give access to 
information locked up in unstructured text; machine translation allows us to retrieve texts written 
in Chinese and read them in Spanish. By providing more natural human-machine interfaces, and more 
sophisticated access to stored information, language processing has come to play a central role in 
the multilingual information society.
<br><br>
This book provides a highly accessible introduction to the field of NLP. It can be used for individual 
study or as the textbook for a course on natural language processing or computational linguistics, or 
as a supplement to courses in artificial intelligence, text mining, or corpus linguistics. The book 
is intensely practical, containing hundreds of fully-worked examples and graded exercises.
<br><br>
The book is based on the Python programming language together with an open source library called the 
Natural Language Toolkit (NLTK). NLTK includes extensive software, data, and documentation, all 
freely downloadable from http://www.nltk.org/. Distributions are provided for Windows, Macintosh 
and Unix platforms. We strongly encourage you to download Python and NLTK, and try out the examples 
and exercises along the way.
<br><br>

<h3>Our Review</h3>
This book is suitable for a wide range of people, like software developper, linguists, business information
analysts, who want to to get a working knowledge of NLP (Natural Language Processing). The book doesn't require
any Python or even programming knowledge, so it's suitable both for readers with no prior knowledge in Python 
and in programming. The first chapters of the books are an introduction into the basic concepts of the language.  

<h3>Details</h3>

Title: Natural Language Processing with Python<br>
Authors: Steven Bird, Ewan Klein, and Edward Loper<br>
Publisher: O'Reilly Media; 1 edition (July 7, 2009)
ISBN-10: 0596516495<br>
ISBN-13: 978-0596516499<br>
512 Pages<br>



</p>					 


</div>


<div id="contextlinks">Previous Chapter: <a href="dive_into_python.php">Dive into Python</a><br>
<LINK rel="prev" href="dive_into_python.php">Next Chapter: <a href="rapid_gui_programming_with_python.php">Rapid GUI Programming with Python and Qt</a><br>
<LINK rel="next" href="rapid_gui_programming_with_python.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
