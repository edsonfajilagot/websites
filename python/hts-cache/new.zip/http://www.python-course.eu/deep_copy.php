<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: Shallow and Deep Copy</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Problems with copying in Python: comparison of shallow and deep copy" />
<meta name="Keywords" content="Python, copy, shallow, deep, Problem, problems" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/Deep_Sea_Squid_copy.jpg" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<br>
<hr>
Beyond doubt one of the most common operations that occurs in computer programs 
is the copying of data. 
<hr>
<i>An original artist is unable to copy. So he has only to copy in order to be original.</i><br>
Jean Cocteau 
<hr>
<i>Look deep into nature, and then you will understand everything better.</i><br>
Albert Einstein
<hr>
<i>Either you decide to stay in the shallow end of the pool or you go out in the ocean.</i><br>
Christopher Reeve 
<br>
<hr>
Supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo, courses and 
seminars in Linux and Python"
		     src="images/bodenseo_python_training.gif"><br>Linux and Python Courses and Seminars </a>
<br><br>
Please see also <a href="http://www.python-training-courses.com">Python Training International</a>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/deep_copy.php">Flaches und Tiefes Kopieren</a><h3>Python 2.7</h3>This tutorial deals with Python Version 2.7<br>This chapter from our course is available in a version for Python3: <a href="python3_deep_copy.php">Shallow and Deep Copy</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>Fools ignore complexity. Pragmatists suffer it. Some can avoid it. Geniuses remove it.</i>
(Alan Perlis)
<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="sets_frozensets.php">Sets and Frozen Sets</a><br>
<LINK rel="prev" href="sets_frozensets.php">Next Chapter: <a href="functions.php">Functions</a><br>
<LINK rel="next" href="functions.php"></div>
<h2>Shallow and Deep Copy</h2>
<h3>Introduction</h3>

<img class="imgright" src="images/Deep_Sea_Squid.jpg" alt="Deep Sea Squid" />
<br>
As we have seen in the chapter "Data Types and Variables", Python has a strange behaviour 
- in comparison with other programming languages - 
when assigning and copying simple data types like integers and strings. The difference between 
shallow and deep copying is only relevant for compound objects, i.e. objects containing other 
objects, like lists or class instances.
<br>
<br>In the following code snippet y points to the same memory location than X. This changes, 
when we assign a different value to y. In this case y will receive a separate memory location, 
as we have seen in the chapter "Data Types and Variables".
<br>
<pre>
>>> x = 3
>>> y = x
</pre>

But even if this internal behaviour appears strange compared to programming languages like C, 
C++ and Perl, yet the observable results of the assignments answer our expectations. 
But it can be problematic, if we copy mutable objects like lists and dictionaries.
<br><br>
Python creates real copies only if it has to, i.e. if the user, the programmer, explicitly 
demands it.
<br><br>
We will introduce you to the most crucial problems, which can occur when copying mutable objects, i.e.
when copying lists and dictionaries.


<h3>Copying a list</h3>
<p>
<pre>
>>> colours1 = ["red", "green"]
>>> colours2 = colours1
>>> colours2 = ["rouge", "vert"]
>>> print colours1
['red', 'green']
</pre>
<img class="imgleft" src="images/deep_copy_1" alt="Copying a simple list" />
In the example above a simple list is assigned to colours1. In the next step we assign colour1 
to colours2. After this, a new list is assigned to colours2.
<br><br>
As we have expected, the values of colours1 remained unchanged. Like it was in our example
in the chapter "Data types and variables", a new memory location had been allocated for colours2, 
because we have assigned a complete new list to this variable. 
<pre>
>>> colours1 = ["red", "green"]
>>> colours2 = colours1
>>> colours2[1] = "blue"
>>> colours1
['red', 'blue']
</pre>

<img class="imgleft" src="images/deep_copy_2" alt="Copying a simple list" />
But the question is, what will happen, if we change an element of the list of colours2 or colours1?
<br>
In the example above, we assign a new value to the second element of colours2. 
Lots of beginners will be astonished, that the list of colours1 has been "automatically" 
changed as well. 
<br>
The explanation is, that there has been no new assignment to colours2, only to one of its elements.  
</p>

<h3>Copy with the Slice Operator</h3>
<p>
It's possible to completely copy shallow list structures with the slice operator without having any 
of the side effects, which we have described above:
<pre>
>>> list1 = ['a','b','c','d']
>>> list2 = list1[:]
>>> list2[1] = 'x'
>>> print list2
['a', 'x', 'c', 'd']
>>> print list1
['a', 'b', 'c', 'd']
>>> 
</pre>
But as soon as a list contains sublists, we have the same difficulty, i.e. just pointers to the
sublists.

<pre>
>>> lst1 = ['a','b',['ab','ba']]
>>> lst2 = lst1[:]
</pre>
<br>
This behaviour is depicted in the following diagram:
<br>
<img class="imgleft" src="images/deep_copy_3" alt="Copying a list with sublists" />
<br><br><br><br><br><br><br><br><br><br><br>
If you assign a new value to the 0th Element of one of the two lists, there will 
be no side effect. Problems arise, if you change one of the elements of the sublist.
<pre>
>>> lst1 = ['a','b',['ab','ba']]
>>> lst2 = lst1[:]
>>> lst2[0] = 'c'
>>> lst2[2][1] = 'd'
>>> print(lst1)
['a', 'b', ['ab', 'd']]
</pre>


<br><br>The following diagram depicts what happens, if one of the elements of a sublist 
will be changed: Both the content of lst1 and lst2 are changed. 
<br>
<br>
<img class="imgleft" src="images/deep_copy_4" alt="Copying lists containing sublists" />
<br><br><br><br><br><br><br><br><br>
<br>
<h3>Using the Method deepcopy from the Module copy</h3>
A solution to the described problems is to use the module "copy". 
This module provides the method "copy", which allows a complete copy of
a arbitrary list, i.e. shallow and other lists. <br><br> 
The following script uses our example above and this method:
<br>
<pre>
from copy import deepcopy

lst1 = ['a','b',['ab','ba']]

lst2 = deepcopy(lst1)

lst2[2][1] = "d"
lst2[0] = "c";

print lst2
print lst1
</pre>
If we save this script under the name of deep_copy.py and if we call the script with 
"python deep_copy.py", we will receive the following output:
<pre>
$ python deep_copy.py 
['c', 'b', ['ab', 'd']]
['a', 'b', ['ab', 'ba']]
</pre>

<img class="imgleft" src="images/deep_copy_5" alt="Copy a list with Deep-Copy" />
<br><br><br><br><br><br><br><br><br><br><br><br>

<br>
 </p>

</tbody>
</table>

<br>
<br>


<div id="contextlinks">Previous Chapter: <a href="sets_frozensets.php">Sets and Frozen Sets</a><br>
<LINK rel="prev" href="sets_frozensets.php">Next Chapter: <a href="functions.php">Functions</a><br>
<LINK rel="next" href="functions.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
