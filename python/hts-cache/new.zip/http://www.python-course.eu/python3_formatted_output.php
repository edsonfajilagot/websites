<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python3 Tutorial: Formatted Output</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="formatted output in three ways: the string methods ljust, rjust, center, format or using a C-style like formatting" />
<meta name="Keywords" content="Python, formatted output, format output, formatting, string modulo, string interpolation, printf, sprintf, string methods, ljust, rjust, center, format" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li class="active"><a id="current" href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/Printer_in_1568_110.png" alt="box" />    <h2>Python 3 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="python3_history_and_philosophy.php">The Origins of Python</a></li><li><a href="python3_interactive.php">Starting with Python: The Interactive Shell</a></li><li><a href="python3_execute_script.php">Executing a Script</a></li><li><a href="python3_blocks.php">Indentation</a></li><li><a href="python3_variables.php">Data Types and Variables</a></li><li><a href="python3_operators.php">Operators</a></li><li><a href="python3_sequential_data_types.php">Sequential Data Types: Lists and Strings</a></li><li><a href="python3_deep_copy.php">Shallow and Deep Copy</a></li><li><a href="python3_dictionaries.php">Dictionaries</a></li><li><a href="python3_sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="python3_input.php">input via the keyboard</a></li><li><a href="python3_conditional_statements.php">Conditional Statements</a></li><li><a href="python3_loops.php">Loops, while Loop</a></li><li><a href="python3_for_loop.php">For Loops</a></li><li><a href="python3_print.php">Output with Print</a></li><li><a href="python3_formatted_output.php">Formatted output with string modulo and the format method</a></li><li><a href="python3_functions.php">Functions</a></li><li><a href="python3_recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="python3_tests.php">Tests, DocTests, UnitTests</a></li><li><a href="python3_memoization.php">Memoization and Decorators</a></li><li><a href="python3_passing_arguments.php">Parameter Passing in Functions</a></li><li><a href="python3_namespaces.php">Namespaces</a></li><li><a href="python3_global_vs_local_variables.php">Global and Local Variables</a></li><li><a href="python3_file_management.php">Read and Write Files</a></li><li><a href="python3_modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="python3_re.php">Regular Expressions</a></li><li><a href="python3_re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="python3_lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="python3_list_comprehension.php">List Comprehension</a></li><li><a href="python3_generators.php">Iterators and Generators</a></li><li><a href="python3_exception_handling.php">Exception Handling</a></li><li><a href="python3_object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="python3_class_and_instance_attributes.php">Class and Instance Attributes</a></li><li><a href="python3_properties.php">Properties vs. getters and setters</a></li><li><a href="python3_inheritance.php">Inheritance</a></li><li><a href="python3_multiple_inheritance.php">Multiple Inheritance</a></li><li><a href="python3_magic_methods.php">Magic Methods and Operator Overloading</a></li><li><a href="python3_inheritance_example.php">OOP, Inheritance Example</a></li></ul>

</div>

<p>
<hr>
<h3>Output</h3>

In computer scienc, output is seen as the information produced by a computer program. The output can be perceived by the user.
<h3>Formatting</h3>
Formatting in computer science is a method of arranging data for storage or display. 
<br><br>
<hr>
This website is supported by:<br>
<a href="http://www.bodenseo.com/courses.php"><img style="width: 150px;" alt="Bodenseo,
Linux, courses and seminars"
		     src="images/bodenseo_python_training.gif"><br>Linux and Python Training Courses and Seminars</a>
<br>
<hr>
</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/python3_formatierte_ausgabe.php">Formatierte Ausgabe</a><h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="formatted_output.php">Formatted Output in Python 2.x</a><p>
<h3>Classroom Training Courses</h3>
The goal of this website is to provide educational material, 
allowing you to learn Python on your own.
Nevertheless, it is faster and more efficient to attend a "real" 
Python course in a classroom, with
an experienced trainer. So why not attend one of the live 
<a href="python_classes.php">Python courses</a> in Paris, London, Berlin, Munich
or Lake Constance by Bernd Klein, the author of this tutorial?
<br><br>
You can also check the   
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python Training courses
<img style="width: 150px;" alt="Bodenseo Kurse in Python"
		     src="images/bodenseo_stairs_to_python.png"></a>
		     delivered by Bodenseo and Bernd Klein.
<br><br>
You can book on-site classes at your company or organization, e.g. in England, Switzerland, Austria, Germany,
France, Belgium, the Netherlands, Luxembourg, Poland, UK, Italy and other locations in Europe.
<br><br>
<h3>Python3</h3>This is a tutorial in Python3, but this chapter of our course is available in a version for Python 2.x as well: <a href="formatted_output.php">Formatted Output in Python 2.x</a>
 </p>




    
</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="python3_print.php">Output with Print</a><br>
<LINK rel="prev" href="python3_print.php">Next Chapter: <a href="python3_functions.php">Functions</a><br>
<LINK rel="next" href="python3_functions.php"></div>
<h2>Formatted Output</h2>
<br><br>
<h3>Three Ways for a Nicer Output</h3>
<br>
<p>
<img class="imgright" src="images/Printer_in_1568.png" alt="Traditional Output with movable types" />

In this chapter of our Python tutorial we will have a closer look at the various ways of creating nicer output in Python. We present all the different ways, but we recommend that you should use the format method of the string class, which you will find at end of the chapter. "string format" is by far the most flexible and Pythonic approach.
<br><br>
So far we have used the print function in two ways, when we had to print out more than two values:
<ul>
<li>The easiest way, but not the most elegant one:<br>We used print with a comma separated list of values to print out the results, as we can see in the following example. All the values are separated by blanks, which is the default behaviour. We can change the default value to an arbitrary string, if we assign this string to the keyword parameter "sep" of the print function:

<pre>
>>> q = 459
>>> p = 0.098
>>> print(q, p, p * q)
459 0.098 44.982
>>> print(q, p, p * q, sep=",")
459,0.098,44.982
>>> print(q, p, p * q, sep=" :-) ")
459 :-) 0.098 :-) 44.982
>>> 
</pre>
<li>Alternatively, we can construe out of the values a new string by using the string concatenation operator:


<pre>
>>> print(str(q) + " " + str(p) + " " + str(p * q))
459 0.098 44.982
>>> 
</pre>

The second method is inferior to the first one in this example.
 

</ul>

<br><br>
<h3>The Old Way or the non-existing printf and sprintf</h3>
<br>
Is there a printf in Python? A burning question for Python newbies coming from C, Perl, Bash or other programming languages who have this statement or function. To answer that Python has a print function and no printf function is only one side of the coin or half of the truth. One can go as far as to say that this answer is not true. So there is a "printf" in Python? No, but the functionality of the "ancient" printf is contained in Python. To this purpose the modulo operator "%" is overloaded by the string class to perform string formatting. Therefore, it is often called string modulo (or somethimes even called modulus) operator, though it has not a lot in common with the actual modulo calculation on numbers. Another term for it is "string interpolation", because it interpolates various class types (like int, float and so on) into a formatted string. In many cases the string created via the string interpolation mechanism is  used for outputting values in a special way. But it can also be used for example to create the right format to put the data into a data base.
<br>
Since Python 2.6 has been introduced, the string method format should be used instead of this old-style formatting. Unfortunately, string modulo "%" is still available in Python3 and what is even worse, it is still widely used. That's why we cover it in great detail in this tutorial. You should be capable of understanding it, when you encounter it in some Python code. But it is very likely, that one day this old style of formatting will be removed from the language. So you should get used to str.format().
<br><br>
The following diagram depicts how the string modulo operator works:
<br><br>
<img src="images/string_modulo_overview.png" width="500" alt="General way of working of the string modulo operator" />
<br><br>
On the left side of the "string modulo operator" is the so-called format string and on the right side is a tuple with the content, which is interpolated in the format string. The values can be literals, variables or arbitrary arithmetic expressions. 

<br><br>
<img src="images/format_string_value_set.png" width="500" alt="General way of working of the string modulo operator, format string" />

The format string contains placeholders. There are two of those in our example: "%5d" and "%8.2f". 
<br><br>
The general syntax for a format placeholder is
<br><br>
<pre>
    %[flags][width][.precision]type 
</pre>
<br><br>
<img  class="imgright" src="images/string_modulo_float.png" width="200" alt="Explaining a float format" />
Let's have a look at the placeholders in our example. The second one "%8.2f" is a format description for a float number.
Like other placeholders, it is introduced with the "%" character. This is followed by the total number of digits the string should contain. This number includes the decimal point and all the digits, i.e. before and after the decimal point. Our float number 59.058 has to be formatted with 8 characters. The decimal part of the number or the precion is set to 2, i.e. the number following the "." in our placeholder. Finally, the last character "f" of our placeholder stands for "float".
<br><br>
If you look at the output, you will notice that the 3 decimal digits have been rounded. Furthermore, the number has been preceded in the output with 3 leading blanks.
<br><br>
The first placeholder "%5d" is used for the first component of our tuple, i.e. the integer 453. The number will be printed with 5 characters. As 453 consists only of 3 digits, the output is padded with 2 leading blanks. You may have expected a "%5i" instead of "%5d". Where is the difference? It's easy: There is no difference between "d" and "i" both are used for formatting integers.


The advantage or beauty of a formatted output can only be seen, if more than one line is printed with the same pattern. In the following picture you can see, how it looks, if 5 float numbers are printed with the placeholder "%6.2f" are printed insubsequent lines:
<br><br>
 <img   src="images/formatting_floats.png"  width="450" alt="formatting multiple floats" />

<br><br>
<table cellpadding="6" cellspacing="0" border="1" bgcolor="#F5F5F5">
  <thead>
    <tr>
      <th>Conversion</th>
      <th>Meaning</th>
      </tr>
    </thead>
  <tbody>
    <tr><td valign="baseline"><tt>d</tt></td>
        <td>Signed integer decimal.</td>
        </tr>
    <tr><td valign="baseline"><tt>i</tt></td>
        <td>Signed integer decimal.</td>
        </tr>
    <tr><td valign="baseline"><tt>o</tt></td>
        <td>Unsigned octal.</td>
        </tr>
    <tr><td valign="baseline"><tt>u</tt></td>
        <td>Unsigned decimal.</td>
        </tr>
    <tr><td valign="baseline"><tt>x</tt></td>
        <td>Unsigned hexadecimal (lowercase).</td>
        </tr>
    <tr><td valign="baseline"><tt>X</tt></td>
        <td>Unsigned hexadecimal (uppercase).</td>
        </tr>
    <tr><td valign="baseline"><tt>e</tt></td>
        <td>Floating point exponential format (lowercase).</td>
        </tr>
    <tr><td valign="baseline"><tt>E</tt></td>
        <td>Floating point exponential format (uppercase).</td>
        </tr>
    <tr><td valign="baseline"><tt>f</tt></td>
        <td>Floating point decimal format.</td>
        </tr>
    <tr><td valign="baseline"><tt>F</tt></td>
        <td>Floating point decimal format.</td>
        </tr>
    <tr><td valign="baseline"><tt>g</tt></td>
        <td>Same as "<tt>e</tt>" if exponent is greater than -4 or
              less than precision, "<tt>f</tt>" otherwise.</td>
        </tr>
    <tr><td valign="baseline"><tt>G</tt></td>
        <td>Same as "<tt>E</tt>" if exponent is greater than -4 or
              less than precision, "<tt>F</tt>" otherwise.</td>
        </tr>
    <tr><td valign="baseline"><tt>c</tt></td>
        <td>Single character (accepts integer or single character
              string).</td>
        </tr>
    <tr><td valign="baseline"><tt>r</tt></td>
        <td>String (converts any python object using
              <tt class="function">repr()</tt>).</td>
        </tr>
    <tr><td valign="baseline"><tt>s</tt></td>
        <td>String (converts any python object using
              <tt class="function">str()</tt>).</td>
        </tr>
    <tr><td valign="baseline"><tt>%</tt></td>
        <td>No argument is converted, results in a "<tt>%</tt>"
               character in the result.</td>
        </tbody>
</table>


<br><br>
The following examples show some example cases of the conversion rules from the table above:
<br>
<pre>
>>> print("%10.3e"% (356.08977))
 3.561e+02
>>> print("%10.3E"% (356.08977))
 3.561E+02
>>> print("%10o"% (25))
        31
>>> print("%10.3o"% (25))
       031
>>> print("%10.5o"% (25))
     00031
>>> print("%5x"% (47))
   2f
>>> print("%5.4x"% (47))
 002f
>>> print("%5.4X"% (47))
 002F
>>> print("Only one percentage sign: %% " % ())
Only one percentage sign: % 
>>> 
</pre>
<br>

<table cellpadding="6" cellspacing="0" border="1" bgcolor="#F5F5F5">
  <thead>
    <tr>
      <th>Flag</th>
      <th>Meaning</th>
      </tr>
    </thead>
  <tbody>
    <tr><td valign="baseline"><tt>#</tt></td>
        <td>Used with o, x or X specifiers the value is preceeded with 0, 0o, 0O, 0x or 0X respectively.
</td></tr>
    <tr><td valign="baseline"><tt>0</tt></td>
        <td  >The conversion result will be zero padded for numeric values.</td></tr>
    <tr><td valign="baseline"><tt>-</tt></td>
        <td>The converted value is left adjusted</td></tr>
    <tr><td valign="baseline"><tt>&nbsp;</tt></td>
        <td>If no sign (minus sign e.g.) is going to be written, a blank space is inserted before the value.</td></tr>
    <tr><td valign="baseline"><tt>+</tt></td>
        <td>A sign character ("<tt>+</tt>" or "<tt>-</tt>") will
             precede the conversion (overrides a "space" flag).</td></tr></tbody>
</table>
<br><br>
Examples:
<br><br>
<pre>
>>> print("%#5X"% (47))
 0X2F
>>> print("%5X"% (47))
   2F
>>> print("%#5.4X"% (47))
0X002F
>>> print("%#5o"% (25))
 0o31
>>> print("%+d"% (42))
+42
>>> print("% d"% (42))
 42
>>> print("%+2d"% (42))
+42
>>> print("% 2d"% (42))
 42
>>> print("%2d"% (42))
42
</pre>


Even though it may look so, the formatting is not part of the print function. If you have a closer look at our examples, you will see that we passed a formatted string to the print function.
Or to put it in outher words: If the string modulo operator is applied to a string, it returns a string. This string in turn is passed in our examples to the print function. So, we could have used the string modulo functionality of Python in a two layer approach as well, i.e. first create a formatted string, which will be assigned to a variable and this variable is passed to the print function:

<br>
<pre>
>>> s = "Price: $ %8.2f"% (356.08977)
>>> print(s)
Price: $   356.09
>>>
</pre>


<br><br>
<h3>The Pythonic Way: The string method "format"</h3>
<br>

The Python help function is not very helpful concerning the string format method. All it says is this:
<br><br>
<quote>
<pre>
 |  format(...)
 |      S.format(*args, **kwargs) -> str
 |      
 |      Return a formatted version of S, using substitutions from args and kwargs.
 |      The substitutions are identified by braces ('{' and '}').
 |  
</pre>
</quote>
<br><br>
Let's dive into this topic a little bit deeper:
The format method was added in Python 2.6. 

The general form of this method looks like this:
<br><br>
<pre>
template.format(p0, p1, ..., k0=v0, k1=v1, ...)
</pre>
<br>
The template (or format string) is a string which contains one or more format codes (fields to be replaced) embedded in constant text. The "fields to be replaced" are surrounded by curly braces {}. The curly braces and the "code" inside will be substituted with a formatted value from one of the arguments, according to the rules which we will specify soon. Anything else, which is not contained in curly braces wil be litterally printed, i.e. without any changes. If a brace character has to be printed, it has to be escaped by doubling it: {{ and }}.
<br><br>
There are two kinds of arguments for the .format() method. The list of arguments starts with zero or more positional arguments (p0, p1, ...), it may be followed by zero or more keyword arguments of the form name=value.
<br></br>
A positional parameter of the format method can be accessed by placing the index of the parameter after the opening brace, e.g. {0} acceses the first parameter, {1} the second one and so on. The index inside of the curly braces can be followed by a colon and a format string, which is similar to the natation of the string modulo, which we had discussed in the beginning of the chapter of our tutorial, e.g. {0:5d}
<br>
If the positional parameters are used in the order in which they are written, the positional argument specifiers inside of the braces can be omitted, so '{} {} {}' corresponds to to '{0} {1} {2}'. But they are needed, if you want to access them in different orders: '{2} {1} {0}'
<br><br>
The following diagram with an example usage depicts how the string method "format" works works for positional parameters:
<br><br>
<img src="images/format_method_positional_parameters.png" height="190" alt="General way of working of the format method with positional parameters" />

<br><br>
Examples of positional parameters:
<pre>
>>> "First argument: {0}, second one: {1}".format(47,11) 
'First argument: 47, second one: 11'
>>> "Second argument: {1}, first one: {0}".format(47,11) 
'Second argument: 11, first one: 47'
>>> "Second argument: {1:3d}, first one: {0:7.2f}".format(47.42,11) 
'Second argument:  11, first one:   47.42'
>>> "First argument: {}, second one: {}".format(47,11) 
'First argument: 47, second one: 11'
>>> # arguments can be used more than once:
... 
>>> "various precions: {0:6.2f} or {0:6.3f}".format(1.4148) 
'various precions:   1.41 or  1.415'
>>> 
</pre>

<br><br>
In the following example we demonstrate how keyword parameters can be used with the format method:

<pre>
>>> "Art: {a:5d},  Price: {p:8.2f}".format(a=453, p=59.058)
'Art:   453,  Price:    59.06'
>>> 
</pre>
<br><br>
<img src="images/format_method_keyword_parameters.png" height="190" alt="General way of working of the format method with keyword parameters" />

<br><br>
It's possible to left or right justify data with the format method. To this end, we can precede the formatting with a "<" (left justify) or ">" (right justify).
We demonstrate this with the following examples:
<br><br>
<pre>
>>> "{0:<20s} {1:6.2f}".format('Spam & Eggs:', 6.99)
'Spam & Eggs:           6.99'
>>> "{0:>20s} {1:6.2f}".format('Spam & Eggs:', 6.99)
'        Spam & Eggs:   6.99'
>>> "{0:>20s} {1:6.2f}".format('Spam & Ham:', 7.99)
'         Spam & Ham:   7.99'
>>> "{0:<20s} {1:6.2f}".format('Spam & Ham:', 7.99)
'Spam & Ham:            7.99'
>>> "{0:<20} {1:6.2f}".format('Spam & Ham:', 7.99)
'Spam & Ham:            7.99'
>>> "{0:>20} {1:6.2f}".format('Spam & Ham:', 7.99)
'         Spam & Ham:   7.99'
>>> 
</pre>

<br><br>

<table  cellpadding="6" cellspacing="0" border="1" bgcolor="#F5F5F5">
<colgroup>
<col width="14%" />
<col width="88%" />
</colgroup>
<thead valign="bottom">
<tr><th class="head">Option</th>
<th class="head">Meaning</th>
</tr>
</thead>
<tbody valign="top">
<tr><td><tt><span class="pre">'&lt;'</span></tt></td>
<td>The field will be left-aligned within the available
space. This is usually the default for strings.</td>
</tr>
<tr><td><tt><span class="pre">'&gt;'</span></tt></td>
<td>The field will be right-aligned within the
available space. This is the default for numbers.</td>
</tr>
<tr><td><tt><span class="pre">'='</span></tt></td>
<td>Forces the padding to be placed after the sign (if any)
but before the digits.  This is used for printing fields
in the form "+000000120". This alignment option is only
valid for numeric types.</td>
</tr>
<tr><td><tt><span class="pre">'^'</span></tt></td>
<td>Forces the field to be centered within the available
space.</td>
</tr>
</tbody>
</table>



<p>Unless a minimum field width is defined, the field width will always
be the same size as the data to fill it, so that the alignment option has no
meaning in this case.</p>

<br>
<p>Additionally, we can modify the formatting with the <em>sign</em> option, which is only valid for number types:</p>



<table cellpadding="6" cellspacing="0" border="1" bgcolor="#F5F5F5">
<colgroup>
<col width="14%" />
<col width="88%" />
</colgroup>
<thead valign="bottom">
<tr><th class="head">Option</th>
<th class="head">Meaning</th>
</tr>
</thead>
<tbody valign="top">
<tr><td><tt><span class="pre">'+'</span></tt></td>
<td>indicates that a sign should be used for both
positive as well as negative numbers.</td>
</tr>
<tr><td><tt><span class="pre">'-'</span></tt></td>
<td>indicates that a sign should be used only for negative
numbers, which is the default behavior.</td>
</tr>
<tr><td>space</td>
<td>indicates that a leading space should be used on
positive numbers, and a minus sign on negative numbers.</td>
</tr>
</tbody>
</table>

<br><br>

<h3>Using dictionionaries in "format"</h3>

We have seen in the previous chapters, that we have two ways to access the values to be formatted:

<ul>
<li>Using the position or the index:<br>
<pre>
>>> print("The capital of {0:s} is {1:s}".format("Ontario","Toronto"))
The capital of Ontario is Toronto
>>> 
</pre>
Just to mention it once more: We could have used empty curly braces in the previous example!
<li>Using keyword parameters:
<pre>
>>> print("The capital of {province} is {capital}".format(province="Ontario",capital="Toronto"))
The capital of Ontario is Toronto
>>>
</pre>
</ul>

The second case can be expressed with a dictionary as well, as we can see in the following code:

<pre>
>>> print("The capital of {province} is {capital}".format(**k))
The capital of Ontario is Toronto
>>> 
</pre>





Let's look at the following Python program:

<pre>
capital_country = {"United States" : "Washington", 
                   "US" : "Washington", 
                   "Canada" : "Ottawa",
                   "Germany": "Berlin",
                   "France" : "Paris",
                   "England" : "London",
                   "UK" : "London",
                   "Switzerland" : "Bern",
                   "Austria" : "Vienna",
                   "Netherlands" : "Amsterdam"}

print("Countries and their capitals:")
for c in capital_country:
    print("{country}: {capital}".format(country=c, capital=capital_country[c]))
</pre>

If we start this program, we get the following output:

<pre>
$ python3 country_capitals.py 
Countries and their capitals:
United States: Washington
Canada: Ottawa
Austria: Vienna
Netherlands: Amsterdam
Germany: Berlin
UK: London
Switzerland: Bern
England: London
US: Washington
France: Paris
</pre>

We can rewrite the previous example by using the dictionary directly. The output will be the same:
<pre>
capital_country = {"United States" : "Washington", 
                   "US" : "Washington", 
                   "Canada" : "Ottawa",
                   "Germany": "Berlin",
                   "France" : "Paris",
                   "England" : "London",
                   "UK" : "London",
                   "Switzerland" : "Bern",
                   "Austria" : "Vienna",
                   "Netherlands" : "Amsterdam"}

print("Countries and their capitals:")
for c in capital_country:
    format_string = c + ": {" + c + "}" 
    print(format_string.format(**capital_country))
</pre>
<br><br>

<h3>Using Local Variable Names in "format"</h3>


"locals" is a function, which returns a dictionary with the current scope's local variables, 
i.e- the local variable names are the keys of this dictionary and the corresponding values are the values of these variables:

<pre>
>>> a = 42
>>> b = 47
>>> def f(): return 42
... 
>>> locals()
{'a': 42, 'b': 47, 'f': &lt;function f at 0xb718ca6c&gt;, '__builtins__': &lt;module 'builtins' (built-in)&gt;, '__package__': None, '__name__': '__main__', '__doc__': None}
>>> 
</pre>

The dictionary returned by locals() can be used as a parameter of the string format method. This way we can use all the local variable names inside of a format string.
<br><br>
Continuing with the previous example, we can create the following output, in which we use the local variables a, b and f:

<pre>
>>> print("a={a}, b={b} and f={f}".format(**locals()))
a=42, b=47 and f=&lt;function f at 0xb718ca6c&gt;
</pre>
<br><br>
<h3>Other string methods for Formatting</h3>
The string class contains further methods, which can be used for formatting purposes as well: ljust, rjust, center and zfill
<br><br>

Let S be a string, the 4 methods are defined like this:
<ul>
<li>center(...):<br>
<pre>
S.center(width[, fillchar]) -> str
</pre>
Return S centered in a string of length width. Padding is done using the specified fill character.
The default value is a space.
<br><br>
Examples:
<pre>
>>> s = "Python"
>>> s.center(10)
'  Python  '
>>> s.center(10,"*")
'**Python**'
</pre>

<li>ljust(...):<br>
<pre>
 S.ljust(width[, fillchar]) -> str 
</pre>
Return S left-justified in a string of length "width". Padding is done using the specified fill character. If none is given, a space will be used as default.
<br><br>
Examples:
<pre>
>>> s = "Training"
>>> s.ljust(12)
'Training    '
>>> s.ljust(12,":")
'Training::::'
>>> 
</pre>

<li>rjust(...):<br>
<pre>
S.rjust(width[, fillchar]) -> str
</pre>
Return S right-justified in a string of length width. Padding is done using the specified fill character. The default value is again a space.
<br><br>
Examples:
<pre>
>>> s = "Programming"
>>> s.rjust(15)
'    Programming'
>>> s.rjust(15, "~")
'~~~~Programming'
>>> 
</pre>

<li>zfill(...):<br>
<pre> 
S.zfill(width) -> str
</pre>
Pad a string S with zeros on the left, to fill a field of the specified width. The string S is never truncated. This method can be easily emulated with rjust.
<br><br>
Examples:
<pre>
>>> account_number = "43447879"
>>> account_number.zfill(12)
'000043447879'
>>> # can be emulated with rjust:
... 
>>> account_number.rjust(12,"0")
'000043447879'
>>> 
</pre>
</ul>



<br><br>
</p>
<div id="contextlinks">Previous Chapter: <a href="python3_print.php">Output with Print</a><br>
<LINK rel="prev" href="python3_print.php">Next Chapter: <a href="python3_functions.php">Functions</a><br>
<LINK rel="next" href="python3_functions.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
