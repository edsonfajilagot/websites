<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: A Tutorial</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial on how to create a dynamic website with Python and Pylons" />
<meta name="Keywords" content="Python, dynamic, website, pylons, Python, tutorial" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li><a href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li class="active"><a id="current" href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/pylons_small.png" alt="box" />    <h2>Advanced Topics</h2>

<div class="menu">

<ul>
<li><a href="sys_module.php">Introduction into the sys module</a></li><li><a href="os_module_shell.php">Python and the Shell</a></li><li><a href="forking.php">Forks and Forking in Python</a></li><li><a href="threads.php">Introduction into Threads</a></li><li><a href="pipes.php">Pipe, Pipes and "99 Bottles of Beer"</a></li><li><a href="graphs_python.php">Graph Theory and Graphs in Python"</a></li><li><a href="pygraph.php">Graphs: PyGraph"</a></li><li><a href="networkx.php">Graphs: NetworkX"</a></li><li><a href="finite_state_machine.php">Finite State Machine in Python</a></li><li><a href="turing_machine.php">Turing Machine in Python</a></li><li><a href="numpy.php">NumPy Module</a></li><li><a href="matrix_arithmetic.php">Matrix Arithmetic</a></li><li><a href="linear_combinations.php">Linear Combinations</a></li><li><a href="text_classification_introduction.php">Introduction into Text Classification using Naive Bayes</a></li><li><a href="text_classification_python.php">Python Implementation of Text Classification</a></li><li><a href="towers_of_hanoi.php">Example for recursive Programming: Towers of Hanoi</a></li><li><a href="mastermind.php">Mastermind / Bulls and Cows</a></li><li><a href="dynamic_websites_wsgi.php">Creating dynamic websites with WSGI</a></li><li><a href="dynamic_websites.php">Dynamic websites with mod_python</a></li><li><a href="pylons.php">Dynamic websites with Pylons</a></li><li><a href="sql_python.php">Python, SQL, MySQL and SQLite</a></li><li><a href="python_scores.php">Python Scores</a></li></ul>

</div>

<p>
<br>
<hr>
<br>
<h3>Pylon, Word definition</h3>

It can be
<ul>
<li>an Egyptian gateway building, which is built in a truncated pyramidal form.</li>
<li>a tower, in the form of a steel lattice, for supporting a number 
of wires over a long span</li>
<li>a line of posts to mark the prescribed course of flight for an plane</li>
<li>a vertical structure used to mount external equipment such as engines and 
weapons externally on an airplane.

</ul>

But this is not, what we are talking about in this chapter.
<br>
<br>
<hr>
Supported by:<br>
<a href="http://www.bodenseo.com"><img style="width: 150px;" alt="Bodenseo, courses, seminars and training 
in Linux and Python"
		     src="images/bodenseo_python_training.gif"><br>Courses and Seminars for Linux and Python</a>
		     <br><br>		     

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
<h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

<i>"Some programming languages manage to absorb change, but withstand progress. "</i> (Alan Perlis)

<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="dynamic_websites.php">Dynamic websites with mod_python</a><br>
<LINK rel="prev" href="dynamic_websites.php">Next Chapter: <a href="sql_python.php">Python, SQL, MySQL and SQLite</a><br>
<LINK rel="next" href="sql_python.php"></div><br>
<h2>Creating dynamic websites with Python and Pylons</h2>
<br><br>
<h3>Introduction</h3>

<img class="imgright" width="350" src="images/pylons.png" alt="Pylons, image created by Bernd Klein" />  

<span style="color:red;background-color:light-grey;">
Please notice:
<br>Work on this topic is under process. (August 2014)
</span>
<br><br>


The picture on the right side is misleading: We are not talking about this kind of Pylons,
i.e. electricity pylons, or transmission towers, used to support an overhead power line.
<br><br>
But their is some interesting aspect in this comparison. It is a set of web application 
frameworks written in Python. So it can be seen as the steel lattice tower of an electricity
pylon, but it is not supporting power lines but web pages. James Gardner, a co-founder of Pylons,
defined this framework as  "<i>Pylons is a lightweight web framework emphasizing flexibility and rapid 
development using standard tools from the Python community.</i>"
<br><br>
We will demonstrate in simple examples - starting with the inevitable "Hello World" project - how to use it. 
We will also introduce the usage of Makos.


<br>
<br>
<h3>Installation</h3>

Before you can use Pylons, you have to install it. If you use Debian, Ubuntu or Mint, all you have to do
is execute the following code on a command shell:

<pre>
apt-get install python-pylons
</pre>

You are able to create your first Pylons project now:

<pre>
$ paster create --template=pylons MyProject
</pre>

You will be asked two questions and you can answer by keeping the default:

<pre>
Enter template_engine (mako/genshi/jinja2/etc: Template language) ['mako']: 
Enter sqlalchemy (True/False: Include SQLAlchemy configuration) [False]: 
</pre>


We have created now a directory MyProject, which contains the following files and subdirectories:

<ul>
<li>development.ini</li>
<li>ez_setup.py</li>
<li>MANIFEST.in</li>
<li>myproject</li>
<li>MyProject.egg-info</li>
<li>README.txt</li>
<li>setup.cfg</li>
<li>setup.py</li>
<li>test.ini</li>
</ul>

The content of the subdirectory myproject looks like this:

<ul>
<li>config<br>contains the files </li>
<li>controllers</li>
<li>__init__.py</li>
<li>__init__.pyc</li>
<li>lib</li>
<li>model</li>
<li>public</li>
<li>templates</li>
<li>tests</li>
<li>websetup.py</li>
</ul>




<pre>
cd MyProject
paster serve --reload development.ini
</pre>

<br>
Now the web server is running. If you visit the URL http://localhost:5000/ with a browser of your choice, you will
see the following welcome screen:
<br><br>

<img width=600 src="images/pylons_welcome_screen.png" alt="Pylons Welcome Screen" />  

<br><br>
It's generated from ./myproject/public/index.html inside of your MyProject directory.

<br><br>

<h3>Static Pages</h3>

You can put other html files into the directory ./myproject/public/. These files can be visited by
the web browser as well. You can save the following html code as python_rabbit.html:

<br><br>

<pre>
&lt;html&gt;
&lt;head&gt;
&lt;title&gt;The Python and the Rabbit&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;h3&gt;Little Girl buys a Rabbit&lt;/h3&gt;
A precious little girl walks into a pet shop and asks in the
sweetest little lisp, "Excuthe me, mithter, do you keep widdle wabbits?"
&lt;br&gt;
As the shopkeeper's heart melts, he gets down on his knees, so that he's
on her level, and asks, "Do you want a widdle white wabby or a thoft and
fuwwy bwack wabby or maybe one like that cute widdle bwown wabby over
there?"
&lt;br&gt;
She, in turn blushes, rocks on her heels, puts her hands on her knees,
leans forward and says in a quiet voice, "I don't fink my pet python
weally gives a thit."
&lt;/body&gt;
&lt;/html&gt;
</pre>

You can visit the URL "http://localhost:5000/python_rabbit.html" and the html file above will
be rendered:
<br><br>
<img width=600 src="images/little_girl_and_rabbit.png" alt="Little Girl and Rabbit" />
<br><br>

Any files in the directory "public" are treated as static files. It may contain subdirectories as
well, which are part of the URL in the usual way. If we create a subdirectory "petshop" in "public",
we will receive a "404 Not Found" error, unless we create an index.html file as well and place it
inside of the subdirectory, in our case "petshop". So, there is no directory index default view, as we
can have it with Apache. This is for security reasons.
<br><br>
We will create now the subdirectory "petshop" and inlcude the following index.html file:
<br><br>

<pre>
&lt;html&gt;
&lt;head&gt;
&lt;title&gt;The Ultimate Petshop&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;h3&gt;The Ultimate Petshop&lt;/h3&gt;
The ideal pet for little girls: A Python snake
&lt;br&gt;&lt;br&gt;
Please, visit the &lt;a href="../python_rabbit.html"&gt;Python and the Rabbit&lt;/a&gt; joke!

&lt;/body&gt;
&lt;/html&gt;
</pre>

Visiting "http://localhost:5000/petshop/" or "http://localhost:5000/petshop/index.html", we will
encounter the following content:

<br><br>
<img width=600 src="images/petshop.png" alt="Petshop" />
<br><br>

<h3>Getting Dynamic with Controllers</h3>

We will create now a dynamic "Hello World" application by creating a controller in our project.
The controller is able to handle requests.  

We can create the controller with the following command:

<pre>
$ paster controller hello
</pre>

If we visit the URL http://localhost:5000/hello/index we will get a website with the content "Hello World":
<br><br>
<img width=600 src="images/chrome_hello.png" alt="Hello World with Pylons controller" />

<br><br>

We want to change our application into a multilingual website, i.e. visitors should be greeted in their 
languages. To this purpose we will have to change the file hello.py, which can be found in 
MyProject/myproject/controllers/:

<pre>
import logging

from pylons import request, response, session, tmpl_context as c, url
from pylons.controllers.util import abort, redirect

from myproject.lib.base import BaseController, render

log = logging.getLogger(__name__)

class HelloController(BaseController):

    def index(self):    
        # Return a rendered template
        #return render('/hello.mako')
        # or, return a string
        return 'Hello World'
</pre>

We will change the index method of the HelloController class:

<pre>
    def index(self, id=None):
        # Return a rendered template
        #return render('/hello.mako')
        # or, return a string
        if id == "fr":
            return 'Bonjour Monde'
        if id == "de":
            return 'Hallo Welt'  
        if id == "it":
            return 'Ciao mondo'      
        return 'Hello World'
</pre>

<br><br>
Calling the URL "http://localhost:5000/hello/index" will still return "Hello World", but adding "/de"
- i.e.  http://localhost:5000/hello/index/de - to the previous URL will return "Hallo Welt". 

<br><br>
<h3>Mako Templates</h3>

You may have noticed the commented line "#return render('/hello.mako')". If we uncomment this line,
the server will use a mako template "hello.mako" or better it will try to use a template. This template is supposed 
to be located in the directory "myproject/templates/". So far this directory is empty. Uncommenting the line
will create the following error message in your browser window:
<br><br>
<pre>
WebError Traceback:
-> TopLevelLookupException: Cant locate template for uri '/hello.mako' 
</pre>


<br><br>
A Mako is a template library - also called a template engine - written in Python. 
It is the default template language included with the Pylons and Pyramid web frameworks. 
Mako's syntax and API borrows from other approaches, e.g. Django, Jinja2, Myghty, and Genshi. 
Mako is an embedded Python language, used for Python server pages. 
<br><br>
A Mako template contains various kind of content, for example XML, HTML, email text, and so on. 
<br><br>
A template can contain directives which represent variable or expression 
substitutions, control structures, or blocks of Python code. It may
also contain tags that offer additional functionality. 
A Mako is compiled into real Python code. 
<br><br>

The easiest possible Mako template consists solely of html code. The following Mako template is statically 
greeting all friends:

<pre>
&lt;html&gt;
&lt;head&gt;
  &lt;title&gt;Greetings&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
  &lt;h1&gt;Greetings&lt;/h1&gt;
  &lt;p&gt;Hello my friends!&lt;/p&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>

We change our hello.py in the directory "controllers" to the following code:

<pre>
from myproject.lib.base import BaseController, render

class HelloController(BaseController):

    def index(self, id=None):
        # Return a rendered template
        return render('/hello.mako')
</pre>

<br><br>
We have to save it in the templates subdirectory. The new page looks like this on a chromium browser:
<br><br>

<img width=600 src="images/template1.png" alt="Hello my friends with a Mako Template" />

<br><br>

This introduction is about dynamic web pages with Pylons, so we have to personalize our greeting. 
At first, we want to demonstrate how to use Python variables inside of a template.
To this purpose, the tmpl_context is available in the pylons module, and refers to the template context. 
Objects attached to it are available in the template namespace as tmpl_context.
In most cases tmpl_context is aliased as c in controllers and templates for convenience. Our hello.py
needs to import tmpl_context and we set c.name to "Frank":

<pre>
from pylons import tmpl_context as c
from myproject.lib.base import BaseController, render


class HelloController(BaseController):

    def index(self, id=None):
        c.name = "Frank"
        # Return a rendered template
        return render('/hello.mako')
</pre>

The output in a broser hasn't changed dramatically. Just "Hello Frank" instead of "Hello my friends!".
Admittedly, still not very dynamical!
<br><br>
But we can use the URL with our id parameter again:

<pre>
from pylons import tmpl_context as c
from myproject.lib.base import BaseController, render


class HelloController(BaseController):

    def index(self, id=None):
        c.name = id if id else "my friends"
        # Return a rendered template
        return render('/hello.mako')
</pre>

<br><br>

Visiting http://localhost:5000/hello/index/Frank renders the output "Hello Frank!", whereas the URL 
http://localhost:5000/hello/index will produce "Hello my friends!"
<br><br>


<h3>Mapping the root URL</h3>

We have seen, that we can put various static html files under the root directory "myproject/public/index.html" 
of our project. We saw, that index.html of the public directory is the own which is shown, if we point the 
browser to http://localhost:5000/

You may want to have a dynamic page right at the root. So, we have to map the root URL http://localhost:5000/
to a controller action. This can be done by modifying the routing.py file in the config directory. If you
look at this file, you will find a comment line "<tt># CUSTOM ROUTES HERE</tt>". You have to add the following 
line after this line:

<pre>
    # CUSTOM ROUTES HERE

    map.connect('/', controller='hello', action='index')
</pre>

There is one more thing you shouldn't forget: You have to remove the index.html file in public. Otherwise
this file will be still served.





<br><br>

<br><br>
<div id="contextlinks">Previous Chapter: <a href="dynamic_websites.php">Dynamic websites with mod_python</a><br>
<LINK rel="prev" href="dynamic_websites.php">Next Chapter: <a href="sql_python.php">Python, SQL, MySQL and SQLite</a><br>
<LINK rel="next" href="sql_python.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
