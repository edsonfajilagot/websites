<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<!-- Dieses Tag in den Head-Bereich oder direkt vor dem schließenden Body-Tag einfügen -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>



<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script><title>Python Tutorial: Sequential Data Types</title>
<meta http-equiv="content-type" content="text/html; charset="ISO-8859-1">
<meta name="Description" content="Tutorial on Sequential Data Types of Python:  introducing strings, lists and tuples with hands-on examples." />
<meta name="Keywords" content="Python, introduction, sequential, data types, sequence,
lists, slicing" />

<link href="favicon.ico" rel="shortcut icon">

<link href="moderna.css" rel="stylesheet" type="text/css" />
<link href="moderna_print.css" media="print" rel="stylesheet" type="text/css" />

</head>

<body>

<div id="container">

<div id="banner">
<!-- <a href="impressum.php">Impressum</a> | <a href="mailto:">contact</a> | --><h1>Python Course</h1>

</div>

	<!-- Begin Top Menu -->
<ul id="navlist">
<li><a href="index.php" >Home</a></li><li class="active"><a id="current" href="course.php" >Python 2 Tutorial</a></li><li><a href="python3_course.php" >Python 3 Tutorial</a></li><li><a href="advanced_topics.php" >Advanced Topics</a></li><li><a href="python_books.php" >Python Books</a></li><li><a href="python_tkinter.php" >Tkinter Tutorial</a></li><li><a href="contact.php" rel="nofollow">Contact</a></li>                          
</ul>
	<!-- End Top Menu -->
<div id="sidebar-a">
<img class="border" src="images/infinite_python.jpg" alt="box" />    <h2>Python 2 Tutorial</h2>

<div class="menu">

<ul>
<li><a href="history_and_philosophy.php">History and Philosophy of Python</a></li><li><a href="why_python.php">Why Python</a></li><li><a href="interactive.php">Interactive Mode</a></li><li><a href="execute_script.php">Execute a Script</a></li><li><a href="blocks.php">Structuring with Indentation</a></li><li><a href="variables.php">Data Types and Variables</a></li><li><a href="operators.php">Operators</a></li><li><a href="input.php">input and raw_input via the keyboard</a></li><li><a href="conditional_statements.php">Conditional Statements</a></li><li><a href="loops.php">While Loops</a></li><li><a href="for_loop.php">For Loops</a></li><li><a href="formatted_output.php">Formatted output</a></li><li><a href="print.php">Output with Print</a></li><li><a href="sequential_data_types.php">Sequential Data Types</a></li><li><a href="dictionaries.php">Dictionaries</a></li><li><a href="sets_frozensets.php">Sets and Frozen Sets</a></li><li><a href="deep_copy.php">Shallow and Deep Copy</a></li><li><a href="functions.php">Functions</a></li><li><a href="recursive_functions.php">Recursion and Recursive Functions</a></li><li><a href="tests.php">Tests, DocTests, UnitTests</a></li><li><a href="memoization.php">Memoization and Decorators</a></li><li><a href="passing_arguments.php">Passing Arguments</a></li><li><a href="namespaces.php">Namespaces</a></li><li><a href="global_vs_local_variables.php">Global vs. Local Variables</a></li><li><a href="file_management.php">File Management</a></li><li><a href="modules_and_modular_programming.php">Modular Programming and Modules</a></li><li><a href="re.php">Introduction in Regular Expressions</a></li><li><a href="re_advanced.php">Regular Expressions, Advanced</a></li><li><a href="lambda.php">Lambda Operator, Filter, Reduce and Map</a></li><li><a href="list_comprehension.php">List Comprehension</a></li><li><a href="generators.php">Generators</a></li><li><a href="exception_handling.php">Exception Handling</a></li><li><a href="object_oriented_programming.php">Object Oriented Programming</a></li><li><a href="inheritance_example.php">Inheritance Example</a></li></ul>

</div>

<p>
<h3>Mythology</h3>
The first great achievement of Apollo was to slay the huge serpent Python. In some texts 
Python is an enormous dragon and not a serpent. 
<br>  
But who was this mythical creature? Python was created out of the slime and mud left after 
the great flood. She was  appointed by Gaia (Mother Earth) to guard the oracle of Delphi, 
known as Pytho. After having defeated Python Apollo remade
her former home and the oracle as his own.
<br>

</div><div id="sidebar-b"><img style="width: 150px;" alt="Python-Logo"
		     src="images/python-logo.png"><!-- Dieses Tag dort einf�gen, wo die +1-Schaltfl�che dargestellt werden soll -->
<g:plusone></g:plusone>
<br><br>

<div class="fb-like" data-href="www.python-course.eu" data-send="false" data-layout="button_count" 
data-width="130" data-show-faces="true" data-action="recommend"></div>

<br><br>
This topic in German / Deutsche �bersetzung:
    <a href="http://www.python-kurs.eu/sequentielle_datentypen.php">Sequentielle Datentypen</a><h3>Python 2.7</h3>This tutorial deals with Python Version 2.7<br>This chapter from our course is available in a version for Python3: <a href="python3_sequential_data_types.php">Sequential Data Types</a><h3>Classroom Training Courses</h3>
<p>
This website contains a free and extensive online tutorial by Bernd Klein, using
material from his classroom <a href="python_classes.php">Python courses</a>.
<br><br>
If you are interested in an instructor-led classroom training, you may have a look at the 
<a href="http://www.bodenseo.com/courses.php?topic=Python">Python courses
<br><img style="width: 150px;" 
alt="Bodenseo, Python and other courses and seminars"
		     src="images/classroom_training_courses.jpg">
</a>
by Bernd Klein at Bodenseo.
<font size="1">� kabliczech - Fotolia.com</font>
 </p>



<h3>Quote of the Day:</h3>
<p>

Computers are like bikinis. They save people a lot of guesswork.<br>
(Sam Ewing)
<br><hr>

<h3>Advantages of Python</h3>
<p>
<ul>
<li>Easy and fast to learn</li>
<li>Simple to get support</li>
<li>Python's syntax is clear and readable</li>
<li>Fast to Code, i.e. it is easier and faster to code a problem in Python than in 
C, C++ or Java, just to mention a few other languages</li>
<li>Python is portable, i.e. it runs on multiple platforms and systems, like e.g. Linux 
and Microsoft Windows</li>
<li>Object oriented</li>
<li>It's trendy, i.e more and more successful companies switch to Python, like Google did a long
time ago.</li>
</ul>
</p>


</p></div>
<div id="content">

<div id="contextlinks">Previous Chapter: <a href="print.php">Output with Print</a><br>
<LINK rel="prev" href="print.php">Next Chapter: <a href="dictionaries.php">Dictionaries</a><br>
<LINK rel="next" href="dictionaries.php"></div>
<h2>Sequential Data Types</h2>
<h3>Strings</h3>
A String can be seen as a sequence of characters, 
which can be expressed in several ways:
<ul>
<li>single quotes (')<br>
'This a a string in single quotes'</li>
<li>double quotes (")
"Miller's dog bites"</li>
<li>triple quotes(''') oder (""")
'''She said: "I'dont mind, if Miller's dog bites"'''</li>
</ul>

<h3>Indexing strings</h3>
<p>
Let's look at the string "Hello World":
<img class="imgleft" src="images/string_aufbau.gif" alt="Diagram string Hello World"/>
You can see, that the characters of a string are enumerated from left to right
starting with 0. If you start from the right side, the enumeration is started with
-1.
<br><br>Every character of a string can be accessed by putting the index after the
string name in square brackets, as can be seen in the following example:
<pre>
>>> txt = "Hello World"
>>> txt[0]
'H'
>>> txt[4]
'o'
</pre>
Negative indices can be used as well. In this case we start counting from right, 
starting with -1:

<pre>
  >>> txt[-1]
  'd'
  >>> txt[-5]
  'W'
</pre>

<h3>Python Lists</h3>
The list is a most versatile data type in Python. It can be written as 
a list of comma-separated items (values) between square brackets. 
Lists are related to arrays of programming languages like C, C++ or Java,
but Python lists are by far more flexible than "classical" arrays.
For example items in a list need not all have the same type. Furthermore 
lists can grow in a program run, while in C the size of an array has to be 
fixed at compile time.
<br><br>
An example of a list:
<pre>
languages = ["Python", "C", "C++", "Java", "Perl"]
</pre>

There are different ways of accessing the elements of a list. 
Most probably the easiest way for C programmers will be through indices, i.e.
the numbers of the lists are enumerated starting with 0:
<pre>
>>> languages = ["Python", "C", "C++", "Java", "Perl"]
>>> languages[0]
'Python'
>>> languages[1]
'C'
>>> languages[2]
'C++'
>>> languages[3]
'Java'
</pre>
The previous example of a list has been a list with elements of equal data types. 
But as we had before, lists can have various data types. The next example shows this:
<pre>
group = ["Bob", 23, "George", 72, "Myriam", 29]
</pre>

<h3>Sublists</h3>
Lists can have sublists as elements. These Sublists may contain sublists as well, i.e.
 lists can be recursively constructed by sublist structures.
<pre>
>>> person = [["Marc","Mayer"],["17, Oxford Str", "12345","London"],"07876-7876"]
>>> name = person[0]
>>> print name
['Marc', 'Mayer']
>>> first_name = person[0][0]
>>> print first_name
Marc
>>> last_name = person[0][1]
>>> print last_name
Mayer
>>> address = person[1]
>>> street = person[1][0]
>>> print street
17, Oxford Str
</pre>
The next example shows a more complex list with a deeply structured list:
<pre>
>>> complex_list = [["a",["b",["c","x"]]]]
>>> complex_list = [["a",["b",["c","x"]]],42]
>>> complex_list[0][1]
['b', ['c', 'x']]
>>> complex_list[0][1][1][0]
'c'
</pre>

<h3>Tuples</h3>
A tuple is an immutable list, i.e. a tuple cannot be changed in any way once it has
been created. A tuple is defined analogously to lists, except that the set of 
elements is enclosed in parentheses instead of square brackets. The rules for 
indices are the same as for lists. Once a tuple has been created, you can't add elements
to a tuple or remove elements from a tuple.
<br><br>
Where is the benefit of tuples?
<ul>
<li>Tuples are faster than lists.</li>
<li>If you know, that some data doesn't have to be changed, you should use tuples
instead of lists, because this protect your data against accidental changes to these
data.</li>
<li>Tuples can be used as keys in dictionaries, while lists can't.</li>
</ul> 
 The following example shows how to define a tuple and how to access a tuple. 
 Furthermore we can see, that we raise an error, if we try to assign a new value
 to an element of a tuple:
<pre>
>>> t = ("tuples", "are", "immutable")
>>> t[0]
'tuples'
>>> t[0]="assignments to elements are not possible"
Traceback (most recent call last):
  File "&lt;stdin&gt;", line 1, in &lt;module&gt;
TypeError: 'tuple' object does not support item assignment
</pre>

<h3>Generalization</h3>
<p>
<img class="imgright" src="images/green_tree_python3_250.jpg" alt="Python endless"/>
Lists and strings have many common properties, e.g. the elements of a list or the 
characters of a string appear in a defined order and can be accessed through indices.
There are other data types with similiar properties like tuple, buffer and xrange.
In Python these data types are called <b>"sequence data types"</b> or 
<b>"sequential data types"</b>. 

<br><br>

Operators and methods are the same for "sequence data types", as we will see in the
following text.
</p>


</p>
<h3>Slicing</h3>
<p>
In many programming languages it can be quite tough to slice a part of a string and
even tougher, if you like to address a "subarray". Python make it very easy with its
slice operator. Slicing is often better known as substring or substr.
<br><br>
When you want to extract part of a string, or some part of a list, you use in Python
the slice operator. The syntax is simple. Actually it looks a little bit like accessing
a single element with an index, but instead of just one number we have more, separated 
with a colon ":". We have a start and an end index, one or both of them may be missing.
It's best to study the mode of operation of slice by having a look at examples:
<pre>
>>> str = "Python is great"
>>> first_six = str[0:6]
>>> first_six
'Python'
>>> starting_at_five = str[5:]
>>> starting_at_five
'n is great'
>>> a_copy = str[:]
>>> without_last_five = str[0:-5]
>>> without_last_five
'Python is '
>>> 
</pre>

Syntactically, there is no difference on lists:
<pre>
>>> languages = ["Python", "C", "C++", "Java", "Perl"]
>>> some_languages = languages[2:4]
>>> some_languages
['C++', 'Java']
>>> without_perl = languages[0:-1]
>>> without_perl
['Python', 'C', 'C++', 'Java']
>>> 
</pre> 

<br>
Slicing works with three arguments as well. If the third argument is for example 3, 
only every third element of the list, string or tuple from the range of the first
two arguments will be taken. 
<br><br>
If s is a sequential data tpye, it works like this:<br>
<pre>
s[begin: end: step]
</pre>

The resulting sequence consists of the following elements:
<pre>
s[begin], s[begin + 1 * step], ... s[begin + i * step] for all (begin + i * step) < end.
</pre>
In the following example we define a string and we print every third character of
this string:
<br>
<pre>
>>> str = "Python under Linux is great"
>>> str[::3]
'Ph d n  e'
</pre>


</p>
<h3>Length</h3>
<p>
<img class="imgleft" src="images/metermass.gif" alt="Length of a sequence"/>
The length of a sequence, i.e. a list, a string or a tuple, can be determined with the 
function len(). For strings it counts the number of characters and for lists or tuples
the number of elements are counted, whereas a sublist counts as 1 element.

<pre>
>>> txt = "Hello World"
>>> len(txt)
11
>>> a = ["Swen", 45, 3.54, "Basel"]
>>> len(a)
4
</pre>

</p>

<h3>Concatenation of Sequences</h3>
Combining two sequences like strings or lists is as easy as adding two numbers.
Even the operator sign is the same.
<br>
The following example shows how to concatenate two strings into one:
<pre>
>>> firstname = "Homer"
>>> surname = "Simpson"
>>> name = firstname + " " + surname
>>> print name
Homer Simpson
>>>  
</pre>

It's as simple for lists:
<pre>
>>> colours1 = ["red", "green","blue"]
>>> colours2 = ["black", "white"]
>>> colours = colours1 + colours2
>>> print colours
['red', 'green', 'blue', 'black', 'white']
</pre>
The augmented assignment "+=" which is well known for arithmetic assignments work 
for sequences as well. 
 
<pre>
s += t
</pre>
is syntactically the same as:
<pre>
s = s + t
</pre>
But it is only syntactically the same. The implementation is different:
In the first case the left side has to be evaluated only once. 
Augment assignments may be applied for mutable objects as an optimization.
<h3>Checking if an Element is Contained in List</h3>
<p>
It's easy to check, if an item is contained in a sequence. We can use the 
"in" or the "not in" operator for this purpose.
<br>
The following example shows how this operator can be applied:
<pre>
>>> abc = ["a","b","c","d","e"]
>>> "a" in abc
True
>>> "a" not in abc
False
>>> "e" not in abc
False
>>> "f" not in abc
True
>>> str = "Python is easy!"
>>> "y" in str
True
>>> "x" in str
False
>>> 
</pre>
 </p>

<h3>Repetitions</h3>
<p>
So far we had a "+" operator for sequences. There is a "*" operator available as well.
Of course there is no "multiplication" between two sequences possible. "*" is defined
for a sequence and an integer, i.e. s * n or  n * s.
<br>
It's a kind of abbreviation for an n-times concatenation, i.e.
<pre>
str * 4
</pre>
is the same as
<pre>
str + str + str + str
</pre>
Further examples:
<pre>
>>> 3 * "xyz-"
'xyz-xyz-xyz-'
>>> "xyz-" * 3
'xyz-xyz-xyz-'
>>> 3 * ["a","b","c"]
['a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c']
</pre>

The augmented assignment for "*" can be used as well:
<br>
s *= n	is the same as  s = s * n.
<br><br><br>
</p>
<h3>The Pitfalls of Repetitions</h3>
In our previous examples we applied the repetition operator on strings and flat lists. We can apply 
it to nested lists as well:
<pre>
>>> x = ["a","b","c"]
>>> y = [x] * 4
>>> y
[['a', 'b', 'c'], ['a', 'b', 'c'], ['a', 'b', 'c'], ['a', 'b', 'c']]
>>> y[0][0] = "p"
>>> y
[['p', 'b', 'c'], ['p', 'b', 'c'], ['p', 'b', 'c'], ['p', 'b', 'c']]
>>> 
</pre>
<img class="imgleft" src="images/repetitions.png" alt="Repetitions with references"/>
This result is quite astonishing for beginners of Python programming. We have assigned a new value to 
the first element of the first sublist of y, i.e. y[0][0] and we have "automatically" changed the first
elements of all the sublists in y, i.e. y[1][0], y[2][0], y[3][0]
 <br>The reason is, that the repetition operator "* 4" creates 4 references to the list x:
and so it's clear that every element of y is changed, if we apply a new 
 value to y[0][0].

<div id="contextlinks">Previous Chapter: <a href="print.php">Output with Print</a><br>
<LINK rel="prev" href="print.php">Next Chapter: <a href="dictionaries.php">Dictionaries</a><br>
<LINK rel="next" href="dictionaries.php"></div><br><br><br>

</div>
<div id="footer">  &copy; 2011 - 2014 <a href="http://www.bklein.de">Bernd Klein</a>,
Bodenseo; 
Design by Denise Mitchinson adapted for python-course.eu by Bernd Klein</div>
</div>
</body>
</html>
