


<!DOCTYPE html>
<html lang="en" class="">
  <head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# object: http://ogp.me/ns/object# article: http://ogp.me/ns/article# profile: http://ogp.me/ns/profile#">
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    
    
    <title>ev3sources/lms2012/d_bt/Linuxmod_AM1808/d_bt.c at 7357369b6ebae4ee62001f3964f0f5fd0cce3c32 · mindboards/ev3sources · GitHub</title>
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-144.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144.png">
    <meta property="fb:app_id" content="1401488693436528">

      <meta content="@github" name="twitter:site" /><meta content="summary" name="twitter:card" /><meta content="mindboards/ev3sources" name="twitter:title" /><meta content="LEGO MINDSTORMS EV3 source code. Contribute to ev3sources development by creating an account on GitHub." name="twitter:description" /><meta content="https://avatars3.githubusercontent.com/u/2578456?v=3&amp;s=400" name="twitter:image:src" />
      <meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="https://avatars3.githubusercontent.com/u/2578456?v=3&amp;s=400" property="og:image" /><meta content="mindboards/ev3sources" property="og:title" /><meta content="https://github.com/mindboards/ev3sources" property="og:url" /><meta content="LEGO MINDSTORMS EV3 source code. Contribute to ev3sources development by creating an account on GitHub." property="og:description" />
      <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">
    <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">
    <link rel="assets" href="https://assets-cdn.github.com/">
    
    <meta name="pjax-timeout" content="1000">
    

    <meta name="msapplication-TileImage" content="/windows-tile.png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="selected-link" value="repo_source" data-pjax-transient>
      <meta name="google-analytics" content="UA-3769691-2">

    <meta content="collector.githubapp.com" name="octolytics-host" /><meta content="collector-cdn.github.com" name="octolytics-script-host" /><meta content="github" name="octolytics-app-id" /><meta content="70C64D49:7BA1:2233299:556C2623" name="octolytics-dimension-request_id" />
    
    <meta content="Rails, view, blob#blame" name="analytics-event" />
    <meta class="js-ga-set" name="dimension1" content="Logged Out">
    <meta class="js-ga-set" name="dimension2" content="Header v3">
    <meta name="is-dotcom" content="true">
      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

    
    <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">


    <meta content="authenticity_token" name="csrf-param" />
<meta content="XGtEcHFIxyvQveNS0G3ASik9zxygFEsnQJ5GyZEJlNbsHaAVqCfugOuumzLNgtoobs1PqkUa3DkDHcgp9Tnh1Q==" name="csrf-token" />

    <link href="https://assets-cdn.github.com/assets/github/index-7e77e66f8436e66d6a9791d7a09cec15828e9e04a0ad97cf73e83223f8b9cb3a.css" media="all" rel="stylesheet" />
    <link href="https://assets-cdn.github.com/assets/github2/index-5df271cf586eee5e48a88e30cdb6b5c32413ce1d7337835a905fc8c16294237e.css" media="all" rel="stylesheet" />
    
    


    <meta http-equiv="x-pjax-version" content="840467a6cd0c672c678f4fd42f529999">

            <meta content="noindex, nofollow" name="robots" />

  <meta name="description" content="LEGO MINDSTORMS EV3 source code. Contribute to ev3sources development by creating an account on GitHub.">
  <meta name="go-import" content="github.com/mindboards/ev3sources git https://github.com/mindboards/ev3sources.git">

  <meta content="2578456" name="octolytics-dimension-user_id" /><meta content="mindboards" name="octolytics-dimension-user_login" /><meta content="11771262" name="octolytics-dimension-repository_id" /><meta content="mindboards/ev3sources" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="11771262" name="octolytics-dimension-repository_network_root_id" /><meta content="mindboards/ev3sources" name="octolytics-dimension-repository_network_root_nwo" />
  <link href="https://github.com/mindboards/ev3sources/commits/7357369b6ebae4ee62001f3964f0f5fd0cce3c32.atom" rel="alternate" title="Recent Commits to ev3sources:7357369b6ebae4ee62001f3964f0f5fd0cce3c32" type="application/atom+xml">

  </head>


  <body class="logged_out  env-production  vis-public">
    <a href="#start-of-content" tabindex="1" class="accessibility-aid js-skip-to-content">Skip to content</a>
    <div class="wrapper">
      
      
      


        
        <div class="header header-logged-out" role="banner">
  <div class="container clearfix">

    <a class="header-logo-wordmark" href="https://github.com/" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
      <span class="mega-octicon octicon-logo-github"></span>
    </a>

    <div class="header-actions" role="navigation">
        <a class="btn btn-primary" href="/join" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
      <a class="btn" href="/login?return_to=%2Fmindboards%2Fev3sources%2Fblame%2F7357369b6ebae4ee62001f3964f0f5fd0cce3c32%2Flms2012%2Fd_bt%2FLinuxmod_AM1808%2Fd_bt.c" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
    </div>

    <div class="site-search repo-scope js-site-search" role="search">
      <form accept-charset="UTF-8" action="/mindboards/ev3sources/search" class="js-site-search-form" data-global-search-url="/search" data-repo-search-url="/mindboards/ev3sources/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
  <label class="js-chromeless-input-container form-control">
    <div class="scope-badge">This repository</div>
    <input type="text"
      class="js-site-search-focus js-site-search-field is-clearable chromeless-input"
      data-hotkey="s"
      name="q"
      placeholder="Search"
      data-global-scope-placeholder="Search GitHub"
      data-repo-scope-placeholder="Search"
      tabindex="1"
      autocapitalize="off">
  </label>
</form>
    </div>

      <ul class="header-nav left" role="navigation">
          <li class="header-nav-item">
            <a class="header-nav-link" href="/explore" data-ga-click="(Logged out) Header, go to explore, text:explore">Explore</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/features" data-ga-click="(Logged out) Header, go to features, text:features">Features</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="https://enterprise.github.com/" data-ga-click="(Logged out) Header, go to enterprise, text:enterprise">Enterprise</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/blog" data-ga-click="(Logged out) Header, go to blog, text:blog">Blog</a>
          </li>
      </ul>

  </div>
</div>



      <div id="start-of-content" class="accessibility-aid"></div>
          <div class="site" itemscope itemtype="http://schema.org/WebPage">
    <div id="js-flash-container">
      
    </div>
    <div class="pagehead repohead instapaper_ignore readability-menu">
      <div class="container">
        
<ul class="pagehead-actions">

  <li>
      <a href="/login?return_to=%2Fmindboards%2Fev3sources"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <span class="octicon octicon-eye"></span>
    Watch
  </a>
  <a class="social-count" href="/mindboards/ev3sources/watchers">
    82
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fmindboards%2Fev3sources"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <span class="octicon octicon-star"></span>
    Star
  </a>

    <a class="social-count js-social-count" href="/mindboards/ev3sources/stargazers">
      241
    </a>

  </li>

    <li>
      <a href="/login?return_to=%2Fmindboards%2Fev3sources"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <span class="octicon octicon-repo-forked"></span>
        Fork
      </a>
      <a href="/mindboards/ev3sources/network" class="social-count">
        123
      </a>
    </li>
</ul>

        <h1 itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="entry-title public">
          <span class="mega-octicon octicon-repo"></span>
          <span class="author"><a href="/mindboards" class="url fn" itemprop="url" rel="author"><span itemprop="title">mindboards</span></a></span><!--
       --><span class="path-divider">/</span><!--
       --><strong><a href="/mindboards/ev3sources" data-pjax="#js-repo-pjax-container">ev3sources</a></strong>

          <span class="page-context-loader">
            <img alt="" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </span>

        </h1>
      </div><!-- /.container -->
    </div><!-- /.repohead -->

    <div class="container">
      <div class="repository-with-sidebar repo-container new-discussion-timeline  ">
        <div class="repository-sidebar clearfix">
            
<nav class="sunken-menu repo-nav js-repo-nav js-sidenav-container-pjax js-octicon-loaders"
     role="navigation"
     data-pjax="#js-repo-pjax-container"
     data-issue-count-url="/mindboards/ev3sources/issues/counts">
  <ul class="sunken-menu-group">
    <li class="tooltipped tooltipped-w" aria-label="Code">
      <a href="/mindboards/ev3sources" aria-label="Code" class="selected js-selected-navigation-item sunken-menu-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /mindboards/ev3sources">
        <span class="octicon octicon-code"></span> <span class="full-word">Code</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Issues">
        <a href="/mindboards/ev3sources/issues" aria-label="Issues" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /mindboards/ev3sources/issues">
          <span class="octicon octicon-issue-opened"></span> <span class="full-word">Issues</span>
          <span class="js-issue-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>

    <li class="tooltipped tooltipped-w" aria-label="Pull requests">
      <a href="/mindboards/ev3sources/pulls" aria-label="Pull requests" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g p" data-selected-links="repo_pulls /mindboards/ev3sources/pulls">
          <span class="octicon octicon-git-pull-request"></span> <span class="full-word">Pull requests</span>
          <span class="js-pull-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Wiki">
        <a href="/mindboards/ev3sources/wiki" aria-label="Wiki" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g w" data-selected-links="repo_wiki /mindboards/ev3sources/wiki">
          <span class="octicon octicon-book"></span> <span class="full-word">Wiki</span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>
  </ul>
  <div class="sunken-menu-separator"></div>
  <ul class="sunken-menu-group">

    <li class="tooltipped tooltipped-w" aria-label="Pulse">
      <a href="/mindboards/ev3sources/pulse" aria-label="Pulse" class="js-selected-navigation-item sunken-menu-item" data-selected-links="pulse /mindboards/ev3sources/pulse">
        <span class="octicon octicon-pulse"></span> <span class="full-word">Pulse</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

    <li class="tooltipped tooltipped-w" aria-label="Graphs">
      <a href="/mindboards/ev3sources/graphs" aria-label="Graphs" class="js-selected-navigation-item sunken-menu-item" data-selected-links="repo_graphs repo_contributors /mindboards/ev3sources/graphs">
        <span class="octicon octicon-graph"></span> <span class="full-word">Graphs</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>
  </ul>


</nav>

              <div class="only-with-full-nav">
                  
<div class="js-clone-url clone-url open"
  data-protocol-type="http">
  <h3><span class="text-emphasized">HTTPS</span> clone URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/mindboards/ev3sources.git" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>

  
<div class="js-clone-url clone-url "
  data-protocol-type="subversion">
  <h3><span class="text-emphasized">Subversion</span> checkout URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/mindboards/ev3sources" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>



<div class="clone-options">You can clone with
  <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=http&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="XXqhQspjhSr7o/HeTcUlmXuNbOffV39m0fvA+A0sNrTu1EcneO0arSOmAvwuArCIIwThoLAK67TdLHmTEfr1Sw==" /></div><button class="btn-link js-clone-selector" data-protocol="http" type="submit">HTTPS</button></form> or <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=subversion&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="zFUoM+AoJDx+sO+G98UhMHtV+YsEmTjPtc75LWIrze3+8U2v5Dz3u5MHw2/7dSnQ89Udwm8dhpaMc9ktDw9r+g==" /></div><button class="btn-link js-clone-selector" data-protocol="subversion" type="submit">Subversion</button></form>.
  <a href="https://help.github.com/articles/which-remote-url-should-i-use" class="help tooltipped tooltipped-n" aria-label="Get help on which URL is right for you.">
    <span class="octicon octicon-question"></span>
  </a>
</div>




                <a href="/mindboards/ev3sources/archive/7357369b6ebae4ee62001f3964f0f5fd0cce3c32.zip"
                   class="btn btn-sm sidebar-button"
                   aria-label="Download the contents of mindboards/ev3sources as a zip file"
                   title="Download the contents of mindboards/ev3sources as a zip file"
                   rel="nofollow">
                  <span class="octicon octicon-cloud-download"></span>
                  Download ZIP
                </a>
              </div>
        </div><!-- /.repository-sidebar -->

        <div id="js-repo-pjax-container" class="repository-content context-loader-container" data-pjax-container>

          
<a href="/mindboards/ev3sources/blame/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_bt/Linuxmod_AM1808/d_bt.c" class="hidden js-permalink-shortcut" data-hotkey="y">Permalink</a>

<div class="breadcrumb css-truncate blame-breadcrumb js-zeroclipboard-container">
  <span class="css-truncate-target js-zeroclipboard-target"><span class='repo-root js-repo-root'><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">ev3sources</span></a></span></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">lms2012</span></a></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_bt" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">d_bt</span></a></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_bt/Linuxmod_AM1808" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">Linuxmod_AM1808</span></a></span><span class="separator">/</span><strong class="final-path">d_bt.c</strong></span>
  <button aria-label="Copy file path to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
</div>

<div class="line-age-legend">
  <span>Newer</span>
  <ol>
      <li class="heat1"></li>
      <li class="heat2"></li>
      <li class="heat3"></li>
      <li class="heat4"></li>
      <li class="heat5"></li>
      <li class="heat6"></li>
      <li class="heat7"></li>
      <li class="heat8"></li>
      <li class="heat9"></li>
      <li class="heat10"></li>
  </ol>
  <span>Older</span>
</div>

<div class="file">
  <div class="file-header">
    <div class="file-actions">
      <div class="btn-group">
        <a href="/mindboards/ev3sources/raw/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_bt/Linuxmod_AM1808/d_bt.c" class="btn btn-sm" id="raw-url">Raw</a>
        <a href="/mindboards/ev3sources/blob/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_bt/Linuxmod_AM1808/d_bt.c" class="btn btn-sm js-update-url-with-hash">Normal view</a>
        <a href="/mindboards/ev3sources/commits/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_bt/Linuxmod_AM1808/d_bt.c" class="btn btn-sm" rel="nofollow">History</a>
      </div>
    </div>



    <div class="file-info">
      <span class="octicon octicon-file-text"></span>
      <span class="file-mode" title="File Mode">100644</span>
      <span class="file-info-divider"></span>
        437 lines (336 sloc)
        <span class="file-info-divider"></span>
      8.894 kb
    </div>
  </div>

  <div class="blob-wrapper">
    <table class="blame-container highlight data js-file-line-container">
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="437">
            <a href="/mindboards/ev3sources/commit/e5be3a6d591c60b26a3fb853989a9c86f5a7cc56" class="blame-sha">e5be3a6</a>
            <img alt="" class="avatar blame-commit-avatar" height="32" src="https://1.gravatar.com/avatar/a3114595e89094e76e43ffc615e7655f?d=https%3A%2F%2Fassets-cdn.github.com%2Fimages%2Fgravatars%2Fgravatar-user-420.png&amp;r=x&amp;s=140" width="32" />
            <a href="/mindboards/ev3sources/commit/e5be3a6d591c60b26a3fb853989a9c86f5a7cc56" class="blame-commit-title" title="Initial commit!  (so exciting!)">Initial commit!  (so exciting!)</a>
            <div class="blame-commit-meta">
              <span class="muted-link">Xander Soldaat</span> authored
              <time datetime="2013-07-30T17:57:56Z" is="relative-time">Jul 30, 2013</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1">1</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1"><span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L2">2</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC2"><span class="pl-c"> * LEGO® MINDSTORMS EV3</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L3">3</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC3"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L4">4</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC4"><span class="pl-c"> * Copyright (C) 2010-2013 The LEGO Group</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L5">5</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC5"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L6">6</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC6"><span class="pl-c"> * This program is free software; you can redistribute it and/or modify</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L7">7</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC7"><span class="pl-c"> * it under the terms of the GNU General Public License as published by</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L8">8</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC8"><span class="pl-c"> * the Free Software Foundation; either version 2 of the License, or</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L9">9</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC9"><span class="pl-c"> * (at your option) any later version.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L10">10</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC10"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L11">11</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC11"><span class="pl-c"> * This program is distributed in the hope that it will be useful,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L12">12</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC12"><span class="pl-c"> * but WITHOUT ANY WARRANTY; without even the implied warranty of</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L13">13</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC13"><span class="pl-c"> * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L14">14</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC14"><span class="pl-c"> * GNU General Public License for more details.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L15">15</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC15"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L16">16</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC16"><span class="pl-c"> * You should have received a copy of the GNU General Public License</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L17">17</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC17"><span class="pl-c"> * along with this program; if not, write to the Free Software</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L18">18</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC18"><span class="pl-c"> * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L19">19</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC19"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L20">20</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC20"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L21">21</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC21"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L22">22</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC22">#<span class="pl-k">ifndef</span> PCASM</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L23">23</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC23">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>asm/types.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L24">24</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC24">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L25">25</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC25"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L26">26</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC26">#<span class="pl-k">define</span>   <span class="pl-en">HW_ID_SUPPORT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L27">27</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC27"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L28">28</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC28">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&quot;</span>../../lms2012/source/lms2012.h<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L29">29</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC29">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&quot;</span>../../lms2012/source/am1808.h<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L30">30</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC30"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L31">31</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC31"><span class="pl-k">int</span>       Hw  =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L32">32</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC32"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L33">33</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC33">#<span class="pl-k">define</span>   <span class="pl-en">MODULE_NAME</span>                   <span class="pl-s"><span class="pl-pds">&quot;</span>bluetooth_module<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L34">34</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC34">#<span class="pl-k">define</span>   <span class="pl-en">DEVICE1_NAME</span>                  BT_DEVICE</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L35">35</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC35">#<span class="pl-k">define</span>   <span class="pl-en">DEVICE2_NAME</span>                  UPDATE_DEVICE</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L36">36</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC36"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L37">37</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC37"><span class="pl-k">static</span>    <span class="pl-k">int</span>  <span class="pl-en">ModuleInit</span>(<span class="pl-k">void</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L38">38</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC38"><span class="pl-k">static</span>    <span class="pl-k">void</span> <span class="pl-en">ModuleExit</span>(<span class="pl-k">void</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L39">39</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC39"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L40">40</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC40">#<span class="pl-k">define</span>   <span class="pl-en">__USE_POSIX</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L41">41</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC41"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L42">42</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC42">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/kernel.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L43">43</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC43">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/fs.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L44">44</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC44"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L45">45</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC45">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/sched.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L46">46</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC46"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L47">47</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC47"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L48">48</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC48">#<span class="pl-k">ifndef</span>   PCASM</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L49">49</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC49">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/hrtimer.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L50">50</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC50"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L51">51</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC51">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/mm.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L52">52</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC52">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/hrtimer.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L53">53</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC53"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L54">54</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC54">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/init.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L55">55</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC55">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/uaccess.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L56">56</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC56">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/debugfs.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L57">57</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC57"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L58">58</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC58">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/ioport.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L59">59</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC59">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>asm/gpio.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L60">60</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC60">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>asm/io.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L61">61</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC61">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/module.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L62">62</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC62">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/miscdevice.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L63">63</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC63">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>asm/uaccess.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L64">64</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC64"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L65">65</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC65"><span class="pl-en">MODULE_LICENSE</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>GPL<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L66">66</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC66"><span class="pl-en">MODULE_AUTHOR</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>The LEGO Group<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L67">67</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC67"><span class="pl-en">MODULE_DESCRIPTION</span>(MODULE_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L68">68</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC68"><span class="pl-en">MODULE_SUPPORTED_DEVICE</span>(DEVICE1_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L69">69</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC69"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L70">70</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC70"><span class="pl-en">module_init</span>(ModuleInit);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L71">71</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC71"><span class="pl-en">module_exit</span>(ModuleExit);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L72">72</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC72"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L73">73</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC73">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L74">74</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC74"><span class="pl-c">// Keep Eclipse happy</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L75">75</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC75">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L76">76</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC76"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L77">77</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC77"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L78">78</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC78"><span class="pl-k">enum</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L79">79</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC79">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L80">80</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC80">  SET   = <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L81">81</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC81">  CLEAR = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L82">82</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC82">  HIIMP = <span class="pl-c1">2</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L83">83</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC83">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L84">84</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC84"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L85">85</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC85"><span class="pl-k">enum</span>      BluetoothPins</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L86">86</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC86">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L87">87</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC87">  CTS_PIC,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L88">88</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC88">  PIC_RST,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L89">89</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC89">  PIC_EN,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L90">90</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC90">  BLUETOOTH_PINS</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L91">91</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC91">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L92">92</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC92"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L93">93</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC93"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L94">94</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC94">INPIN     EP2_BluetoothPin[BLUETOOTH_PINS] =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L95">95</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC95">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L96">96</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC96">  { GP5_7  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// CTS_PIC</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L97">97</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC97">  { GP4_14 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// PIC_RST</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L98">98</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC98">  { GP3_3  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// PIC_EN</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L99">99</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC99">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L100">100</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC100"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L101">101</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC101"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L102">102</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC102">INPIN     FINALB_BluetoothPin[BLUETOOTH_PINS] =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L103">103</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC103">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L104">104</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC104">  { GP5_7  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// CTS_PIC</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L105">105</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC105">  { GP4_14 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// PIC_RST</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L106">106</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC106">  { GP3_3  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// PIC_EN</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L107">107</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC107">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L108">108</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC108"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L109">109</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC109"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L110">110</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC110">INPIN     FINAL_BluetoothPin[BLUETOOTH_PINS] =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L111">111</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC111">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L112">112</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC112">  { GP5_7  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// CTS_PIC</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L113">113</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC113">  { GP4_14 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// PIC_RST</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L114">114</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC114">  { GP3_3  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// PIC_EN</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L115">115</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC115">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L116">116</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC116"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L117">117</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC117"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L118">118</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC118">INPIN     *pBluetoothPin[] =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L119">119</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC119">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L120">120</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC120">  [FINAL]     =   (INPIN*)&amp;FINAL_BluetoothPin[<span class="pl-c1">0</span>],    <span class="pl-c">//  FINAL   platform</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L121">121</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC121">  [FINALB]    =   (INPIN*)&amp;FINALB_BluetoothPin[<span class="pl-c1">0</span>],   <span class="pl-c">//  FINALB  platform</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L122">122</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC122">  [EP2]       =   (INPIN*)&amp;EP2_BluetoothPin[<span class="pl-c1">0</span>],      <span class="pl-c">//  EP2     platform</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L123">123</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC123">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L124">124</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC124"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L125">125</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC125"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L126">126</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC126"><span class="pl-k">static</span>    <span class="pl-k">void</span>  __iomem *GpioBase;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L127">127</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC127"><span class="pl-k">static</span>    UBYTE         *pLocalRam;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L128">128</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC128"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L129">129</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC129"><span class="pl-k">void</span>      <span class="pl-en">SetGpio</span>(<span class="pl-k">int</span> Pin)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L130">130</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC130">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L131">131</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC131">  <span class="pl-k">int</span>     Tmp = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L132">132</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC132">  <span class="pl-k">void</span>    __iomem *Reg;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L133">133</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC133"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L134">134</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC134">  <span class="pl-k">while</span> ((MuxRegMap[Tmp].<span class="pl-smi">Pin</span> != -<span class="pl-c1">1</span>) &amp;&amp; (MuxRegMap[Tmp].<span class="pl-smi">Pin</span> != Pin))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L135">135</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC135">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L136">136</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC136">    Tmp++;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L137">137</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC137">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L138">138</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC138">  <span class="pl-k">if</span> (MuxRegMap[Tmp].<span class="pl-smi">Pin</span> == Pin)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L139">139</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC139">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L140">140</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC140">    Reg   =  da8xx_syscfg0_base + 0x120 + (MuxRegMap[Tmp].<span class="pl-smi">MuxReg</span> &lt;&lt; <span class="pl-c1">2</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L141">141</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC141"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L142">142</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC142">    *(u32*)Reg &amp;=  MuxRegMap[Tmp].<span class="pl-smi">Mask</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L143">143</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC143">    *(u32*)Reg |=  MuxRegMap[Tmp].<span class="pl-smi">Mode</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L144">144</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC144"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L145">145</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC145">    <span class="pl-k">if</span> (Pin &lt; NO_OF_GPIOS)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L146">146</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC146">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L147">147</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC147">      #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L148">148</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC148">        <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>    GP<span class="pl-c1">%d</span>_<span class="pl-c1">%-2d</span>   0x<span class="pl-c1">%08X</span> and 0x<span class="pl-c1">%08X</span> or 0x<span class="pl-c1">%08X</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,(Pin &gt;&gt; <span class="pl-c1">4</span>),(Pin &amp; 0x0F),(u32)Reg, MuxRegMap[Tmp].<span class="pl-smi">Mask</span>, MuxRegMap[Tmp].<span class="pl-smi">Mode</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L149">149</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC149">      #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L150">150</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC150">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L151">151</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC151">    <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L152">152</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC152">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L153">153</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC153">      #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L154">154</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC154">        <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>   OUTPUT FUNCTION 0x<span class="pl-c1">%08X</span> and 0x<span class="pl-c1">%08X</span> or 0x<span class="pl-c1">%08X</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,(u32)Reg, MuxRegMap[Tmp].<span class="pl-smi">Mask</span>, MuxRegMap[Tmp].<span class="pl-smi">Mode</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L155">155</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC155">      #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L156">156</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC156">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L157">157</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC157">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L158">158</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC158">  <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L159">159</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC159">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L160">160</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC160">    <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>    GP<span class="pl-c1">%d</span>_<span class="pl-c1">%-2d</span> Not found (Const no. <span class="pl-c1">%d</span>, Tmp = <span class="pl-c1">%d</span>)<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,(Pin &gt;&gt; <span class="pl-c1">4</span>),(Pin &amp; 0x0F), Pin, Tmp);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L161">161</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC161">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L162">162</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC162">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L163">163</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC163"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L164">164</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC164"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L165">165</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC165"><span class="pl-k">void</span>      <span class="pl-en">InitGpio</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L166">166</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC166">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L167">167</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC167">  <span class="pl-k">int</span>     Pin;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L168">168</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC168"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L169">169</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC169">  REGUnlock;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L170">170</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC170"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L171">171</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC171">  <span class="pl-k">for</span> (Pin = <span class="pl-c1">0</span>; Pin &lt; BLUETOOTH_PINS; Pin++)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L172">172</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC172">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L173">173</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC173">    pBluetoothPin[Hw][Pin].<span class="pl-smi">pGpio</span>  =  (<span class="pl-k">struct</span> gpio_controller *__iomem)(GpioBase + ((pBluetoothPin[Hw][Pin].<span class="pl-smi">Pin</span> &gt;&gt; <span class="pl-c1">5</span>) * 0x28) + 0x10);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L174">174</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC174">    pBluetoothPin[Hw][Pin].<span class="pl-smi">Mask</span>   =  (<span class="pl-c1">1</span> &lt;&lt; (pBluetoothPin[Hw][Pin].<span class="pl-smi">Pin</span> &amp; 0x1F));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L175">175</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC175"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L176">176</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC176">    <span class="pl-c1">SetGpio</span>(pBluetoothPin[Hw][Pin].<span class="pl-smi">Pin</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L177">177</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC177">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L178">178</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC178"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L179">179</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC179">  REGLock;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L180">180</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC180">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L181">181</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC181"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L182">182</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC182"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L183">183</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC183">#<span class="pl-k">define</span>   <span class="pl-en">BtFloat</span>(<span class="pl-v">pin</span>)              {\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L184">184</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC184">                                      (*pBluetoothPin[Hw][pin].<span class="pl-smi">pGpio</span>).<span class="pl-smi">dir</span>   |=  pBluetoothPin[Hw][pin].<span class="pl-smi">Mask</span>;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L185">185</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC185">                                    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L186">186</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC186"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L187">187</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC187">#<span class="pl-k">define</span>   <span class="pl-en">BtRead</span>(<span class="pl-v">pin</span>)               ((*pBluetoothPin[Hw][pin].pGpio).in_data &amp;  pBluetoothPin[Hw][pin].Mask)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L188">188</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC188"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L189">189</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC189">#<span class="pl-k">define</span>   <span class="pl-en">BtHigh</span>(<span class="pl-v">pin</span>)               {\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L190">190</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC190">                                      (*pBluetoothPin[Hw][pin].<span class="pl-smi">pGpio</span>).<span class="pl-smi">set_data</span>  =  pBluetoothPin[Hw][pin].<span class="pl-smi">Mask</span>;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L191">191</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC191">                                      (*pBluetoothPin[Hw][pin].<span class="pl-smi">pGpio</span>).<span class="pl-smi">dir</span>      &amp;= ~pBluetoothPin[Hw][pin].<span class="pl-smi">Mask</span>;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L192">192</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC192">                                    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L193">193</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC193"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L194">194</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC194">#<span class="pl-k">define</span>   <span class="pl-en">BtLow</span>(<span class="pl-v">pin</span>)                {\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L195">195</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC195">                                      (*pBluetoothPin[Hw][pin].<span class="pl-smi">pGpio</span>).<span class="pl-smi">clr_data</span>  =  pBluetoothPin[Hw][pin].<span class="pl-smi">Mask</span>;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L196">196</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC196">                                      (*pBluetoothPin[Hw][pin].<span class="pl-smi">pGpio</span>).<span class="pl-smi">dir</span>      &amp;= ~pBluetoothPin[Hw][pin].<span class="pl-smi">Mask</span>;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L197">197</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC197">                                    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L198">198</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC198"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L199">199</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC199"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L200">200</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC200"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L201">201</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC201"><span class="pl-c">// DEVICE1 ********************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L202">202</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC202"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L203">203</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC203"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L204">204</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC204"><span class="pl-k">static</span> <span class="pl-c1">ssize_t</span> <span class="pl-en">Device1Write</span>(<span class="pl-k">struct</span> file *File,<span class="pl-k">const</span> <span class="pl-k">char</span> *Buffer,<span class="pl-c1">size_t</span> Count,<span class="pl-c1">loff_t</span> *Data)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L205">205</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC205">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L206">206</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC206">  SBYTE   Buf[<span class="pl-c1">20</span>];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L207">207</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC207">  <span class="pl-k">int</span>     Lng;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L208">208</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC208"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L209">209</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC209">  Lng  =  Count;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L210">210</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC210">  <span class="pl-c1">copy_from_user</span>(Buf,Buffer,Count);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L211">211</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC211"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L212">212</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC212">  <span class="pl-k">if</span> (SET == (UBYTE)(Buf[<span class="pl-c1">0</span>]))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L213">213</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC213">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L214">214</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC214">    <span class="pl-k">if</span> (BLUETOOTH_PINS &gt; (UBYTE)(Buf[<span class="pl-c1">1</span>]))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L215">215</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC215">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L216">216</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC216">      <span class="pl-c1">BtHigh</span>((UBYTE)(Buf[<span class="pl-c1">1</span>]));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L217">217</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC217">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L218">218</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC218">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L219">219</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC219">  <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L220">220</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC220">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L221">221</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC221">    <span class="pl-k">if</span> (CLEAR == (UBYTE)(Buf[<span class="pl-c1">0</span>]))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L222">222</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC222">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L223">223</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC223">      <span class="pl-k">if</span> (BLUETOOTH_PINS &gt; (UBYTE)(Buf[<span class="pl-c1">1</span>]))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L224">224</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC224">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L225">225</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC225">        <span class="pl-c1">BtLow</span>((UBYTE)(Buf[<span class="pl-c1">1</span>]));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L226">226</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC226">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L227">227</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC227">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L228">228</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC228">    <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L229">229</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC229">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L230">230</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC230">      <span class="pl-k">if</span> (BLUETOOTH_PINS &gt; (UBYTE)(Buf[<span class="pl-c1">1</span>]))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L231">231</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC231">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L232">232</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC232">        <span class="pl-c1">BtFloat</span>((UBYTE)(Buf[<span class="pl-c1">1</span>]));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L233">233</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC233">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L234">234</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC234">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L235">235</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC235">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L236">236</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC236"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L237">237</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC237">  <span class="pl-k">return</span> (Lng);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L238">238</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC238">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L239">239</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC239"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L240">240</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC240"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L241">241</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC241"><span class="pl-k">static</span> <span class="pl-c1">ssize_t</span> <span class="pl-en">Device1Read</span>(<span class="pl-k">struct</span> file *File,<span class="pl-k">char</span> *Buffer,<span class="pl-c1">size_t</span> Count,<span class="pl-c1">loff_t</span> *Offset)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L242">242</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC242">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L243">243</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC243"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L244">244</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC244">  <span class="pl-k">if</span> (<span class="pl-c1">BtRead</span>(CTS_PIC))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L245">245</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC245">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L246">246</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC246">    Buffer[<span class="pl-c1">0</span>] = <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L247">247</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC247">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L248">248</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC248">  <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L249">249</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC249">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L250">250</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC250">    Buffer[<span class="pl-c1">0</span>] = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L251">251</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC251">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L252">252</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC252"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L253">253</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC253">  <span class="pl-k">return</span>(<span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L254">254</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC254">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L255">255</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC255"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L256">256</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC256"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L257">257</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC257"><span class="pl-k">static</span> <span class="pl-c1">ssize_t</span> <span class="pl-en">Device2Write</span>(<span class="pl-k">struct</span> file *File,<span class="pl-k">const</span> <span class="pl-k">char</span> *Buffer,<span class="pl-c1">size_t</span> Count,<span class="pl-c1">loff_t</span> *Data)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L258">258</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC258">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L259">259</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC259">  *((ULONG*)&amp;(pLocalRam[<span class="pl-c1">2</span>])) = 0x5555AAAA;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L260">260</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC260">  <span class="pl-k">return</span>(<span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L261">261</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC261">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L262">262</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC262"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L263">263</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC263"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L264">264</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC264"><span class="pl-k">static</span> <span class="pl-c1">ssize_t</span> <span class="pl-en">Device2Read</span>(<span class="pl-k">struct</span> file *File,<span class="pl-k">char</span> *Buffer,<span class="pl-c1">size_t</span> Count,<span class="pl-c1">loff_t</span> *Offset)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L265">265</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC265">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L266">266</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC266">  Buffer[<span class="pl-c1">0</span>] = pLocalRam[<span class="pl-c1">0</span>];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L267">267</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC267">  Buffer[<span class="pl-c1">1</span>] = pLocalRam[<span class="pl-c1">1</span>];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L268">268</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC268">  <span class="pl-k">return</span>(<span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L269">269</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC269">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L270">270</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC270"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L271">271</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC271"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L272">272</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC272"><span class="pl-k">static</span>    <span class="pl-k">const</span> <span class="pl-k">struct</span> file_operations Device1Entries =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L273">273</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC273">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L274">274</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC274">  .<span class="pl-smi">owner</span>   =  THIS_MODULE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L275">275</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC275">  .<span class="pl-smi">read</span>    =  Device1Read,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L276">276</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC276">  .<span class="pl-smi">write</span>   =  Device1Write</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L277">277</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC277">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L278">278</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC278"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L279">279</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC279"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L280">280</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC280"><span class="pl-k">static</span>    <span class="pl-k">struct</span> miscdevice Device1 =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L281">281</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC281">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L282">282</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC282">  MISC_DYNAMIC_MINOR,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L283">283</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC283">  DEVICE1_NAME,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L284">284</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC284">  &amp;Device1Entries</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L285">285</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC285">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L286">286</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC286"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L287">287</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC287"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L288">288</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC288"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">Device1Init</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L289">289</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC289">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L290">290</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC290">  <span class="pl-k">int</span>     Result = -<span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L291">291</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC291"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L292">292</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC292">  Result  =  <span class="pl-c1">misc_register</span>(&amp;Device1);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L293">293</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC293">  <span class="pl-k">if</span> (Result)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L294">294</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC294">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L295">295</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC295">    <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  <span class="pl-c1">%s</span> device register failed<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,DEVICE1_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L296">296</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC296">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L297">297</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC297">  <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L298">298</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC298">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L299">299</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC299">    #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L300">300</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC300">      <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  <span class="pl-c1">%s</span> device register succes<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,DEVICE1_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L301">301</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC301">    #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L302">302</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC302">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L303">303</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC303"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L304">304</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC304">  <span class="pl-k">return</span> (Result);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L305">305</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC305">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L306">306</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC306"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L307">307</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC307"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L308">308</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC308"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">Device1Exit</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L309">309</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC309">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L310">310</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC310">  <span class="pl-c1">misc_deregister</span>(&amp;Device1);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L311">311</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC311">#<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L312">312</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC312">  <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  <span class="pl-c1">%s</span> device unregistered<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,DEVICE1_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L313">313</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC313">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L314">314</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC314">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L315">315</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC315"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L316">316</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC316"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L317">317</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC317"><span class="pl-c">/* Device 2 is to handle pirmware update status writing into */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L318">318</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC318"><span class="pl-c">/* internal RAM                                              */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L319">319</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC319"><span class="pl-k">static</span>    <span class="pl-k">const</span> <span class="pl-k">struct</span> file_operations Device2Entries =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L320">320</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC320">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L321">321</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC321">  .<span class="pl-smi">owner</span>   =  THIS_MODULE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L322">322</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC322">  .<span class="pl-smi">read</span>    =  Device2Read,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L323">323</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC323">  .<span class="pl-smi">write</span>   =  Device2Write</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L324">324</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC324">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L325">325</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC325"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L326">326</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC326"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L327">327</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC327"><span class="pl-k">static</span>    <span class="pl-k">struct</span> miscdevice Device2 =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L328">328</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC328">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L329">329</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC329">  MISC_DYNAMIC_MINOR,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L330">330</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC330">  DEVICE2_NAME,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L331">331</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC331">  &amp;Device2Entries</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L332">332</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC332">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L333">333</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC333"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L334">334</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC334"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L335">335</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC335"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">Device2Init</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L336">336</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC336">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L337">337</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC337">  <span class="pl-k">int</span>     Result = -<span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L338">338</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC338"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L339">339</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC339">  Result  =  <span class="pl-c1">misc_register</span>(&amp;Device2);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L340">340</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC340">  <span class="pl-k">if</span> (Result)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L341">341</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC341">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L342">342</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC342">    <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  <span class="pl-c1">%s</span> device register failed<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,DEVICE2_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L343">343</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC343">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L344">344</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC344">  <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L345">345</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC345">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L346">346</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC346">    #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L347">347</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC347">      <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  <span class="pl-c1">%s</span> device register succes<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,DEVICE2_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L348">348</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC348">    #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L349">349</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC349">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L350">350</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC350"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L351">351</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC351">  <span class="pl-k">return</span> (Result);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L352">352</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC352">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L353">353</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC353"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L354">354</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC354"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L355">355</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC355"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">Device2Exit</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L356">356</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC356">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L357">357</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC357">  <span class="pl-c1">misc_deregister</span>(&amp;Device2);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L358">358</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC358">#<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L359">359</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC359">  <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  <span class="pl-c1">%s</span> device unregistered<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,DEVICE2_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L360">360</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC360">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L361">361</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC361">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L362">362</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC362"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L363">363</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC363"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L364">364</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC364"><span class="pl-c">// MODULE *********************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L365">365</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC365"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L366">366</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC366"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L367">367</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC367">#<span class="pl-k">ifndef</span> PCASM</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L368">368</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC368"><span class="pl-en">module_param</span> (HwId, charp, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L369">369</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC369">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L370">370</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC370"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L371">371</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC371"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">ModuleInit</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L372">372</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC372">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L373">373</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC373">  Hw  =  HWID;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L374">374</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC374"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L375">375</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC375">  <span class="pl-k">if</span> (Hw &lt; PLATFORM_START)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L376">376</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC376">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L377">377</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC377">    Hw  =  PLATFORM_START;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L378">378</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC378">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L379">379</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC379">  <span class="pl-k">if</span> (Hw &gt; PLATFORM_END)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L380">380</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC380">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L381">381</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC381">    Hw  =  PLATFORM_END;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L382">382</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC382">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L383">383</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC383"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L384">384</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC384">  #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L385">385</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC385">    <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span> init started<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,MODULE_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L386">386</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC386">  #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L387">387</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC387"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L388">388</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC388">  <span class="pl-c">/* Local memory for saving the firmware update status */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L389">389</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC389">  <span class="pl-k">if</span> (<span class="pl-c1">request_mem_region</span>(0xFFFF1FFC,0x00000004,MODULE_NAME) &gt;= <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L390">390</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC390">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L391">391</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC391"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L392">392</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC392">    pLocalRam  =  (UBYTE*)<span class="pl-c1">ioremap</span>(0xFFFF1FFA,0x00000006);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L393">393</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC393"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L394">394</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC394">    <span class="pl-k">if</span> (pLocalRam != <span class="pl-c1">NULL</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L395">395</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC395">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L396">396</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC396">      #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L397">397</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC397">        <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span> Local address mapped<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,MODULE_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L398">398</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC398">      #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L399">399</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC399">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L400">400</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC400">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L401">401</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC401"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L402">402</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC402">  <span class="pl-k">if</span> (<span class="pl-c1">request_mem_region</span>(DA8XX_GPIO_BASE,0xD8,MODULE_NAME) &gt;= <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L403">403</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC403">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L404">404</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC404">    GpioBase  =  (<span class="pl-k">void</span>*)<span class="pl-c1">ioremap</span>(DA8XX_GPIO_BASE,0xD8);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L405">405</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC405">    <span class="pl-k">if</span> (GpioBase != <span class="pl-c1">NULL</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L406">406</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC406">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L407">407</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC407">      #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L408">408</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC408">        <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span> gpio address mapped<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,MODULE_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L409">409</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC409">      #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L410">410</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC410"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L411">411</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC411">      <span class="pl-c1">InitGpio</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L412">412</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC412">      <span class="pl-c1">Device1Init</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L413">413</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC413">      <span class="pl-c1">Device2Init</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L414">414</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC414"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L415">415</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC415">      <span class="pl-c1">BtHigh</span>(PIC_RST);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L416">416</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC416">      <span class="pl-c1">BtLow</span>(PIC_EN);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L417">417</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC417">      <span class="pl-c1">BtFloat</span>(CTS_PIC);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L418">418</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC418">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L419">419</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC419">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L420">420</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC420">  <span class="pl-k">return</span> (<span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L421">421</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC421">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L422">422</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC422"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L423">423</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC423"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L424">424</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC424"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">ModuleExit</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L425">425</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC425">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L426">426</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC426">  #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L427">427</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC427">    <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span> exit started<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,MODULE_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L428">428</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC428">  #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L429">429</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC429"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L430">430</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC430">  <span class="pl-c1">BtHigh</span>(PIC_RST);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L431">431</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC431">  <span class="pl-c1">BtLow</span>(PIC_EN);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L432">432</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC432"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L433">433</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC433">  <span class="pl-c1">Device1Exit</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L434">434</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC434">  <span class="pl-c1">Device2Exit</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L435">435</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC435"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L436">436</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC436">}</td>
          </tr>
    </table>
  </div>
</div>


        </div>

      </div><!-- /.repo-container -->
      <div class="modal-backdrop"></div>
    </div><!-- /.container -->
  </div><!-- /.site -->


    </div><!-- /.wrapper -->

      <div class="container">
  <div class="site-footer" role="contentinfo">
    <ul class="site-footer-links right">
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage">
      <span class="mega-octicon octicon-mark-github" title="GitHub"></span>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2015 <span title="0.06384s from github-fe130-cp1-prd.iad.github.net">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact</a></li>
    </ul>
  </div>
</div>


    <div class="fullscreen-overlay js-fullscreen-overlay" id="fullscreen_overlay">
  <div class="fullscreen-container js-suggester-container">
    <div class="textarea-wrap">
      <textarea name="fullscreen-contents" id="fullscreen-contents" class="fullscreen-contents js-fullscreen-contents" placeholder=""></textarea>
      <div class="suggester-container">
        <div class="suggester fullscreen-suggester js-suggester js-navigation-container"></div>
      </div>
    </div>
  </div>
  <div class="fullscreen-sidebar">
    <a href="#" class="exit-fullscreen js-exit-fullscreen tooltipped tooltipped-w" aria-label="Exit Zen Mode">
      <span class="mega-octicon octicon-screen-normal"></span>
    </a>
    <a href="#" class="theme-switcher js-theme-switcher tooltipped tooltipped-w"
      aria-label="Switch themes">
      <span class="octicon octicon-color-mode"></span>
    </a>
  </div>
</div>



    

    <div id="ajax-error-message" class="flash flash-error">
      <span class="octicon octicon-alert"></span>
      <a href="#" class="octicon octicon-x flash-close js-ajax-error-dismiss" aria-label="Dismiss error"></a>
      Something went wrong with that request. Please try again.
    </div>


      <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-447ce66a36506ebddc8e84b4e32a77f6062f3d3482e77dd21a77a01f0643ad98.js"></script>
      <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github/index-83be60956d0d00076a726f0864b49916aae8e7bc6ee140798791be0b6644d661.js"></script>
      
      
  </body>
</html>

