


<!DOCTYPE html>
<html lang="en" class="">
  <head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# object: http://ogp.me/ns/object# article: http://ogp.me/ns/article# profile: http://ogp.me/ns/profile#">
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    
    
    <title>ev3sources/extra/linux-03.20.00.13/arch/arm/mach-davinci/board-da850-evm.c at 7357369b6ebae4ee62001f3964f0f5fd0cce3c32 · mindboards/ev3sources · GitHub</title>
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-144.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144.png">
    <meta property="fb:app_id" content="1401488693436528">

      <meta content="@github" name="twitter:site" /><meta content="summary" name="twitter:card" /><meta content="mindboards/ev3sources" name="twitter:title" /><meta content="LEGO MINDSTORMS EV3 source code. Contribute to ev3sources development by creating an account on GitHub." name="twitter:description" /><meta content="https://avatars3.githubusercontent.com/u/2578456?v=3&amp;s=400" name="twitter:image:src" />
      <meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="https://avatars3.githubusercontent.com/u/2578456?v=3&amp;s=400" property="og:image" /><meta content="mindboards/ev3sources" property="og:title" /><meta content="https://github.com/mindboards/ev3sources" property="og:url" /><meta content="LEGO MINDSTORMS EV3 source code. Contribute to ev3sources development by creating an account on GitHub." property="og:description" />
      <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">
    <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">
    <link rel="assets" href="https://assets-cdn.github.com/">
    
    <meta name="pjax-timeout" content="1000">
    

    <meta name="msapplication-TileImage" content="/windows-tile.png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="selected-link" value="repo_source" data-pjax-transient>
      <meta name="google-analytics" content="UA-3769691-2">

    <meta content="collector.githubapp.com" name="octolytics-host" /><meta content="collector-cdn.github.com" name="octolytics-script-host" /><meta content="github" name="octolytics-app-id" /><meta content="70C64D49:7BA7:46FA33B:556C2647" name="octolytics-dimension-request_id" />
    
    <meta content="Rails, view, blob#blame" name="analytics-event" />
    <meta class="js-ga-set" name="dimension1" content="Logged Out">
    <meta class="js-ga-set" name="dimension2" content="Header v3">
    <meta name="is-dotcom" content="true">
      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

    
    <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">


    <meta content="authenticity_token" name="csrf-param" />
<meta content="mS5R91GajJ+DvFp/1N9S6+bqQTAOHipy15876rpD+pVDvznQbkSNXkug0ywO097c7GFqR3fK63n/RBhRsc7g8g==" name="csrf-token" />

    <link href="https://assets-cdn.github.com/assets/github/index-7e77e66f8436e66d6a9791d7a09cec15828e9e04a0ad97cf73e83223f8b9cb3a.css" media="all" rel="stylesheet" />
    <link href="https://assets-cdn.github.com/assets/github2/index-5df271cf586eee5e48a88e30cdb6b5c32413ce1d7337835a905fc8c16294237e.css" media="all" rel="stylesheet" />
    
    


    <meta http-equiv="x-pjax-version" content="840467a6cd0c672c678f4fd42f529999">

            <meta content="noindex, nofollow" name="robots" />

  <meta name="description" content="LEGO MINDSTORMS EV3 source code. Contribute to ev3sources development by creating an account on GitHub.">
  <meta name="go-import" content="github.com/mindboards/ev3sources git https://github.com/mindboards/ev3sources.git">

  <meta content="2578456" name="octolytics-dimension-user_id" /><meta content="mindboards" name="octolytics-dimension-user_login" /><meta content="11771262" name="octolytics-dimension-repository_id" /><meta content="mindboards/ev3sources" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="11771262" name="octolytics-dimension-repository_network_root_id" /><meta content="mindboards/ev3sources" name="octolytics-dimension-repository_network_root_nwo" />
  <link href="https://github.com/mindboards/ev3sources/commits/7357369b6ebae4ee62001f3964f0f5fd0cce3c32.atom" rel="alternate" title="Recent Commits to ev3sources:7357369b6ebae4ee62001f3964f0f5fd0cce3c32" type="application/atom+xml">

  </head>


  <body class="logged_out  env-production  vis-public">
    <a href="#start-of-content" tabindex="1" class="accessibility-aid js-skip-to-content">Skip to content</a>
    <div class="wrapper">
      
      
      


        
        <div class="header header-logged-out" role="banner">
  <div class="container clearfix">

    <a class="header-logo-wordmark" href="https://github.com/" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
      <span class="mega-octicon octicon-logo-github"></span>
    </a>

    <div class="header-actions" role="navigation">
        <a class="btn btn-primary" href="/join" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
      <a class="btn" href="/login?return_to=%2Fmindboards%2Fev3sources%2Fblame%2F7357369b6ebae4ee62001f3964f0f5fd0cce3c32%2Fextra%2Flinux-03.20.00.13%2Farch%2Farm%2Fmach-davinci%2Fboard-da850-evm.c" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
    </div>

    <div class="site-search repo-scope js-site-search" role="search">
      <form accept-charset="UTF-8" action="/mindboards/ev3sources/search" class="js-site-search-form" data-global-search-url="/search" data-repo-search-url="/mindboards/ev3sources/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
  <label class="js-chromeless-input-container form-control">
    <div class="scope-badge">This repository</div>
    <input type="text"
      class="js-site-search-focus js-site-search-field is-clearable chromeless-input"
      data-hotkey="s"
      name="q"
      placeholder="Search"
      data-global-scope-placeholder="Search GitHub"
      data-repo-scope-placeholder="Search"
      tabindex="1"
      autocapitalize="off">
  </label>
</form>
    </div>

      <ul class="header-nav left" role="navigation">
          <li class="header-nav-item">
            <a class="header-nav-link" href="/explore" data-ga-click="(Logged out) Header, go to explore, text:explore">Explore</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/features" data-ga-click="(Logged out) Header, go to features, text:features">Features</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="https://enterprise.github.com/" data-ga-click="(Logged out) Header, go to enterprise, text:enterprise">Enterprise</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/blog" data-ga-click="(Logged out) Header, go to blog, text:blog">Blog</a>
          </li>
      </ul>

  </div>
</div>



      <div id="start-of-content" class="accessibility-aid"></div>
          <div class="site" itemscope itemtype="http://schema.org/WebPage">
    <div id="js-flash-container">
      
    </div>
    <div class="pagehead repohead instapaper_ignore readability-menu">
      <div class="container">
        
<ul class="pagehead-actions">

  <li>
      <a href="/login?return_to=%2Fmindboards%2Fev3sources"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <span class="octicon octicon-eye"></span>
    Watch
  </a>
  <a class="social-count" href="/mindboards/ev3sources/watchers">
    82
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fmindboards%2Fev3sources"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <span class="octicon octicon-star"></span>
    Star
  </a>

    <a class="social-count js-social-count" href="/mindboards/ev3sources/stargazers">
      241
    </a>

  </li>

    <li>
      <a href="/login?return_to=%2Fmindboards%2Fev3sources"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <span class="octicon octicon-repo-forked"></span>
        Fork
      </a>
      <a href="/mindboards/ev3sources/network" class="social-count">
        123
      </a>
    </li>
</ul>

        <h1 itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="entry-title public">
          <span class="mega-octicon octicon-repo"></span>
          <span class="author"><a href="/mindboards" class="url fn" itemprop="url" rel="author"><span itemprop="title">mindboards</span></a></span><!--
       --><span class="path-divider">/</span><!--
       --><strong><a href="/mindboards/ev3sources" data-pjax="#js-repo-pjax-container">ev3sources</a></strong>

          <span class="page-context-loader">
            <img alt="" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </span>

        </h1>
      </div><!-- /.container -->
    </div><!-- /.repohead -->

    <div class="container">
      <div class="repository-with-sidebar repo-container new-discussion-timeline  ">
        <div class="repository-sidebar clearfix">
            
<nav class="sunken-menu repo-nav js-repo-nav js-sidenav-container-pjax js-octicon-loaders"
     role="navigation"
     data-pjax="#js-repo-pjax-container"
     data-issue-count-url="/mindboards/ev3sources/issues/counts">
  <ul class="sunken-menu-group">
    <li class="tooltipped tooltipped-w" aria-label="Code">
      <a href="/mindboards/ev3sources" aria-label="Code" class="selected js-selected-navigation-item sunken-menu-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /mindboards/ev3sources">
        <span class="octicon octicon-code"></span> <span class="full-word">Code</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Issues">
        <a href="/mindboards/ev3sources/issues" aria-label="Issues" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /mindboards/ev3sources/issues">
          <span class="octicon octicon-issue-opened"></span> <span class="full-word">Issues</span>
          <span class="js-issue-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>

    <li class="tooltipped tooltipped-w" aria-label="Pull requests">
      <a href="/mindboards/ev3sources/pulls" aria-label="Pull requests" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g p" data-selected-links="repo_pulls /mindboards/ev3sources/pulls">
          <span class="octicon octicon-git-pull-request"></span> <span class="full-word">Pull requests</span>
          <span class="js-pull-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Wiki">
        <a href="/mindboards/ev3sources/wiki" aria-label="Wiki" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g w" data-selected-links="repo_wiki /mindboards/ev3sources/wiki">
          <span class="octicon octicon-book"></span> <span class="full-word">Wiki</span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>
  </ul>
  <div class="sunken-menu-separator"></div>
  <ul class="sunken-menu-group">

    <li class="tooltipped tooltipped-w" aria-label="Pulse">
      <a href="/mindboards/ev3sources/pulse" aria-label="Pulse" class="js-selected-navigation-item sunken-menu-item" data-selected-links="pulse /mindboards/ev3sources/pulse">
        <span class="octicon octicon-pulse"></span> <span class="full-word">Pulse</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

    <li class="tooltipped tooltipped-w" aria-label="Graphs">
      <a href="/mindboards/ev3sources/graphs" aria-label="Graphs" class="js-selected-navigation-item sunken-menu-item" data-selected-links="repo_graphs repo_contributors /mindboards/ev3sources/graphs">
        <span class="octicon octicon-graph"></span> <span class="full-word">Graphs</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>
  </ul>


</nav>

              <div class="only-with-full-nav">
                  
<div class="js-clone-url clone-url open"
  data-protocol-type="http">
  <h3><span class="text-emphasized">HTTPS</span> clone URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/mindboards/ev3sources.git" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>

  
<div class="js-clone-url clone-url "
  data-protocol-type="subversion">
  <h3><span class="text-emphasized">Subversion</span> checkout URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/mindboards/ev3sources" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>



<div class="clone-options">You can clone with
  <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=http&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="s0HUhan0mZcUM0p+Y6ljovCLEjhYiRH4q57LgiRp0WQdqkUJlPu4vaZV+Z7isTlpPw4KdD88NNBWk3cCc2dTFw==" /></div><button class="btn-link js-clone-selector" data-protocol="http" type="submit">HTTPS</button></form> or <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=subversion&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="C8DgxmoTpxGQ8e/1OhP+I5yeQiBlitMBNnvgUD7GoEsxqJ3APciOnARQ6xlRXogURfpxee9JWZYbmJLHwE76wQ==" /></div><button class="btn-link js-clone-selector" data-protocol="subversion" type="submit">Subversion</button></form>.
  <a href="https://help.github.com/articles/which-remote-url-should-i-use" class="help tooltipped tooltipped-n" aria-label="Get help on which URL is right for you.">
    <span class="octicon octicon-question"></span>
  </a>
</div>




                <a href="/mindboards/ev3sources/archive/7357369b6ebae4ee62001f3964f0f5fd0cce3c32.zip"
                   class="btn btn-sm sidebar-button"
                   aria-label="Download the contents of mindboards/ev3sources as a zip file"
                   title="Download the contents of mindboards/ev3sources as a zip file"
                   rel="nofollow">
                  <span class="octicon octicon-cloud-download"></span>
                  Download ZIP
                </a>
              </div>
        </div><!-- /.repository-sidebar -->

        <div id="js-repo-pjax-container" class="repository-content context-loader-container" data-pjax-container>

          
<a href="/mindboards/ev3sources/blame/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra/linux-03.20.00.13/arch/arm/mach-davinci/board-da850-evm.c" class="hidden js-permalink-shortcut" data-hotkey="y">Permalink</a>

<div class="breadcrumb css-truncate blame-breadcrumb js-zeroclipboard-container">
  <span class="css-truncate-target js-zeroclipboard-target"><span class='repo-root js-repo-root'><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">ev3sources</span></a></span></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">extra</span></a></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra/linux-03.20.00.13" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">linux-03.20.00.13</span></a></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra/linux-03.20.00.13/arch" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">arch</span></a></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra/linux-03.20.00.13/arch/arm" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">arm</span></a></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra/linux-03.20.00.13/arch/arm/mach-davinci" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">mach-davinci</span></a></span><span class="separator">/</span><strong class="final-path">board-da850-evm.c</strong></span>
  <button aria-label="Copy file path to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
</div>

<div class="line-age-legend">
  <span>Newer</span>
  <ol>
      <li class="heat1"></li>
      <li class="heat2"></li>
      <li class="heat3"></li>
      <li class="heat4"></li>
      <li class="heat5"></li>
      <li class="heat6"></li>
      <li class="heat7"></li>
      <li class="heat8"></li>
      <li class="heat9"></li>
      <li class="heat10"></li>
  </ol>
  <span>Older</span>
</div>

<div class="file">
  <div class="file-header">
    <div class="file-actions">
      <div class="btn-group">
        <a href="/mindboards/ev3sources/raw/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra/linux-03.20.00.13/arch/arm/mach-davinci/board-da850-evm.c" class="btn btn-sm" id="raw-url">Raw</a>
        <a href="/mindboards/ev3sources/blob/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra/linux-03.20.00.13/arch/arm/mach-davinci/board-da850-evm.c" class="btn btn-sm js-update-url-with-hash">Normal view</a>
        <a href="/mindboards/ev3sources/commits/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra/linux-03.20.00.13/arch/arm/mach-davinci/board-da850-evm.c" class="btn btn-sm" rel="nofollow">History</a>
      </div>
    </div>



    <div class="file-info">
      <span class="octicon octicon-file-text"></span>
      <span class="file-mode" title="File Mode">100644</span>
      <span class="file-info-divider"></span>
        1772 lines (1496 sloc)
        <span class="file-info-divider"></span>
      44.171 kb
    </div>
  </div>

  <div class="blob-wrapper">
    <table class="blame-container highlight data js-file-line-container">
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="1772">
            <a href="/mindboards/ev3sources/commit/fea79c0e219cd5e43193ce2987b496e04758f3e2" class="blame-sha">fea79c0</a>
            <img alt="" class="avatar blame-commit-avatar" height="32" src="https://1.gravatar.com/avatar/a3114595e89094e76e43ffc615e7655f?d=https%3A%2F%2Fassets-cdn.github.com%2Fimages%2Fgravatars%2Fgravatar-user-420.png&amp;r=x&amp;s=140" width="32" />
            <a href="/mindboards/ev3sources/commit/fea79c0e219cd5e43193ce2987b496e04758f3e2" class="blame-commit-title" title="Additional files, like kernel, uboot and device specific lib/includes">Additional files, like kernel, uboot and device specific lib/includes</a>
            <div class="blame-commit-meta">
              <span class="muted-link">Xander Soldaat</span> authored
              <time datetime="2013-07-31T21:58:56Z" is="relative-time">Jul 31, 2013</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1">1</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1"><span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L2">2</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC2"><span class="pl-c"> * TI DA850/OMAP-L138 EVM board</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L3">3</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC3"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L4">4</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC4"><span class="pl-c"> * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L5">5</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC5"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L6">6</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC6"><span class="pl-c"> * Derived from: arch/arm/mach-davinci/board-da830-evm.c</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L7">7</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC7"><span class="pl-c"> * Original Copyrights follow:</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L8">8</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC8"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L9">9</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC9"><span class="pl-c"> * 2007, 2009 (c) MontaVista Software, Inc. This file is licensed under</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L10">10</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC10"><span class="pl-c"> * the terms of the GNU General Public License version 2. This program</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L11">11</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC11"><span class="pl-c"> * is licensed &quot;as is&quot; without any warranty of any kind, whether express</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L12">12</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC12"><span class="pl-c"> * or implied.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L13">13</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC13"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L14">14</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC14">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/kernel.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L15">15</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC15">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/init.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L16">16</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC16">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/console.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L17">17</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC17">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/i2c.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L18">18</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC18">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/i2c/at24.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L19">19</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC19">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/i2c/pca953x.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L20">20</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC20">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/mfd/tps6507x.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L21">21</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC21">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/gpio.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L22">22</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC22">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/delay.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L23">23</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC23">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/platform_device.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L24">24</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC24">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/mtd/mtd.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L25">25</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC25">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/mtd/nand.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L26">26</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC26">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/mtd/partitions.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L27">27</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC27">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/regulator/machine.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L28">28</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC28">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/spi/spi.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L29">29</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC29">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/spi/flash.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L30">30</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC30">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/usb/musb.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L31">31</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC31">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/usb/g_hid.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L32">32</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC32">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/i2c-gpio.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L33">33</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC33"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L34">34</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC34">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>asm/mach-types.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L35">35</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC35">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>asm/mach/arch.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L36">36</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC36"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L37">37</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC37">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>mach/cp_intc.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L38">38</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC38">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>mach/da8xx.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L39">39</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC39">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>mach/nand.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L40">40</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC40">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>mach/mux.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L41">41</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC41">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>mach/flash.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L42">42</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC42">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>mach/vpif.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L43">43</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC43"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L44">44</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC44">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>media/tvp514x.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L45">45</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC45">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>video/st7586fb.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L46">46</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC46"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L47">47</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC47">#<span class="pl-k">define</span> <span class="pl-en">DA850_EVM_PHY_MASK</span>		0x1</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L48">48</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC48">#<span class="pl-k">define</span> <span class="pl-en">DA850_EVM_MDIO_FREQUENCY</span>	<span class="pl-c1">2200000</span> <span class="pl-c">/* PHY bus frequency */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L49">49</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC49"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L50">50</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC50">#<span class="pl-k">define</span> <span class="pl-en">DA850_LCD_PWR_PIN</span>		<span class="pl-en">GPIO_TO_PIN</span>(<span class="pl-c1">2</span>, <span class="pl-c1">8</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L51">51</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC51">#<span class="pl-k">define</span> <span class="pl-en">DA850_LCD_BL_PIN</span>		<span class="pl-en">GPIO_TO_PIN</span>(<span class="pl-c1">2</span>, <span class="pl-c1">15</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L52">52</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC52"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L53">53</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC53"><span class="pl-c">//#define DA850_MMCSD_CD_PIN		GPIO_TO_PIN(4, 0)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L54">54</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC54">#<span class="pl-k">define</span> <span class="pl-en">DA850_MMCSD_CD_PIN</span>		<span class="pl-en">GPIO_TO_PIN</span>(<span class="pl-c1">4</span>, <span class="pl-c1">2</span>) <span class="pl-c">//Lego</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L55">55</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC55"><span class="pl-c">//#define DA850_MMCSD_WP_PIN		GPIO_TO_PIN(4, 1) //Lego</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L56">56</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC56">#<span class="pl-k">define</span> <span class="pl-en">DA850_PRU_CAN_TRX_PIN</span>	<span class="pl-en">GPIO_TO_PIN</span>(<span class="pl-c1">2</span>, <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L57">57</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC57"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L58">58</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC58">#<span class="pl-k">define</span> <span class="pl-en">DA850_MII_MDIO_CLKEN_PIN</span>	<span class="pl-en">GPIO_TO_PIN</span>(<span class="pl-c1">2</span>, <span class="pl-c1">6</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L59">59</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC59"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L60">60</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC60">#<span class="pl-k">define</span> <span class="pl-en">DA850_BT_EN</span>			<span class="pl-en">GPIO_TO_PIN</span>(<span class="pl-c1">0</span>, <span class="pl-c1">15</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L61">61</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC61"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L62">62</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC62"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L63">63</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC63">#<span class="pl-k">define</span> <span class="pl-en">TVP5147_CH0</span>		<span class="pl-s"><span class="pl-pds">&quot;</span>tvp514x-0<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L64">64</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC64">#<span class="pl-k">define</span> <span class="pl-en">TVP5147_CH1</span>		<span class="pl-s"><span class="pl-pds">&quot;</span>tvp514x-1<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L65">65</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC65"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L66">66</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC66">#<span class="pl-k">define</span> <span class="pl-en">VPIF_STATUS</span>	(0x002C)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L67">67</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC67">#<span class="pl-k">define</span> <span class="pl-en">VPIF_STATUS_CLR</span>	(0x0030)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L68">68</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC68">#<span class="pl-k">define</span> <span class="pl-en">DA850_USB1_VBUS_PIN</span>		<span class="pl-en">GPIO_TO_PIN</span>(<span class="pl-c1">1</span>, <span class="pl-c1">4</span>) <span class="pl-c">//GPIO_TO_PIN(6, 14) //GPIO_TO_PIN(2, 4)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L69">69</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC69">#<span class="pl-k">define</span> <span class="pl-en">DA850_USB1_OC_PIN</span>		<span class="pl-en">GPIO_TO_PIN</span>(<span class="pl-c1">6</span>, <span class="pl-c1">3</span>) <span class="pl-c">//GPIO_TO_PIN(6, 11) //GPIO_TO_PIN(6, 13)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L70">70</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC70"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L71">71</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC71">#<span class="pl-k">define</span>  <span class="pl-en">DA850_BT_SHUT_DOWN</span>		<span class="pl-en">GPIO_TO_PIN</span>(<span class="pl-c1">4</span>, <span class="pl-c1">1</span>)      <span class="pl-c">//LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L72">72</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC72">#<span class="pl-k">define</span>  <span class="pl-en">DA850_BT_SHUT_DOWN_EP2</span>		<span class="pl-en">GPIO_TO_PIN</span>(<span class="pl-c1">4</span>, <span class="pl-c1">9</span>)      <span class="pl-c">//LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L73">73</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC73"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L74">74</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC74">static struct davinci_spi_platform_data da850_spi0_pdata = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L75">75</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC75">        .<span class="pl-smi">version</span>        = SPI_VERSION_2,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L76">76</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC76">        .<span class="pl-smi">num_chipselect</span> = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L77">77</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC77">        .<span class="pl-smi">intr_line</span>      = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L78">78</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC78">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L79">79</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC79"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L80">80</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC80"><span class="pl-k">static</span> <span class="pl-k">struct</span> davinci_spi_platform_data da850_spi1_pdata = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L81">81</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC81">        .<span class="pl-smi">version</span>        = SPI_VERSION_2,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L82">82</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC82">        .<span class="pl-smi">num_chipselect</span> = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L83">83</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC83">        .<span class="pl-smi">intr_line</span>      = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L84">84</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC84">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L85">85</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC85"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L86">86</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC86"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L87">87</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC87"><span class="pl-k">static</span> <span class="pl-k">struct</span> mtd_partition da850_evm_norflash_partition[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L88">88</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC88">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L89">89</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC89">		.<span class="pl-smi">name</span>           = <span class="pl-s"><span class="pl-pds">&quot;</span>bootloaders + env<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L90">90</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC90">		.<span class="pl-smi">offset</span>         = <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L91">91</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC91">		.<span class="pl-smi">size</span>           = SZ_512K,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L92">92</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC92">		.<span class="pl-smi">mask_flags</span>     = MTD_WRITEABLE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L93">93</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC93">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L94">94</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC94">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L95">95</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC95">		.<span class="pl-smi">name</span>           = <span class="pl-s"><span class="pl-pds">&quot;</span>kernel<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L96">96</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC96">		.<span class="pl-smi">offset</span>         = MTDPART_OFS_APPEND,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L97">97</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC97">		.<span class="pl-smi">size</span>           = SZ_2M,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L98">98</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC98">		.<span class="pl-smi">mask_flags</span>     = <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L99">99</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC99">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L100">100</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC100">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L101">101</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC101">		.<span class="pl-smi">name</span>           = <span class="pl-s"><span class="pl-pds">&quot;</span>filesystem<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L102">102</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC102">		.<span class="pl-smi">offset</span>         = MTDPART_OFS_APPEND,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L103">103</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC103">		.<span class="pl-smi">size</span>           = MTDPART_SIZ_FULL,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L104">104</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC104">		.<span class="pl-smi">mask_flags</span>     = <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L105">105</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC105">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L106">106</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC106">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L107">107</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC107"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L108">108</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC108"><span class="pl-k">static</span> <span class="pl-k">struct</span> davinci_aemif_timing da850_evm_norflash_timing = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L109">109</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC109">	.<span class="pl-smi">wsetup</span>		= <span class="pl-c1">10</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L110">110</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC110">	.<span class="pl-smi">wstrobe</span>	= <span class="pl-c1">60</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L111">111</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC111">	.<span class="pl-smi">whold</span>		= <span class="pl-c1">10</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L112">112</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC112">	.<span class="pl-smi">rsetup</span>		= <span class="pl-c1">10</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L113">113</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC113">	.<span class="pl-smi">rstrobe</span>	= <span class="pl-c1">110</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L114">114</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC114">	.<span class="pl-smi">rhold</span>		= <span class="pl-c1">10</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L115">115</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC115">	.<span class="pl-smi">ta</span>		= <span class="pl-c1">30</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L116">116</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC116">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L117">117</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC117"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L118">118</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC118"><span class="pl-k">static</span> <span class="pl-k">struct</span> davinciflash_pdata da850_evm_norflash_data = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L119">119</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC119">	.<span class="pl-smi">width</span>		= <span class="pl-c1">2</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L120">120</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC120">	.<span class="pl-smi">parts</span>		= da850_evm_norflash_partition,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L121">121</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC121">	.<span class="pl-smi">nr_parts</span>	= <span class="pl-c1">ARRAY_SIZE</span>(da850_evm_norflash_partition),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L122">122</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC122">	.<span class="pl-smi">timing</span>		= &amp;da850_evm_norflash_timing,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L123">123</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC123">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L124">124</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC124"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L125">125</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC125"><span class="pl-k">static</span> <span class="pl-k">struct</span> resource da850_evm_norflash_resource[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L126">126</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC126">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L127">127</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC127">		.<span class="pl-smi">start</span>	= DA8XX_AEMIF_CS2_BASE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L128">128</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC128">		.<span class="pl-smi">end</span>	= DA8XX_AEMIF_CS2_BASE + SZ_32M - <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L129">129</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC129">		.<span class="pl-smi">flags</span>	= IORESOURCE_MEM,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L130">130</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC130">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L131">131</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC131">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L132">132</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC132">		.<span class="pl-smi">start</span>	= DA8XX_AEMIF_CTL_BASE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L133">133</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC133">		.<span class="pl-smi">end</span>	= DA8XX_AEMIF_CTL_BASE + SZ_32K - <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L134">134</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC134">		.<span class="pl-smi">flags</span>	= IORESOURCE_MEM,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L135">135</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC135">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L136">136</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC136">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L137">137</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC137"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L138">138</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC138"><span class="pl-k">static</span> <span class="pl-k">struct</span> platform_device da850_evm_norflash_device = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L139">139</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC139">	.<span class="pl-smi">name</span>		= <span class="pl-s"><span class="pl-pds">&quot;</span>davinci-flash<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L140">140</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC140">	.<span class="pl-smi">id</span>		= <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L141">141</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC141">	.<span class="pl-smi">dev</span>		= {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L142">142</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC142">		.<span class="pl-smi">platform_data</span>  = &amp;da850_evm_norflash_data,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L143">143</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC143">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L144">144</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC144">	.<span class="pl-smi">num_resources</span>	= <span class="pl-c1">ARRAY_SIZE</span>(da850_evm_norflash_resource),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L145">145</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC145">	.<span class="pl-smi">resource</span>	= da850_evm_norflash_resource,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L146">146</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC146">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L147">147</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC147"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L148">148</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC148"><span class="pl-k">static</span> <span class="pl-k">struct</span> davinci_pm_config da850_pm_pdata = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L149">149</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC149">	.<span class="pl-smi">sleepcount</span> = <span class="pl-c1">128</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L150">150</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC150">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L151">151</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC151"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L152">152</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC152"><span class="pl-k">static</span> <span class="pl-k">struct</span> platform_device da850_pm_device = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L153">153</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC153">	.<span class="pl-smi">name</span>           = <span class="pl-s"><span class="pl-pds">&quot;</span>pm-davinci<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L154">154</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC154">	.<span class="pl-smi">dev</span> = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L155">155</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC155">		.<span class="pl-smi">platform_data</span>	= &amp;da850_pm_pdata,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L156">156</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC156">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L157">157</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC157">	.<span class="pl-smi">id</span>             = -<span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L158">158</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC158">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L159">159</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC159"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L160">160</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC160"><span class="pl-c">/* DA850/OMAP-L138 EVM includes a 512 MByte large-page NAND flash</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L161">161</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC161"><span class="pl-c"> * (128K blocks). It may be used instead of the (default) SPI flash</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L162">162</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC162"><span class="pl-c"> * to boot, using TI&#39;s tools to install the secondary boot loader</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L163">163</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC163"><span class="pl-c"> * (UBL) and U-Boot.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L164">164</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC164"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L165">165</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC165"><span class="pl-k">struct</span> mtd_partition da850_evm_nandflash_partition[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L166">166</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC166">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L167">167</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC167">		.<span class="pl-smi">name</span>		= <span class="pl-s"><span class="pl-pds">&quot;</span>u-boot env<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L168">168</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC168">		.<span class="pl-smi">offset</span>		= <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L169">169</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC169">		.<span class="pl-smi">size</span>		= SZ_128K,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L170">170</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC170">		.<span class="pl-smi">mask_flags</span>	= MTD_WRITEABLE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L171">171</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC171">	 },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L172">172</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC172">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L173">173</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC173">		.<span class="pl-smi">name</span>		= <span class="pl-s"><span class="pl-pds">&quot;</span>UBL<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L174">174</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC174">		.<span class="pl-smi">offset</span>		= MTDPART_OFS_APPEND,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L175">175</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC175">		.<span class="pl-smi">size</span>		= SZ_128K,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L176">176</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC176">		.<span class="pl-smi">mask_flags</span>	= MTD_WRITEABLE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L177">177</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC177">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L178">178</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC178">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L179">179</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC179">		.<span class="pl-smi">name</span>		= <span class="pl-s"><span class="pl-pds">&quot;</span>u-boot<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L180">180</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC180">		.<span class="pl-smi">offset</span>		= MTDPART_OFS_APPEND,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L181">181</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC181">		.<span class="pl-smi">size</span>		= <span class="pl-c1">4</span> * SZ_128K,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L182">182</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC182">		.<span class="pl-smi">mask_flags</span>	= MTD_WRITEABLE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L183">183</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC183">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L184">184</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC184">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L185">185</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC185">		.<span class="pl-smi">name</span>		= <span class="pl-s"><span class="pl-pds">&quot;</span>kernel<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L186">186</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC186">		.<span class="pl-smi">offset</span>		= 0x200000,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L187">187</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC187">		.<span class="pl-smi">size</span>		= SZ_4M,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L188">188</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC188">		.<span class="pl-smi">mask_flags</span>	= <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L189">189</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC189">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L190">190</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC190">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L191">191</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC191">		.<span class="pl-smi">name</span>		= <span class="pl-s"><span class="pl-pds">&quot;</span>filesystem<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L192">192</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC192">		.<span class="pl-smi">offset</span>		= MTDPART_OFS_APPEND,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L193">193</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC193">		.<span class="pl-smi">size</span>		= MTDPART_SIZ_FULL,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L194">194</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC194">		.<span class="pl-smi">mask_flags</span>	= <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L195">195</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC195">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L196">196</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC196">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L197">197</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC197"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L198">198</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC198"><span class="pl-k">static</span> <span class="pl-k">struct</span> davinci_aemif_timing da850_evm_nandflash_timing = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L199">199</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC199">	.<span class="pl-smi">wsetup</span>		= <span class="pl-c1">24</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L200">200</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC200">	.<span class="pl-smi">wstrobe</span>	= <span class="pl-c1">21</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L201">201</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC201">	.<span class="pl-smi">whold</span>		= <span class="pl-c1">14</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L202">202</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC202">	.<span class="pl-smi">rsetup</span>		= <span class="pl-c1">19</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L203">203</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC203">	.<span class="pl-smi">rstrobe</span>	= <span class="pl-c1">50</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L204">204</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC204">	.<span class="pl-smi">rhold</span>		= <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L205">205</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC205">	.<span class="pl-smi">ta</span>		= <span class="pl-c1">20</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L206">206</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC206">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L207">207</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC207"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L208">208</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC208"><span class="pl-k">static</span> <span class="pl-k">struct</span> davinci_nand_pdata da850_evm_nandflash_data = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L209">209</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC209">	.<span class="pl-smi">parts</span>		= da850_evm_nandflash_partition,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L210">210</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC210">	.<span class="pl-smi">nr_parts</span>	= <span class="pl-c1">ARRAY_SIZE</span>(da850_evm_nandflash_partition),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L211">211</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC211">	.<span class="pl-smi">ecc_mode</span>	= NAND_ECC_HW,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L212">212</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC212">	.<span class="pl-smi">ecc_bits</span>	= <span class="pl-c1">4</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L213">213</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC213">	.<span class="pl-smi">options</span>	= NAND_USE_FLASH_BBT,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L214">214</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC214">	.<span class="pl-smi">timing</span>		= &amp;da850_evm_nandflash_timing,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L215">215</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC215">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L216">216</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC216"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L217">217</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC217"><span class="pl-k">static</span> <span class="pl-k">struct</span> resource da850_evm_nandflash_resource[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L218">218</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC218">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L219">219</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC219">		.<span class="pl-smi">start</span>	= DA8XX_AEMIF_CS3_BASE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L220">220</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC220">		.<span class="pl-smi">end</span>	= DA8XX_AEMIF_CS3_BASE + SZ_512K + <span class="pl-c1">2</span> * SZ_1K - <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L221">221</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC221">		.<span class="pl-smi">flags</span>	= IORESOURCE_MEM,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L222">222</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC222">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L223">223</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC223">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L224">224</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC224">		.<span class="pl-smi">start</span>	= DA8XX_AEMIF_CTL_BASE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L225">225</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC225">		.<span class="pl-smi">end</span>	= DA8XX_AEMIF_CTL_BASE + SZ_32K - <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L226">226</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC226">		.<span class="pl-smi">flags</span>	= IORESOURCE_MEM,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L227">227</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC227">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L228">228</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC228">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L229">229</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC229"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L230">230</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC230"><span class="pl-k">static</span> <span class="pl-k">struct</span> platform_device da850_evm_nandflash_device = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L231">231</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC231">	.<span class="pl-smi">name</span>		= <span class="pl-s"><span class="pl-pds">&quot;</span>davinci_nand<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L232">232</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC232">	.<span class="pl-smi">id</span>		= <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L233">233</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC233">	.<span class="pl-smi">dev</span>		= {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L234">234</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC234">		.<span class="pl-smi">platform_data</span>	= &amp;da850_evm_nandflash_data,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L235">235</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC235">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L236">236</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC236">	.<span class="pl-smi">num_resources</span>	= <span class="pl-c1">ARRAY_SIZE</span>(da850_evm_nandflash_resource),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L237">237</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC237">	.<span class="pl-smi">resource</span>	= da850_evm_nandflash_resource,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L238">238</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC238">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L239">239</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC239"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L240">240</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC240"><span class="pl-k">static</span> <span class="pl-k">struct</span> platform_device *da850_evm_devices[] __initdata = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L241">241</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC241">	&amp;da850_evm_nandflash_device,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L242">242</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC242">	&amp;da850_evm_norflash_device,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L243">243</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC243">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L244">244</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC244"><span class="pl-c">// LEGO CHANGED - 20120425 + 20120830</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L245">245</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC245"><span class="pl-k">static</span> <span class="pl-k">struct</span> mtd_partition spi0_flash_partitions[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L246">246</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC246">	[<span class="pl-c1">0</span>] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L247">247</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC247">		.<span class="pl-smi">name</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>U-Boot<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L248">248</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC248">		.<span class="pl-smi">offset</span> = <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L249">249</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC249">		.<span class="pl-smi">size</span> = SZ_256K,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L250">250</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC250">		.<span class="pl-smi">mask_flags</span> = MTD_WRITEABLE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L251">251</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC251">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L252">252</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC252">	[<span class="pl-c1">1</span>] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L253">253</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC253">		.<span class="pl-smi">name</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>U-Boot Env<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L254">254</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC254">		.<span class="pl-smi">offset</span> = MTDPART_OFS_APPEND,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L255">255</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC255">		.<span class="pl-smi">size</span> = SZ_64K,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L256">256</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC256">		.<span class="pl-smi">mask_flags</span> = MTD_WRITEABLE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L257">257</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC257">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L258">258</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC258">	[<span class="pl-c1">2</span>] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L259">259</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC259">		.<span class="pl-smi">name</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>Kernel<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L260">260</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC260">		.<span class="pl-smi">offset</span> = MTDPART_OFS_NXTBLK,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L261">261</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC261">		.<span class="pl-smi">size</span> = SZ_2M,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L262">262</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC262">		.<span class="pl-smi">mask_flags</span> = <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L263">263</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC263">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L264">264</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC264">	[<span class="pl-c1">3</span>] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L265">265</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC265">		.<span class="pl-smi">name</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>Filesystem<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L266">266</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC266">		.<span class="pl-smi">offset</span> = MTDPART_OFS_NXTBLK,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L267">267</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC267">		.<span class="pl-smi">size</span> = SZ_8M + SZ_2M + SZ_256K + SZ_128K,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L268">268</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC268">		.<span class="pl-smi">mask_flags</span> = <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L269">269</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC269">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L270">270</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC270">	[<span class="pl-c1">4</span>] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L271">271</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC271">		.<span class="pl-smi">name</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>Storage<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L272">272</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC272">		.<span class="pl-smi">offset</span> = MTDPART_OFS_NXTBLK,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L273">273</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC273">		.<span class="pl-smi">size</span> = SZ_2M + SZ_1M + SZ_256K + SZ_64K,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L274">274</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC274">		.<span class="pl-smi">mask_flags</span> = <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L275">275</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC275">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L276">276</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC276"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L277">277</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC277">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L278">278</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC278"><span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L279">279</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC279"><span class="pl-c">static struct mtd_partition spi1_display_partitions[] = {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L280">280</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC280"><span class="pl-c">	[0] = {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L281">281</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC281"><span class="pl-c">		.name = &quot;U-Boot&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L282">282</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC282"><span class="pl-c">		.offset = 0,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L283">283</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC283"><span class="pl-c">		.size = SZ_128K + SZ_64K,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L284">284</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC284"><span class="pl-c">		.mask_flags = MTD_WRITEABLE,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L285">285</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC285"><span class="pl-c">	},</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L286">286</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC286"><span class="pl-c">	[1] = {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L287">287</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC287"><span class="pl-c">		.name = &quot;U-Boot Environment&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L288">288</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC288"><span class="pl-c">		.offset = MTDPART_OFS_APPEND,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L289">289</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC289"><span class="pl-c">		.size = SZ_64K,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L290">290</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC290"><span class="pl-c">		.mask_flags = MTD_WRITEABLE,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L291">291</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC291"><span class="pl-c">	},</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L292">292</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC292"><span class="pl-c">	[2] = {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L293">293</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC293"><span class="pl-c">		.name = &quot;Linux uImage&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L294">294</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC294"><span class="pl-c">		.offset = MTDPART_OFS_NXTBLK,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L295">295</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC295"><span class="pl-c">		.size = SZ_2M + SZ_64K,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L296">296</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC296"><span class="pl-c">		.mask_flags = 0,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L297">297</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC297"><span class="pl-c">	},</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L298">298</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC298"><span class="pl-c">	[3] = {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L299">299</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC299"><span class="pl-c">		.name = &quot;File System (CRAMFS) &quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L300">300</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC300"><span class="pl-c">		.offset = MTDPART_OFS_NXTBLK,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L301">301</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC301"><span class="pl-c">		.size = SZ_8M + SZ_2M + SZ_256K + SZ_128K,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L302">302</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC302"><span class="pl-c">		.mask_flags = 0,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L303">303</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC303"><span class="pl-c">	},</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L304">304</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC304"><span class="pl-c">	[4] = {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L305">305</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC305"><span class="pl-c">		.name = &quot;User Data (RAMDisk)&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L306">306</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC306"><span class="pl-c">		.offset = MTDPART_OFS_NXTBLK,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L307">307</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC307"><span class="pl-c">		.size = SZ_2M + SZ_1M + SZ_256K + SZ_64K,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L308">308</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC308"><span class="pl-c">		.mask_flags = 0,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L309">309</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC309"><span class="pl-c">	},</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L310">310</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC310"><span class="pl-c"></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L311">311</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC311"><span class="pl-c">};</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L312">312</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC312"><span class="pl-c">*/</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L313">313</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC313"><span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L314">314</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC314"><span class="pl-c">// LEGO - Early MTD config</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L315">315</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC315"><span class="pl-c">static struct mtd_partition spi0_flash_partitions[] = {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L316">316</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC316"><span class="pl-c">        [0] = {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L317">317</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC317"><span class="pl-c">                .name = &quot;U-Boot&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L318">318</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC318"><span class="pl-c">                .offset = 0,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L319">319</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC319"><span class="pl-c">                .size = SZ_256K,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L320">320</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC320"><span class="pl-c">                .mask_flags = MTD_WRITEABLE,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L321">321</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC321"><span class="pl-c">        },</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L322">322</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC322"><span class="pl-c">        [1] = {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L323">323</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC323"><span class="pl-c">                .name = &quot;U-Boot Environment&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L324">324</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC324"><span class="pl-c">                .offset = MTDPART_OFS_APPEND,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L325">325</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC325"><span class="pl-c">                .size = SZ_64K,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L326">326</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC326"><span class="pl-c">                .mask_flags = MTD_WRITEABLE,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L327">327</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC327"><span class="pl-c">        },</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L328">328</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC328"><span class="pl-c">        [2] = {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L329">329</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC329"><span class="pl-c">                .name = &quot;Linux uImage&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L330">330</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC330"><span class="pl-c">                .offset = MTDPART_OFS_NXTBLK,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L331">331</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC331"><span class="pl-c">                .size = SZ_8M - (SZ_256K + SZ_64K + SZ_64K),</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L332">332</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC332"><span class="pl-c">                .mask_flags = 0,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L333">333</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC333"><span class="pl-c">        },</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L334">334</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC334"><span class="pl-c">};</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L335">335</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC335"><span class="pl-c">*/</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L336">336</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC336"><span class="pl-k">static</span> <span class="pl-k">struct</span> flash_platform_data spi0_flash_data = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L337">337</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC337">	.<span class="pl-smi">name</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>m25p80<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L338">338</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC338">	.<span class="pl-smi">parts</span> = spi0_flash_partitions,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L339">339</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC339">	.<span class="pl-smi">nr_parts</span> = <span class="pl-c1">ARRAY_SIZE</span>(spi0_flash_partitions),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L340">340</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC340">	<span class="pl-c">//.type = &quot;m25p64&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L341">341</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC341">	.<span class="pl-smi">type</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>s25sl12801<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L342">342</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC342">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L343">343</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC343"><span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L344">344</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC344"><span class="pl-c">static struct flash_platform_data spi1_display_data = {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L345">345</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC345"><span class="pl-c">	.name = &quot;st7586fb&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L346">346</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC346"><span class="pl-c">	.parts = spi1_display_partitions,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L347">347</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC347"><span class="pl-c">	.nr_parts = ARRAY_SIZE(spi1_display_partitions),</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L348">348</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC348"><span class="pl-c">	//.type = &quot;m25p64&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L349">349</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC349"><span class="pl-c">//	.type = &quot;s25sl12801&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L350">350</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC350"><span class="pl-c">};</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L351">351</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC351"><span class="pl-c">*/</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L352">352</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC352"><span class="pl-k">static</span> <span class="pl-k">const</span> <span class="pl-k">struct</span> st7586fb_platform_data lms2012_st7586fb_data = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L353">353</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC353">	.<span class="pl-smi">rst_gpio</span>	= <span class="pl-c1">GPIO_TO_PIN</span>(<span class="pl-c1">5</span>, <span class="pl-c1">0</span>),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L354">354</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC354">	.<span class="pl-smi">a0_gpio</span>	= <span class="pl-c1">GPIO_TO_PIN</span>(<span class="pl-c1">2</span>, <span class="pl-c1">11</span>),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L355">355</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC355">	.<span class="pl-smi">cs_gpio</span>	= <span class="pl-c1">GPIO_TO_PIN</span>(<span class="pl-c1">2</span>, <span class="pl-c1">12</span>),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L356">356</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC356">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L357">357</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC357"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L358">358</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC358"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L359">359</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC359"><span class="pl-k">static</span> <span class="pl-k">struct</span> davinci_spi_config da850_spiflash_cfg = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L360">360</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC360">	.<span class="pl-smi">io_type</span>	= SPI_IO_TYPE_DMA,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L361">361</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC361">	.<span class="pl-smi">c2tdelay</span>	= <span class="pl-c1">8</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L362">362</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC362">	.<span class="pl-smi">t2cdelay</span>	= <span class="pl-c1">8</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L363">363</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC363">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L364">364</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC364"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L365">365</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC365"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L366">366</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC366"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L367">367</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC367"><span class="pl-k">static</span> <span class="pl-k">struct</span> davinci_spi_config lms2012_st7586fb_cfg = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L368">368</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC368">        .<span class="pl-smi">io_type</span>	= SPI_IO_TYPE_DMA,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L369">369</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC369">        .<span class="pl-smi">c2tdelay</span>	= <span class="pl-c1">10</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L370">370</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC370">        .<span class="pl-smi">t2cdelay</span>	= <span class="pl-c1">10</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L371">371</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC371"> };</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L372">372</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC372"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L373">373</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC373"><span class="pl-k">static</span> <span class="pl-k">struct</span> spi_board_info da850_spi_board_info[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L374">374</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC374">	[<span class="pl-c1">0</span>] = { <span class="pl-c">// SPI0</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L375">375</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC375">		.<span class="pl-smi">modalias</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>m25p80<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L376">376</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC376">		.<span class="pl-smi">platform_data</span> = &amp;spi0_flash_data,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L377">377</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC377"><span class="pl-c">// LEGO - CHANGED 20120830</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L378">378</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC378">		.<span class="pl-smi">controller_data</span>= &amp;da850_spiflash_cfg,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L379">379</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC379">		.<span class="pl-smi">mode</span> = SPI_MODE_0,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L380">380</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC380"><span class="pl-c">//		.max_speed_hz = 30000000,       /* max sample rate at 3V */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L381">381</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC381">		.<span class="pl-smi">max_speed_hz</span> = <span class="pl-c1">50000000</span>,       <span class="pl-c">/* max sample rate at 3V */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L382">382</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC382"><span class="pl-c">// LEGO - CHANGE END</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L383">383</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC383">		.<span class="pl-smi">bus_num</span> = <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L384">384</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC384">		.<span class="pl-smi">chip_select</span> = <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L385">385</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC385">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L386">386</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC386">	[<span class="pl-c1">1</span>] = { <span class="pl-c">// SPI1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L387">387</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC387"><span class="pl-c">//		.modalias = &quot;st7586fb&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L388">388</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC388"><span class="pl-c">//		.platform_data = &amp;spi1_display_data,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L389">389</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC389"><span class="pl-c">//		.controller_data= &amp;da850_spidisplay_cfg,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L390">390</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC390"><span class="pl-c">//		.mode = SPI_MODE_0,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L391">391</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC391"><span class="pl-c">//		.max_speed_hz = 30000000,       /* max sample rate at 3V */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L392">392</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC392"><span class="pl-c">//		.bus_num = 1,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L393">393</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC393"><span class="pl-c">//		.chip_select = 0,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L394">394</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC394">		.<span class="pl-smi">modalias</span>		= <span class="pl-s"><span class="pl-pds">&quot;</span>lms2012_lcd<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L395">395</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC395">		.<span class="pl-smi">platform_data</span>		= &amp;lms2012_st7586fb_data,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L396">396</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC396">		.<span class="pl-smi">controller_data</span>	= &amp;lms2012_st7586fb_cfg,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L397">397</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC397">		.<span class="pl-smi">mode</span>			= SPI_MODE_3 | SPI_NO_CS,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L398">398</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC398">		.<span class="pl-smi">max_speed_hz</span>		= <span class="pl-c1">10000000</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L399">399</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC399"> 		.<span class="pl-smi">bus_num</span>		= <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L400">400</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC400"> 		.<span class="pl-smi">chip_select</span>		= <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L401">401</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC401"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L402">402</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC402">    },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L403">403</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC403">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L404">404</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC404"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L405">405</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC405"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L406">406</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC406"><span class="pl-k">static</span> <span class="pl-k">void</span> __init <span class="pl-en">da850_init_spi</span>(<span class="pl-k">struct</span> spi_board_info *info, <span class="pl-k">unsigned</span> len)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L407">407</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC407">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L408">408</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC408">        <span class="pl-k">int</span> ret;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L409">409</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC409"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L410">410</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC410">	<span class="pl-c1">printk</span> (<span class="pl-s"><span class="pl-pds">&quot;</span>start  da850_init_spi <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);      </td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L411">411</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC411">	ret = <span class="pl-c1">spi_register_board_info</span>(info, len);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L412">412</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC412">        <span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L413">413</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC413">                <span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>failed to register board info : <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L414">414</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC414"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L415">415</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC415">        ret = <span class="pl-c1">da8xx_register_spi</span>(<span class="pl-c1">0</span>, &amp;da850_spi0_pdata);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L416">416</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC416">        <span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L417">417</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC417">                <span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>failed to register spi 0 device : <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L418">418</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC418">        </td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L419">419</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC419">	ret = <span class="pl-c1">da8xx_register_spi</span>(<span class="pl-c1">1</span>, &amp;da850_spi1_pdata);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L420">420</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC420">        <span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L421">421</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC421">                <span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>failed to register spi 1 device : <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L422">422</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC422"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L423">423</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC423">	<span class="pl-c1">printk</span> (<span class="pl-s"><span class="pl-pds">&quot;</span>end  da850_init_spi <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);    </td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L424">424</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC424">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L425">425</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC425"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L426">426</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC426"><span class="pl-k">static</span> u32 ui_card_detected;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L427">427</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC427"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L428">428</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC428">#<span class="pl-k">if</span> defined(CONFIG_MMC_DAVINCI) || \</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L429">429</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC429">    <span class="pl-en">defined</span>(CONFIG_MMC_DAVINCI_MODULE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L430">430</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC430">#<span class="pl-k">define</span> <span class="pl-en">HAS_MMC</span> <span class="pl-c1">1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L431">431</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC431">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L432">432</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC432">#<span class="pl-k">define</span> <span class="pl-en">HAS_MMC</span> <span class="pl-c1">0</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L433">433</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC433">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L434">434</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC434"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L435">435</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC435"><span class="pl-k">static</span> __init <span class="pl-k">void</span> <span class="pl-en">da850_evm_setup_nor_nand</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L436">436</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC436">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L437">437</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC437">	<span class="pl-k">int</span> ret = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L438">438</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC438"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L439">439</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC439">	<span class="pl-k">if</span> (ui_card_detected &amp; !HAS_MMC) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L440">440</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC440">		ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_nand_pins);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L441">441</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC441">		<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L442">442</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC442">			<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: nand mux setup failed: <span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L443">443</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC443">					<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L444">444</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC444"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L445">445</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC445">		ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_nor_pins);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L446">446</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC446">		<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L447">447</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC447">			<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: nor mux setup failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L448">448</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC448">				ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L449">449</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC449"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L450">450</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC450">		<span class="pl-c1">platform_add_devices</span>(da850_evm_devices,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L451">451</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC451">					<span class="pl-c1">ARRAY_SIZE</span>(da850_evm_devices));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L452">452</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC452">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L453">453</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC453">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L454">454</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC454"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L455">455</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC455">#<span class="pl-k">ifdef</span> CONFIG_DA850_UI_RMII</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L456">456</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC456"><span class="pl-k">static</span> <span class="pl-k">inline</span> <span class="pl-k">void</span> <span class="pl-en">da850_evm_setup_emac_rmii</span>(<span class="pl-k">int</span> rmii_sel)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L457">457</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC457">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L458">458</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC458">	<span class="pl-k">struct</span> davinci_soc_info *soc_info = &amp;davinci_soc_info;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L459">459</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC459"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L460">460</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC460">	soc_info-&gt;emac_pdata-&gt;rmii_en = <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L461">461</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC461">	<span class="pl-c1">gpio_set_value</span>(rmii_sel, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L462">462</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC462">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L463">463</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC463">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L464">464</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC464"><span class="pl-k">static</span> <span class="pl-k">inline</span> <span class="pl-k">void</span> <span class="pl-en">da850_evm_setup_emac_rmii</span>(<span class="pl-k">int</span> rmii_sel) { }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L465">465</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC465">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L466">466</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC466"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L467">467</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC467">#<span class="pl-k">ifdef</span> CONFIG_DA850_UI_CLCD</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L468">468</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC468"><span class="pl-k">static</span> <span class="pl-k">inline</span> <span class="pl-k">void</span> <span class="pl-en">da850_evm_setup_char_lcd</span>(<span class="pl-k">int</span> a, <span class="pl-k">int</span> b, <span class="pl-k">int</span> c)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L469">469</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC469">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L470">470</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC470">	<span class="pl-c1">gpio_set_value</span>(a, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L471">471</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC471">	<span class="pl-c1">gpio_set_value</span>(b, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L472">472</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC472">	<span class="pl-c1">gpio_set_value</span>(c, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L473">473</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC473">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L474">474</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC474">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L475">475</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC475"><span class="pl-k">static</span> <span class="pl-k">inline</span> <span class="pl-k">void</span> <span class="pl-en">da850_evm_setup_char_lcd</span>(<span class="pl-k">int</span> a, <span class="pl-k">int</span> b, <span class="pl-k">int</span> c) { }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L476">476</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC476">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L477">477</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC477"><span class="pl-k">static</span> <span class="pl-k">struct</span> at24_platform_data da850_evm_i2c_eeprom_info = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L478">478</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC478">	.<span class="pl-smi">byte_len</span> = SZ_256K/<span class="pl-c1">8</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L479">479</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC479">	.<span class="pl-smi">page_size</span> = <span class="pl-c1">64</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L480">480</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC480">	.<span class="pl-smi">flags</span>	= AT24_FLAG_ADDR16,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L481">481</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC481">	.<span class="pl-smi">setup</span>  = davinci_get_mac_addr,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L482">482</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC482">	.<span class="pl-smi">context</span> = (<span class="pl-k">void</span>*)0x7f00,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L483">483</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC483">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L484">484</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC484"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L485">485</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC485">#<span class="pl-k">ifdef</span> CONFIG_DA850_UI_VIDEO_PORT</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L486">486</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC486"><span class="pl-k">static</span> <span class="pl-k">inline</span> <span class="pl-k">void</span> <span class="pl-en">da850_evm_setup_video_port</span>(<span class="pl-k">int</span> video_sel)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L487">487</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC487">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L488">488</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC488">	<span class="pl-c1">gpio_set_value</span>(video_sel, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L489">489</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC489">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L490">490</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC490">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L491">491</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC491"><span class="pl-k">static</span> <span class="pl-k">inline</span> <span class="pl-k">void</span> <span class="pl-en">da850_evm_setup_video_port</span>(<span class="pl-k">int</span> video_sel) { }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L492">492</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC492">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L493">493</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC493"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L494">494</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC494"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">da850_evm_ui_expander_setup</span>(<span class="pl-k">struct</span> i2c_client *client, <span class="pl-k">unsigned</span> gpio,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L495">495</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC495">						<span class="pl-k">unsigned</span> ngpio, <span class="pl-k">void</span> *c)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L496">496</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC496">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L497">497</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC497">	<span class="pl-k">int</span> sel_a, sel_b, sel_c, ret;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L498">498</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC498"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L499">499</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC499">	sel_a = gpio + <span class="pl-c1">7</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L500">500</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC500">	sel_b = gpio + <span class="pl-c1">6</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L501">501</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC501">	sel_c = gpio + <span class="pl-c1">5</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L502">502</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC502"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L503">503</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC503">	ret = <span class="pl-c1">gpio_request</span>(sel_a, <span class="pl-s"><span class="pl-pds">&quot;</span>sel_a<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L504">504</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC504">	<span class="pl-k">if</span> (ret) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L505">505</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC505">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>Cannot open UI expander pin <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, sel_a);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L506">506</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC506">		<span class="pl-k">goto</span> exp_setup_sela_fail;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L507">507</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC507">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L508">508</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC508"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L509">509</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC509">	ret = <span class="pl-c1">gpio_request</span>(sel_b, <span class="pl-s"><span class="pl-pds">&quot;</span>sel_b<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L510">510</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC510">	<span class="pl-k">if</span> (ret) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L511">511</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC511">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>Cannot open UI expander pin <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, sel_b);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L512">512</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC512">		<span class="pl-k">goto</span> exp_setup_selb_fail;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L513">513</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC513">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L514">514</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC514"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L515">515</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC515">	ret = <span class="pl-c1">gpio_request</span>(sel_c, <span class="pl-s"><span class="pl-pds">&quot;</span>sel_c<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L516">516</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC516">	<span class="pl-k">if</span> (ret) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L517">517</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC517">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>Cannot open UI expander pin <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, sel_c);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L518">518</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC518">		<span class="pl-k">goto</span> exp_setup_selc_fail;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L519">519</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC519">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L520">520</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC520"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L521">521</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC521">	<span class="pl-c">/* deselect all functionalities */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L522">522</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC522">	<span class="pl-c1">gpio_direction_output</span>(sel_a, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L523">523</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC523">	<span class="pl-c1">gpio_direction_output</span>(sel_b, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L524">524</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC524">	<span class="pl-c1">gpio_direction_output</span>(sel_c, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L525">525</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC525"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L526">526</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC526">	ui_card_detected = <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L527">527</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC527">	<span class="pl-c1">pr_info</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>DA850/OMAP-L138 EVM UI card detected<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L528">528</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC528"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L529">529</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC529">	<span class="pl-c1">da850_evm_setup_nor_nand</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L530">530</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC530"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L531">531</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC531">	<span class="pl-c1">da850_evm_setup_emac_rmii</span>(sel_a);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L532">532</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC532"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L533">533</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC533">	<span class="pl-c1">da850_evm_setup_char_lcd</span>(sel_a, sel_b, sel_c);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L534">534</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC534"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L535">535</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC535">	<span class="pl-c1">da850_evm_setup_video_port</span>(sel_c);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L536">536</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC536"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L537">537</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC537">	<span class="pl-k">return</span> <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L538">538</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC538"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L539">539</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC539">exp_setup_selc_fail:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L540">540</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC540">	<span class="pl-c1">gpio_free</span>(sel_b);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L541">541</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC541">exp_setup_selb_fail:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L542">542</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC542">	<span class="pl-c1">gpio_free</span>(sel_a);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L543">543</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC543">exp_setup_sela_fail:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L544">544</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC544">	<span class="pl-k">return</span> ret;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L545">545</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC545">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L546">546</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC546"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L547">547</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC547"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">da850_evm_ui_expander_teardown</span>(<span class="pl-k">struct</span> i2c_client *client,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L548">548</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC548">					<span class="pl-k">unsigned</span> gpio, <span class="pl-k">unsigned</span> ngpio, <span class="pl-k">void</span> *c)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L549">549</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC549">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L550">550</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC550">	<span class="pl-c">/* deselect all functionalities */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L551">551</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC551">	<span class="pl-c1">gpio_set_value</span>(gpio + <span class="pl-c1">5</span>, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L552">552</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC552">	<span class="pl-c1">gpio_set_value</span>(gpio + <span class="pl-c1">6</span>, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L553">553</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC553">	<span class="pl-c1">gpio_set_value</span>(gpio + <span class="pl-c1">7</span>, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L554">554</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC554"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L555">555</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC555">	<span class="pl-c1">gpio_free</span>(gpio + <span class="pl-c1">5</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L556">556</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC556">	<span class="pl-c1">gpio_free</span>(gpio + <span class="pl-c1">6</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L557">557</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC557">	<span class="pl-c1">gpio_free</span>(gpio + <span class="pl-c1">7</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L558">558</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC558"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L559">559</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC559">	<span class="pl-k">return</span> <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L560">560</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC560">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L561">561</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC561"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L562">562</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC562"><span class="pl-k">static</span> <span class="pl-k">struct</span> pca953x_platform_data da850_evm_ui_expander_info = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L563">563</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC563">	.<span class="pl-smi">gpio_base</span>	= DAVINCI_N_GPIO,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L564">564</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC564">	.<span class="pl-smi">setup</span>		= da850_evm_ui_expander_setup,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L565">565</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC565">	.<span class="pl-smi">teardown</span>	= da850_evm_ui_expander_teardown,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L566">566</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC566">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L567">567</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC567"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L568">568</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC568"><span class="pl-c">/* TPS65070 voltage regulator support */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L569">569</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC569"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L570">570</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC570"><span class="pl-c">/* 3.3V */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L571">571</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC571"><span class="pl-k">struct</span> regulator_consumer_supply tps65070_dcdc1_consumers[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L572">572</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC572">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L573">573</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC573">		.<span class="pl-smi">supply</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>usb0_vdda33<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L574">574</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC574">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L575">575</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC575">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L576">576</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC576">		.<span class="pl-smi">supply</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>usb1_vdda33<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L577">577</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC577">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L578">578</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC578">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L579">579</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC579"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L580">580</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC580"><span class="pl-c">/* 3.3V or 1.8V */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L581">581</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC581"><span class="pl-k">struct</span> regulator_consumer_supply tps65070_dcdc2_consumers[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L582">582</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC582">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L583">583</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC583">		.<span class="pl-smi">supply</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>dvdd3318_a<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L584">584</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC584">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L585">585</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC585">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L586">586</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC586">		.<span class="pl-smi">supply</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>dvdd3318_b<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L587">587</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC587">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L588">588</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC588">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L589">589</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC589">		.<span class="pl-smi">supply</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>dvdd3318_c<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L590">590</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC590">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L591">591</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC591">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L592">592</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC592"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L593">593</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC593"><span class="pl-c">/* 1.2V */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L594">594</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC594"><span class="pl-k">struct</span> regulator_consumer_supply tps65070_dcdc3_consumers[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L595">595</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC595">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L596">596</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC596">		.<span class="pl-smi">supply</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>cvdd<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L597">597</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC597">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L598">598</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC598">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L599">599</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC599"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L600">600</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC600"><span class="pl-c">/* 1.8V LDO */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L601">601</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC601"><span class="pl-k">struct</span> regulator_consumer_supply tps65070_ldo1_consumers[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L602">602</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC602">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L603">603</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC603">		.<span class="pl-smi">supply</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>sata_vddr<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L604">604</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC604">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L605">605</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC605">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L606">606</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC606">		.<span class="pl-smi">supply</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>usb0_vdda18<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L607">607</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC607">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L608">608</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC608">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L609">609</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC609">		.<span class="pl-smi">supply</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>usb1_vdda18<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L610">610</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC610">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L611">611</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC611">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L612">612</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC612">		.<span class="pl-smi">supply</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>ddr_dvdd18<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L613">613</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC613">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L614">614</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC614">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L615">615</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC615"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L616">616</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC616"><span class="pl-c">/* 1.2V LDO */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L617">617</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC617"><span class="pl-k">struct</span> regulator_consumer_supply tps65070_ldo2_consumers[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L618">618</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC618">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L619">619</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC619">		.<span class="pl-smi">supply</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>sata_vdd<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L620">620</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC620">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L621">621</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC621">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L622">622</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC622">		.<span class="pl-smi">supply</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>pll0_vdda<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L623">623</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC623">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L624">624</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC624">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L625">625</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC625">		.<span class="pl-smi">supply</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>pll1_vdda<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L626">626</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC626">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L627">627</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC627">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L628">628</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC628">		.<span class="pl-smi">supply</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>usbs_cvdd<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L629">629</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC629">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L630">630</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC630">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L631">631</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC631">		.<span class="pl-smi">supply</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>vddarnwa1<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L632">632</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC632">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L633">633</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC633">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L634">634</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC634"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L635">635</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC635"><span class="pl-k">struct</span> regulator_init_data tps65070_regulator_data[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L636">636</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC636">	<span class="pl-c">/* dcdc1 */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L637">637</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC637">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L638">638</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC638">		.<span class="pl-smi">constraints</span> = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L639">639</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC639">			.<span class="pl-smi">min_uV</span> = <span class="pl-c1">3150000</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L640">640</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC640">			.<span class="pl-smi">max_uV</span> = <span class="pl-c1">3450000</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L641">641</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC641">			.<span class="pl-smi">valid_ops_mask</span> = (REGULATOR_CHANGE_VOLTAGE |</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L642">642</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC642">				REGULATOR_CHANGE_STATUS),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L643">643</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC643">			.<span class="pl-smi">boot_on</span> = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L644">644</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC644">		},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L645">645</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC645">		.<span class="pl-smi">num_consumer_supplies</span> = <span class="pl-c1">ARRAY_SIZE</span>(tps65070_dcdc1_consumers),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L646">646</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC646">		.<span class="pl-smi">consumer_supplies</span> = tps65070_dcdc1_consumers,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L647">647</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC647">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L648">648</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC648"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L649">649</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC649">	<span class="pl-c">/* dcdc2 */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L650">650</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC650">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L651">651</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC651">		.<span class="pl-smi">constraints</span> = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L652">652</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC652">			.<span class="pl-smi">min_uV</span> = <span class="pl-c1">1710000</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L653">653</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC653">			.<span class="pl-smi">max_uV</span> = <span class="pl-c1">3450000</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L654">654</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC654">			.<span class="pl-smi">valid_ops_mask</span> = (REGULATOR_CHANGE_VOLTAGE |</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L655">655</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC655">				REGULATOR_CHANGE_STATUS),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L656">656</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC656">			.<span class="pl-smi">boot_on</span> = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L657">657</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC657">		},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L658">658</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC658">		.<span class="pl-smi">num_consumer_supplies</span> = <span class="pl-c1">ARRAY_SIZE</span>(tps65070_dcdc2_consumers),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L659">659</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC659">		.<span class="pl-smi">consumer_supplies</span> = tps65070_dcdc2_consumers,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L660">660</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC660">		.<span class="pl-smi">driver_data</span> = (<span class="pl-k">void</span> *) <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L661">661</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC661">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L662">662</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC662"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L663">663</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC663">	<span class="pl-c">/* dcdc3 */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L664">664</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC664">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L665">665</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC665">		.<span class="pl-smi">constraints</span> = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L666">666</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC666">			.<span class="pl-smi">min_uV</span> = <span class="pl-c1">950000</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L667">667</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC667">			.<span class="pl-smi">max_uV</span> = <span class="pl-c1">1380000</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L668">668</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC668">			.<span class="pl-smi">valid_ops_mask</span> = (REGULATOR_CHANGE_VOLTAGE |</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L669">669</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC669">				REGULATOR_CHANGE_STATUS),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L670">670</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC670">			.<span class="pl-smi">boot_on</span> = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L671">671</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC671">		},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L672">672</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC672">		.<span class="pl-smi">num_consumer_supplies</span> = <span class="pl-c1">ARRAY_SIZE</span>(tps65070_dcdc3_consumers),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L673">673</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC673">		.<span class="pl-smi">consumer_supplies</span> = tps65070_dcdc3_consumers,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L674">674</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC674">		.<span class="pl-smi">driver_data</span> = (<span class="pl-k">void</span> *) <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L675">675</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC675">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L676">676</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC676"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L677">677</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC677">	<span class="pl-c">/* ldo1 */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L678">678</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC678">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L679">679</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC679">		.<span class="pl-smi">constraints</span> = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L680">680</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC680">			.<span class="pl-smi">min_uV</span> = <span class="pl-c1">1710000</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L681">681</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC681">			.<span class="pl-smi">max_uV</span> = <span class="pl-c1">1890000</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L682">682</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC682">			.<span class="pl-smi">valid_ops_mask</span> = (REGULATOR_CHANGE_VOLTAGE |</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L683">683</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC683">				REGULATOR_CHANGE_STATUS),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L684">684</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC684">			.<span class="pl-smi">boot_on</span> = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L685">685</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC685">		},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L686">686</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC686">		.<span class="pl-smi">num_consumer_supplies</span> = <span class="pl-c1">ARRAY_SIZE</span>(tps65070_ldo1_consumers),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L687">687</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC687">		.<span class="pl-smi">consumer_supplies</span> = tps65070_ldo1_consumers,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L688">688</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC688">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L689">689</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC689"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L690">690</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC690">	<span class="pl-c">/* ldo2 */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L691">691</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC691">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L692">692</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC692">		.<span class="pl-smi">constraints</span> = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L693">693</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC693">			.<span class="pl-smi">min_uV</span> = <span class="pl-c1">1140000</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L694">694</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC694">			.<span class="pl-smi">max_uV</span> = <span class="pl-c1">1320000</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L695">695</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC695">			.<span class="pl-smi">valid_ops_mask</span> = (REGULATOR_CHANGE_VOLTAGE |</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L696">696</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC696">				REGULATOR_CHANGE_STATUS),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L697">697</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC697">			.<span class="pl-smi">boot_on</span> = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L698">698</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC698">		},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L699">699</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC699">		.<span class="pl-smi">num_consumer_supplies</span> = <span class="pl-c1">ARRAY_SIZE</span>(tps65070_ldo2_consumers),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L700">700</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC700">		.<span class="pl-smi">consumer_supplies</span> = tps65070_ldo2_consumers,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L701">701</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC701">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L702">702</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC702">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L703">703</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC703"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L704">704</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC704"><span class="pl-k">static</span> <span class="pl-k">struct</span> tps6507x_board tps_board = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L705">705</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC705">	.<span class="pl-smi">tps6507x_pmic_init_data</span> = &amp;tps65070_regulator_data[<span class="pl-c1">0</span>],</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L706">706</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC706">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L707">707</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC707"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L708">708</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC708"><span class="pl-k">static</span> <span class="pl-k">struct</span> i2c_board_info __initdata da850_evm_i2c_devices[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L709">709</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC709">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L710">710</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC710"><span class="pl-c">//		I2C_BOARD_INFO(&quot;tps6507x&quot;, 0x48),</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L711">711</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC711"><span class="pl-c">//		.platform_data = &amp;tps_board,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L712">712</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC712"><span class="pl-c">//	},</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L713">713</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC713"><span class="pl-c">//	{</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L714">714</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC714"><span class="pl-c">//		I2C_BOARD_INFO(&quot;tlv320aic3x&quot;, 0x18),</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L715">715</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC715"><span class="pl-c">//	},</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L716">716</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC716"><span class="pl-c">//	{</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L717">717</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC717"><span class="pl-c">//		I2C_BOARD_INFO(&quot;tca6416&quot;, 0x20),</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L718">718</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC718"><span class="pl-c">//		.platform_data = &amp;da850_evm_ui_expander_info,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L719">719</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC719"><span class="pl-c">//	},</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L720">720</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC720"><span class="pl-c">//	{</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L721">721</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC721">		<span class="pl-c1">I2C_BOARD_INFO</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>24FC128<span class="pl-pds">&quot;</span></span>, 0x50),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L722">722</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC722">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L723">723</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC723">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L724">724</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC724">		<span class="pl-c1">I2C_BOARD_INFO</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>PIC_CodedDataTo<span class="pl-pds">&quot;</span></span>, 0x54),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L725">725</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC725">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L726">726</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC726">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L727">727</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC727">		<span class="pl-c1">I2C_BOARD_INFO</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>PIC_ReadStatus<span class="pl-pds">&quot;</span></span>, 0x55),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L728">728</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC728">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L729">729</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC729">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L730">730</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC730">		<span class="pl-c1">I2C_BOARD_INFO</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>PIC_RawDataTo<span class="pl-pds">&quot;</span></span>, 0x56),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L731">731</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC731">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L732">732</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC732">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L733">733</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC733">		<span class="pl-c1">I2C_BOARD_INFO</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>PIC_ReadDataFrom<span class="pl-pds">&quot;</span></span>, 0x57),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L734">734</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC734">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L735">735</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC735"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L736">736</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC736"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L737">737</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC737">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L738">738</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC738"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L739">739</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC739"><span class="pl-k">static</span> <span class="pl-k">struct</span> davinci_i2c_platform_data lego_i2c_0_pdata = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L740">740</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC740">	.<span class="pl-smi">bus_freq</span>	= <span class="pl-c1">400</span>	<span class="pl-c">/* kHz */</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L741">741</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC741">	.<span class="pl-smi">bus_delay</span>	= <span class="pl-c1">0</span>	<span class="pl-c">/* usec */</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L742">742</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC742">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L743">743</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC743"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L744">744</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC744"><span class="pl-k">static</span> <span class="pl-k">struct</span> davinci_uart_config da850_evm_uart_config __initdata = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L745">745</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC745">	.<span class="pl-smi">enabled_uarts</span> = 0x7,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L746">746</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC746">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L747">747</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC747"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L748">748</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC748"><span class="pl-c">/* davinci da850 evm audio machine driver */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L749">749</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC749"><span class="pl-k">static</span> u8 da850_iis_serializer_direction[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L750">750</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC750">	INACTIVE_MODE,	INACTIVE_MODE,	INACTIVE_MODE,	INACTIVE_MODE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L751">751</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC751">	INACTIVE_MODE,	INACTIVE_MODE,	INACTIVE_MODE,	INACTIVE_MODE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L752">752</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC752">	INACTIVE_MODE,	INACTIVE_MODE,	INACTIVE_MODE,	TX_MODE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L753">753</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC753">	RX_MODE,	INACTIVE_MODE,	INACTIVE_MODE,	INACTIVE_MODE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L754">754</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC754">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L755">755</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC755"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L756">756</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC756"><span class="pl-k">static</span> <span class="pl-k">struct</span> snd_platform_data da850_evm_snd_data = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L757">757</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC757">	.<span class="pl-smi">tx_dma_offset</span>	= 0x2000,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L758">758</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC758">	.<span class="pl-smi">rx_dma_offset</span>	= 0x2000,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L759">759</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC759">	.<span class="pl-smi">op_mode</span>	= DAVINCI_MCASP_IIS_MODE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L760">760</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC760">	.<span class="pl-smi">num_serializer</span>	= <span class="pl-c1">ARRAY_SIZE</span>(da850_iis_serializer_direction),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L761">761</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC761">	.<span class="pl-smi">tdm_slots</span>	= <span class="pl-c1">2</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L762">762</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC762">	.<span class="pl-smi">serial_dir</span>	= da850_iis_serializer_direction,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L763">763</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC763">	.<span class="pl-smi">eventq_no</span>	= EVENTQ_1,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L764">764</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC764">	.<span class="pl-smi">version</span>	= MCASP_VERSION_2,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L765">765</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC765">	.<span class="pl-smi">txnumevt</span>	= <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L766">766</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC766">	.<span class="pl-smi">rxnumevt</span>	= <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L767">767</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC767">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L768">768</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC768"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L769">769</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC769"><span class="pl-k">static</span> <span class="pl-k">struct</span> davinci_mcbsp_platform_data da850_mcbsp0_config = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L770">770</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC770">	.<span class="pl-smi">inst</span>	= <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L771">771</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC771">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L772">772</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC772"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L773">773</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC773"><span class="pl-k">static</span> <span class="pl-k">struct</span> davinci_mcbsp_platform_data da850_mcbsp1_config = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L774">774</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC774">	.<span class="pl-smi">inst</span>	= <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L775">775</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC775">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L776">776</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC776"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L777">777</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC777"><span class="pl-c">//static int da850_evm_mmc_get_ro(int index)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L778">778</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC778"><span class="pl-c">//{</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L779">779</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC779"><span class="pl-c">//	return gpio_get_value(DA850_MMCSD_WP_PIN);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L780">780</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC780"><span class="pl-c">//}</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L781">781</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC781"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L782">782</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC782"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">da850_evm_mmc_get_cd</span>(<span class="pl-k">int</span> index)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L783">783</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC783">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L784">784</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC784"><span class="pl-c">//	return !gpio_get_value(DA850_MMCSD_CD_PIN);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L785">785</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC785">	<span class="pl-k">return</span> <span class="pl-c1">1</span> ;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L786">786</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC786">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L787">787</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC787"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L788">788</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC788"><span class="pl-k">static</span> <span class="pl-k">struct</span> davinci_mmc_config da850_mmc_config = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L789">789</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC789"><span class="pl-c">//	.get_ro		= da850_evm_mmc_get_ro,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L790">790</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC790"><span class="pl-c">//	.get_cd		= da850_evm_mmc_get_cd,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L791">791</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC791">	.<span class="pl-smi">wires</span>		= <span class="pl-c1">4</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L792">792</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC792">	.<span class="pl-smi">max_freq</span>	= <span class="pl-c1">50000000</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L793">793</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC793">	.<span class="pl-smi">caps</span>		= MMC_CAP_MMC_HIGHSPEED | MMC_CAP_SD_HIGHSPEED,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L794">794</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC794">	.<span class="pl-smi">version</span>	= MMC_CTLR_VERSION_2,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L795">795</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC795">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L796">796</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC796"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L797">797</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC797"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">da850_panel_power_ctrl</span>(<span class="pl-k">int</span> val)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L798">798</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC798">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L799">799</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC799">	<span class="pl-c">/* lcd power */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L800">800</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC800">	<span class="pl-c1">gpio_set_value</span>(DA850_LCD_PWR_PIN, val);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L801">801</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC801"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L802">802</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC802">	<span class="pl-c1">mdelay</span>(<span class="pl-c1">200</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L803">803</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC803"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L804">804</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC804">	<span class="pl-c">/* lcd backlight */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L805">805</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC805">	<span class="pl-c1">gpio_set_value</span>(DA850_LCD_BL_PIN, val);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L806">806</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC806">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L807">807</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC807"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L808">808</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC808"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">da850_lcd_hw_init</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L809">809</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC809">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L810">810</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC810">	<span class="pl-k">void</span> __iomem *cfg_mstpri2_base;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L811">811</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC811">	<span class="pl-k">int</span> status;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L812">812</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC812">	u32 val;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L813">813</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC813"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L814">814</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC814">	<span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L815">815</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC815"><span class="pl-c">	 * Reconfigure the LCDC priority to the highest to ensure that</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L816">816</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC816"><span class="pl-c">	 * the throughput/latency requirements for the LCDC are met.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L817">817</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC817"><span class="pl-c">	 */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L818">818</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC818">	cfg_mstpri2_base = <span class="pl-c1">DA8XX_SYSCFG0_VIRT</span>(DA8XX_MSTPRI2_REG);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L819">819</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC819"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L820">820</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC820">	val = <span class="pl-c1">__raw_readl</span>(cfg_mstpri2_base);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L821">821</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC821">	val &amp;= 0x0fffffff;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L822">822</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC822">	<span class="pl-c1">__raw_writel</span>(val, cfg_mstpri2_base);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L823">823</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC823"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L824">824</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC824">	status = <span class="pl-c1">gpio_request</span>(DA850_LCD_BL_PIN, <span class="pl-s"><span class="pl-pds">&quot;</span>lcd bl<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L825">825</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC825">	<span class="pl-k">if</span> (status &lt; <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L826">826</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC826">		<span class="pl-k">return</span> status;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L827">827</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC827"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L828">828</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC828">	status = <span class="pl-c1">gpio_request</span>(DA850_LCD_PWR_PIN, <span class="pl-s"><span class="pl-pds">&quot;</span>lcd pwr<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L829">829</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC829">	<span class="pl-k">if</span> (status &lt; <span class="pl-c1">0</span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L830">830</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC830">		<span class="pl-c1">gpio_free</span>(DA850_LCD_BL_PIN);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L831">831</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC831">		<span class="pl-k">return</span> status;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L832">832</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC832">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L833">833</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC833"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L834">834</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC834">	<span class="pl-c1">gpio_direction_output</span>(DA850_LCD_BL_PIN, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L835">835</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC835">	<span class="pl-c1">gpio_direction_output</span>(DA850_LCD_PWR_PIN, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L836">836</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC836"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L837">837</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC837">	<span class="pl-k">return</span> <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L838">838</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC838">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L839">839</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC839"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L840">840</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC840"><span class="pl-k">static</span> <span class="pl-k">const</span> <span class="pl-k">short</span> da850_evm_lcdc_pins[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L841">841</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC841">	DA850_GPIO2_8, DA850_GPIO2_15,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L842">842</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC842">	-<span class="pl-c1">1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L843">843</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC843">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L844">844</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC844"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L845">845</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC845"><span class="pl-k">static</span> <span class="pl-k">int</span> __init <span class="pl-en">da850_evm_config_emac</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L846">846</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC846">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L847">847</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC847">	<span class="pl-k">void</span> __iomem *cfg_chip3_base;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L848">848</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC848">	<span class="pl-k">int</span> ret;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L849">849</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC849">	u32 val;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L850">850</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC850">	<span class="pl-k">struct</span> davinci_soc_info *soc_info = &amp;davinci_soc_info;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L851">851</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC851">	u8 rmii_en = soc_info-&gt;emac_pdata-&gt;rmii_en;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L852">852</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC852"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L853">853</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC853">	<span class="pl-k">if</span> (!<span class="pl-c1">machine_is_davinci_da850_evm</span>())</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L854">854</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC854">		<span class="pl-k">return</span> <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L855">855</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC855"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L856">856</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC856">	cfg_chip3_base = <span class="pl-c1">DA8XX_SYSCFG0_VIRT</span>(DA8XX_CFGCHIP3_REG);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L857">857</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC857"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L858">858</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC858">	val = <span class="pl-c1">__raw_readl</span>(cfg_chip3_base);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L859">859</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC859"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L860">860</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC860"><span class="pl-c">//	if (rmii_en) {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L861">861</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC861"><span class="pl-c">//		val |= BIT(8);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L862">862</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC862"><span class="pl-c">//		ret = da8xx_pinmux_setup(da850_rmii_pins);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L863">863</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC863"><span class="pl-c">//		pr_info(&quot;EMAC: RMII PHY configured, MII PHY will not be&quot;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L864">864</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC864"><span class="pl-c">//							&quot; functional\n&quot;);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L865">865</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC865"><span class="pl-c">//	} else {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L866">866</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC866"><span class="pl-c">//		val &amp;= ~BIT(8);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L867">867</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC867"><span class="pl-c">//		ret = da8xx_pinmux_setup(da850_cpgmac_pins);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L868">868</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC868"><span class="pl-c">//		pr_info(&quot;EMAC: MII PHY configured, RMII PHY will not be&quot;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L869">869</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC869"><span class="pl-c">//							&quot; functional\n&quot;);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L870">870</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC870"><span class="pl-c">//	}</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L871">871</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC871"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L872">872</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC872"><span class="pl-c">//	if (ret)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L873">873</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC873"><span class="pl-c">//		pr_warning(&quot;da850_evm_init: cpgmac/rmii mux setup failed: %d\n&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L874">874</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC874"><span class="pl-c">//				ret);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L875">875</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC875"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L876">876</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC876">	<span class="pl-c">/* configure the CFGCHIP3 register for RMII or MII */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L877">877</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC877"><span class="pl-c">//	__raw_writel(val, cfg_chip3_base);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L878">878</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC878"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L879">879</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC879"><span class="pl-c">//	ret = davinci_cfg_reg(DA850_GPIO2_6);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L880">880</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC880"><span class="pl-c">//	if (ret)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L881">881</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC881"><span class="pl-c">//		pr_warning(&quot;da850_evm_init:GPIO(2,6) mux setup &quot;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L882">882</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC882"><span class="pl-c">//							&quot;failed\n&quot;);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L883">883</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC883"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L884">884</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC884"><span class="pl-c">//	ret = gpio_request(DA850_MII_MDIO_CLKEN_PIN, &quot;mdio_clk_en&quot;);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L885">885</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC885"><span class="pl-c">//	if (ret) {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L886">886</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC886"><span class="pl-c">//		pr_warning(&quot;Cannot open GPIO %d\n&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L887">887</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC887"><span class="pl-c">//					DA850_MII_MDIO_CLKEN_PIN);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L888">888</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC888"><span class="pl-c">//		return ret;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L889">889</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC889"><span class="pl-c">//	}</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L890">890</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC890"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L891">891</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC891">	<span class="pl-c">/* Enable/Disable MII MDIO clock */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L892">892</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC892"><span class="pl-c">//	gpio_direction_output(DA850_MII_MDIO_CLKEN_PIN, rmii_en);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L893">893</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC893"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L894">894</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC894"><span class="pl-c">//	soc_info-&gt;emac_pdata-&gt;phy_mask = DA850_EVM_PHY_MASK;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L895">895</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC895"><span class="pl-c">//	soc_info-&gt;emac_pdata-&gt;mdio_max_freq = DA850_EVM_MDIO_FREQUENCY;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L896">896</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC896"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L897">897</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC897"><span class="pl-c">//	ret = da8xx_register_emac();</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L898">898</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC898"><span class="pl-c">//	if (ret)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L899">899</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC899"><span class="pl-c">//		pr_warning(&quot;da850_evm_init: emac registration failed: %d\n&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L900">900</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC900"><span class="pl-c">//				ret);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L901">901</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC901"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L902">902</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC902"><span class="pl-c">//	return 0;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L903">903</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC903">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L904">904</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC904"><span class="pl-en">device_initcall</span>(da850_evm_config_emac);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L905">905</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC905"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L906">906</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC906"><span class="pl-c">/* Retaining these APIs, since the VPIF drivers do not check NULL handlers */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L907">907</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC907"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">da850_set_vpif_clock</span>(<span class="pl-k">int</span> mux_mode, <span class="pl-k">int</span> hd)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L908">908</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC908">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L909">909</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC909">	<span class="pl-k">return</span> <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L910">910</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC910">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L911">911</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC911"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L912">912</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC912"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">da850_setup_vpif_input_channel_mode</span>(<span class="pl-k">int</span> mux_mode)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L913">913</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC913">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L914">914</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC914">	<span class="pl-k">return</span> <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L915">915</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC915">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L916">916</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC916"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L917">917</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC917"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">da850_vpif_intr_status</span>(<span class="pl-k">void</span> __iomem *vpif_base, <span class="pl-k">int</span> channel)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L918">918</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC918">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L919">919</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC919">	<span class="pl-k">int</span> status = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L920">920</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC920">	<span class="pl-k">int</span> mask;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L921">921</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC921"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L922">922</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC922">	<span class="pl-k">if</span> (channel &lt; <span class="pl-c1">0</span> || channel &gt; <span class="pl-c1">3</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L923">923</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC923">		<span class="pl-k">return</span> <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L924">924</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC924"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L925">925</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC925">	mask = <span class="pl-c1">1</span> &lt;&lt; channel;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L926">926</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC926">	status = <span class="pl-c1">__raw_readl</span>((vpif_base + VPIF_STATUS)) &amp; mask;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L927">927</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC927">	<span class="pl-c1">__raw_writel</span>(status, (vpif_base + VPIF_STATUS_CLR));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L928">928</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC928"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L929">929</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC929">	<span class="pl-k">return</span> status;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L930">930</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC930">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L931">931</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC931"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L932">932</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC932"><span class="pl-c">/* VPIF capture configuration */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L933">933</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC933"><span class="pl-k">static</span> <span class="pl-k">struct</span> tvp514x_platform_data tvp5146_pdata = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L934">934</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC934">	.<span class="pl-smi">clk_polarity</span> = <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L935">935</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC935">	.<span class="pl-smi">hs_polarity</span> = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L936">936</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC936">	.<span class="pl-smi">vs_polarity</span> = <span class="pl-c1">1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L937">937</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC937">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L938">938</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC938"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L939">939</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC939">#<span class="pl-k">define</span> <span class="pl-en">TVP514X_STD_ALL</span> (V4L2_STD_NTSC | V4L2_STD_PAL)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L940">940</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC940"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L941">941</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC941"><span class="pl-k">static</span> <span class="pl-k">struct</span> vpif_subdev_info da850_vpif_capture_sdev_info[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L942">942</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC942">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L943">943</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC943">		.<span class="pl-smi">name</span>	= TVP5147_CH0,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L944">944</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC944">		.<span class="pl-smi">board_info</span> = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L945">945</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC945">			<span class="pl-c1">I2C_BOARD_INFO</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>tvp5146<span class="pl-pds">&quot;</span></span>, 0x5d),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L946">946</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC946">			.<span class="pl-smi">platform_data</span> = &amp;tvp5146_pdata,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L947">947</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC947">		},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L948">948</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC948">		.<span class="pl-smi">input</span> = INPUT_CVBS_VI2B,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L949">949</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC949">		.<span class="pl-smi">output</span> = OUTPUT_10BIT_422_EMBEDDED_SYNC,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L950">950</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC950">		.<span class="pl-smi">can_route</span> = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L951">951</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC951">		.<span class="pl-smi">vpif_if</span> = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L952">952</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC952">			.<span class="pl-smi">if_type</span> = VPIF_IF_BT656,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L953">953</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC953">			.<span class="pl-smi">hd_pol</span> = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L954">954</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC954">			.<span class="pl-smi">vd_pol</span> = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L955">955</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC955">			.<span class="pl-smi">fid_pol</span> = <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L956">956</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC956">		},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L957">957</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC957">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L958">958</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC958">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L959">959</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC959">		.<span class="pl-smi">name</span>	= TVP5147_CH1,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L960">960</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC960">		.<span class="pl-smi">board_info</span> = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L961">961</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC961">			<span class="pl-c1">I2C_BOARD_INFO</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>tvp5146<span class="pl-pds">&quot;</span></span>, 0x5c),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L962">962</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC962">			.<span class="pl-smi">platform_data</span> = &amp;tvp5146_pdata,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L963">963</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC963">		},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L964">964</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC964">		.<span class="pl-smi">input</span> = INPUT_SVIDEO_VI2C_VI1C,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L965">965</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC965">		.<span class="pl-smi">output</span> = OUTPUT_10BIT_422_EMBEDDED_SYNC,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L966">966</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC966">		.<span class="pl-smi">can_route</span> = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L967">967</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC967">		.<span class="pl-smi">vpif_if</span> = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L968">968</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC968">			.<span class="pl-smi">if_type</span> = VPIF_IF_BT656,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L969">969</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC969">			.<span class="pl-smi">hd_pol</span> = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L970">970</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC970">			.<span class="pl-smi">vd_pol</span> = <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L971">971</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC971">			.<span class="pl-smi">fid_pol</span> = <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L972">972</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC972">		},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L973">973</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC973">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L974">974</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC974">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L975">975</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC975"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L976">976</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC976"><span class="pl-k">static</span> <span class="pl-k">const</span> <span class="pl-k">struct</span> vpif_input da850_ch0_inputs[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L977">977</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC977">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L978">978</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC978">		.<span class="pl-smi">input</span> = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L979">979</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC979">			.<span class="pl-smi">index</span> = <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L980">980</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC980">			.<span class="pl-smi">name</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>Composite<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L981">981</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC981">			.<span class="pl-smi">type</span> = V4L2_INPUT_TYPE_CAMERA,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L982">982</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC982">			.<span class="pl-smi">std</span> = TVP514X_STD_ALL,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L983">983</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC983">		},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L984">984</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC984">		.<span class="pl-smi">subdev_name</span> = TVP5147_CH0,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L985">985</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC985">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L986">986</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC986">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L987">987</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC987"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L988">988</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC988"><span class="pl-k">static</span> <span class="pl-k">const</span> <span class="pl-k">struct</span> vpif_input da850_ch1_inputs[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L989">989</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC989">       {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L990">990</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC990">		.<span class="pl-smi">input</span> = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L991">991</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC991">			.<span class="pl-smi">index</span> = <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L992">992</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC992">			.<span class="pl-smi">name</span> = <span class="pl-s"><span class="pl-pds">&quot;</span>S-Video<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L993">993</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC993">			.<span class="pl-smi">type</span> = V4L2_INPUT_TYPE_CAMERA,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L994">994</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC994">			.<span class="pl-smi">std</span> = TVP514X_STD_ALL,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L995">995</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC995">		},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L996">996</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC996">		.<span class="pl-smi">subdev_name</span> = TVP5147_CH1,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L997">997</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC997">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L998">998</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC998">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L999">999</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC999"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1000">1000</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1000"><span class="pl-k">static</span> <span class="pl-k">struct</span> vpif_capture_config da850_vpif_capture_config = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1001">1001</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1001">	.<span class="pl-smi">setup_input_channel_mode</span> = da850_setup_vpif_input_channel_mode,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1002">1002</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1002">	.<span class="pl-smi">intr_status</span> = da850_vpif_intr_status,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1003">1003</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1003">	.<span class="pl-smi">subdev_info</span> = da850_vpif_capture_sdev_info,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1004">1004</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1004">	.<span class="pl-smi">subdev_count</span> = <span class="pl-c1">ARRAY_SIZE</span>(da850_vpif_capture_sdev_info),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1005">1005</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1005">	.<span class="pl-smi">chan_config</span>[<span class="pl-c1">0</span>] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1006">1006</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1006">		.<span class="pl-smi">inputs</span> = da850_ch0_inputs,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1007">1007</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1007">		.<span class="pl-smi">input_count</span> = <span class="pl-c1">ARRAY_SIZE</span>(da850_ch0_inputs),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1008">1008</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1008">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1009">1009</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1009">	.<span class="pl-smi">chan_config</span>[<span class="pl-c1">1</span>] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1010">1010</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1010">		.<span class="pl-smi">inputs</span> = da850_ch1_inputs,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1011">1011</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1011">		.<span class="pl-smi">input_count</span> = <span class="pl-c1">ARRAY_SIZE</span>(da850_ch1_inputs),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1012">1012</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1012">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1013">1013</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1013">	.<span class="pl-smi">card_name</span>      = <span class="pl-s"><span class="pl-pds">&quot;</span>DA850/OMAP-L138 Video Capture<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1014">1014</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1014">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1015">1015</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1015"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1016">1016</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1016"><span class="pl-c">/* VPIF display configuration */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1017">1017</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1017"><span class="pl-k">static</span> <span class="pl-k">struct</span> vpif_subdev_info da850_vpif_subdev[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1018">1018</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1018">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1019">1019</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1019">		.<span class="pl-smi">name</span>	= <span class="pl-s"><span class="pl-pds">&quot;</span>adv7343<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1020">1020</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1020">		.<span class="pl-smi">board_info</span> = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1021">1021</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1021">			<span class="pl-c1">I2C_BOARD_INFO</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>adv7343<span class="pl-pds">&quot;</span></span>, 0x2a),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1022">1022</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1022">		},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1023">1023</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1023">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1024">1024</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1024">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1025">1025</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1025"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1026">1026</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1026"><span class="pl-k">static</span> <span class="pl-k">const</span> <span class="pl-k">char</span> *vpif_output[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1027">1027</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1027">	<span class="pl-s"><span class="pl-pds">&quot;</span>Composite<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1028">1028</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1028">	<span class="pl-s"><span class="pl-pds">&quot;</span>Component<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1029">1029</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1029">	<span class="pl-s"><span class="pl-pds">&quot;</span>S-Video<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1030">1030</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1030">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1031">1031</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1031"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1032">1032</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1032"><span class="pl-k">static</span> <span class="pl-k">struct</span> vpif_display_config da850_vpif_display_config = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1033">1033</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1033">	.<span class="pl-smi">set_clock</span>	= da850_set_vpif_clock,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1034">1034</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1034">	.<span class="pl-smi">intr_status</span>	= da850_vpif_intr_status,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1035">1035</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1035">	.<span class="pl-smi">subdevinfo</span>	= da850_vpif_subdev,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1036">1036</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1036">	.<span class="pl-smi">subdev_count</span>	= <span class="pl-c1">ARRAY_SIZE</span>(da850_vpif_subdev),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1037">1037</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1037">	.<span class="pl-smi">output</span>		= vpif_output,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1038">1038</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1038">	.<span class="pl-smi">output_count</span>	= <span class="pl-c1">ARRAY_SIZE</span>(vpif_output),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1039">1039</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1039">	.<span class="pl-smi">card_name</span>	= <span class="pl-s"><span class="pl-pds">&quot;</span>DA850/OMAP-L138 Video Display<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1040">1040</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1040">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1041">1041</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1041"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1042">1042</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1042">#<span class="pl-k">if</span> defined(CONFIG_DAVINCI_MCBSP0)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1043">1043</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1043">#<span class="pl-k">define</span> <span class="pl-en">HAS_MCBSP0</span> <span class="pl-c1">1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1044">1044</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1044">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1045">1045</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1045">#<span class="pl-k">define</span> <span class="pl-en">HAS_MCBSP0</span> <span class="pl-c1">0</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1046">1046</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1046">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1047">1047</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1047"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1048">1048</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1048">#<span class="pl-k">if</span> defined(CONFIG_DAVINCI_MCBSP1)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1049">1049</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1049">#<span class="pl-k">define</span> <span class="pl-en">HAS_MCBSP1</span> <span class="pl-c1">1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1050">1050</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1050">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1051">1051</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1051">#<span class="pl-k">define</span> <span class="pl-en">HAS_MCBSP1</span> <span class="pl-c1">0</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1052">1052</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1052">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1053">1053</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1053"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1054">1054</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1054">#<span class="pl-k">if</span> defined(CONFIG_TI_DAVINCI_EMAC) || \</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1055">1055</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1055">	<span class="pl-en">defined</span>(CONFIG_TI_DAVINCI_EMAC_MODULE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1056">1056</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1056">#<span class="pl-k">define</span> <span class="pl-en">HAS_EMAC</span> <span class="pl-c1">1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1057">1057</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1057">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1058">1058</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1058">#<span class="pl-k">define</span> <span class="pl-en">HAS_EMAC</span> <span class="pl-c1">0</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1059">1059</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1059">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1060">1060</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1060"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1061">1061</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1061">#<span class="pl-k">if</span> defined(CONFIG_SND_DA850_SOC_EVM) || \</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1062">1062</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1062">	<span class="pl-en">defined</span>(CONFIG_SND_DA850_SOC_EVM_MODULE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1063">1063</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1063">#<span class="pl-k">define</span> <span class="pl-en">HAS_MCASP</span> <span class="pl-c1">1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1064">1064</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1064">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1065">1065</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1065">#<span class="pl-k">define</span> <span class="pl-en">HAS_MCASP</span> <span class="pl-c1">0</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1066">1066</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1066">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1067">1067</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1067"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1068">1068</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1068">#<span class="pl-k">if</span> defined(CONFIG_DA850_UI_RMII) &amp;&amp; (HAS_EMAC)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1069">1069</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1069">#<span class="pl-k">define</span> <span class="pl-en">HAS_RMII</span> <span class="pl-c1">1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1070">1070</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1070">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1071">1071</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1071">#<span class="pl-k">define</span> <span class="pl-en">HAS_RMII</span> <span class="pl-c1">0</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1072">1072</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1072">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1073">1073</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1073"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1074">1074</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1074">#<span class="pl-k">if</span> defined(CONFIG_DA850_UI_LCD) &amp;&amp; defined(CONFIG_FB_DA8XX) ||\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1075">1075</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1075">		<span class="pl-en">defined</span>(CONFIG_FB_DA8XX_MODULE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1076">1076</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1076">#<span class="pl-k">define</span> <span class="pl-en">HAS_GLCD</span> <span class="pl-c1">1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1077">1077</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1077">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1078">1078</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1078">#<span class="pl-k">define</span> <span class="pl-en">HAS_GLCD</span> <span class="pl-c1">0</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1079">1079</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1079">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1080">1080</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1080"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1081">1081</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1081">#<span class="pl-k">if</span> defined(CONFIG_VIDEO_DAVINCI_VPIF_DISPLAY) ||\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1082">1082</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1082">		<span class="pl-en">defined</span>(CONFIG_VIDEO_DAVINCI_VPIF_DISPLAY_MODULE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1083">1083</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1083">#<span class="pl-k">define</span> <span class="pl-en">HAS_VPIF_DISPLAY</span> <span class="pl-c1">1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1084">1084</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1084">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1085">1085</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1085">#<span class="pl-k">define</span> <span class="pl-en">HAS_VPIF_DISPLAY</span> <span class="pl-c1">0</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1086">1086</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1086">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1087">1087</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1087"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1088">1088</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1088">#<span class="pl-k">if</span> defined(CONFIG_VIDEO_DAVINCI_VPIF_CAPTURE) ||\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1089">1089</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1089">		<span class="pl-en">defined</span>(CONFIG_VIDEO_DAVINCI_VPIF_CAPTURE_MODULE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1090">1090</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1090">#<span class="pl-k">define</span> <span class="pl-en">HAS_VPIF_CAPTURE</span> <span class="pl-c1">1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1091">1091</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1091">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1092">1092</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1092">#<span class="pl-k">define</span> <span class="pl-en">HAS_VPIF_CAPTURE</span> <span class="pl-c1">0</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1093">1093</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1093">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1094">1094</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1094"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1095">1095</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1095"><span class="pl-k">static</span> <span class="pl-c1">da8xx_ocic_handler_t</span> da850_evm_usb_ocic_handler;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1096">1096</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1096"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1097">1097</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1097"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">da850_evm_usb_set_power</span>(<span class="pl-k">unsigned</span> port, <span class="pl-k">int</span> on)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1098">1098</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1098">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1099">1099</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1099">	<span class="pl-c1">pr_info</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_usb_set_power<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);	</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1100">1100</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1100">	<span class="pl-c1">gpio_set_value</span>(DA850_USB1_VBUS_PIN, on); <span class="pl-c">//on on AM18xx EVM</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1101">1101</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1101">	<span class="pl-k">return</span> <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1102">1102</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1102">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1103">1103</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1103"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1104">1104</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1104"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">da850_evm_usb_get_power</span>(<span class="pl-k">unsigned</span> port)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1105">1105</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1105">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1106">1106</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1106">	<span class="pl-k">return</span> <span class="pl-c1">gpio_get_value</span>(DA850_USB1_VBUS_PIN);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1107">1107</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1107">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1108">1108</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1108"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1109">1109</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1109"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">da850_evm_usb_get_oci</span>(<span class="pl-k">unsigned</span> port)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1110">1110</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1110">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1111">1111</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1111">	<span class="pl-k">return</span> !<span class="pl-c1">gpio_get_value</span>(DA850_USB1_OC_PIN);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1112">1112</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1112">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1113">1113</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1113"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1114">1114</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1114"><span class="pl-k">static</span> <span class="pl-c1">irqreturn_t</span> <span class="pl-en">da850_evm_usb_ocic_irq</span>(<span class="pl-k">int</span>, <span class="pl-k">void</span> *);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1115">1115</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1115"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1116">1116</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1116"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">da850_evm_usb_ocic_notify</span>(<span class="pl-c1">da8xx_ocic_handler_t</span> handler)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1117">1117</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1117">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1118">1118</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1118">	<span class="pl-k">int</span> irq 	= <span class="pl-c1">gpio_to_irq</span>(DA850_USB1_OC_PIN);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1119">1119</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1119">	<span class="pl-k">int</span> error	= <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1120">1120</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1120"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1121">1121</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1121">	<span class="pl-c1">pr_info</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_usb_ocic_notify<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1122">1122</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1122"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1123">1123</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1123">	<span class="pl-k">if</span> (handler != <span class="pl-c1">NULL</span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1124">1124</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1124">		da850_evm_usb_ocic_handler = handler;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1125">1125</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1125">		<span class="pl-c1">pr_info</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_usb_ocic_handler = handler<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1126">1126</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1126"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1127">1127</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1127">		error = <span class="pl-c1">request_irq</span>(irq, da850_evm_usb_ocic_irq, IRQF_DISABLED |</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1128">1128</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1128">				    IRQF_TRIGGER_RISING | IRQF_TRIGGER_FALLING,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1129">1129</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1129">				    <span class="pl-s"><span class="pl-pds">&quot;</span>OHCI over-current indicator<span class="pl-pds">&quot;</span></span>, <span class="pl-c1">NULL</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1130">1130</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1130">		<span class="pl-k">if</span> (error)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1131">1131</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1131">			<span class="pl-c1">printk</span>(KERN_ERR <span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span>: could not request IRQ to watch <span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1132">1132</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1132">			       <span class="pl-s"><span class="pl-pds">&quot;</span>over-current indicator changes<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, __func__);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1133">1133</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1133">	} <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1134">1134</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1134">		<span class="pl-c1">free_irq</span>(irq, <span class="pl-c1">NULL</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1135">1135</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1135"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1136">1136</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1136">	<span class="pl-k">return</span> error;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1137">1137</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1137">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1138">1138</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1138"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1139">1139</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1139"><span class="pl-k">static</span> <span class="pl-k">struct</span> da8xx_ohci_root_hub da850_evm_usb11_pdata = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1140">1140</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1140">	.<span class="pl-smi">set_power</span>	= da850_evm_usb_set_power,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1141">1141</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1141">	.<span class="pl-smi">get_power</span>	= da850_evm_usb_get_power,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1142">1142</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1142">	.<span class="pl-smi">get_oci</span>	= da850_evm_usb_get_oci,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1143">1143</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1143">	.<span class="pl-smi">ocic_notify</span>	= da850_evm_usb_ocic_notify,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1144">1144</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1144"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1145">1145</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1145">	<span class="pl-c">/* TPS2065 switch @ 5V */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1146">1146</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1146">	.<span class="pl-smi">potpgt</span>		= (<span class="pl-c1">3</span> + <span class="pl-c1">1</span>) / <span class="pl-c1">2</span>,	<span class="pl-c">/* 3 ms max */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1147">1147</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1147">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1148">1148</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1148"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1149">1149</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1149"><span class="pl-k">static</span> <span class="pl-c1">irqreturn_t</span> <span class="pl-en">da850_evm_usb_ocic_irq</span>(<span class="pl-k">int</span> irq, <span class="pl-k">void</span> *dev_id)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1150">1150</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1150">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1151">1151</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1151">	<span class="pl-c1">pr_info</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_usb_ocic_irq<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);	</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1152">1152</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1152">	<span class="pl-c1">da850_evm_usb_ocic_handler</span>(&amp;da850_evm_usb11_pdata, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1153">1153</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1153">	<span class="pl-c1">pr_info</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_usb_ocic_handler<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1154">1154</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1154">	<span class="pl-k">return</span> IRQ_HANDLED;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1155">1155</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1155">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1156">1156</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1156"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1157">1157</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1157"><span class="pl-c">/* hid descriptor for a test */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1158">1158</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1158"><span class="pl-k">static</span> <span class="pl-k">struct</span> hidg_func_descriptor rudolf_hid1_data = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1159">1159</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1159">	.<span class="pl-smi">subclass</span>		= <span class="pl-c1">0</span>, <span class="pl-c">/* Subclass NONE */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1160">1160</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1160">	.<span class="pl-smi">protocol</span>		= <span class="pl-c1">0</span>, <span class="pl-c">/* Protocol NONE */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1161">1161</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1161">	.<span class="pl-smi">report_length</span>		= 0x40,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1162">1162</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1162">	.<span class="pl-smi">report_desc_length</span>	= <span class="pl-c1">25</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1163">1163</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1163">	.<span class="pl-smi">report_desc</span>		= {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1164">1164</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1164"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1165">1165</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1165">		0x06, 0x00, 0xFF, <span class="pl-c">// Usage page (vendor defined) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1166">1166</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1166">      		0x09, 0x01, <span class="pl-c">// Usage ID (vendor defined) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1167">1167</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1167">      		0xA1, 0x01, <span class="pl-c">// Collection (application) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1168">1168</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1168"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1169">1169</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1169">    		<span class="pl-c">// The Input report </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1170">1170</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1170">        	<span class="pl-c">// 0x09, 0x03,       // Usage ID - vendor defined </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1171">1171</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1171">        	0x15, 0x00,       <span class="pl-c">// Logical Minimum (0) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1172">1172</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1172">        	0x26, 0xFF, 0x00,   <span class="pl-c">// Logical Maximum (255) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1173">1173</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1173">        	0x75, 0x08,       <span class="pl-c">// Report Size (8 bits) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1174">1174</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1174">        	0x95, 0x40,       <span class="pl-c">// Report Count (64 fields)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1175">1175</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1175"> </td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1176">1176</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1176">		0x09, 0x01,	  <span class="pl-c">// USAGE (vendor usage 1)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1177">1177</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1177">        	0x81, 0x02,       <span class="pl-c">// Input (Data, Variable, Absolute) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1178">1178</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1178"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1179">1179</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1179">		0x09, 0x01,	  <span class="pl-c">// USAGE (vendor usage 1)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1180">1180</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1180">        	0x91, 0x02,       <span class="pl-c">// Output (Data, Variable, Absolute) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1181">1181</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1181"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1182">1182</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1182">      		0xc0		<span class="pl-c">/* END_COLLECTION                         */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1183">1183</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1183"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1184">1184</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1184">		}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1185">1185</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1185">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1186">1186</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1186"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1187">1187</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1187"><span class="pl-k">static</span> <span class="pl-k">struct</span> platform_device rudolf_hid1 = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1188">1188</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1188">	.<span class="pl-smi">name</span>			= <span class="pl-s"><span class="pl-pds">&quot;</span>hidg<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1189">1189</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1189">	.<span class="pl-smi">id</span>			= <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1190">1190</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1190">	.<span class="pl-smi">num_resources</span>		= <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1191">1191</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1191">	.<span class="pl-smi">resource</span>		= <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1192">1192</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1192">	.<span class="pl-smi">dev</span>.<span class="pl-smi">platform_data</span>	= &amp;rudolf_hid1_data,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1193">1193</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1193">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1194">1194</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1194"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1195">1195</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1195"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1196">1196</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1196"><span class="pl-c">/* hid descriptor for a keyboard */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1197">1197</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1197"><span class="pl-k">static</span> <span class="pl-k">struct</span> hidg_func_descriptor rudolf_hid2_data = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1198">1198</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1198">	.<span class="pl-smi">subclass</span>		= <span class="pl-c1">0</span>, <span class="pl-c">/* Subclass NONE */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1199">1199</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1199">	.<span class="pl-smi">protocol</span>		= <span class="pl-c1">0</span>, <span class="pl-c">/* Protocol NONE */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1200">1200</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1200">	.<span class="pl-smi">report_length</span>		= 0x40,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1201">1201</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1201">	.<span class="pl-smi">report_desc_length</span>	= <span class="pl-c1">25</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1202">1202</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1202">	.<span class="pl-smi">report_desc</span>		= {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1203">1203</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1203"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1204">1204</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1204">		0x06, 0x00, 0xFF, <span class="pl-c">// Usage page (vendor defined) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1205">1205</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1205">      		0x09, 0x01, <span class="pl-c">// Usage ID (vendor defined) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1206">1206</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1206">      		0xA1, 0x01, <span class="pl-c">// Collection (application) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1207">1207</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1207"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1208">1208</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1208">    		<span class="pl-c">// The Input report </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1209">1209</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1209">        	<span class="pl-c">// 0x09, 0x03,       // Usage ID - vendor defined </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1210">1210</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1210">        	0x15, 0x00,       <span class="pl-c">// Logical Minimum (0) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1211">1211</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1211">        	0x26, 0xFF, 0x00,   <span class="pl-c">// Logical Maximum (255) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1212">1212</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1212">        	0x75, 0x08,       <span class="pl-c">// Report Size (8 bits) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1213">1213</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1213">        	0x95, 0x40,       <span class="pl-c">// Report Count (64 fields)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1214">1214</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1214"> </td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1215">1215</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1215">		0x09, 0x01,	  <span class="pl-c">// USAGE (vendor usage 1)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1216">1216</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1216">        	0x81, 0x02,       <span class="pl-c">// Input (Data, Variable, Absolute) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1217">1217</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1217"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1218">1218</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1218">		0x09, 0x01,	  <span class="pl-c">// USAGE (vendor usage 1)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1219">1219</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1219">        	0x91, 0x02,       <span class="pl-c">// Output (Data, Variable, Absolute) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1220">1220</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1220"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1221">1221</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1221">      		0xc0		<span class="pl-c">/* END_COLLECTION                         */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1222">1222</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1222">		}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1223">1223</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1223">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1224">1224</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1224"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1225">1225</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1225"><span class="pl-k">static</span> <span class="pl-k">struct</span> platform_device rudolf_hid2 = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1226">1226</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1226">	.<span class="pl-smi">name</span>			= <span class="pl-s"><span class="pl-pds">&quot;</span>hidg<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1227">1227</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1227">	.<span class="pl-smi">id</span>			= <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1228">1228</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1228">	.<span class="pl-smi">num_resources</span>		= <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1229">1229</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1229">	.<span class="pl-smi">resource</span>		= <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1230">1230</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1230">	.<span class="pl-smi">dev</span>.<span class="pl-smi">platform_data</span>	= &amp;rudolf_hid2_data,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1231">1231</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1231">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1232">1232</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1232"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1233">1233</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1233"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1234">1234</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1234"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1235">1235</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1235"><span class="pl-c">/* Bluetooth Slow clock init using ecap 2 */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1236">1236</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1236"><span class="pl-k">static</span> __init <span class="pl-k">void</span> <span class="pl-en">da850_evm_bt_slow_clock_init</span>(<span class="pl-k">void</span>)						<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1237">1237</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1237">{												<span class="pl-c">// LEGO BT		</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1238">1238</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1238">  <span class="pl-k">int</span> PSC1;											<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1239">1239</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1239">												<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1240">1240</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1240">  PSC1 = <span class="pl-c1">__raw_readl</span>(<span class="pl-c1">DA8XX_PSC1_VIRT</span>(0x294 * <span class="pl-c1">4</span>));  <span class="pl-c">// Old PSC1 is 32bit -&gt; explains &quot;* 4&quot;	// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1241">1241</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1241">  PSC1 |= <span class="pl-c1">3</span>;											<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1242">1242</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1242">  <span class="pl-c1">__raw_writel</span>(PSC1, <span class="pl-c1">DA8XX_PSC1_VIRT</span>(0x294 * <span class="pl-c1">4</span>));						<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1243">1243</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1243">												<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1244">1244</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1244">  PSC1 = <span class="pl-c1">__raw_readl</span>(<span class="pl-c1">DA8XX_PSC1_VIRT</span>(0x48 * <span class="pl-c1">4</span>));						<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1245">1245</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1245">  PSC1 |= <span class="pl-c1">3</span>;											<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1246">1246</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1246">  <span class="pl-c1">__raw_writel</span>(PSC1, <span class="pl-c1">DA8XX_PSC1_VIRT</span>(0x48 * <span class="pl-c1">4</span>));						<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1247">1247</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1247"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1248">1248</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1248">  PSC1 = <span class="pl-c1">__raw_readl</span>(<span class="pl-c1">DA8XX_SYSCFG1_VIRT</span>(0x3 * <span class="pl-c1">4</span>));						<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1249">1249</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1249">  PSC1 &amp;= ~0x00000004;										<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1250">1250</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1250">  <span class="pl-c1">__raw_writel</span>(PSC1, <span class="pl-c1">DA8XX_SYSCFG1_VIRT</span>(0x3 * <span class="pl-c1">4</span>));						<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1251">1251</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1251"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1252">1252</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1252">  <span class="pl-c1">__raw_writel</span>(<span class="pl-c1">0</span>,      <span class="pl-c1">DA8XX_ECAP2_VIRT</span>(<span class="pl-c1">0</span> * <span class="pl-c1">2</span>));     <span class="pl-c">// Old ECAP is 16bit -&gt; explains &quot;* 2&quot;     // LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1253">1253</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1253">  <span class="pl-c1">__raw_writel</span>(<span class="pl-c1">0</span>,      <span class="pl-c1">DA8XX_ECAP2_VIRT</span>(<span class="pl-c1">2</span> * <span class="pl-c1">2</span>));     <span class="pl-c">//						// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1254">1254</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1254">  <span class="pl-c1">__raw_writew</span>(0x0690, <span class="pl-c1">DA8XX_ECAP2_VIRT</span>(0x15 * <span class="pl-c1">2</span>));  <span class="pl-c">// Setup					// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1255">1255</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1255">  <span class="pl-c1">__raw_writel</span>(<span class="pl-c1">2014</span>,   <span class="pl-c1">DA8XX_ECAP2_VIRT</span>(0x06 * <span class="pl-c1">2</span>));  <span class="pl-c">// Duty					// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1256">1256</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1256">  <span class="pl-c1">__raw_writel</span>(<span class="pl-c1">4028</span>,   <span class="pl-c1">DA8XX_ECAP2_VIRT</span>(0x04 * <span class="pl-c1">2</span>));  <span class="pl-c">// Freq					// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1257">1257</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1257"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1258">1258</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1258">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1259">1259</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1259"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1260">1260</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1260"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1261">1261</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1261"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1262">1262</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1262"><span class="pl-k">static</span> <span class="pl-k">struct</span> musb_hdrc_platform_data usb_evm_data[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1263">1263</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1263">	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1264">1264</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1264">#<span class="pl-k">ifdef</span> CONFIG_USB_MUSB_OTG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1265">1265</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1265">		.<span class="pl-smi">mode</span> = MUSB_OTG,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1266">1266</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1266">#<span class="pl-k">elif</span> defined(CONFIG_USB_MUSB_DUAL_ROLE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1267">1267</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1267">		.<span class="pl-smi">mode</span> = MUSB_DUAL_ROLE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1268">1268</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1268">#<span class="pl-k">elif</span> defined(CONFIG_USB_MUSB_PERIPHERAL)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1269">1269</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1269">		.<span class="pl-smi">mode</span> =  MUSB_PERIPHERAL,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1270">1270</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1270">#<span class="pl-k">elif</span> defined(CONFIG_USB_MUSB_HOST)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1271">1271</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1271">		.<span class="pl-smi">mode</span> = MUSB_HOST,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1272">1272</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1272">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1273">1273</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1273">		.<span class="pl-smi">power</span> = <span class="pl-c1">255</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1274">1274</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1274">		.<span class="pl-smi">potpgt</span> = <span class="pl-c1">8</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1275">1275</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1275">		.<span class="pl-smi">set_vbus</span> = <span class="pl-c1">NULL</span>, <span class="pl-c">/* VBUs is directly controlled by the IP */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1276">1276</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1276">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1277">1277</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1277">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1278">1278</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1278"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1279">1279</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1279"><span class="pl-k">static</span> __init <span class="pl-k">void</span> <span class="pl-en">da850_evm_usb_init</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1280">1280</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1280">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1281">1281</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1281">	<span class="pl-k">int</span> ret;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1282">1282</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1282">	u32 cfgchip2;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1283">1283</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1283"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1284">1284</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1284">	<span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1285">1285</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1285"><span class="pl-c">	 * Setup the Ref. clock frequency for the EVM at 24 MHz.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1286">1286</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1286"><span class="pl-c">	 */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1287">1287</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1287">	cfgchip2 = <span class="pl-c1">__raw_readl</span>(<span class="pl-c1">DA8XX_SYSCFG0_VIRT</span>(DA8XX_CFGCHIP2_REG));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1288">1288</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1288">	cfgchip2 &amp;= ~CFGCHIP2_REFFREQ;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1289">1289</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1289">	cfgchip2 |=  CFGCHIP2_REFFREQ_24MHZ;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1290">1290</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1290">	<span class="pl-c1">__raw_writel</span>(cfgchip2, <span class="pl-c1">DA8XX_SYSCFG0_VIRT</span>(DA8XX_CFGCHIP2_REG));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1291">1291</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1291"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1292">1292</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1292">	<span class="pl-c1">da8xx_usb20_configure</span>(usb_evm_data, <span class="pl-c1">ARRAY_SIZE</span>(usb_evm_data));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1293">1293</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1293"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1294">1294</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1294">	<span class="pl-c1">platform_device_register</span>(&amp;rudolf_hid1);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1295">1295</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1295">	<span class="pl-c1">platform_device_register</span>(&amp;rudolf_hid2);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1296">1296</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1296"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1297">1297</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1297">	ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_evm_usb11_pins);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1298">1298</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1298">	<span class="pl-k">if</span> (ret) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1299">1299</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1299">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span>: USB 1.1 PinMux setup failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1300">1300</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1300">			   __func__, ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1301">1301</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1301">		<span class="pl-k">return</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1302">1302</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1302">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1303">1303</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1303"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1304">1304</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1304">	ret = <span class="pl-c1">gpio_request</span>(DA850_USB1_VBUS_PIN, <span class="pl-s"><span class="pl-pds">&quot;</span>USB1 VBUS<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1305">1305</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1305">	<span class="pl-k">if</span> (ret) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1306">1306</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1306">		<span class="pl-c1">printk</span>(KERN_ERR <span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span>: failed to request GPIO for USB 1.1 port <span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1307">1307</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1307">		       <span class="pl-s"><span class="pl-pds">&quot;</span>power control: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, __func__, ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1308">1308</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1308">		<span class="pl-k">return</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1309">1309</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1309">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1310">1310</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1310">	<span class="pl-c1">gpio_direction_output</span>(DA850_USB1_VBUS_PIN, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1311">1311</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1311"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1312">1312</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1312">	ret = <span class="pl-c1">gpio_request</span>(DA850_USB1_OC_PIN, <span class="pl-s"><span class="pl-pds">&quot;</span>USB1 OC<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1313">1313</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1313">	<span class="pl-k">if</span> (ret) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1314">1314</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1314">		<span class="pl-c1">printk</span>(KERN_ERR <span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span>: failed to request GPIO for USB 1.1 port <span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1315">1315</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1315">		       <span class="pl-s"><span class="pl-pds">&quot;</span>over-current indicator: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, __func__, ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1316">1316</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1316">		<span class="pl-k">return</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1317">1317</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1317">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1318">1318</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1318">	<span class="pl-c1">gpio_direction_input</span>(DA850_USB1_OC_PIN);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1319">1319</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1319"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1320">1320</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1320">	ret = <span class="pl-c1">da8xx_register_usb11</span>(&amp;da850_evm_usb11_pdata);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1321">1321</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1321">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1322">1322</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1322">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span>: USB 1.1 registration failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1323">1323</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1323">			   __func__, ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1324">1324</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1324">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1325">1325</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1325"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1326">1326</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1326"><span class="pl-k">static</span> <span class="pl-k">struct</span> i2c_gpio_platform_data da850_gpio_i2c_pdata = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1327">1327</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1327">	.<span class="pl-smi">sda_pin</span>	= <span class="pl-c1">GPIO_TO_PIN</span>(<span class="pl-c1">1</span>, <span class="pl-c1">4</span>),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1328">1328</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1328">	.<span class="pl-smi">scl_pin</span>	= <span class="pl-c1">GPIO_TO_PIN</span>(<span class="pl-c1">1</span>, <span class="pl-c1">5</span>),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1329">1329</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1329">	.<span class="pl-smi">udelay</span>		= <span class="pl-c1">2</span>,			<span class="pl-c">/* 250 KHz */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1330">1330</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1330">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1331">1331</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1331"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1332">1332</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1332"><span class="pl-k">static</span> <span class="pl-k">struct</span> platform_device da850_gpio_i2c = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1333">1333</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1333">	.<span class="pl-smi">name</span>		= <span class="pl-s"><span class="pl-pds">&quot;</span>i2c-gpio<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1334">1334</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1334">	.<span class="pl-smi">id</span>		= <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1335">1335</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1335">	.<span class="pl-smi">dev</span>		= {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1336">1336</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1336">		.<span class="pl-smi">platform_data</span>	= &amp;da850_gpio_i2c_pdata,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1337">1337</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1337">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1338">1338</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1338">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1339">1339</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1339"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1340">1340</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1340"><span class="pl-k">static</span> <span class="pl-k">int</span> __init <span class="pl-en">da850_evm_config_pru_can</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1341">1341</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1341">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1342">1342</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1342">    <span class="pl-k">int</span> ret;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1343">1343</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1343"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1344">1344</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1344">    <span class="pl-k">if</span> (!<span class="pl-c1">machine_is_davinci_da850_evm</span>())</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1345">1345</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1345">        <span class="pl-k">return</span> <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1346">1346</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1346"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1347">1347</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1347"><span class="pl-c">//	ret = da8xx_pinmux_setup(da850_pru_can_pins);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1348">1348</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1348"><span class="pl-c">//	if (ret)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1349">1349</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1349"><span class="pl-c">//        pr_warning(&quot;da850_evm_init: da850_pru_can_pins mux setup failed: %d\n&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1350">1350</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1350"><span class="pl-c">//                ret);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1351">1351</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1351"><span class="pl-c">//</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1352">1352</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1352"><span class="pl-c">//	ret = gpio_request(DA850_PRU_CAN_TRX_PIN, &quot;pru_can_en&quot;);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1353">1353</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1353"><span class="pl-c">//   if (ret) </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1354">1354</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1354"><span class="pl-c">//         pr_warning(&quot;Cannot open GPIO %d\n&quot;, DA850_PRU_CAN_TRX_PIN);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1355">1355</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1355"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1356">1356</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1356">	<span class="pl-c">/* value = 0 to enable the can transceiver */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1357">1357</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1357"><span class="pl-c">//    gpio_direction_output(DA850_PRU_CAN_TRX_PIN, 0);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1358">1358</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1358"><span class="pl-c">//    ret = da8xx_register_pru_can();</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1359">1359</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1359"><span class="pl-c">//    if (ret)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1360">1360</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1360"><span class="pl-c">//        pr_warning(&quot;da850_evm_init: pru can registration failed: %d\n&quot;, ret);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1361">1361</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1361"><span class="pl-c">//    return ret;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1362">1362</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1362">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1363">1363</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1363"><span class="pl-en">device_initcall</span>(da850_evm_config_pru_can);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1364">1364</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1364"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1365">1365</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1365"><span class="pl-k">static</span> <span class="pl-k">int</span> __init <span class="pl-en">da850_evm_config_pru_suart</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1366">1366</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1366">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1367">1367</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1367">    <span class="pl-k">int</span> ret;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1368">1368</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1368"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1369">1369</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1369">     <span class="pl-c1">pr_info</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_config_pru_suart configuration<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1370">1370</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1370">    <span class="pl-k">if</span> (!<span class="pl-c1">machine_is_davinci_da850_evm</span>())</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1371">1371</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1371">        <span class="pl-k">return</span> <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1372">1372</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1372"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1373">1373</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1373">    ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_pru_suart_pins);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1374">1374</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1374">    <span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1375">1375</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1375">        <span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: da850_pru_suart_pins mux setup failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1376">1376</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1376">                ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1377">1377</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1377"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1378">1378</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1378">    ret = <span class="pl-c1">da8xx_register_pru_suart</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1379">1379</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1379">    <span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1380">1380</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1380">        <span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: pru suart registration failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1381">1381</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1381">    <span class="pl-k">return</span> ret;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1382">1382</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1382">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1383">1383</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1383"><span class="pl-en">device_initcall</span>(da850_evm_config_pru_suart);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1384">1384</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1384"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1385">1385</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1385"><span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1386">1386</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1386"><span class="pl-c"> * The following EDMA channels/slots are not being used by drivers (for</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1387">1387</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1387"><span class="pl-c"> * example: Timer, GPIO, UART events etc) on da850/omap-l138 EVM, hence</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1388">1388</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1388"><span class="pl-c"> * they are being reserved for codecs on the DSP side.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1389">1389</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1389"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1390">1390</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1390"><span class="pl-k">static</span> <span class="pl-k">const</span> s16 da850_dma0_rsv_chans[][<span class="pl-c1">2</span>] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1391">1391</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1391">        <span class="pl-c">/* (offset, number) */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1392">1392</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1392">        { <span class="pl-c1">8</span>,  <span class="pl-c1">6</span>},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1393">1393</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1393">        {<span class="pl-c1">24</span>,  <span class="pl-c1">4</span>},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1394">1394</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1394">        {<span class="pl-c1">30</span>,  <span class="pl-c1">2</span>},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1395">1395</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1395">        {-<span class="pl-c1">1</span>, -<span class="pl-c1">1</span>}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1396">1396</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1396">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1397">1397</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1397"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1398">1398</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1398"><span class="pl-k">static</span> <span class="pl-k">const</span> s16 da850_dma0_rsv_slots[][<span class="pl-c1">2</span>] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1399">1399</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1399">        <span class="pl-c">/* (offset, number) */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1400">1400</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1400">        { <span class="pl-c1">8</span>,  <span class="pl-c1">6</span>},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1401">1401</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1401">        {<span class="pl-c1">24</span>,  <span class="pl-c1">4</span>},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1402">1402</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1402">        {<span class="pl-c1">30</span>, <span class="pl-c1">50</span>},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1403">1403</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1403">        {-<span class="pl-c1">1</span>, -<span class="pl-c1">1</span>}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1404">1404</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1404">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1405">1405</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1405"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1406">1406</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1406"><span class="pl-k">static</span> <span class="pl-k">const</span> s16 da850_dma1_rsv_chans[][<span class="pl-c1">2</span>] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1407">1407</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1407">        <span class="pl-c">/* (offset, number) */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1408">1408</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1408">        { <span class="pl-c1">0</span>, <span class="pl-c1">28</span>},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1409">1409</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1409">        {<span class="pl-c1">30</span>,  <span class="pl-c1">2</span>},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1410">1410</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1410">        {-<span class="pl-c1">1</span>, -<span class="pl-c1">1</span>}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1411">1411</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1411">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1412">1412</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1412"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1413">1413</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1413"><span class="pl-k">static</span> <span class="pl-k">const</span> s16 da850_dma1_rsv_slots[][<span class="pl-c1">2</span>] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1414">1414</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1414">        <span class="pl-c">/* (offset, number) */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1415">1415</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1415">        { <span class="pl-c1">0</span>, <span class="pl-c1">28</span>},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1416">1416</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1416">        {<span class="pl-c1">30</span>, <span class="pl-c1">90</span>},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1417">1417</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1417">        {-<span class="pl-c1">1</span>, -<span class="pl-c1">1</span>}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1418">1418</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1418">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1419">1419</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1419"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1420">1420</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1420"><span class="pl-k">static</span> <span class="pl-k">struct</span> edma_rsv_info da850_edma_cc0_rsv = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1421">1421</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1421">        .<span class="pl-smi">rsv_chans</span>      = da850_dma0_rsv_chans,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1422">1422</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1422">        .<span class="pl-smi">rsv_slots</span>      = da850_dma0_rsv_slots,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1423">1423</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1423">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1424">1424</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1424"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1425">1425</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1425"><span class="pl-k">static</span> <span class="pl-k">struct</span> edma_rsv_info da850_edma_cc1_rsv = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1426">1426</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1426">        .<span class="pl-smi">rsv_chans</span>      = da850_dma1_rsv_chans,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1427">1427</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1427">        .<span class="pl-smi">rsv_slots</span>      = da850_dma1_rsv_slots,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1428">1428</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1428">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1429">1429</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1429"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1430">1430</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1430"><span class="pl-k">static</span> <span class="pl-k">struct</span> edma_rsv_info *da850_edma_rsv[<span class="pl-c1">2</span>] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1431">1431</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1431">        &amp;da850_edma_cc0_rsv,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1432">1432</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1432">        &amp;da850_edma_cc1_rsv,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1433">1433</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1433">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1434">1434</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1434"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1435">1435</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1435"><span class="pl-k">static</span> <span class="pl-k">const</span> <span class="pl-k">short</span> da850_lms2012_lcd_pins[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1436">1436</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1436">	DA850_GPIO2_11, DA850_GPIO2_12, DA850_GPIO5_0,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1437">1437</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1437">	-<span class="pl-c1">1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1438">1438</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1438">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1439">1439</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1439"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1440">1440</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1440"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1441">1441</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1441"><span class="pl-k">static</span> __init <span class="pl-k">void</span> <span class="pl-en">da850_evm_init</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1442">1442</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1442">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1443">1443</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1443">	<span class="pl-k">int</span> ret;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1444">1444</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1444"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1445">1445</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1445">	<span class="pl-c">//ret = da8xx_register_edma();</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1446">1446</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1446">	ret = <span class="pl-c1">da850_register_edma</span>(da850_edma_rsv);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1447">1447</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1447">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1448">1448</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1448">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: edma registration failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1449">1449</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1449">				ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1450">1450</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1450"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1451">1451</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1451">	ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_spi0_pins);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1452">1452</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1452">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1453">1453</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1453">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: spi0 mux setup failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1454">1454</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1454">				ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1455">1455</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1455"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1456">1456</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1456">	ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_spi1_pins);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1457">1457</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1457">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1458">1458</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1458">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: spi0 mux setup failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1459">1459</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1459">				ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1460">1460</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1460"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1461">1461</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1461">	ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_lms2012_lcd_pins);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1462">1462</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1462">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1463">1463</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1463">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: lms2012 lcd mux setup failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1464">1464</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1464">				ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1465">1465</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1465"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1466">1466</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1466"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1467">1467</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1467"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1468">1468</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1468">	<span class="pl-c">//da850_init_spi0(BIT(0), da850_spi0_board_info,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1469">1469</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1469">	<span class="pl-c1">da850_init_spi</span>(da850_spi_board_info,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1470">1470</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1470">			<span class="pl-c1">ARRAY_SIZE</span>(da850_spi_board_info));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1471">1471</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1471"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1472">1472</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1472">	ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_i2c0_pins);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1473">1473</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1473">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1474">1474</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1474">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: i2c0 mux setup failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1475">1475</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1475">				ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1476">1476</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1476">        </td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1477">1477</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1477">  <span class="pl-c1">i2c_register_board_info</span>(<span class="pl-c1">1</span>, da850_evm_i2c_devices,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1478">1478</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1478">			<span class="pl-c1">ARRAY_SIZE</span>(da850_evm_i2c_devices));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1479">1479</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1479">	<span class="pl-c1">da8xx_register_i2c</span>(<span class="pl-c1">0</span>,&amp;lego_i2c_0_pdata);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1480">1480</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1480"><span class="pl-c">//	platform_device_register(&amp;da850_gpio_i2c);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1481">1481</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1481">	</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1482">1482</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1482">	ret = <span class="pl-c1">da8xx_register_watchdog</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1483">1483</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1483">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1484">1484</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1484">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da830_evm_init: watchdog registration failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1485">1485</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1485">				ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1486">1486</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1486"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1487">1487</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1487">	<span class="pl-k">if</span> (HAS_MMC) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1488">1488</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1488">		ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_mmcsd0_pins);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1489">1489</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1489">		<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1490">1490</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1490">			<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: mmcsd0 mux setup failed:<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1491">1491</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1491">					<span class="pl-s"><span class="pl-pds">&quot;</span> <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1492">1492</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1492"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1493">1493</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1493">		ret = <span class="pl-c1">gpio_request</span>(DA850_MMCSD_CD_PIN, <span class="pl-s"><span class="pl-pds">&quot;</span>MMC CD<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1494">1494</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1494">		<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1495">1495</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1495">			<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: can not open GPIO <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1496">1496</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1496">					DA850_MMCSD_CD_PIN);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1497">1497</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1497">		<span class="pl-c1">gpio_direction_input</span>(DA850_MMCSD_CD_PIN);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1498">1498</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1498"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1499">1499</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1499"><span class="pl-c">//		ret = gpio_request(DA850_MMCSD_WP_PIN, &quot;MMC WP\n&quot;);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1500">1500</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1500"><span class="pl-c">//		if (ret)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1501">1501</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1501"><span class="pl-c">//			pr_warning(&quot;da850_evm_init: can not open GPIO %d\n&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1502">1502</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1502"><span class="pl-c">//					DA850_MMCSD_WP_PIN);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1503">1503</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1503"><span class="pl-c">//		gpio_direction_input(DA850_MMCSD_WP_PIN);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1504">1504</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1504"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1505">1505</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1505">		ret = <span class="pl-c1">da8xx_register_mmcsd0</span>(&amp;da850_mmc_config);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1506">1506</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1506">		<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1507">1507</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1507">			<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: mmcsd0 registration failed:<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1508">1508</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1508">					<span class="pl-s"><span class="pl-pds">&quot;</span> <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1509">1509</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1509">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1510">1510</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1510"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1511">1511</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1511"><span class="pl-c">//ret = da8xx_pinmux_setup(da850_uart0_pins);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1512">1512</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1512"><span class="pl-c">//      if (ret)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1513">1513</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1513"><span class="pl-c">//            pr_warning(&quot;da850_evm_init: uart0 mux setup failed: %d\n&quot;, ret);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1514">1514</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1514"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1515">1515</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1515"><span class="pl-c">//      ret = da8xx_pinmux_setup(da850_uart1_pins);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1516">1516</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1516"><span class="pl-c">//      if (ret)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1517">1517</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1517"><span class="pl-c">//            pr_warning(&quot;da850_evm_init: uart1 mux setup failed: %d\n&quot;, ret);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1518">1518</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1518"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1519">1519</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1519">	<span class="pl-c">/* Support for UART 1 */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1520">1520</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1520">	ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_uart1_pins);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1521">1521</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1521">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1522">1522</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1522">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: UART 1 mux setup failed:<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1523">1523</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1523">						<span class="pl-s"><span class="pl-pds">&quot;</span> <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1524">1524</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1524"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1525">1525</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1525">	<span class="pl-c">/* Support for UART 2 */</span>						<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1526">1526</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1526">	ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_uart2_pins);				<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1527">1527</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1527">	<span class="pl-k">if</span> (ret)								<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1528">1528</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1528">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: UART 2 mux setup failed:<span class="pl-pds">&quot;</span></span>		<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1529">1529</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1529">						<span class="pl-s"><span class="pl-pds">&quot;</span> <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, ret);			<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1530">1530</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1530"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1531">1531</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1531"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1532">1532</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1532">	<span class="pl-c1">pr_info</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_gpio_req_BT_EN<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);	</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1533">1533</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1533">	</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1534">1534</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1534">	ret = <span class="pl-c1">gpio_request</span>(DA850_BT_EN, <span class="pl-s"><span class="pl-pds">&quot;</span>WL1271_BT_EN<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1535">1535</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1535">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1536">1536</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1536">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: can not open BT GPIO <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1537">1537</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1537">					DA850_BT_EN);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1538">1538</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1538">	<span class="pl-c1">gpio_direction_output</span>(DA850_BT_EN, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1539">1539</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1539">	<span class="pl-c1">udelay</span>(<span class="pl-c1">1000</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1540">1540</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1540">	<span class="pl-c1">gpio_direction_output</span>(DA850_BT_EN, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1541">1541</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1541"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1542">1542</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1542"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1543">1543</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1543">	<span class="pl-c1">davinci_serial_init</span>(&amp;da850_evm_uart_config);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1544">1544</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1544"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1545">1545</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1545">	<span class="pl-c">//i2c_register_board_info(1, da850_evm_i2c_devices,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1546">1546</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1546">	<span class="pl-c">//		ARRAY_SIZE(da850_evm_i2c_devices));</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1547">1547</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1547"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1548">1548</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1548">	<span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1549">1549</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1549"><span class="pl-c">	 * shut down uart 0 and 1; they are not used on the board and</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1550">1550</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1550"><span class="pl-c">	 * accessing them causes endless &quot;too much work in irq53&quot; messages</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1551">1551</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1551"><span class="pl-c">	 * with arago fs</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1552">1552</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1552"><span class="pl-c">	 */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1553">1553</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1553">	<span class="pl-c">//__raw_writel(0, IO_ADDRESS(DA8XX_UART1_BASE) + 0x30);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1554">1554</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1554">	<span class="pl-c">//__raw_writel(0, IO_ADDRESS(DA8XX_UART0_BASE) + 0x30);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1555">1555</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1555"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1556">1556</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1556"><span class="pl-c">/*	if (HAS_MCBSP0) {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1557">1557</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1557"><span class="pl-c">		if (HAS_EMAC)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1558">1558</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1558"><span class="pl-c">			pr_warning(&quot;WARNING: both MCBSP0 and EMAC are &quot;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1559">1559</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1559"><span class="pl-c">				&quot;enabled, but they share pins.\n&quot;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1560">1560</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1560"><span class="pl-c">				&quot;\tDisable one of them.\n&quot;);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1561">1561</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1561"><span class="pl-c"></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1562">1562</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1562"><span class="pl-c">		ret = da8xx_pinmux_setup(da850_mcbsp0_pins);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1563">1563</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1563"><span class="pl-c">		if (ret)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1564">1564</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1564"><span class="pl-c">			pr_warning(&quot;da850_evm_init: mcbsp0 mux setup failed:&quot;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1565">1565</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1565"><span class="pl-c">					&quot; %d\n&quot;, ret);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1566">1566</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1566"><span class="pl-c"></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1567">1567</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1567"><span class="pl-c">		ret = da850_init_mcbsp(&amp;da850_mcbsp0_config);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1568">1568</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1568"><span class="pl-c">		if (ret)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1569">1569</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1569"><span class="pl-c">			pr_warning(&quot;da850_evm_init: mcbsp0 registration&quot;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1570">1570</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1570"><span class="pl-c">					&quot;failed: %d\n&quot;,	ret);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1571">1571</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1571"><span class="pl-c">	}</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1572">1572</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1572"><span class="pl-c"></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1573">1573</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1573"><span class="pl-c">	if (HAS_MCBSP1) {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1574">1574</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1574"><span class="pl-c">		ret = da8xx_pinmux_setup(da850_mcbsp1_pins);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1575">1575</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1575"><span class="pl-c">		if (ret)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1576">1576</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1576"><span class="pl-c">			pr_warning(&quot;da850_evm_init: mcbsp1 mux setup failed:&quot;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1577">1577</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1577"><span class="pl-c">					&quot; %d\n&quot;, ret);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1578">1578</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1578"><span class="pl-c"></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1579">1579</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1579"><span class="pl-c">		ret = da850_init_mcbsp(&amp;da850_mcbsp1_config);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1580">1580</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1580"><span class="pl-c">		if (ret)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1581">1581</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1581"><span class="pl-c">			pr_warning(&quot;da850_evm_init: mcbsp1 registration&quot;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1582">1582</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1582"><span class="pl-c">					&quot; failed: %d\n&quot;, ret);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1583">1583</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1583"><span class="pl-c">	}</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1584">1584</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1584"><span class="pl-c"></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1585">1585</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1585"><span class="pl-c">	if (HAS_MCASP) {</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1586">1586</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1586"><span class="pl-c">		if ((HAS_MCBSP0 || HAS_MCBSP1))</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1587">1587</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1587"><span class="pl-c">			pr_warning(&quot;WARNING: both McASP and McBSP are enabled, &quot;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1588">1588</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1588"><span class="pl-c">					&quot;but they share pins.\n&quot;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1589">1589</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1589"><span class="pl-c">					&quot;\tDisable one of them.\n&quot;);*/</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1590">1590</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1590"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1591">1591</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1591"><span class="pl-c">//		ret = da8xx_pinmux_setup(da850_mcasp_pins);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1592">1592</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1592"><span class="pl-c">//		if (ret)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1593">1593</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1593"><span class="pl-c">//			pr_warning(&quot;da850_evm_init: mcasp mux setup failed:&quot;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1594">1594</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1594"><span class="pl-c">//					&quot;%d\n&quot;, ret);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1595">1595</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1595"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1596">1596</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1596"><span class="pl-c">//		da8xx_register_mcasp(0, &amp;da850_evm_snd_data);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1597">1597</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1597">	<span class="pl-c">//}</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1598">1598</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1598"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1599">1599</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1599">	ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_lcdcntl_pins);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1600">1600</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1600">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1601">1601</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1601">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: lcdcntl mux setup failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1602">1602</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1602">				ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1603">1603</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1603"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1604">1604</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1604">	<span class="pl-c">/* Handle board specific muxing for LCD here */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1605">1605</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1605">	ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_evm_lcdc_pins);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1606">1606</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1606">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1607">1607</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1607">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: evm specific lcd mux setup <span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1608">1608</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1608">				<span class="pl-s"><span class="pl-pds">&quot;</span>failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,	ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1609">1609</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1609"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1610">1610</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1610">	ret = <span class="pl-c1">da850_lcd_hw_init</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1611">1611</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1611">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1612">1612</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1612">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: lcd initialization failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1613">1613</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1613">				ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1614">1614</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1614"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1615">1615</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1615">	sharp_lk043t1dg01_pdata.<span class="pl-smi">panel_power_ctrl</span> = da850_panel_power_ctrl,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1616">1616</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1616">	ret = <span class="pl-c1">da8xx_register_lcdc</span>(&amp;sharp_lk043t1dg01_pdata);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1617">1617</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1617">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1618">1618</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1618">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: lcdc registration failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1619">1619</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1619">				ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1620">1620</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1620"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1621">1621</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1621">	ret = <span class="pl-c1">da8xx_register_rtc</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1622">1622</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1622">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1623">1623</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1623">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: rtc setup failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1624">1624</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1624"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1625">1625</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1625">	ret = <span class="pl-c1">da850_register_cpufreq</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1626">1626</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1626">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1627">1627</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1627">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: cpufreq registration failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1628">1628</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1628">				ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1629">1629</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1629"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1630">1630</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1630">	ret = <span class="pl-c1">da8xx_register_cpuidle</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1631">1631</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1631">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1632">1632</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1632">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: cpuidle registration failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1633">1633</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1633">				ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1634">1634</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1634"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1635">1635</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1635">	ret = <span class="pl-c1">da850_register_pm</span>(&amp;da850_pm_device);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1636">1636</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1636">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1637">1637</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1637">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: suspend registration failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1638">1638</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1638">				ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1639">1639</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1639"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1640">1640</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1640"><span class="pl-c">//	ret = da8xx_pinmux_setup(da850_spi1_pins);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1641">1641</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1641"><span class="pl-c">//	if (ret)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1642">1642</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1642"><span class="pl-c">//		pr_warning(&quot;da850_evm_init: spi1 mux setup failed: %d\n&quot;,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1643">1643</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1643"><span class="pl-c">//				ret);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1644">1644</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1644"><span class="pl-c">//</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1645">1645</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1645"><span class="pl-c">//	da850_init_spi1(BIT(0), da850_spi_board_info,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1646">1646</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1646"><span class="pl-c">//			ARRAY_SIZE(da850_spi_board_info));</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1647">1647</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1647"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1648">1648</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1648">	<span class="pl-c1">da850_evm_usb_init</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1649">1649</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1649"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1650">1650</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1650">	ret = <span class="pl-c1">da8xx_register_sata</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1651">1651</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1651">	<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1652">1652</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1652">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: SATA registration failed: <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1653">1653</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1653">						ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1654">1654</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1654"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1655">1655</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1655">	<span class="pl-k">if</span> (HAS_VPIF_DISPLAY || HAS_VPIF_CAPTURE) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1656">1656</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1656">		ret = <span class="pl-c1">da850_register_vpif</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1657">1657</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1657">		<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1658">1658</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1658">			<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: VPIF registration failed: <span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1659">1659</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1659">					<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,	ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1660">1660</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1660">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1661">1661</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1661"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1662">1662</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1662">	<span class="pl-k">if</span> (!HAS_RMII &amp;&amp; HAS_VPIF_CAPTURE) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1663">1663</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1663">		ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_vpif_capture_pins);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1664">1664</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1664">		<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1665">1665</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1665">			<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: vpif capture mux failed: <span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1666">1666</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1666">					<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,	ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1667">1667</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1667"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1668">1668</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1668">		ret = <span class="pl-c1">da850_register_vpif_capture</span>(&amp;da850_vpif_capture_config);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1669">1669</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1669">		<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1670">1670</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1670">			<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: VPIF registration failed: <span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1671">1671</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1671">					<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,	ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1672">1672</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1672"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1673">1673</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1673">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1674">1674</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1674"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1675">1675</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1675">	<span class="pl-k">if</span> (!HAS_GLCD &amp;&amp; HAS_VPIF_DISPLAY) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1676">1676</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1676">		ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_vpif_display_pins);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1677">1677</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1677">		<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1678">1678</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1678">			<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: vpif capture mux failed: <span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1679">1679</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1679">					<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,	ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1680">1680</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1680"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1681">1681</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1681">		ret = <span class="pl-c1">da850_register_vpif_display</span>(&amp;da850_vpif_display_config);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1682">1682</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1682">		<span class="pl-k">if</span> (ret)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1683">1683</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1683">			<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: VPIF registration failed: <span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1684">1684</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1684">					<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,	ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1685">1685</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1685"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1686">1686</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1686">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1687">1687</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1687"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1688">1688</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1688"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1689">1689</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1689">	<span class="pl-k">if</span> (<span class="pl-c1">gpio_request</span>(DA850_BT_SHUT_DOWN, <span class="pl-s"><span class="pl-pds">&quot;</span>bt_en<span class="pl-pds">&quot;</span></span>)) {			<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1690">1690</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1690">		<span class="pl-c1">printk</span>(KERN_ERR <span class="pl-s"><span class="pl-pds">&quot;</span>Failed to request gpio DA850_BT_SHUT_DOWN<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);	<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1691">1691</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1691">		<span class="pl-k">return</span>;								<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1692">1692</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1692">	}									<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1693">1693</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1693"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1694">1694</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1694">	<span class="pl-k">if</span> (<span class="pl-c1">gpio_request</span>(DA850_BT_SHUT_DOWN_EP2, <span class="pl-s"><span class="pl-pds">&quot;</span>bt_en_EP2<span class="pl-pds">&quot;</span></span>)) {		<span class="pl-c">// LEGO BT - EP2</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1695">1695</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1695">		<span class="pl-c1">printk</span>(KERN_ERR <span class="pl-s"><span class="pl-pds">&quot;</span>Failed to request gpio DA850_BT_SHUT_DOWN<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);	<span class="pl-c">// LEGO BT - EP2</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1696">1696</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1696">		<span class="pl-k">return</span>;								<span class="pl-c">// LEGO BT - EP2</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1697">1697</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1697">	}									<span class="pl-c">// LEGO BT - EP2</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1698">1698</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1698"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1699">1699</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1699">	<span class="pl-c1">gpio_set_value</span>(DA850_BT_SHUT_DOWN_EP2, <span class="pl-c1">0</span>);				<span class="pl-c">// LEGO BT - EP2</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1700">1700</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1700">	<span class="pl-c1">gpio_direction_output</span>(DA850_BT_SHUT_DOWN_EP2, <span class="pl-c1">0</span>);			<span class="pl-c">// LEGO BT - EP2</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1701">1701</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1701"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1702">1702</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1702">	<span class="pl-c1">gpio_set_value</span>(DA850_BT_SHUT_DOWN, <span class="pl-c1">0</span>);					<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1703">1703</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1703">	<span class="pl-c1">gpio_direction_output</span>(DA850_BT_SHUT_DOWN, <span class="pl-c1">0</span>);				<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1704">1704</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1704"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1705">1705</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1705">	<span class="pl-c">/* Support for Bluetooth shut dw pin */</span>					<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1706">1706</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1706">	<span class="pl-c1">pr_info</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>Support for Bluetooth shut dw pin<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);	</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1707">1707</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1707">	ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_bt_shut_down_pin);			<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1708">1708</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1708">	<span class="pl-k">if</span> (ret)								<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1709">1709</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1709">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: BT shut down mux setup failed:<span class="pl-pds">&quot;</span></span>	<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1710">1710</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1710">						<span class="pl-s"><span class="pl-pds">&quot;</span> <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, ret);			<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1711">1711</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1711"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1712">1712</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1712"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1713">1713</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1713">	<span class="pl-c1">gpio_set_value</span>(DA850_BT_SHUT_DOWN, <span class="pl-c1">0</span>);					<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1714">1714</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1714">	<span class="pl-c1">gpio_set_value</span>(DA850_BT_SHUT_DOWN_EP2, <span class="pl-c1">0</span>);				<span class="pl-c">// LEGO BT - EP2</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1715">1715</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1715"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1716">1716</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1716">        <span class="pl-c">/* Support for Bluetooth slow clock */</span>					<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1717">1717</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1717">	ret = <span class="pl-c1">da8xx_pinmux_setup</span>(da850_bt_slow_clock_pin);			<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1718">1718</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1718">	<span class="pl-k">if</span> (ret)								<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1719">1719</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1719">		<span class="pl-c1">pr_warning</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>da850_evm_init: BT slow clock mux setup failed:<span class="pl-pds">&quot;</span></span>	<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1720">1720</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1720">						<span class="pl-s"><span class="pl-pds">&quot;</span> <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, ret);			<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1721">1721</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1721"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1722">1722</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1722">        <span class="pl-c1">da850_evm_bt_slow_clock_init</span>();						<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1723">1723</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1723">        <span class="pl-c1">gpio_direction_input</span>(DA850_ECAP2_OUT_ENABLE);				<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1724">1724</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1724"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1725">1725</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1725">	<span class="pl-c1">gpio_set_value</span>(DA850_BT_SHUT_DOWN, <span class="pl-c1">1</span>);					<span class="pl-c">// LEGO BT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1726">1726</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1726">	<span class="pl-c1">gpio_set_value</span>(DA850_BT_SHUT_DOWN_EP2, <span class="pl-c1">1</span>);				<span class="pl-c">// LEGO BT - EP2</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1727">1727</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1727"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1728">1728</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1728"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1729">1729</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1729">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1730">1730</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1730"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1731">1731</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1731">#<span class="pl-k">ifdef</span> CONFIG_SERIAL_8250_CONSOLE</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1732">1732</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1732"><span class="pl-k">static</span> <span class="pl-k">int</span> __init <span class="pl-en">da850_evm_console_init</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1733">1733</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1733">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1734">1734</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1734">	<span class="pl-k">return</span> <span class="pl-c1">add_preferred_console</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>ttyS<span class="pl-pds">&quot;</span></span>, <span class="pl-c1">1</span>, <span class="pl-s"><span class="pl-pds">&quot;</span>115200<span class="pl-pds">&quot;</span></span>); <span class="pl-c">//Nico</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1735">1735</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1735">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1736">1736</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1736"><span class="pl-en">console_initcall</span>(da850_evm_console_init);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1737">1737</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1737">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1738">1738</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1738"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1739">1739</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1739"><span class="pl-k">static</span> __init <span class="pl-k">void</span> <span class="pl-en">da850_evm_irq_init</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1740">1740</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1740">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1741">1741</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1741">	<span class="pl-k">struct</span> davinci_soc_info *soc_info = &amp;davinci_soc_info;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1742">1742</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1742"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1743">1743</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1743">	<span class="pl-c1">cp_intc_init</span>((<span class="pl-k">void</span> __iomem *)DA8XX_CP_INTC_VIRT, DA850_N_CP_INTC_IRQ,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1744">1744</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1744">			soc_info-&gt;intc_irq_prios);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1745">1745</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1745">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1746">1746</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1746"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1747">1747</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1747"><span class="pl-k">static</span> <span class="pl-k">void</span> __init <span class="pl-en">da850_evm_map_io</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1748">1748</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1748">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1749">1749</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1749">	<span class="pl-c1">da850_init</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1750">1750</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1750">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1751">1751</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1751"><span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1752">1752</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1752"><span class="pl-c">MACHINE_START(DAVINCI_DA850_EVM, &quot;DaVinci DA850/OMAP-L138/AM18xx EVM&quot;)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1753">1753</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1753"><span class="pl-c">	.phys_io	= IO_PHYS,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1754">1754</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1754"><span class="pl-c">	.io_pg_offst	= (__IO_ADDRESS(IO_PHYS) &gt;&gt; 18) &amp; 0xfffc,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1755">1755</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1755"><span class="pl-c">	.boot_params	= (DA8XX_DDR_BASE + 0x100),</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1756">1756</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1756"><span class="pl-c">	.map_io		= da850_evm_map_io,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1757">1757</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1757"><span class="pl-c">	.init_irq	= da850_evm_irq_init,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1758">1758</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1758"><span class="pl-c">	.timer		= &amp;davinci_timer,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1759">1759</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1759"><span class="pl-c">	.init_machine	= da850_evm_init,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1760">1760</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1760"><span class="pl-c">MACHINE_END</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1761">1761</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1761"><span class="pl-c">*/</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1762">1762</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1762"><span class="pl-c">// LEGO CHANGED - 20120501</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1763">1763</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1763"><span class="pl-en">MACHINE_START</span>(DAVINCI_DA850_EVM, <span class="pl-s"><span class="pl-pds">&quot;</span>MindStorms EV3<span class="pl-pds">&quot;</span></span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1764">1764</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1764">        .phys_io        = IO_PHYS,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1765">1765</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1765">        .io_pg_offst    = (__IO_ADDRESS(IO_PHYS) &gt;&gt; 18) &amp; 0xfffc,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1766">1766</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1766">        .boot_params    = (DA8XX_DDR_BASE + 0x100),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1767">1767</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1767">        .map_io         = da850_evm_map_io,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1768">1768</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1768">        .init_irq       = da850_evm_irq_init,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1769">1769</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1769">        .timer          = &amp;davinci_timer,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1770">1770</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1770">        .init_machine   = da850_evm_init,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1771">1771</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1771">MACHINE_END</td>
          </tr>
    </table>
  </div>
</div>


        </div>

      </div><!-- /.repo-container -->
      <div class="modal-backdrop"></div>
    </div><!-- /.container -->
  </div><!-- /.site -->


    </div><!-- /.wrapper -->

      <div class="container">
  <div class="site-footer" role="contentinfo">
    <ul class="site-footer-links right">
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage">
      <span class="mega-octicon octicon-mark-github" title="GitHub"></span>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2015 <span title="0.82407s from github-fe138-cp1-prd.iad.github.net">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact</a></li>
    </ul>
  </div>
</div>


    <div class="fullscreen-overlay js-fullscreen-overlay" id="fullscreen_overlay">
  <div class="fullscreen-container js-suggester-container">
    <div class="textarea-wrap">
      <textarea name="fullscreen-contents" id="fullscreen-contents" class="fullscreen-contents js-fullscreen-contents" placeholder=""></textarea>
      <div class="suggester-container">
        <div class="suggester fullscreen-suggester js-suggester js-navigation-container"></div>
      </div>
    </div>
  </div>
  <div class="fullscreen-sidebar">
    <a href="#" class="exit-fullscreen js-exit-fullscreen tooltipped tooltipped-w" aria-label="Exit Zen Mode">
      <span class="mega-octicon octicon-screen-normal"></span>
    </a>
    <a href="#" class="theme-switcher js-theme-switcher tooltipped tooltipped-w"
      aria-label="Switch themes">
      <span class="octicon octicon-color-mode"></span>
    </a>
  </div>
</div>



    

    <div id="ajax-error-message" class="flash flash-error">
      <span class="octicon octicon-alert"></span>
      <a href="#" class="octicon octicon-x flash-close js-ajax-error-dismiss" aria-label="Dismiss error"></a>
      Something went wrong with that request. Please try again.
    </div>


      <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-447ce66a36506ebddc8e84b4e32a77f6062f3d3482e77dd21a77a01f0643ad98.js"></script>
      <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github/index-83be60956d0d00076a726f0864b49916aae8e7bc6ee140798791be0b6644d661.js"></script>
      
      
  </body>
</html>

