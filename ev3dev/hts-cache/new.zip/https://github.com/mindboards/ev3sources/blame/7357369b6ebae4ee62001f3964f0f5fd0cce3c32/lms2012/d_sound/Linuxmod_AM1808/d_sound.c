


<!DOCTYPE html>
<html lang="en" class="">
  <head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# object: http://ogp.me/ns/object# article: http://ogp.me/ns/article# profile: http://ogp.me/ns/profile#">
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    
    
    <title>ev3sources/lms2012/d_sound/Linuxmod_AM1808/d_sound.c at 7357369b6ebae4ee62001f3964f0f5fd0cce3c32 · mindboards/ev3sources · GitHub</title>
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-144.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144.png">
    <meta property="fb:app_id" content="1401488693436528">

      <meta content="@github" name="twitter:site" /><meta content="summary" name="twitter:card" /><meta content="mindboards/ev3sources" name="twitter:title" /><meta content="LEGO MINDSTORMS EV3 source code. Contribute to ev3sources development by creating an account on GitHub." name="twitter:description" /><meta content="https://avatars3.githubusercontent.com/u/2578456?v=3&amp;s=400" name="twitter:image:src" />
      <meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="https://avatars3.githubusercontent.com/u/2578456?v=3&amp;s=400" property="og:image" /><meta content="mindboards/ev3sources" property="og:title" /><meta content="https://github.com/mindboards/ev3sources" property="og:url" /><meta content="LEGO MINDSTORMS EV3 source code. Contribute to ev3sources development by creating an account on GitHub." property="og:description" />
      <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">
    <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">
    <link rel="assets" href="https://assets-cdn.github.com/">
    
    <meta name="pjax-timeout" content="1000">
    

    <meta name="msapplication-TileImage" content="/windows-tile.png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="selected-link" value="repo_source" data-pjax-transient>
      <meta name="google-analytics" content="UA-3769691-2">

    <meta content="collector.githubapp.com" name="octolytics-host" /><meta content="collector-cdn.github.com" name="octolytics-script-host" /><meta content="github" name="octolytics-app-id" /><meta content="70C64D49:7BA6:74FF36A:556C26F4" name="octolytics-dimension-request_id" />
    
    <meta content="Rails, view, blob#blame" name="analytics-event" />
    <meta class="js-ga-set" name="dimension1" content="Logged Out">
    <meta class="js-ga-set" name="dimension2" content="Header v3">
    <meta name="is-dotcom" content="true">
      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

    
    <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">


    <meta content="authenticity_token" name="csrf-param" />
<meta content="tTnJdPNn7bwcaIxKELOKhF9zYgUQ4mWsUyN1CAC+R8elWtHHnwTrPGn/qbImONcNE1p4tutHS3vn4VjTzRlcjQ==" name="csrf-token" />

    <link href="https://assets-cdn.github.com/assets/github/index-7e77e66f8436e66d6a9791d7a09cec15828e9e04a0ad97cf73e83223f8b9cb3a.css" media="all" rel="stylesheet" />
    <link href="https://assets-cdn.github.com/assets/github2/index-5df271cf586eee5e48a88e30cdb6b5c32413ce1d7337835a905fc8c16294237e.css" media="all" rel="stylesheet" />
    
    


    <meta http-equiv="x-pjax-version" content="840467a6cd0c672c678f4fd42f529999">

            <meta content="noindex, nofollow" name="robots" />

  <meta name="description" content="LEGO MINDSTORMS EV3 source code. Contribute to ev3sources development by creating an account on GitHub.">
  <meta name="go-import" content="github.com/mindboards/ev3sources git https://github.com/mindboards/ev3sources.git">

  <meta content="2578456" name="octolytics-dimension-user_id" /><meta content="mindboards" name="octolytics-dimension-user_login" /><meta content="11771262" name="octolytics-dimension-repository_id" /><meta content="mindboards/ev3sources" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="11771262" name="octolytics-dimension-repository_network_root_id" /><meta content="mindboards/ev3sources" name="octolytics-dimension-repository_network_root_nwo" />
  <link href="https://github.com/mindboards/ev3sources/commits/7357369b6ebae4ee62001f3964f0f5fd0cce3c32.atom" rel="alternate" title="Recent Commits to ev3sources:7357369b6ebae4ee62001f3964f0f5fd0cce3c32" type="application/atom+xml">

  </head>


  <body class="logged_out  env-production  vis-public">
    <a href="#start-of-content" tabindex="1" class="accessibility-aid js-skip-to-content">Skip to content</a>
    <div class="wrapper">
      
      
      


        
        <div class="header header-logged-out" role="banner">
  <div class="container clearfix">

    <a class="header-logo-wordmark" href="https://github.com/" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
      <span class="mega-octicon octicon-logo-github"></span>
    </a>

    <div class="header-actions" role="navigation">
        <a class="btn btn-primary" href="/join" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
      <a class="btn" href="/login?return_to=%2Fmindboards%2Fev3sources%2Fblame%2F7357369b6ebae4ee62001f3964f0f5fd0cce3c32%2Flms2012%2Fd_sound%2FLinuxmod_AM1808%2Fd_sound.c" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
    </div>

    <div class="site-search repo-scope js-site-search" role="search">
      <form accept-charset="UTF-8" action="/mindboards/ev3sources/search" class="js-site-search-form" data-global-search-url="/search" data-repo-search-url="/mindboards/ev3sources/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
  <label class="js-chromeless-input-container form-control">
    <div class="scope-badge">This repository</div>
    <input type="text"
      class="js-site-search-focus js-site-search-field is-clearable chromeless-input"
      data-hotkey="s"
      name="q"
      placeholder="Search"
      data-global-scope-placeholder="Search GitHub"
      data-repo-scope-placeholder="Search"
      tabindex="1"
      autocapitalize="off">
  </label>
</form>
    </div>

      <ul class="header-nav left" role="navigation">
          <li class="header-nav-item">
            <a class="header-nav-link" href="/explore" data-ga-click="(Logged out) Header, go to explore, text:explore">Explore</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/features" data-ga-click="(Logged out) Header, go to features, text:features">Features</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="https://enterprise.github.com/" data-ga-click="(Logged out) Header, go to enterprise, text:enterprise">Enterprise</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/blog" data-ga-click="(Logged out) Header, go to blog, text:blog">Blog</a>
          </li>
      </ul>

  </div>
</div>



      <div id="start-of-content" class="accessibility-aid"></div>
          <div class="site" itemscope itemtype="http://schema.org/WebPage">
    <div id="js-flash-container">
      
    </div>
    <div class="pagehead repohead instapaper_ignore readability-menu">
      <div class="container">
        
<ul class="pagehead-actions">

  <li>
      <a href="/login?return_to=%2Fmindboards%2Fev3sources"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <span class="octicon octicon-eye"></span>
    Watch
  </a>
  <a class="social-count" href="/mindboards/ev3sources/watchers">
    82
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fmindboards%2Fev3sources"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <span class="octicon octicon-star"></span>
    Star
  </a>

    <a class="social-count js-social-count" href="/mindboards/ev3sources/stargazers">
      241
    </a>

  </li>

    <li>
      <a href="/login?return_to=%2Fmindboards%2Fev3sources"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <span class="octicon octicon-repo-forked"></span>
        Fork
      </a>
      <a href="/mindboards/ev3sources/network" class="social-count">
        123
      </a>
    </li>
</ul>

        <h1 itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="entry-title public">
          <span class="mega-octicon octicon-repo"></span>
          <span class="author"><a href="/mindboards" class="url fn" itemprop="url" rel="author"><span itemprop="title">mindboards</span></a></span><!--
       --><span class="path-divider">/</span><!--
       --><strong><a href="/mindboards/ev3sources" data-pjax="#js-repo-pjax-container">ev3sources</a></strong>

          <span class="page-context-loader">
            <img alt="" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </span>

        </h1>
      </div><!-- /.container -->
    </div><!-- /.repohead -->

    <div class="container">
      <div class="repository-with-sidebar repo-container new-discussion-timeline  ">
        <div class="repository-sidebar clearfix">
            
<nav class="sunken-menu repo-nav js-repo-nav js-sidenav-container-pjax js-octicon-loaders"
     role="navigation"
     data-pjax="#js-repo-pjax-container"
     data-issue-count-url="/mindboards/ev3sources/issues/counts">
  <ul class="sunken-menu-group">
    <li class="tooltipped tooltipped-w" aria-label="Code">
      <a href="/mindboards/ev3sources" aria-label="Code" class="selected js-selected-navigation-item sunken-menu-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /mindboards/ev3sources">
        <span class="octicon octicon-code"></span> <span class="full-word">Code</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Issues">
        <a href="/mindboards/ev3sources/issues" aria-label="Issues" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /mindboards/ev3sources/issues">
          <span class="octicon octicon-issue-opened"></span> <span class="full-word">Issues</span>
          <span class="js-issue-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>

    <li class="tooltipped tooltipped-w" aria-label="Pull requests">
      <a href="/mindboards/ev3sources/pulls" aria-label="Pull requests" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g p" data-selected-links="repo_pulls /mindboards/ev3sources/pulls">
          <span class="octicon octicon-git-pull-request"></span> <span class="full-word">Pull requests</span>
          <span class="js-pull-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Wiki">
        <a href="/mindboards/ev3sources/wiki" aria-label="Wiki" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g w" data-selected-links="repo_wiki /mindboards/ev3sources/wiki">
          <span class="octicon octicon-book"></span> <span class="full-word">Wiki</span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>
  </ul>
  <div class="sunken-menu-separator"></div>
  <ul class="sunken-menu-group">

    <li class="tooltipped tooltipped-w" aria-label="Pulse">
      <a href="/mindboards/ev3sources/pulse" aria-label="Pulse" class="js-selected-navigation-item sunken-menu-item" data-selected-links="pulse /mindboards/ev3sources/pulse">
        <span class="octicon octicon-pulse"></span> <span class="full-word">Pulse</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

    <li class="tooltipped tooltipped-w" aria-label="Graphs">
      <a href="/mindboards/ev3sources/graphs" aria-label="Graphs" class="js-selected-navigation-item sunken-menu-item" data-selected-links="repo_graphs repo_contributors /mindboards/ev3sources/graphs">
        <span class="octicon octicon-graph"></span> <span class="full-word">Graphs</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>
  </ul>


</nav>

              <div class="only-with-full-nav">
                  
<div class="js-clone-url clone-url open"
  data-protocol-type="http">
  <h3><span class="text-emphasized">HTTPS</span> clone URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/mindboards/ev3sources.git" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>

  
<div class="js-clone-url clone-url "
  data-protocol-type="subversion">
  <h3><span class="text-emphasized">Subversion</span> checkout URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/mindboards/ev3sources" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>



<div class="clone-options">You can clone with
  <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=http&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="noETEKA+wUAjwe1Aq6NyDBnS28gC/NWeNOYXFLcyJwsGX9x/sfENZIItoN7goSM5Kd9uP+rmISbVeTpO8EJSCw==" /></div><button class="btn-link js-clone-selector" data-protocol="http" type="submit">HTTPS</button></form> or <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=subversion&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="u3mxtUn1x8ZW5PBQbo9W2F8OYU5qdkYvP7p8yaC4sOvGyCHOgaf3ZNf4H0Pnf036ODi3MSr4Xz23SUA+wf4uMA==" /></div><button class="btn-link js-clone-selector" data-protocol="subversion" type="submit">Subversion</button></form>.
  <a href="https://help.github.com/articles/which-remote-url-should-i-use" class="help tooltipped tooltipped-n" aria-label="Get help on which URL is right for you.">
    <span class="octicon octicon-question"></span>
  </a>
</div>




                <a href="/mindboards/ev3sources/archive/7357369b6ebae4ee62001f3964f0f5fd0cce3c32.zip"
                   class="btn btn-sm sidebar-button"
                   aria-label="Download the contents of mindboards/ev3sources as a zip file"
                   title="Download the contents of mindboards/ev3sources as a zip file"
                   rel="nofollow">
                  <span class="octicon octicon-cloud-download"></span>
                  Download ZIP
                </a>
              </div>
        </div><!-- /.repository-sidebar -->

        <div id="js-repo-pjax-container" class="repository-content context-loader-container" data-pjax-container>

          
<a href="/mindboards/ev3sources/blame/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_sound/Linuxmod_AM1808/d_sound.c" class="hidden js-permalink-shortcut" data-hotkey="y">Permalink</a>

<div class="breadcrumb css-truncate blame-breadcrumb js-zeroclipboard-container">
  <span class="css-truncate-target js-zeroclipboard-target"><span class='repo-root js-repo-root'><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">ev3sources</span></a></span></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">lms2012</span></a></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_sound" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">d_sound</span></a></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_sound/Linuxmod_AM1808" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">Linuxmod_AM1808</span></a></span><span class="separator">/</span><strong class="final-path">d_sound.c</strong></span>
  <button aria-label="Copy file path to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
</div>

<div class="line-age-legend">
  <span>Newer</span>
  <ol>
      <li class="heat1"></li>
      <li class="heat2"></li>
      <li class="heat3"></li>
      <li class="heat4"></li>
      <li class="heat5"></li>
      <li class="heat6"></li>
      <li class="heat7"></li>
      <li class="heat8"></li>
      <li class="heat9"></li>
      <li class="heat10"></li>
  </ol>
  <span>Older</span>
</div>

<div class="file">
  <div class="file-header">
    <div class="file-actions">
      <div class="btn-group">
        <a href="/mindboards/ev3sources/raw/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_sound/Linuxmod_AM1808/d_sound.c" class="btn btn-sm" id="raw-url">Raw</a>
        <a href="/mindboards/ev3sources/blob/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_sound/Linuxmod_AM1808/d_sound.c" class="btn btn-sm js-update-url-with-hash">Normal view</a>
        <a href="/mindboards/ev3sources/commits/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_sound/Linuxmod_AM1808/d_sound.c" class="btn btn-sm" rel="nofollow">History</a>
      </div>
    </div>



    <div class="file-info">
      <span class="octicon octicon-file-text"></span>
      <span class="file-mode" title="File Mode">100644</span>
      <span class="file-info-divider"></span>
        910 lines (727 sloc)
        <span class="file-info-divider"></span>
      27.295 kb
    </div>
  </div>

  <div class="blob-wrapper">
    <table class="blame-container highlight data js-file-line-container">
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="910">
            <a href="/mindboards/ev3sources/commit/e5be3a6d591c60b26a3fb853989a9c86f5a7cc56" class="blame-sha">e5be3a6</a>
            <img alt="" class="avatar blame-commit-avatar" height="32" src="https://1.gravatar.com/avatar/a3114595e89094e76e43ffc615e7655f?d=https%3A%2F%2Fassets-cdn.github.com%2Fimages%2Fgravatars%2Fgravatar-user-420.png&amp;r=x&amp;s=140" width="32" />
            <a href="/mindboards/ev3sources/commit/e5be3a6d591c60b26a3fb853989a9c86f5a7cc56" class="blame-commit-title" title="Initial commit!  (so exciting!)">Initial commit!  (so exciting!)</a>
            <div class="blame-commit-meta">
              <span class="muted-link">Xander Soldaat</span> authored
              <time datetime="2013-07-30T17:57:56Z" is="relative-time">Jul 30, 2013</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1">1</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1"><span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L2">2</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC2"><span class="pl-c"> * LEGO® MINDSTORMS EV3</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L3">3</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC3"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L4">4</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC4"><span class="pl-c"> * Copyright (C) 2010-2013 The LEGO Group</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L5">5</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC5"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L6">6</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC6"><span class="pl-c"> * This program is free software; you can redistribute it and/or modify</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L7">7</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC7"><span class="pl-c"> * it under the terms of the GNU General Public License as published by</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L8">8</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC8"><span class="pl-c"> * the Free Software Foundation; either version 2 of the License, or</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L9">9</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC9"><span class="pl-c"> * (at your option) any later version.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L10">10</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC10"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L11">11</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC11"><span class="pl-c"> * This program is distributed in the hope that it will be useful,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L12">12</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC12"><span class="pl-c"> * but WITHOUT ANY WARRANTY; without even the implied warranty of</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L13">13</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC13"><span class="pl-c"> * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L14">14</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC14"><span class="pl-c"> * GNU General Public License for more details.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L15">15</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC15"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L16">16</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC16"><span class="pl-c"> * You should have received a copy of the GNU General Public License</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L17">17</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC17"><span class="pl-c"> * along with this program; if not, write to the Free Software</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L18">18</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC18"><span class="pl-c"> * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L19">19</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC19"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L20">20</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC20"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L21">21</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC21"><span class="pl-c">/*! \page Sound Driver Module</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L22">22</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC22"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L23">23</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC23"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L24">24</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC24"><span class="pl-c"> *-  \subpage SoundDriverModuleResources</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L25">25</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC25"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L26">26</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC26"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L27">27</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC27"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L28">28</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC28">#<span class="pl-k">define</span>   <span class="pl-en">HW_ID_SUPPORT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L29">29</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC29"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L30">30</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC30">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&quot;</span>../../lms2012/source/lms2012.h<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L31">31</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC31">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&quot;</span>../../lms2012/source/am1808.h<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L32">32</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC32"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L33">33</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC33">#<span class="pl-k">ifdef</span>    DEBUG_D_SOUND</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L34">34</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC34">#<span class="pl-k">define</span>   <span class="pl-en">DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L35">35</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC35">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L36">36</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC36"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L37">37</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC37">#<span class="pl-k">define</span>   <span class="pl-en">MODULE_NAME</span>                   <span class="pl-s"><span class="pl-pds">&quot;</span>sound_module<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L38">38</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC38">#<span class="pl-k">define</span>   <span class="pl-en">DEVICE1_NAME</span>                  SOUND_DEVICE</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L39">39</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC39"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L40">40</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC40"><span class="pl-k">static</span>    <span class="pl-k">int</span>  <span class="pl-en">ModuleInit</span>(<span class="pl-k">void</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L41">41</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC41"><span class="pl-k">static</span>    <span class="pl-k">void</span> <span class="pl-en">ModuleExit</span>(<span class="pl-k">void</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L42">42</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC42"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L43">43</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC43">#<span class="pl-k">define</span>   <span class="pl-en">__USE_POSIX</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L44">44</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC44"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L45">45</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC45">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/kernel.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L46">46</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC46">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/fs.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L47">47</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC47"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L48">48</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC48">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/sched.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L49">49</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC49"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L50">50</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC50"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L51">51</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC51">#<span class="pl-k">ifndef</span>   PCASM</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L52">52</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC52">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/hrtimer.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L53">53</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC53"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L54">54</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC54">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/mm.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L55">55</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC55">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/hrtimer.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L56">56</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC56"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L57">57</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC57">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/init.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L58">58</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC58">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/uaccess.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L59">59</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC59">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/debugfs.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L60">60</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC60"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L61">61</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC61">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/ioport.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L62">62</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC62">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>asm/gpio.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L63">63</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC63">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>asm/io.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L64">64</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC64">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/module.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L65">65</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC65">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/miscdevice.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L66">66</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC66">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>asm/uaccess.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L67">67</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC67"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L68">68</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC68"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L69">69</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC69"><span class="pl-en">MODULE_LICENSE</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>GPL<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L70">70</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC70"><span class="pl-en">MODULE_AUTHOR</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>The LEGO Group<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L71">71</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC71"><span class="pl-en">MODULE_DESCRIPTION</span>(MODULE_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L72">72</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC72"><span class="pl-en">MODULE_SUPPORTED_DEVICE</span>(DEVICE1_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L73">73</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC73"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L74">74</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC74"><span class="pl-en">module_init</span>(ModuleInit);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L75">75</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC75"><span class="pl-en">module_exit</span>(ModuleExit);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L76">76</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC76"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L77">77</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC77">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L78">78</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC78"><span class="pl-c">// Keep Eclipse happy</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L79">79</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC79">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L80">80</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC80"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L81">81</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC81"><span class="pl-k">enum</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L82">82</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC82">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L83">83</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC83">  TIMING_SAMPLES,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L84">84</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC84">  ONE_SHOT,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L85">85</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC85">  MANUAL,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L86">86</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC86">  READY_FOR_SAMPLES,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L87">87</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC87">  IDLE</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L88">88</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC88">} TIMER_MODES;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L89">89</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC89"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L90">90</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC90"><span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L91">91</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC91"><span class="pl-c"> * Variables</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L92">92</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC92"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L93">93</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC93"><span class="pl-k">static</span>    ULONG   *SYSCFG0;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L94">94</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC94"><span class="pl-k">static</span>    ULONG   *PSC1;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L95">95</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC95"><span class="pl-k">static</span>    UWORD   *eHRPWM0;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L96">96</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC96"><span class="pl-k">static</span>    <span class="pl-k">void</span>    __iomem *GpioBase;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L97">97</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC97"><span class="pl-k">static</span>    UWORD   <span class="pl-c1">Duration</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L98">98</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC98"><span class="pl-k">static</span>    UWORD   Period;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L99">99</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC99"><span class="pl-k">static</span>    UBYTE   Level;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L100">100</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC100"><span class="pl-k">static</span> 	  UBYTE	  TimerMode = READY_FOR_SAMPLES;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L101">101</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC101"><span class="pl-k">static</span>	  SOUND		SoundDefault;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L102">102</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC102"><span class="pl-k">static</span>	  SOUND   *pSound = &amp;SoundDefault;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L103">103</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC103"><span class="pl-k">static</span>    <span class="pl-k">struct</span> hrtimer  Device1Timer;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L104">104</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC104"><span class="pl-k">static</span>    <span class="pl-c1">ktime_t</span>         Device1Time;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L105">105</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC105"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L106">106</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC106"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L107">107</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC107"><span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L108">108</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC108"><span class="pl-c"> * Defines related to hardware PWM output</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L109">109</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC109"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L110">110</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC110"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L111">111</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC111">#<span class="pl-k">define</span> <span class="pl-en">CFGCHIP0</span>          0x60            <span class="pl-c">// 32 bit wide index into SYSCFG0</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L112">112</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC112">#<span class="pl-k">define</span> <span class="pl-en">PLL_MASTER_LOCK</span>   0x00001000</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L113">113</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC113">#<span class="pl-k">define</span> <span class="pl-en">DEFAULT_FREQUENCY</span> <span class="pl-c1">16499</span>           <span class="pl-c">// 16499 should give 8 KHz</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L114">114</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC114">#<span class="pl-k">define</span> <span class="pl-en">DEFAULT_LEVEL</span>     <span class="pl-c1">1000</span>            <span class="pl-c">// 25% D.C.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L115">115</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC115"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L116">116</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC116"><span class="pl-k">static</span> UWORD	SoundBuffers[SOUND_BUFFER_COUNT][SOUND_FILE_BUFFER_SIZE];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L117">117</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC117"><span class="pl-k">static</span> UBYTE  SoundChunkSize[SOUND_BUFFER_COUNT];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L118">118</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC118"><span class="pl-k">static</span> UWORD  BufferReadPointer;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L119">119</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC119"><span class="pl-k">static</span> UBYTE	BufferReadIndex;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L120">120</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC120"><span class="pl-k">static</span> UBYTE	BufferWriteIndex;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L121">121</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC121"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L122">122</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC122"><span class="pl-c">// TBCTL (Time-Base Control)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L123">123</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC123"><span class="pl-c">// = = = = = = = = = = = = = = = = = = = = = = = = = =</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L124">124</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC124">#<span class="pl-k">define</span>   <span class="pl-en">TB_COUNT_UP</span>                   0x0     <span class="pl-c">// TBCNT MODE bits</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L125">125</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC125">#<span class="pl-k">define</span>   <span class="pl-en">TB_DISABLE</span>                    0x0     <span class="pl-c">// PHSEN bit</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L126">126</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC126">#<span class="pl-k">define</span>   <span class="pl-en">TB_ENABLE</span>                     0x4</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L127">127</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC127">#<span class="pl-k">define</span>   <span class="pl-en">TB_SHADOW</span>                     0x0     <span class="pl-c">// PRDLD bit</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L128">128</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC128">#<span class="pl-k">define</span>   <span class="pl-en">TB_IMMEDIATE</span>                  0x8</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L129">129</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC129">#<span class="pl-k">define</span>   <span class="pl-en">TB_SYNC_DISABLE</span>               0x30    <span class="pl-c">// SYNCOSEL bits</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L130">130</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC130">#<span class="pl-k">define</span>   <span class="pl-en">TB_HDIV1</span>                      0x0     <span class="pl-c">// HSPCLKDIV bits</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L131">131</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC131">#<span class="pl-k">define</span>   <span class="pl-en">TB_DIV1</span>                       0x0     <span class="pl-c">// CLKDIV bits</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L132">132</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC132">#<span class="pl-k">define</span>   <span class="pl-en">TB_UP</span>                         0x2000  <span class="pl-c">// PHSDIR bit</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L133">133</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC133"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L134">134</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC134"><span class="pl-c">// CMPCTL (Compare Control)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L135">135</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC135"><span class="pl-c">// = = = = = = = = = = = = = = = = = = = = = = = = = =</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L136">136</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC136">#<span class="pl-k">define</span>   <span class="pl-en">CC_CTR_A_ZERO</span>                 0x0     <span class="pl-c">// LOADAMODE bits</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L137">137</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC137">#<span class="pl-k">define</span>   <span class="pl-en">CC_CTR_B_ZERO</span>                 0x0</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L138">138</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC138">#<span class="pl-k">define</span>   <span class="pl-en">CC_A_SHADOW</span>                   0x00    <span class="pl-c">// SHDWAMODE and SHDWBMODE bits</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L139">139</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC139">#<span class="pl-k">define</span>   <span class="pl-en">CC_B_SHADOW</span>                   0x00</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L140">140</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC140">#<span class="pl-k">define</span>   <span class="pl-en">CC_B_NO_SHADOW</span>                0x40</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L141">141</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC141"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L142">142</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC142">#<span class="pl-k">define</span>   <span class="pl-en">TBCTL</span>                         0x0</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L143">143</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC143">#<span class="pl-k">define</span>   <span class="pl-en">TBPHS</span>                         0x3</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L144">144</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC144">#<span class="pl-k">define</span>   <span class="pl-en">TBCNT</span>                         0x4</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L145">145</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC145">#<span class="pl-k">define</span>   <span class="pl-en">TBPRD</span>                         0x5</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L146">146</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC146">#<span class="pl-k">define</span>   <span class="pl-en">CMPCTL</span>                        0x7</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L147">147</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC147">#<span class="pl-k">define</span>   <span class="pl-en">CMPA</span>                          0x9</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L148">148</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC148">#<span class="pl-k">define</span>   <span class="pl-en">CMPB</span>                          0xA</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L149">149</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC149">#<span class="pl-k">define</span>   <span class="pl-en">AQCTLA</span>                        0xB</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L150">150</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC150">#<span class="pl-k">define</span>   <span class="pl-en">AQCTLB</span>                        0xC</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L151">151</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC151"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L152">152</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC152"><span class="pl-c">// Action-Qualifier Output B Control Register AQCTLB:</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L153">153</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC153"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L154">154</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC154"><span class="pl-c">//                              1111 11</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L155">155</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC155"><span class="pl-c">//                        bit   5432 1098 7654 3210</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L156">156</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC156"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L157">157</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC157"><span class="pl-c">//      Bit 15 Reserved         R000 0000 0000 0000</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L158">158</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC158"><span class="pl-c">//      Bit 14 -                0R00 0000 0000 0000</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L159">159</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC159"><span class="pl-c">//      Bit 13 -                00R0 0000 0000 0000</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L160">160</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC160"><span class="pl-c">//      Bit 12 -                000R 0000 0000 0000</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L161">161</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC161">#<span class="pl-k">define</span> <span class="pl-en">SOUND_RESERVED</span>          0x0000</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L162">162</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC162"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L163">163</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC163"><span class="pl-c">//      Bit 11 CBD              0000 0000 0000 0000</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L164">164</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC164"><span class="pl-c">//      Bit 10 -                0000 0100 0000 0000 CLEAR Forces EPWM0B LOW</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L165">165</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC165">#<span class="pl-k">define</span> <span class="pl-en">SOUND_CBD</span>               0x0400</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L166">166</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC166"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L167">167</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC167"><span class="pl-c">//      Bit  9 CBU              0000 0000 0000 0000</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L168">168</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC168"><span class="pl-c">//      Bit  8 -                0000 0001 0000 0000 CLEAR Forces EPWM0B LOW</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L169">169</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC169">#<span class="pl-k">define</span> <span class="pl-en">SOUND_CBU</span>               0x0100</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L170">170</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC170"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L171">171</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC171"><span class="pl-c">//      Bit  7 CAD              0000 0000 N000 0000 DO NOTHING</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L172">172</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC172"><span class="pl-c">//      Bit  6 -                0000 0000 0N00 0000 -</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L173">173</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC173">#<span class="pl-k">define</span> <span class="pl-en">SOUND_CAD</span>               0x0000</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L174">174</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC174"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L175">175</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC175"><span class="pl-c">//      Bit  5 CAU              0000 0000 00N0 0000 DO NOTHING</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L176">176</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC176"><span class="pl-c">//      Bit  4 -                0000 0000 000N 0000 -</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L177">177</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC177">#<span class="pl-k">define</span> <span class="pl-en">SOUND_CAU</span>               0x0000</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L178">178</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC178"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L179">179</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC179"><span class="pl-c">//      Bit  3 PRD              0000 00N0 0000 1000 Forces EPWM0B HIGH</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L180">180</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC180"><span class="pl-c">//      Bit  2 -                0000 000N 0000 0000 -</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L181">181</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC181">#<span class="pl-k">define</span> <span class="pl-en">SOUND_PRD</span>               0x0008</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L182">182</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC182"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L183">183</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC183"><span class="pl-c">//      Bit  1 ZRO              0000 00N0 0000 0010 Forces EPWM0B HIGH</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L184">184</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC184"><span class="pl-c">//      Bit  0 -                0000 000N 0000 0000 -</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L185">185</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC185">#<span class="pl-k">define</span> <span class="pl-en">SOUND_ZRO</span>               0x0002</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L186">186</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC186"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L187">187</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC187"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L188">188</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC188"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L189">189</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC189"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L190">190</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC190">#<span class="pl-k">define</span> <span class="pl-en">SOUND_SYMM_TONE</span> (SOUND_RESERVED +\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L191">191</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC191">                         SOUND_CBD +\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L192">192</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC192">                         SOUND_CBU +\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L193">193</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC193">                         SOUND_CAD +\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L194">194</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC194">                         SOUND_CAU +\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L195">195</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC195">                         SOUND_PRD +\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L196">196</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC196">                         SOUND_ZRO)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L197">197</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC197"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L198">198</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC198"><span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L199">199</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC199"><span class="pl-c"> * Macro defines related to hardware PWM output</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L200">200</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC200"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L201">201</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC201"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L202">202</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC202"><span class="pl-c">// Put the &quot;Magic key&quot; into KICK0R and KICK1R to open for manipulation</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L203">203</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC203"><span class="pl-c">// Stop Time Base Clock (TBCLK) - clear bit TBCLKSYNC in CFGCHIP1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L204">204</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC204"><span class="pl-c">// Remove the &quot;Magic key&quot; from KICK0R and KICK1R to lock</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L205">205</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC205"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L206">206</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC206">#<span class="pl-k">define</span>   <span class="pl-en">EHRPWMClkDisable</span>              {\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L207">207</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC207">                                          eHRPWM0[TBCTL]  = 0xC033;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L208">208</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC208"><span class="pl-c">/*                                        REGUnlock;\</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L209">209</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC209"><span class="pl-c">                                          iowrite32((ioread32(&amp;SYSCFG0[CFGCHIP0]) &amp; ~PLL_MASTER_LOCK),&amp;SYSCFG0[0x60]);\</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L210">210</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC210"><span class="pl-c">                                          REGLock;*/</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L211">211</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC211">                                        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L212">212</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC212"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L213">213</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC213"><span class="pl-c">// Put the &quot;Magic key&quot; into KICK0R and KICK1R to open for manipulation</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L214">214</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC214"><span class="pl-c">// Start Time Base Clock (TBCLK) - set bit TBCLKSYNC in CFGCHIP1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L215">215</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC215"><span class="pl-c">// Remove the &quot;Magic key&quot; from KICK0R and KICK1R to lock</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L216">216</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC216"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L217">217</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC217">#<span class="pl-k">define</span>   <span class="pl-en">EHRPWMClkEnable</span>               {\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L218">218</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC218">                                          eHRPWM0[TBCTL]  = 0xC030; \</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L219">219</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC219">                                          REGUnlock;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L220">220</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC220">                                          <span class="pl-c1">iowrite32</span>((<span class="pl-c1">ioread32</span>(&amp;SYSCFG0[CFGCHIP0]) | PLL_MASTER_LOCK),&amp;SYSCFG0[0x60]);\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L221">221</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC221">                                          REGLock;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L222">222</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC222">                                        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L223">223</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC223"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L224">224</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC224">#<span class="pl-k">define</span>   <span class="pl-en">EHRPWMClkEnableTone</span>           {\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L225">225</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC225">                                          eHRPWM0[TBCTL]  = 0xDC30;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L226">226</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC226">                                          REGUnlock;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L227">227</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC227">                                          <span class="pl-c1">iowrite32</span>((<span class="pl-c1">ioread32</span>(&amp;SYSCFG0[CFGCHIP0]) | PLL_MASTER_LOCK),&amp;SYSCFG0[0x60]);\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L228">228</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC228">                                          REGLock;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L229">229</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC229">                                        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L230">230</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC230"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L231">231</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC231">#<span class="pl-k">define</span>   <span class="pl-en">SETPwmPeriod</span>(<span class="pl-v">Prd</span>)               {\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L232">232</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC232">                                          eHRPWM0[TBPRD] = Prd; <span class="pl-c">/* A factor of sample-rate  */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L233">233</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC233">                                                                <span class="pl-c">/* For lowering the quanti- */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L234">234</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC234">                                                                <span class="pl-c">/* zation noise (simpler    */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L235">235</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC235">                                                                <span class="pl-c">/* filtering)               */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L236">236</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC236">                                        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L237">237</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC237"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L238">238</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC238">#<span class="pl-k">define</span>   <span class="pl-en">SETSoundLevel</span>(<span class="pl-v">Level</span>)          {\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L239">239</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC239">                                          eHRPWM0[CMPB] = Level;  <span class="pl-c">/* The amplitude for this */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L240">240</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC240">                                                                  <span class="pl-c">/* very and/or following  */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L241">241</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC241">                                                                  <span class="pl-c">/* samples/periods        */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L242">242</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC242">                                        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L243">243</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC243"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L244">244</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC244">#<span class="pl-k">define</span>   <span class="pl-en">STOPPwm</span>                       {\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L245">245</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC245">                                          <span class="pl-c1">iowrite16</span>(0x00, &amp;eHRPWM0[TBCTL]);\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L246">246</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC246">                                          <span class="pl-c1">iowrite16</span>(0x00, &amp;eHRPWM0[CMPCTL]);\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L247">247</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC247">                                          EHRPWMClkDisable;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L248">248</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC248">                                        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L249">249</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC249"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L250">250</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC250">#<span class="pl-k">define</span>   <span class="pl-en">SOUNDPwmModuleSetupPcm</span>        { \</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L251">251</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC251">                                          \</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L252">252</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC252">                                          <span class="pl-c">/* eHRPWM Module */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L253">253</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC253">                                          <span class="pl-c">/*  In eHRPWM1[TBCTL] TB_DISABLE, TB_SHADOW, TB_HDIV1, TB_DIV1, TB_COUNT_UP all cleared */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L254">254</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC254">                                          EHRPWMClkDisable;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L255">255</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC255">                                          eHRPWM0[TBPHS]  = <span class="pl-c1">0</span>; <span class="pl-c">/* Phase register cleared */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L256">256</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC256">                                          eHRPWM0[TBCNT]  = <span class="pl-c1">0</span>; <span class="pl-c">/* Clear TB counter */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L257">257</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC257"><span class="pl-c">/*                                        eHRPWM0[TBCTL]  = 0xC030;*/</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L258">258</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC258">                                          eHRPWM0[CMPCTL] = (CC_B_SHADOW | CC_CTR_B_ZERO);\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L259">259</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC259">                                          eHRPWM0[AQCTLB] = 0x0102;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L260">260</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC260">                                          EHRPWMClkEnable;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L261">261</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC261">                                        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L262">262</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC262"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L263">263</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC263">#<span class="pl-k">define</span>   <span class="pl-en">SOUNDPwmModuleSetupTone</span>        { \</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L264">264</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC264">                                          \</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L265">265</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC265">                                          <span class="pl-c">/* eHRPWM Module */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L266">266</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC266">                                          <span class="pl-c">/*  In eHRPWM1[TBCTL] TB_DISABLE, TB_SHADOW, TB_HDIV1, TB_DIV1, TB_COUNT_UP all cleared */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L267">267</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC267">                                          EHRPWMClkDisable;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L268">268</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC268">                                          eHRPWM0[TBPHS]  = <span class="pl-c1">0</span>; <span class="pl-c">/* Phase register cleared */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L269">269</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC269">                                          eHRPWM0[TBCNT]  = <span class="pl-c1">0</span>; <span class="pl-c">/* Clear TB counter */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L270">270</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC270"><span class="pl-c">/*                                        eHRPWM0[TBCTL]  = 0xDC30;*/</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L271">271</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC271">                                          eHRPWM0[CMPCTL] = (CC_B_SHADOW | CC_CTR_B_ZERO);\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L272">272</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC272">                                          eHRPWM0[AQCTLB] = 0x0102;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L273">273</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC273"><span class="pl-c">/*                                        EHRPWMClkEnable;*/</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L274">274</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC274">                                          EHRPWMClkEnableTone;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L275">275</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC275">                                        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L276">276</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC276"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L277">277</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC277">#<span class="pl-k">define</span>   <span class="pl-en">SOUNDEnable</span>           {\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L278">278</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC278">                                  (*SoundPin[SOUNDEN].<span class="pl-smi">pGpio</span>).<span class="pl-smi">set_data</span>    =  SoundPin[SOUNDEN].<span class="pl-smi">Mask</span>;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L279">279</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC279">                                  (*SoundPin[SOUNDEN].<span class="pl-smi">pGpio</span>).<span class="pl-smi">dir</span>        &amp;= ~SoundPin[SOUNDEN].<span class="pl-smi">Mask</span>;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L280">280</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC280">                                }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L281">281</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC281"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L282">282</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC282">#<span class="pl-k">define</span>   <span class="pl-en">SOUNDDisable</span>          {\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L283">283</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC283">                                  (*SoundPin[SOUNDEN].<span class="pl-smi">pGpio</span>).<span class="pl-smi">clr_data</span>    =  SoundPin[SOUNDEN].<span class="pl-smi">Mask</span>;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L284">284</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC284">                                  (*SoundPin[SOUNDEN].<span class="pl-smi">pGpio</span>).<span class="pl-smi">dir</span>        &amp;= ~SoundPin[SOUNDEN].<span class="pl-smi">Mask</span>;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L285">285</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC285">                                }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L286">286</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC286"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L287">287</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC287">#<span class="pl-k">define</span>   <span class="pl-en">SOUNDPwmPoweron</span>       {\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L288">288</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC288">                                  <span class="pl-c1">iowrite32</span>(0x00000003, &amp;PSC1[0x291]); <span class="pl-c">/* Set ePWM module power on      */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L289">289</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC289">                                  <span class="pl-c1">iowrite32</span>(0x00000003, &amp;PSC1[0x48]);  <span class="pl-c">/* Evaluate all the NEXT fields  */</span>\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L290">290</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC290">                                }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L291">291</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC291"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L292">292</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC292"><span class="pl-k">enum</span>      SoundPins</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L293">293</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC293">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L294">294</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC294">  SOUNDEN,        <span class="pl-c">// Sound Enable to Amp</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L295">295</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC295">  SOUND_ARMA,     <span class="pl-c">// PWM audio signal from ARM</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L296">296</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC296">  SOUND_PINS</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L297">297</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC297">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L298">298</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC298"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L299">299</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC299"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L300">300</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC300"><span class="pl-c">//*****************************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L301">301</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC301">#<span class="pl-k">if</span>       (HARDWARE == FINAL)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L302">302</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC302"><span class="pl-c">//***************************************SETSoundLevel**************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L303">303</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC303"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L304">304</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC304"><span class="pl-c">/*! \page SoundModuleResources Gpios and Resources used for Module</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L305">305</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC305"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L306">306</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC306"><span class="pl-c"> *  Describes use of gpio and resources\n</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L307">307</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC307"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L308">308</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC308"><span class="pl-c"> *  \verbatim</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L309">309</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC309"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L310">310</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC310"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L311">311</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC311">INPIN     SoundPin[SOUND_PINS] =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L312">312</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC312">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L313">313</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC313">  { GP6_15 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// SOUNDEN</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L314">314</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC314">  { EPWM0B , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// SOUND_ARMA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L315">315</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC315">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L316">316</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC316"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L317">317</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC317"><span class="pl-c">/*  \endverbatim</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L318">318</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC318"><span class="pl-c"> *  \n</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L319">319</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC319"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L320">320</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC320"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L321">321</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC321">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L322">322</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC322"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L323">323</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC323"><span class="pl-c">//*****************************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L324">324</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC324">#<span class="pl-k">if</span>       (HARDWARE == ONE2ONE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L325">325</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC325"><span class="pl-c">//*****************************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L326">326</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC326"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L327">327</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC327"><span class="pl-c">/*! \page SoundModuleResources Gpios and Resources used for Module</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L328">328</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC328"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L329">329</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC329"><span class="pl-c"> *  Describes use of gpio and resources\n</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L330">330</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC330"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L331">331</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC331"><span class="pl-c"> *  \verbatim</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L332">332</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC332"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L333">333</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC333"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L334">334</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC334">INPIN     SoundPin[SOUND_PINS] =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L335">335</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC335">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L336">336</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC336">  { GP2_8  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// SOUNDEN</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L337">337</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC337">  { EPWM0B , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// SOUND_ARMA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L338">338</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC338">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L339">339</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC339"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L340">340</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC340"><span class="pl-c">/*  \endverbatim</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L341">341</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC341"><span class="pl-c"> *  \n</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L342">342</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC342"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L343">343</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC343"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L344">344</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC344">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L345">345</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC345"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L346">346</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC346"><span class="pl-c">//*****************************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L347">347</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC347">#<span class="pl-k">if</span>       (HARDWARE == A4)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L348">348</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC348"><span class="pl-c">//*****************************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L349">349</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC349"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L350">350</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC350">INPIN     SoundPin[SOUND_PINS] =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L351">351</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC351">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L352">352</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC352">  { GP5_6  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// SOUNDEN</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L353">353</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC353">  { EPWM0B , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// SOUND_ARMA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L354">354</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC354">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L355">355</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC355"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L356">356</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC356">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L357">357</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC357"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L358">358</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC358"><span class="pl-c">//*****************************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L359">359</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC359">#<span class="pl-k">if</span>       (HARDWARE == EVALBOARD)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L360">360</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC360"><span class="pl-c">//*****************************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L361">361</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC361"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L362">362</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC362">INPIN     SoundPin[SOUND_PINS] =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L363">363</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC363">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L364">364</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC364">  { GP7_4  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// SOUNDEN</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L365">365</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC365">  { EPWM0B , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// SOUND_ARMA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L366">366</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC366">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L367">367</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC367"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L368">368</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC368">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L369">369</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC369"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L370">370</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC370"><span class="pl-c">//*****************************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L371">371</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC371"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L372">372</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC372"><span class="pl-k">void</span>      <span class="pl-en">SetGpio</span>(<span class="pl-k">int</span> Pin)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L373">373</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC373">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L374">374</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC374">  <span class="pl-k">int</span>     Tmp = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L375">375</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC375">  <span class="pl-k">void</span>    __iomem *Reg;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L376">376</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC376"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L377">377</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC377">  <span class="pl-k">while</span> ((MuxRegMap[Tmp].<span class="pl-smi">Pin</span> != -<span class="pl-c1">1</span>) &amp;&amp; (MuxRegMap[Tmp].<span class="pl-smi">Pin</span> != Pin))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L378">378</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC378">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L379">379</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC379">    Tmp++;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L380">380</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC380">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L381">381</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC381">  <span class="pl-k">if</span> (MuxRegMap[Tmp].<span class="pl-smi">Pin</span> == Pin)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L382">382</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC382">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L383">383</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC383">    Reg   =  da8xx_syscfg0_base + 0x120 + (MuxRegMap[Tmp].<span class="pl-smi">MuxReg</span> &lt;&lt; <span class="pl-c1">2</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L384">384</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC384"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L385">385</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC385">    *(u32*)Reg &amp;=  MuxRegMap[Tmp].<span class="pl-smi">Mask</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L386">386</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC386">    *(u32*)Reg |=  MuxRegMap[Tmp].<span class="pl-smi">Mode</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L387">387</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC387"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L388">388</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC388">    <span class="pl-k">if</span> (Pin &lt; NO_OF_GPIOS)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L389">389</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC389">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L390">390</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC390">      <span class="pl-c">//#define DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L391">391</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC391">      #<span class="pl-k">undef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L392">392</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC392">      #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L393">393</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC393">        <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>    GP<span class="pl-c1">%d</span>_<span class="pl-c1">%-2d</span>   0x<span class="pl-c1">%08X</span> and 0x<span class="pl-c1">%08X</span> or 0x<span class="pl-c1">%08X</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,(Pin &gt;&gt; <span class="pl-c1">4</span>),(Pin &amp; 0x0F),(u32)Reg, MuxRegMap[Tmp].<span class="pl-smi">Mask</span>, MuxRegMap[Tmp].<span class="pl-smi">Mode</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L394">394</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC394">      #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L395">395</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC395">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L396">396</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC396">    <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L397">397</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC397">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L398">398</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC398">      <span class="pl-c">//#define DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L399">399</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC399">      #<span class="pl-k">undef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L400">400</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC400">      #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L401">401</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC401">        <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>    FUNCTION 0x<span class="pl-c1">%08X</span> and 0x<span class="pl-c1">%08X</span> or 0x<span class="pl-c1">%08X</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,(u32)Reg, MuxRegMap[Tmp].<span class="pl-smi">Mask</span>, MuxRegMap[Tmp].<span class="pl-smi">Mode</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L402">402</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC402">      #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L403">403</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC403">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L404">404</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC404">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L405">405</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC405">  <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L406">406</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC406">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L407">407</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC407">    <span class="pl-c">//#define DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L408">408</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC408">    #<span class="pl-k">undef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L409">409</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC409">    #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L410">410</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC410">      <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>*   GP<span class="pl-c1">%d</span>_<span class="pl-c1">%-2d</span>  ********* ERROR not found *********<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,(Pin &gt;&gt; <span class="pl-c1">4</span>),(Pin &amp; 0x0F));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L411">411</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC411">    #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L412">412</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC412">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L413">413</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC413"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L414">414</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC414">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L415">415</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC415"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L416">416</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC416"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L417">417</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC417"><span class="pl-k">void</span>      <span class="pl-en">InitGpio</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L418">418</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC418">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L419">419</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC419">  <span class="pl-k">int</span>     Pin;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L420">420</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC420"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L421">421</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC421">  <span class="pl-c">// unlock</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L422">422</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC422">  REGUnlock;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L423">423</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC423"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L424">424</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC424">  <span class="pl-c">//#define DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L425">425</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC425">  #<span class="pl-k">undef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L426">426</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC426">  #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L427">427</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC427">    <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  Sound<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L428">428</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC428">  #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L429">429</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC429"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L430">430</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC430">  <span class="pl-k">for</span> (Pin = <span class="pl-c1">0</span>;Pin &lt; SOUND_PINS;Pin++)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L431">431</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC431">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L432">432</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC432">    SoundPin[Pin].<span class="pl-smi">pGpio</span>  =  (<span class="pl-k">struct</span> gpio_controller *__iomem)(GpioBase + ((SoundPin[Pin].<span class="pl-smi">Pin</span> &gt;&gt; <span class="pl-c1">5</span>) * 0x28) + 0x10);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L433">433</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC433">    SoundPin[Pin].<span class="pl-smi">Mask</span>   =  (<span class="pl-c1">1</span> &lt;&lt; (SoundPin[Pin].<span class="pl-smi">Pin</span> &amp; 0x1F));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L434">434</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC434"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L435">435</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC435">    <span class="pl-c1">SetGpio</span>(SoundPin[Pin].<span class="pl-smi">Pin</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L436">436</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC436">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L437">437</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC437"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L438">438</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC438">  <span class="pl-c">// lock</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L439">439</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC439">  REGLock;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L440">440</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC440">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L441">441</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC441"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L442">442</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC442"><span class="pl-c">/*! \page PwmModule</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L443">443</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC443"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L444">444</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC444"><span class="pl-c"> *  &lt;hr size=&quot;1&quot;/&gt;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L445">445</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC445"><span class="pl-c"> *  &lt;b&gt;     write &lt;/b&gt;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L446">446</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC446"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L447">447</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC447"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L448">448</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC448"><span class="pl-c">/*! \brief    GetPeriphealBasePtr</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L449">449</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC449"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L450">450</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC450"><span class="pl-c"> *  Helper function for getting the peripheal HW base address</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L451">451</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC451"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L452">452</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC452"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L453">453</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC453"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L454">454</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC454"><span class="pl-k">void</span>    <span class="pl-en">GetPeriphealBasePtr</span>(ULONG Address, ULONG <span class="pl-c1">Size</span>, ULONG **<span class="pl-c1">Ptr</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L455">455</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC455">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L456">456</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC456">  <span class="pl-c">/* eCAP0 pointer */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L457">457</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC457">  <span class="pl-k">if</span> (<span class="pl-c1">request_mem_region</span>(Address,<span class="pl-c1">Size</span>,MODULE_NAME) &gt;= <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L458">458</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC458">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L459">459</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC459"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L460">460</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC460">    *<span class="pl-c1">Ptr</span>  =  (ULONG*)<span class="pl-c1">ioremap</span>(Address,<span class="pl-c1">Size</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L461">461</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC461"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L462">462</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC462">    <span class="pl-k">if</span> (*<span class="pl-c1">Ptr</span> != <span class="pl-c1">NULL</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L463">463</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC463">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L464">464</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC464">      <span class="pl-c">//#define DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L465">465</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC465">      #<span class="pl-k">undef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L466">466</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC466">      #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L467">467</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC467">        <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span> memory Remapped from 0x<span class="pl-c1">%08lX</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,DEVICE1_NAME,(<span class="pl-k">unsigned</span> <span class="pl-k">long</span>)*<span class="pl-c1">Ptr</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L468">468</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC468">      #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L469">469</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC469">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L470">470</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC470">    <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L471">471</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC471">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L472">472</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC472">      <span class="pl-c">//#define DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L473">473</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC473">      #<span class="pl-k">undef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L474">474</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC474">      #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L475">475</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC475">        <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>Memory remap ERROR<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L476">476</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC476">      #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L477">477</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC477">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L478">478</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC478">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L479">479</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC479">  <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L480">480</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC480">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L481">481</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC481">    <span class="pl-c">//#define DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L482">482</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC482">    #<span class="pl-k">undef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L483">483</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC483">    #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L484">484</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC484">      <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>Region request error<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L485">485</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC485">    #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L486">486</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC486">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L487">487</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC487">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L488">488</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC488"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L489">489</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC489"><span class="pl-c">// DEVICE1 ********************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L490">490</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC490"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L491">491</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC491"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">Device1TimerSetTiming</span>(ULONG Secs, ULONG NanoSecs )</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L492">492</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC492">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L493">493</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC493">  Device1Time  =  <span class="pl-c1">ktime_set</span>(Secs, NanoSecs);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L494">494</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC494">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L495">495</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC495"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L496">496</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC496"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">Device1TimerStart</span>(<span class="pl-k">void</span>)     <span class="pl-c">// (Re) start the high-resolution timer</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L497">497</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC497">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L498">498</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC498">  <span class="pl-c1">hrtimer_start</span>(&amp;Device1Timer,Device1Time,HRTIMER_MODE_REL);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L499">499</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC499">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L500">500</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC500"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L501">501</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC501"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">Device1TimerInitDuration</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L502">502</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC502">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L503">503</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC503">  UWORD Sec;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L504">504</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC504">  ULONG nSec;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L505">505</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC505"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L506">506</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC506">  Sec = (UWORD)(<span class="pl-c1">Duration</span> / <span class="pl-c1">1000</span>);                       <span class="pl-c">// Whole secs</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L507">507</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC507">  nSec = (ULONG)((<span class="pl-c1">Duration</span> - Sec * <span class="pl-c1">1000</span>) * <span class="pl-c1">1000000</span>);    <span class="pl-c">// Raised to mSec</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L508">508</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC508">  TimerMode = ONE_SHOT;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L509">509</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC509">  <span class="pl-c1">Device1TimerSetTiming</span>(Sec, nSec);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L510">510</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC510">  <span class="pl-c1">Device1TimerStart</span>();                                  <span class="pl-c">// Start / reStart</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L511">511</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC511">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L512">512</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC512"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L513">513</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC513"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">Device1TimerCancel</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L514">514</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC514">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L515">515</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC515">  TimerMode = IDLE;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L516">516</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC516">  <span class="pl-c1">hrtimer_cancel</span>(&amp;Device1Timer);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L517">517</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC517">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L518">518</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC518"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L519">519</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC519"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">Device1TimerExit</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L520">520</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC520">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L521">521</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC521">  <span class="pl-c1">Device1TimerCancel</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L522">522</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC522">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L523">523</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC523"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L524">524</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC524"><span class="pl-k">static</span> <span class="pl-k">enum</span> hrtimer_restart <span class="pl-en">Device1TimerInterrupt1</span>(<span class="pl-k">struct</span> hrtimer *pTimer)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L525">525</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC525">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L526">526</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC526">  UWORD TempLevel;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L527">527</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC527"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L528">528</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC528">  <span class="pl-k">enum</span> hrtimer_restart ret = HRTIMER_RESTART;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L529">529</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC529"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L530">530</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC530">  <span class="pl-k">if</span> (<span class="pl-c1">0</span> &lt; <span class="pl-c1">hrtimer_forward_now</span>(pTimer,Device1Time))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L531">531</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC531">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L532">532</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC532">    <span class="pl-c">// Take care sample missed!!!!!</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L533">533</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC533">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L534">534</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC534"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L535">535</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC535">  <span class="pl-k">switch</span>(TimerMode)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L536">536</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC536">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L537">537</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC537">    <span class="pl-k">case</span> READY_FOR_SAMPLES: <span class="pl-k">if</span>(SoundChunkSize[BufferReadIndex] &gt; <span class="pl-c1">0</span>) <span class="pl-c">// Any samples D/L yet?</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L538">538</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC538">                            {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L539">539</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC539"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L540">540</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC540">                              TimerMode = TIMING_SAMPLES;           <span class="pl-c">// We&#39;re ready, next interrupt will</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L541">541</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC541">                                                                    <span class="pl-c">// bring the sound alive</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L542">542</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC542">                            }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L543">543</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC543">                            <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L544">544</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC544"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L545">545</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC545">    <span class="pl-k">case</span> TIMING_SAMPLES:    <span class="pl-c">// Get new sample - if any</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L546">546</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC546"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L547">547</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC547">                            <span class="pl-k">if</span>(SoundChunkSize[BufferReadIndex] &gt; <span class="pl-c1">0</span>) <span class="pl-c">// Anything to use in Buffers?</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L548">548</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC548">                            {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L549">549</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC549">                              <span class="pl-c">// Get raw sample</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L550">550</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC550">                              TempLevel = SoundBuffers[BufferReadIndex][BufferReadPointer++];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L551">551</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC551">                              <span class="pl-k">if</span>(TempLevel == <span class="pl-c1">0</span>) TempLevel++;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L552">552</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC552">                              <span class="pl-c">// Add volume i.e. scale the PWM level</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L553">553</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC553"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L554">554</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC554">                              TempLevel = (UWORD)(Level * TempLevel);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L555">555</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC555">                              <span class="pl-c1">SETSoundLevel</span>(TempLevel);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L556">556</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC556"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L557">557</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC557">                              SoundChunkSize[BufferReadIndex]--;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L558">558</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC558"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L559">559</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC559">                              <span class="pl-k">if</span>(SoundChunkSize[BufferReadIndex] &lt; <span class="pl-c1">1</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L560">560</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC560">                              {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L561">561</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC561">                                BufferReadPointer = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L562">562</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC562">                                BufferReadIndex++;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L563">563</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC563">                                <span class="pl-k">if</span>(BufferReadIndex &gt;= SOUND_BUFFER_COUNT)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L564">564</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC564">                                  BufferReadIndex = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L565">565</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC565">                              }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L566">566</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC566">                            }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L567">567</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC567">                            <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L568">568</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC568">                            {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L569">569</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC569">                              ret = HRTIMER_NORESTART;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L570">570</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC570"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L571">571</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC571">                              SOUNDDisable;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L572">572</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC572">                              TimerMode = IDLE;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L573">573</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC573">                              (*pSound).<span class="pl-smi">Status</span>  =  OK;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L574">574</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC574">                              <span class="pl-c">// ret(urn value) already set</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L575">575</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC575">                            }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L576">576</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC576">                            <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L577">577</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC577"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L578">578</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC578">    <span class="pl-k">case</span> ONE_SHOT:          <span class="pl-c">// Stop tone - duration elapsed!</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L579">579</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC579">                            ret = HRTIMER_NORESTART;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L580">580</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC580">                            EHRPWMClkDisable;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L581">581</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC581">                            SOUNDDisable;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L582">582</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC582">                            TimerMode = IDLE;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L583">583</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC583">                            (*pSound).<span class="pl-smi">Status</span>  =  OK;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L584">584</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC584">                            <span class="pl-c">// ret(urn value) already set</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L585">585</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC585"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L586">586</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC586">    <span class="pl-k">case</span> IDLE:              <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L587">587</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC587">    <span class="pl-k">case</span> MANUAL:            <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L588">588</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC588">    <span class="pl-k">default</span>:                ret = HRTIMER_NORESTART;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L589">589</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC589">                            <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L590">590</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC590">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L591">591</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC591"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L592">592</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC592">    <span class="pl-k">return</span> (ret);   <span class="pl-c">// Keep on or stop doing the job</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L593">593</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC593">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L594">594</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC594"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L595">595</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC595"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">Device1TimerInit8KHz</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L596">596</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC596">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L597">597</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC597">  <span class="pl-c">/* Setup 125 uS timer interrupt*/</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L598">598</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC598"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L599">599</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC599">    TimerMode = READY_FOR_SAMPLES;    <span class="pl-c">// Allow for D/L to SoundBuffer(s)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L600">600</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC600">    <span class="pl-c1">Device1TimerSetTiming</span>(<span class="pl-c1">0</span>, <span class="pl-c1">125000</span>); <span class="pl-c">// 8 KHz. sample-rate</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L601">601</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC601">    <span class="pl-c1">Device1TimerStart</span>();              <span class="pl-c">// Start / reStart</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L602">602</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC602">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L603">603</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC603"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L604">604</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC604"><span class="pl-k">static</span> <span class="pl-c1">ssize_t</span> <span class="pl-en">Device1Write</span>(<span class="pl-k">struct</span> file *File, <span class="pl-k">const</span> <span class="pl-k">char</span> *Buffer, <span class="pl-c1">size_t</span> Count, <span class="pl-c1">loff_t</span> *Data)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L605">605</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC605">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L606">606</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC606"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L607">607</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC607">    <span class="pl-k">char</span>    CommandBuffer[SOUND_FILE_BUFFER_SIZE + <span class="pl-c1">1</span>];	<span class="pl-c">// Space for command @ byte 0</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L608">608</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC608">    UWORD   Frequency;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L609">609</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC609">    UWORD   PwmLevel;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L610">610</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC610">    <span class="pl-k">int</span>		BytesWritten = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L611">611</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC611">    <span class="pl-k">int</span> 	i = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L612">612</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC612"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L613">613</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC613">    <span class="pl-c1">copy_from_user</span>(CommandBuffer, Buffer, Count);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L614">614</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC614"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L615">615</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC615">    <span class="pl-k">switch</span>(CommandBuffer[<span class="pl-c1">0</span>])</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L616">616</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC616">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L617">617</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC617">      <span class="pl-k">case</span> SERVICE:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L618">618</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC618">                      <span class="pl-k">if</span>(Count &gt; <span class="pl-c1">1</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L619">619</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC619">      	  	  	  	  	{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L620">620</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC620">    	  	  	  	    	  <span class="pl-k">if</span>(SoundChunkSize[BufferWriteIndex] == <span class="pl-c1">0</span>) <span class="pl-c">// Is the requested RingBuffer[Index] ready for write?</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L621">621</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC621">    	  	  	  	    	  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L622">622</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC622">    	  	  	  	    	    <span class="pl-k">for</span>(i = <span class="pl-c1">1</span>; i &lt; Count; i++)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L623">623</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC623">    	  	  	  	    	      SoundBuffers[BufferWriteIndex][i-<span class="pl-c1">1</span>] = CommandBuffer[i];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L624">624</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC624">    	  	  	  	    	    SoundChunkSize[BufferWriteIndex] = Count - <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L625">625</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC625">    	  	  	  	    	    BufferWriteIndex++;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L626">626</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC626">    	  	  	  	    	    <span class="pl-k">if</span>(BufferWriteIndex &gt;= SOUND_BUFFER_COUNT)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L627">627</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC627">    	  	  	  	    	      BufferWriteIndex = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L628">628</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC628">    	  	  	  	    	    BytesWritten = Count - <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L629">629</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC629">    	  	  	  	    	  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L630">630</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC630">      	  	  	  	  	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L631">631</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC631">          	  	  	  	<span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L632">632</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC632"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L633">633</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC633">      <span class="pl-k">case</span> TONE:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L634">634</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC634">    	  	  	  	    SOUNDDisable;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L635">635</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC635">                        SOUNDPwmModuleSetupTone;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L636">636</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC636">                        Level = CommandBuffer[<span class="pl-c1">1</span>];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L637">637</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC637">                        Frequency = (UWORD)(CommandBuffer[<span class="pl-c1">2</span>] + (CommandBuffer[<span class="pl-c1">3</span>] &lt;&lt; <span class="pl-c1">8</span>));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L638">638</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC638">                        <span class="pl-c1">Duration</span> = (UWORD) (CommandBuffer[<span class="pl-c1">4</span>] + (CommandBuffer[<span class="pl-c1">5</span>] &lt;&lt; <span class="pl-c1">8</span>));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L639">639</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC639"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L640">640</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC640">                        <span class="pl-k">if</span> (Frequency &lt; SOUND_MIN_FRQ)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L641">641</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC641">                        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L642">642</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC642">                          Frequency = SOUND_MIN_FRQ;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L643">643</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC643">                        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L644">644</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC644">                        <span class="pl-k">else</span> <span class="pl-k">if</span> (Frequency &gt; SOUND_MAX_FRQ)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L645">645</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC645">                        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L646">646</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC646">                          Frequency = SOUND_MAX_FRQ;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L647">647</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC647">                        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L648">648</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC648"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L649">649</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC649">                        Period = (UWORD)((SOUND_TONE_MASTER_CLOCK / Frequency) - <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L650">650</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC650">                        <span class="pl-c1">SETPwmPeriod</span>(Period);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L651">651</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC651"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L652">652</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC652">                        <span class="pl-k">if</span> (Level &gt; <span class="pl-c1">100</span>) Level = <span class="pl-c1">100</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L653">653</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC653"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L654">654</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC654">                        PwmLevel = (UWORD)(((ulong)(Period) * (ulong)(Level)) /(ulong)(<span class="pl-c1">200</span>)); <span class="pl-c">// Level from % to ticks (Duty Cycle)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L655">655</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC655"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L656">656</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC656">                        <span class="pl-c1">SETSoundLevel</span>(PwmLevel);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L657">657</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC657"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L658">658</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC658">                        <span class="pl-k">if</span>(<span class="pl-c1">Duration</span> &gt; <span class="pl-c1">0</span>)  <span class="pl-c">// Infinite or specific?</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L659">659</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC659">                        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L660">660</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC660">                          <span class="pl-c1">Device1TimerInitDuration</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L661">661</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC661">                          TimerMode = ONE_SHOT;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L662">662</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC662">                        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L663">663</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC663">                        <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L664">664</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC664">                          TimerMode = MANUAL;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L665">665</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC665"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L666">666</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC666">                        SOUNDEnable;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L667">667</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC667"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L668">668</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC668">                        <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L669">669</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC669"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L670">670</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC670">      <span class="pl-k">case</span> REPEAT:	  <span class="pl-c">// Handled in Green Layer</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L671">671</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC671">    	  	  	  	    <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L672">672</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC672"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L673">673</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC673">      <span class="pl-k">case</span> PLAY:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L674">674</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC674">    	  	  	  	  SOUNDDisable;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L675">675</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC675">                      SOUNDPwmModuleSetupPcm;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L676">676</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC676">                      Level = CommandBuffer[<span class="pl-c1">1</span>];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L677">677</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC677">                      Period = (UWORD)(SOUND_MASTER_CLOCK / <span class="pl-c1">64000</span>); <span class="pl-c">// 64 KHz =&gt; 8 shots of each sample</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L678">678</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC678">      	  	  	  	  <span class="pl-c1">SETPwmPeriod</span>(Period);                         <span class="pl-c">// helps filtering</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L679">679</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC679"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L680">680</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC680">    	  	  	  	    BufferWriteIndex = <span class="pl-c1">0</span>;		<span class="pl-c">// Reset to first ring Buffer</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L681">681</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC681">      	  	  	  	  BufferReadIndex = <span class="pl-c1">0</span>;		<span class="pl-c">// -</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L682">682</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC682">      	  	  	  	  BufferReadPointer = <span class="pl-c1">0</span>;	<span class="pl-c">// Ready for very first sample</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L683">683</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC683">      	  	  	  	  <span class="pl-k">for</span> (i = <span class="pl-c1">0</span>; i &lt; SOUND_BUFFER_COUNT; i++)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L684">684</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC684">      	  	  	  		  SoundChunkSize[i] = <span class="pl-c1">0</span>;	<span class="pl-c">// Reset all Buffer sizes</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L685">685</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC685"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L686">686</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC686">      	  	  	  	  <span class="pl-c1">Device1TimerInit8KHz</span>();   <span class="pl-c">// TimerMode = READY_FOR_SAMPLES;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L687">687</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC687">      	  	  	  	  <span class="pl-k">if</span>(Level != <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L688">688</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC688">      	  	  	  	    SOUNDEnable;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L689">689</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC689">      	  	  	  	  <span class="pl-c">// Else we remove any &quot;selfmade&quot; noise</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L690">690</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC690">      	  	  	  	  <span class="pl-c">// Better n/s+n ratio ;-)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L691">691</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC691">      	  	          BytesWritten = <span class="pl-c1">2</span>; <span class="pl-c">// CMD and Level</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L692">692</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC692">    	  	  	  	    <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L693">693</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC693"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L694">694</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC694">      <span class="pl-k">case</span> BREAK:     <span class="pl-c1">Device1TimerCancel</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L695">695</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC695">                      SOUNDDisable;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L696">696</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC696">                      EHRPWMClkDisable;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L697">697</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC697">                      TimerMode = IDLE;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L698">698</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC698">                      (*pSound).<span class="pl-smi">Status</span>  =  OK;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L699">699</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC699">                      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L700">700</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC700"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L701">701</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC701">      <span class="pl-k">default</span>:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L702">702</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC702">                      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L703">703</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC703">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L704">704</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC704"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L705">705</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC705">  <span class="pl-k">return</span> (BytesWritten);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L706">706</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC706">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L707">707</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC707"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L708">708</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC708"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L709">709</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC709"><span class="pl-k">static</span> <span class="pl-c1">ssize_t</span> <span class="pl-en">Device1Read</span>(<span class="pl-k">struct</span> file *File,<span class="pl-k">char</span> *Buffer,<span class="pl-c1">size_t</span> Count,<span class="pl-c1">loff_t</span> *Offset)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L710">710</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC710">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L711">711</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC711">  <span class="pl-k">int</span>     Lng     = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L712">712</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC712"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L713">713</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC713">  Lng  =  <span class="pl-c1">snprintf</span>(Buffer,Count,<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span><span class="pl-cce">\r</span><span class="pl-pds">&quot;</span></span>,DEVICE1_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L714">714</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC714"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L715">715</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC715">  <span class="pl-k">return</span> (Lng);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L716">716</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC716">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L717">717</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC717"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L718">718</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC718">#<span class="pl-k">define</span>     <span class="pl-en">SHM_LENGTH</span>    (<span class="pl-k">sizeof</span>(SoundDefault))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L719">719</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC719">#<span class="pl-k">define</span>     <span class="pl-en">NPAGES</span>        ((SHM_LENGTH + PAGE_SIZE - <span class="pl-c1">1</span>) / PAGE_SIZE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L720">720</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC720"><span class="pl-k">static</span> <span class="pl-k">void</span> *kmalloc_ptr;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L721">721</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC721"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L722">722</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC722"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">Device1Mmap</span>(<span class="pl-k">struct</span> file *filp, <span class="pl-k">struct</span> vm_area_struct *vma)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L723">723</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC723">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L724">724</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC724">   <span class="pl-k">int</span> ret;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L725">725</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC725"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L726">726</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC726">   ret = <span class="pl-c1">remap_pfn_range</span>(vma,vma-&gt;vm_start,<span class="pl-c1">virt_to_phys</span>((<span class="pl-k">void</span>*)((<span class="pl-k">unsigned</span> <span class="pl-k">long</span>)pSound)) &gt;&gt; PAGE_SHIFT,vma-&gt;vm_end-vma-&gt;vm_start,PAGE_SHARED);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L727">727</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC727"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L728">728</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC728">   <span class="pl-k">if</span> (ret != <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L729">729</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC729">   {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L730">730</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC730">     ret  =  -EAGAIN;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L731">731</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC731">   }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L732">732</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC732"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L733">733</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC733">   <span class="pl-k">return</span> (ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L734">734</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC734">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L735">735</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC735"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L736">736</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC736"><span class="pl-k">static</span>    <span class="pl-k">const</span> <span class="pl-k">struct</span> file_operations Device1Entries =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L737">737</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC737">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L738">738</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC738">  .<span class="pl-smi">owner</span>        = THIS_MODULE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L739">739</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC739">  .<span class="pl-smi">read</span>         = Device1Read,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L740">740</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC740">  .<span class="pl-smi">write</span>        = Device1Write,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L741">741</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC741">  .<span class="pl-smi">mmap</span>         = Device1Mmap,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L742">742</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC742">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L743">743</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC743"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L744">744</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC744"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L745">745</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC745"><span class="pl-k">static</span>    <span class="pl-k">struct</span> miscdevice Device1 =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L746">746</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC746">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L747">747</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC747">  MISC_DYNAMIC_MINOR,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L748">748</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC748">  DEVICE1_NAME,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L749">749</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC749">  &amp;Device1Entries</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L750">750</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC750">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L751">751</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC751"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L752">752</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC752"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L753">753</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC753"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">Device1Init</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L754">754</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC754">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L755">755</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC755">  <span class="pl-k">int</span>     Result = -<span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L756">756</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC756">  <span class="pl-k">int</span> i = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L757">757</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC757">  UWORD   *pTmp;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L758">758</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC758"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L759">759</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC759">  <span class="pl-c">// Get pointers to memory-mapped registers</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L760">760</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC760">  <span class="pl-c1">GetPeriphealBasePtr</span>(0x01C14000, 0x190, (ULONG**)&amp;SYSCFG0); <span class="pl-c">/* SYSCFG0 Pointer */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L761">761</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC761">  <span class="pl-c1">GetPeriphealBasePtr</span>(0x01F00000, 0x1042,(ULONG**)&amp;eHRPWM0); <span class="pl-c">/* eHRPWM0 Pointer */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L762">762</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC762">  <span class="pl-c1">GetPeriphealBasePtr</span>(0x01E27000, 0xA80, (ULONG**)&amp;PSC1);    <span class="pl-c">/* PSC1 pointer    */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L763">763</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC763"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L764">764</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC764">  Result  =  <span class="pl-c1">misc_register</span>(&amp;Device1);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L765">765</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC765">  <span class="pl-k">if</span> (Result)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L766">766</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC766">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L767">767</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC767">    <span class="pl-c">//#define DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L768">768</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC768">    #<span class="pl-k">undef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L769">769</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC769">    #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L770">770</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC770">      <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  <span class="pl-c1">%s</span> device register failed<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,DEVICE1_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L771">771</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC771">    #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L772">772</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC772">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L773">773</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC773">  <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L774">774</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC774">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L775">775</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC775">    <span class="pl-c">// allocate kernel shared memory for SoundFlags used by Test etc.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L776">776</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC776">    <span class="pl-c">// showing the state of the sound-module used by async and waiting</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L777">777</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC777">    <span class="pl-c">// use from VM</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L778">778</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC778"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L779">779</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC779">        <span class="pl-k">if</span> ((kmalloc_ptr = <span class="pl-c1">kmalloc</span>((NPAGES + <span class="pl-c1">2</span>) * PAGE_SIZE, GFP_KERNEL)) != <span class="pl-c1">NULL</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L780">780</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC780">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L781">781</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC781">          pTmp = (UWORD*)((((<span class="pl-k">unsigned</span> <span class="pl-k">long</span>)kmalloc_ptr) + PAGE_SIZE - <span class="pl-c1">1</span>) &amp; PAGE_MASK);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L782">782</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC782">          <span class="pl-k">for</span> (i = <span class="pl-c1">0</span>; i &lt; NPAGES * PAGE_SIZE; i += PAGE_SIZE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L783">783</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC783">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L784">784</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC784">            <span class="pl-c1">SetPageReserved</span>(<span class="pl-c1">virt_to_page</span>(((<span class="pl-k">unsigned</span> <span class="pl-k">long</span>)pTmp) + i));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L785">785</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC785">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L786">786</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC786">          pSound =  (SOUND*)pTmp;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L787">787</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC787"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L788">788</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC788">          SOUNDPwmPoweron;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L789">789</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC789"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L790">790</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC790">          <span class="pl-c">/* Setup the Sound PWM peripherals */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L791">791</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC791"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L792">792</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC792">          SOUNDPwmModuleSetupPcm;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L793">793</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC793"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L794">794</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC794">          <span class="pl-c">/* Setup 125 uS timer interrupt*/</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L795">795</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC795">          <span class="pl-c1">Device1TimerSetTiming</span>(<span class="pl-c1">0</span>, <span class="pl-c1">125000</span>); <span class="pl-c">// Default to 8 KHz. sample-rate</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L796">796</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC796">          <span class="pl-c1">hrtimer_init</span>(&amp;Device1Timer,CLOCK_MONOTONIC,HRTIMER_MODE_REL);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L797">797</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC797">          <span class="pl-c">// Timer Callback function - do the sequential job</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L798">798</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC798">          Device1Timer.<span class="pl-smi">function</span>  =  Device1TimerInterrupt1;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L799">799</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC799">          <span class="pl-c1">Device1TimerCancel</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L800">800</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC800"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L801">801</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC801">          SOUNDDisable; <span class="pl-c">// Disable the Sound Power Amp</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L802">802</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC802"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L803">803</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC803">          <span class="pl-c">//#define DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L804">804</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC804">          #<span class="pl-k">undef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L805">805</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC805">		      #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L806">806</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC806">        	  <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  <span class="pl-c1">%s</span> device register succes<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,DEVICE1_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L807">807</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC807">		      #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L808">808</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC808"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L809">809</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC809">        	(*pSound).<span class="pl-smi">Status</span>  =  OK;  <span class="pl-c">// We&#39;re ready for making &quot;noise&quot;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L810">810</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC810">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L811">811</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC811">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L812">812</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC812"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L813">813</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC813">  <span class="pl-k">return</span> (Result);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L814">814</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC814">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L815">815</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC815"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L816">816</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC816"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">Device1Exit</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L817">817</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC817">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L818">818</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC818">  UWORD   *pTmp;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L819">819</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC819">  <span class="pl-k">int</span> i = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L820">820</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC820"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L821">821</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC821">  <span class="pl-c1">Device1TimerExit</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L822">822</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC822">  <span class="pl-c1">misc_deregister</span>(&amp;Device1);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L823">823</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC823"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L824">824</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC824">  #<span class="pl-k">define</span> <span class="pl-en">DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L825">825</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC825">  #<span class="pl-k">undef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L826">826</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC826">  #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L827">827</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC827">    <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span> exit started<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,MODULE_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L828">828</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC828">  #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L829">829</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC829"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L830">830</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC830">  <span class="pl-c1">iounmap</span>(SYSCFG0);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L831">831</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC831">  <span class="pl-c1">iounmap</span>(eHRPWM0);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L832">832</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC832">  <span class="pl-c1">iounmap</span>(PSC1);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L833">833</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC833"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L834">834</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC834">  <span class="pl-c">// free shared memory</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L835">835</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC835">  pTmp    =  (UWORD*)pSound;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L836">836</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC836">  pSound  =  &amp;SoundDefault;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L837">837</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC837"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L838">838</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC838">  <span class="pl-k">for</span> (i = <span class="pl-c1">0</span>; i &lt; NPAGES * PAGE_SIZE; i+= PAGE_SIZE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L839">839</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC839">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L840">840</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC840">    <span class="pl-c1">ClearPageReserved</span>(<span class="pl-c1">virt_to_page</span>(((<span class="pl-k">unsigned</span> <span class="pl-k">long</span>)pTmp) + i));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L841">841</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC841"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L842">842</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC842">    #<span class="pl-k">define</span> <span class="pl-en">DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L843">843</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC843">    #<span class="pl-k">undef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L844">844</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC844">    #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L845">845</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC845">      <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  <span class="pl-c1">%s</span> memory page <span class="pl-c1">%d</span> unmapped<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,DEVICE1_NAME,i);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L846">846</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC846">    #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L847">847</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC847">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L848">848</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC848"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L849">849</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC849">  <span class="pl-c1">kfree</span>(kmalloc_ptr);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L850">850</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC850"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L851">851</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC851"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L852">852</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC852">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L853">853</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC853"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L854">854</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC854"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L855">855</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC855"><span class="pl-c">// MODULE *********************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L856">856</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC856"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L857">857</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC857"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L858">858</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC858">#<span class="pl-k">ifndef</span> PCASM</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L859">859</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC859"><span class="pl-en">module_param</span> (HwId, charp, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L860">860</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC860">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L861">861</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC861"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L862">862</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC862"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">ModuleInit</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L863">863</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC863">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L864">864</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC864">  <span class="pl-c">//#define DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L865">865</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC865">  #<span class="pl-k">undef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L866">866</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC866">  #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L867">867</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC867">    <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>HwId = <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,HWID);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L868">868</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC868">  #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L869">869</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC869"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L870">870</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC870">  <span class="pl-c">//#define DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L871">871</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC871">  #<span class="pl-k">undef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L872">872</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC872">  #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L873">873</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC873">    <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span> init started<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,MODULE_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L874">874</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC874">  #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L875">875</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC875"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L876">876</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC876">  <span class="pl-k">if</span> (<span class="pl-c1">request_mem_region</span>(DA8XX_GPIO_BASE,0xD8,MODULE_NAME) &gt;= <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L877">877</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC877">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L878">878</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC878">    GpioBase  =  (<span class="pl-k">void</span>*)<span class="pl-c1">ioremap</span>(DA8XX_GPIO_BASE,0xD8);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L879">879</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC879">    <span class="pl-k">if</span> (GpioBase != <span class="pl-c1">NULL</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L880">880</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC880">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L881">881</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC881">      <span class="pl-c">//#define DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L882">882</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC882">      #<span class="pl-k">undef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L883">883</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC883">      #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L884">884</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC884">        <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span> gpio address mapped<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,MODULE_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L885">885</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC885">      #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L886">886</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC886"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L887">887</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC887">      <span class="pl-c1">InitGpio</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L888">888</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC888">      <span class="pl-c1">Device1Init</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L889">889</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC889"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L890">890</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC890">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L891">891</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC891">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L892">892</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC892"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L893">893</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC893">  <span class="pl-k">return</span> (<span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L894">894</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC894">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L895">895</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC895"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L896">896</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC896"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L897">897</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC897"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">ModuleExit</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L898">898</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC898">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L899">899</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC899">  <span class="pl-c">//#define DEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L900">900</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC900">  #<span class="pl-k">undef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L901">901</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC901">  #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L902">902</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC902">    <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span> exit started<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,MODULE_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L903">903</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC903">  #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L904">904</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC904"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L905">905</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC905">  SOUNDDisable; <span class="pl-c">// Disable the Sound Power Amp</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L906">906</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC906">  <span class="pl-c1">Device1Exit</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L907">907</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC907"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L908">908</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC908">  <span class="pl-c1">iounmap</span>(GpioBase);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L909">909</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC909">}</td>
          </tr>
    </table>
  </div>
</div>


        </div>

      </div><!-- /.repo-container -->
      <div class="modal-backdrop"></div>
    </div><!-- /.container -->
  </div><!-- /.site -->


    </div><!-- /.wrapper -->

      <div class="container">
  <div class="site-footer" role="contentinfo">
    <ul class="site-footer-links right">
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage">
      <span class="mega-octicon octicon-mark-github" title="GitHub"></span>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2015 <span title="0.08615s from github-fe120-cp1-prd.iad.github.net">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact</a></li>
    </ul>
  </div>
</div>


    <div class="fullscreen-overlay js-fullscreen-overlay" id="fullscreen_overlay">
  <div class="fullscreen-container js-suggester-container">
    <div class="textarea-wrap">
      <textarea name="fullscreen-contents" id="fullscreen-contents" class="fullscreen-contents js-fullscreen-contents" placeholder=""></textarea>
      <div class="suggester-container">
        <div class="suggester fullscreen-suggester js-suggester js-navigation-container"></div>
      </div>
    </div>
  </div>
  <div class="fullscreen-sidebar">
    <a href="#" class="exit-fullscreen js-exit-fullscreen tooltipped tooltipped-w" aria-label="Exit Zen Mode">
      <span class="mega-octicon octicon-screen-normal"></span>
    </a>
    <a href="#" class="theme-switcher js-theme-switcher tooltipped tooltipped-w"
      aria-label="Switch themes">
      <span class="octicon octicon-color-mode"></span>
    </a>
  </div>
</div>



    

    <div id="ajax-error-message" class="flash flash-error">
      <span class="octicon octicon-alert"></span>
      <a href="#" class="octicon octicon-x flash-close js-ajax-error-dismiss" aria-label="Dismiss error"></a>
      Something went wrong with that request. Please try again.
    </div>


      <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-447ce66a36506ebddc8e84b4e32a77f6062f3d3482e77dd21a77a01f0643ad98.js"></script>
      <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github/index-83be60956d0d00076a726f0864b49916aae8e7bc6ee140798791be0b6644d661.js"></script>
      
      
  </body>
</html>

