

  <div class="commit file-history-tease">
    <div class="file-history-tease-header">
        <img alt="" class="avatar" height="24" src="https://1.gravatar.com/avatar/a3114595e89094e76e43ffc615e7655f?d=https%3A%2F%2Fassets-cdn.github.com%2Fimages%2Fgravatars%2Fgravatar-user-420.png&amp;r=x&amp;s=140" width="24" />
        <span class="author"><span>Xander Soldaat</span></span>
        <time datetime="2013-07-31T21:58:56Z" is="relative-time">Jul 31, 2013</time>
        <div class="commit-title">
            <a href="/mindboards/ev3sources/commit/fea79c0e219cd5e43193ce2987b496e04758f3e2" class="message" data-pjax="true" title="Additional files, like kernel, uboot and device specific lib/includes">Additional files, like kernel, uboot and device specific lib/includes</a>
        </div>
    </div>

    <div class="participation">
      <p class="quickstat">
        <a href="#blob_contributors_box" rel="facebox">
          <strong>0</strong>
           contributors
        </a>
      </p>
      
    </div>
    <div id="blob_contributors_box" style="display:none">
      <h2 class="facebox-header">Users who have contributed to this file</h2>
      <ul class="facebox-user-list">
      </ul>
    </div>
  </div>
