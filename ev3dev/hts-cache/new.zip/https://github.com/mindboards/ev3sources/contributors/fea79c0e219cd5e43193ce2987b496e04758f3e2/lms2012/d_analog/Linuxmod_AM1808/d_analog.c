

  <div class="commit file-history-tease">
    <div class="file-history-tease-header">
        <img alt="" class="avatar" height="24" src="https://1.gravatar.com/avatar/a3114595e89094e76e43ffc615e7655f?d=https%3A%2F%2Fassets-cdn.github.com%2Fimages%2Fgravatars%2Fgravatar-user-420.png&amp;r=x&amp;s=140" width="24" />
        <span class="author"><span>Xander Soldaat</span></span>
        <time datetime="2013-07-30T17:57:56Z" is="relative-time">Jul 30, 2013</time>
        <div class="commit-title">
            <a href="/mindboards/ev3sources/commit/e5be3a6d591c60b26a3fb853989a9c86f5a7cc56" class="message" data-pjax="true" title="Initial commit!  (so exciting!)">Initial commit! (so exciting!)</a>
        </div>
    </div>

    <div class="participation">
      <p class="quickstat">
        <a href="#blob_contributors_box" rel="facebox">
          <strong>0</strong>
           contributors
        </a>
      </p>
      
    </div>
    <div id="blob_contributors_box" style="display:none">
      <h2 class="facebox-header">Users who have contributed to this file</h2>
      <ul class="facebox-user-list">
      </ul>
    </div>
  </div>
