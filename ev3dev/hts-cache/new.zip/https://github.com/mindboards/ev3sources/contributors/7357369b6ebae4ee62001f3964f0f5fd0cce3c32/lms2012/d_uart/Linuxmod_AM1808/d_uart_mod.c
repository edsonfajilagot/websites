

  <div class="commit file-history-tease">
    <div class="file-history-tease-header">
        <img alt="@schodet" class="avatar" data-user="179400" height="24" src="https://avatars1.githubusercontent.com/u/179400?v=3&amp;s=48" width="24" />
        <span class="author"><a href="/schodet" rel="contributor">schodet</a></span>
        <time datetime="2013-08-23T05:10:37Z" is="relative-time">Aug 23, 2013</time>
        <div class="commit-title">
            <a href="/mindboards/ev3sources/commit/fb1908a1e555025e1abdc62b62bcb2ccc0fa48fd" class="message" data-pjax="true" title="Add Makefiles for kernel and modules">Add Makefiles for kernel and modules</a>
        </div>
    </div>

    <div class="participation">
      <p class="quickstat">
        <a href="#blob_contributors_box" rel="facebox">
          <strong>1</strong>
           contributor
        </a>
      </p>
      
    </div>
    <div id="blob_contributors_box" style="display:none">
      <h2 class="facebox-header">Users who have contributed to this file</h2>
      <ul class="facebox-user-list">
          <li class="facebox-user-list-item">
            <img alt="@schodet" data-user="179400" height="24" src="https://avatars1.githubusercontent.com/u/179400?v=3&amp;s=48" width="24" />
            <a href="/schodet">schodet</a>
          </li>
      </ul>
    </div>
  </div>
