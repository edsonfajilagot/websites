


<!DOCTYPE html>
<html lang="en" class="">
  <head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# object: http://ogp.me/ns/object# article: http://ogp.me/ns/article# profile: http://ogp.me/ns/profile#">
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    
    
    <title>ev3sources/lms2012/d_iic/Linuxmod_AM1808/d_iic.c at 7357369b6ebae4ee62001f3964f0f5fd0cce3c32 · mindboards/ev3sources · GitHub</title>
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-144.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144.png">
    <meta property="fb:app_id" content="1401488693436528">

      <meta content="@github" name="twitter:site" /><meta content="summary" name="twitter:card" /><meta content="mindboards/ev3sources" name="twitter:title" /><meta content="LEGO MINDSTORMS EV3 source code. Contribute to ev3sources development by creating an account on GitHub." name="twitter:description" /><meta content="https://avatars3.githubusercontent.com/u/2578456?v=3&amp;s=400" name="twitter:image:src" />
      <meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="https://avatars3.githubusercontent.com/u/2578456?v=3&amp;s=400" property="og:image" /><meta content="mindboards/ev3sources" property="og:title" /><meta content="https://github.com/mindboards/ev3sources" property="og:url" /><meta content="LEGO MINDSTORMS EV3 source code. Contribute to ev3sources development by creating an account on GitHub." property="og:description" />
      <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">
    <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">
    <link rel="assets" href="https://assets-cdn.github.com/">
    
    <meta name="pjax-timeout" content="1000">
    

    <meta name="msapplication-TileImage" content="/windows-tile.png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="selected-link" value="repo_source" data-pjax-transient>
      <meta name="google-analytics" content="UA-3769691-2">

    <meta content="collector.githubapp.com" name="octolytics-host" /><meta content="collector-cdn.github.com" name="octolytics-script-host" /><meta content="github" name="octolytics-app-id" /><meta content="70C64D49:7B9E:7430FD:556C2674" name="octolytics-dimension-request_id" />
    
    <meta content="Rails, view, blob#blame" name="analytics-event" />
    <meta class="js-ga-set" name="dimension1" content="Logged Out">
    <meta class="js-ga-set" name="dimension2" content="Header v3">
    <meta name="is-dotcom" content="true">
      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

    
    <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">


    <meta content="authenticity_token" name="csrf-param" />
<meta content="z7Q2mG5HpQexjpr77beJUG9oTltylNshOZTPaGQ7pEUIB0X7XnkRxc0G9nGyjRbQqARW5PsCvJtSrdgTneko0w==" name="csrf-token" />

    <link href="https://assets-cdn.github.com/assets/github/index-7e77e66f8436e66d6a9791d7a09cec15828e9e04a0ad97cf73e83223f8b9cb3a.css" media="all" rel="stylesheet" />
    <link href="https://assets-cdn.github.com/assets/github2/index-5df271cf586eee5e48a88e30cdb6b5c32413ce1d7337835a905fc8c16294237e.css" media="all" rel="stylesheet" />
    
    


    <meta http-equiv="x-pjax-version" content="840467a6cd0c672c678f4fd42f529999">

            <meta content="noindex, nofollow" name="robots" />

  <meta name="description" content="LEGO MINDSTORMS EV3 source code. Contribute to ev3sources development by creating an account on GitHub.">
  <meta name="go-import" content="github.com/mindboards/ev3sources git https://github.com/mindboards/ev3sources.git">

  <meta content="2578456" name="octolytics-dimension-user_id" /><meta content="mindboards" name="octolytics-dimension-user_login" /><meta content="11771262" name="octolytics-dimension-repository_id" /><meta content="mindboards/ev3sources" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="11771262" name="octolytics-dimension-repository_network_root_id" /><meta content="mindboards/ev3sources" name="octolytics-dimension-repository_network_root_nwo" />
  <link href="https://github.com/mindboards/ev3sources/commits/7357369b6ebae4ee62001f3964f0f5fd0cce3c32.atom" rel="alternate" title="Recent Commits to ev3sources:7357369b6ebae4ee62001f3964f0f5fd0cce3c32" type="application/atom+xml">

  </head>


  <body class="logged_out  env-production  vis-public">
    <a href="#start-of-content" tabindex="1" class="accessibility-aid js-skip-to-content">Skip to content</a>
    <div class="wrapper">
      
      
      


        
        <div class="header header-logged-out" role="banner">
  <div class="container clearfix">

    <a class="header-logo-wordmark" href="https://github.com/" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
      <span class="mega-octicon octicon-logo-github"></span>
    </a>

    <div class="header-actions" role="navigation">
        <a class="btn btn-primary" href="/join" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
      <a class="btn" href="/login?return_to=%2Fmindboards%2Fev3sources%2Fblame%2F7357369b6ebae4ee62001f3964f0f5fd0cce3c32%2Flms2012%2Fd_iic%2FLinuxmod_AM1808%2Fd_iic.c" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
    </div>

    <div class="site-search repo-scope js-site-search" role="search">
      <form accept-charset="UTF-8" action="/mindboards/ev3sources/search" class="js-site-search-form" data-global-search-url="/search" data-repo-search-url="/mindboards/ev3sources/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
  <label class="js-chromeless-input-container form-control">
    <div class="scope-badge">This repository</div>
    <input type="text"
      class="js-site-search-focus js-site-search-field is-clearable chromeless-input"
      data-hotkey="s"
      name="q"
      placeholder="Search"
      data-global-scope-placeholder="Search GitHub"
      data-repo-scope-placeholder="Search"
      tabindex="1"
      autocapitalize="off">
  </label>
</form>
    </div>

      <ul class="header-nav left" role="navigation">
          <li class="header-nav-item">
            <a class="header-nav-link" href="/explore" data-ga-click="(Logged out) Header, go to explore, text:explore">Explore</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/features" data-ga-click="(Logged out) Header, go to features, text:features">Features</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="https://enterprise.github.com/" data-ga-click="(Logged out) Header, go to enterprise, text:enterprise">Enterprise</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/blog" data-ga-click="(Logged out) Header, go to blog, text:blog">Blog</a>
          </li>
      </ul>

  </div>
</div>



      <div id="start-of-content" class="accessibility-aid"></div>
          <div class="site" itemscope itemtype="http://schema.org/WebPage">
    <div id="js-flash-container">
      
    </div>
    <div class="pagehead repohead instapaper_ignore readability-menu">
      <div class="container">
        
<ul class="pagehead-actions">

  <li>
      <a href="/login?return_to=%2Fmindboards%2Fev3sources"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <span class="octicon octicon-eye"></span>
    Watch
  </a>
  <a class="social-count" href="/mindboards/ev3sources/watchers">
    82
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fmindboards%2Fev3sources"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <span class="octicon octicon-star"></span>
    Star
  </a>

    <a class="social-count js-social-count" href="/mindboards/ev3sources/stargazers">
      241
    </a>

  </li>

    <li>
      <a href="/login?return_to=%2Fmindboards%2Fev3sources"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <span class="octicon octicon-repo-forked"></span>
        Fork
      </a>
      <a href="/mindboards/ev3sources/network" class="social-count">
        123
      </a>
    </li>
</ul>

        <h1 itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="entry-title public">
          <span class="mega-octicon octicon-repo"></span>
          <span class="author"><a href="/mindboards" class="url fn" itemprop="url" rel="author"><span itemprop="title">mindboards</span></a></span><!--
       --><span class="path-divider">/</span><!--
       --><strong><a href="/mindboards/ev3sources" data-pjax="#js-repo-pjax-container">ev3sources</a></strong>

          <span class="page-context-loader">
            <img alt="" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </span>

        </h1>
      </div><!-- /.container -->
    </div><!-- /.repohead -->

    <div class="container">
      <div class="repository-with-sidebar repo-container new-discussion-timeline  ">
        <div class="repository-sidebar clearfix">
            
<nav class="sunken-menu repo-nav js-repo-nav js-sidenav-container-pjax js-octicon-loaders"
     role="navigation"
     data-pjax="#js-repo-pjax-container"
     data-issue-count-url="/mindboards/ev3sources/issues/counts">
  <ul class="sunken-menu-group">
    <li class="tooltipped tooltipped-w" aria-label="Code">
      <a href="/mindboards/ev3sources" aria-label="Code" class="selected js-selected-navigation-item sunken-menu-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /mindboards/ev3sources">
        <span class="octicon octicon-code"></span> <span class="full-word">Code</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Issues">
        <a href="/mindboards/ev3sources/issues" aria-label="Issues" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /mindboards/ev3sources/issues">
          <span class="octicon octicon-issue-opened"></span> <span class="full-word">Issues</span>
          <span class="js-issue-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>

    <li class="tooltipped tooltipped-w" aria-label="Pull requests">
      <a href="/mindboards/ev3sources/pulls" aria-label="Pull requests" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g p" data-selected-links="repo_pulls /mindboards/ev3sources/pulls">
          <span class="octicon octicon-git-pull-request"></span> <span class="full-word">Pull requests</span>
          <span class="js-pull-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Wiki">
        <a href="/mindboards/ev3sources/wiki" aria-label="Wiki" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g w" data-selected-links="repo_wiki /mindboards/ev3sources/wiki">
          <span class="octicon octicon-book"></span> <span class="full-word">Wiki</span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>
  </ul>
  <div class="sunken-menu-separator"></div>
  <ul class="sunken-menu-group">

    <li class="tooltipped tooltipped-w" aria-label="Pulse">
      <a href="/mindboards/ev3sources/pulse" aria-label="Pulse" class="js-selected-navigation-item sunken-menu-item" data-selected-links="pulse /mindboards/ev3sources/pulse">
        <span class="octicon octicon-pulse"></span> <span class="full-word">Pulse</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

    <li class="tooltipped tooltipped-w" aria-label="Graphs">
      <a href="/mindboards/ev3sources/graphs" aria-label="Graphs" class="js-selected-navigation-item sunken-menu-item" data-selected-links="repo_graphs repo_contributors /mindboards/ev3sources/graphs">
        <span class="octicon octicon-graph"></span> <span class="full-word">Graphs</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>
  </ul>


</nav>

              <div class="only-with-full-nav">
                  
<div class="js-clone-url clone-url open"
  data-protocol-type="http">
  <h3><span class="text-emphasized">HTTPS</span> clone URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/mindboards/ev3sources.git" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>

  
<div class="js-clone-url clone-url "
  data-protocol-type="subversion">
  <h3><span class="text-emphasized">Subversion</span> checkout URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/mindboards/ev3sources" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>



<div class="clone-options">You can clone with
  <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=http&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="/K7La32idbN8ROcJ/xe4kseIamtSnECJzfiNdKTbMls4vt8JcBZZWFKXUIR1LOhVrAfqYiGyv4PMmdmqWEhtXg==" /></div><button class="btn-link js-clone-selector" data-protocol="http" type="submit">HTTPS</button></form> or <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=subversion&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="mSh11g3zLIt97eLJFdBNhI22iANbMN/fpsQuAhrzJEgMXV3XJ7CBQ49Etm6+AhcoPbq7sLUymuj/Q2POww7Oag==" /></div><button class="btn-link js-clone-selector" data-protocol="subversion" type="submit">Subversion</button></form>.
  <a href="https://help.github.com/articles/which-remote-url-should-i-use" class="help tooltipped tooltipped-n" aria-label="Get help on which URL is right for you.">
    <span class="octicon octicon-question"></span>
  </a>
</div>




                <a href="/mindboards/ev3sources/archive/7357369b6ebae4ee62001f3964f0f5fd0cce3c32.zip"
                   class="btn btn-sm sidebar-button"
                   aria-label="Download the contents of mindboards/ev3sources as a zip file"
                   title="Download the contents of mindboards/ev3sources as a zip file"
                   rel="nofollow">
                  <span class="octicon octicon-cloud-download"></span>
                  Download ZIP
                </a>
              </div>
        </div><!-- /.repository-sidebar -->

        <div id="js-repo-pjax-container" class="repository-content context-loader-container" data-pjax-container>

          
<a href="/mindboards/ev3sources/blame/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_iic/Linuxmod_AM1808/d_iic.c" class="hidden js-permalink-shortcut" data-hotkey="y">Permalink</a>

<div class="breadcrumb css-truncate blame-breadcrumb js-zeroclipboard-container">
  <span class="css-truncate-target js-zeroclipboard-target"><span class='repo-root js-repo-root'><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">ev3sources</span></a></span></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">lms2012</span></a></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_iic" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">d_iic</span></a></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_iic/Linuxmod_AM1808" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">Linuxmod_AM1808</span></a></span><span class="separator">/</span><strong class="final-path">d_iic.c</strong></span>
  <button aria-label="Copy file path to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
</div>

<div class="line-age-legend">
  <span>Newer</span>
  <ol>
      <li class="heat1"></li>
      <li class="heat2"></li>
      <li class="heat3"></li>
      <li class="heat4"></li>
      <li class="heat5"></li>
      <li class="heat6"></li>
      <li class="heat7"></li>
      <li class="heat8"></li>
      <li class="heat9"></li>
      <li class="heat10"></li>
  </ol>
  <span>Older</span>
</div>

<div class="file">
  <div class="file-header">
    <div class="file-actions">
      <div class="btn-group">
        <a href="/mindboards/ev3sources/raw/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_iic/Linuxmod_AM1808/d_iic.c" class="btn btn-sm" id="raw-url">Raw</a>
        <a href="/mindboards/ev3sources/blob/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_iic/Linuxmod_AM1808/d_iic.c" class="btn btn-sm js-update-url-with-hash">Normal view</a>
        <a href="/mindboards/ev3sources/commits/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/lms2012/d_iic/Linuxmod_AM1808/d_iic.c" class="btn btn-sm" rel="nofollow">History</a>
      </div>
    </div>



    <div class="file-info">
      <span class="octicon octicon-file-text"></span>
      <span class="file-mode" title="File Mode">100644</span>
      <span class="file-info-divider"></span>
        1563 lines (1288 sloc)
        <span class="file-info-divider"></span>
      39.723 kb
    </div>
  </div>

  <div class="blob-wrapper">
    <table class="blame-container highlight data js-file-line-container">
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="1563">
            <a href="/mindboards/ev3sources/commit/e5be3a6d591c60b26a3fb853989a9c86f5a7cc56" class="blame-sha">e5be3a6</a>
            <img alt="" class="avatar blame-commit-avatar" height="32" src="https://1.gravatar.com/avatar/a3114595e89094e76e43ffc615e7655f?d=https%3A%2F%2Fassets-cdn.github.com%2Fimages%2Fgravatars%2Fgravatar-user-420.png&amp;r=x&amp;s=140" width="32" />
            <a href="/mindboards/ev3sources/commit/e5be3a6d591c60b26a3fb853989a9c86f5a7cc56" class="blame-commit-title" title="Initial commit!  (so exciting!)">Initial commit!  (so exciting!)</a>
            <div class="blame-commit-meta">
              <span class="muted-link">Xander Soldaat</span> authored
              <time datetime="2013-07-30T17:57:56Z" is="relative-time">Jul 30, 2013</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1">1</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1"><span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L2">2</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC2"><span class="pl-c"> * LEGO® MINDSTORMS EV3</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L3">3</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC3"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L4">4</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC4"><span class="pl-c"> * Copyright (C) 2010-2013 The LEGO Group</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L5">5</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC5"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L6">6</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC6"><span class="pl-c"> * This program is free software; you can redistribute it and/or modify</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L7">7</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC7"><span class="pl-c"> * it under the terms of the GNU General Public License as published by</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L8">8</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC8"><span class="pl-c"> * the Free Software Foundation; either version 2 of the License, or</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L9">9</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC9"><span class="pl-c"> * (at your option) any later version.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L10">10</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC10"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L11">11</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC11"><span class="pl-c"> * This program is distributed in the hope that it will be useful,</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L12">12</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC12"><span class="pl-c"> * but WITHOUT ANY WARRANTY; without even the implied warranty of</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L13">13</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC13"><span class="pl-c"> * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L14">14</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC14"><span class="pl-c"> * GNU General Public License for more details.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L15">15</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC15"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L16">16</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC16"><span class="pl-c"> * You should have received a copy of the GNU General Public License</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L17">17</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC17"><span class="pl-c"> * along with this program; if not, write to the Free Software</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L18">18</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC18"><span class="pl-c"> * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L19">19</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC19"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L20">20</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC20"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L21">21</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC21"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L22">22</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC22"><span class="pl-c">/*! \page IicModule IIC Module</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L23">23</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC23"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L24">24</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC24"><span class="pl-c"> *  &lt;hr size=&quot;1&quot;/&gt;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L25">25</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC25"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L26">26</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC26"><span class="pl-c"> *  Manages communication with intelligent IIC devices on an input port.\n</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L27">27</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC27"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L28">28</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC28"><span class="pl-c"> *-  \subpage IicDriver</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L29">29</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC29"><span class="pl-c"> *-  \subpage IicModuleMemory</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L30">30</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC30"><span class="pl-c"> *-  \subpage IicModuleResources</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L31">31</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC31"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L32">32</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC32"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L33">33</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC33"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L34">34</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC34"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L35">35</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC35"><span class="pl-c">/*! \page IicDriver IIC Device Controller</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L36">36</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC36"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L37">37</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC37"><span class="pl-c"> *  &lt;hr size=&quot;1&quot;/&gt;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L38">38</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC38"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L39">39</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC39"><span class="pl-c"> *  Manages the sequence necessary when adding a IIC devices to an input port.\n</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L40">40</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC40"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L41">41</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC41"><span class="pl-c"> * \n</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L42">42</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC42"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L43">43</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC43"><span class="pl-c"> *  The IIC Device Controller gets information from the DCM driver \ref DcmDriver &quot;Device Detection Manager Driver&quot;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L44">44</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC44"><span class="pl-c"> *  about the port state and when the DCM driver detects a IIC device on the port the sequence below the following defines</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L45">45</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC45"><span class="pl-c"> *  is started inside the IIC Device Controller.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L46">46</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC46"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L47">47</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC47"><span class="pl-c"> * \verbatim</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L48">48</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC48"><span class="pl-c">*/</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L49">49</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC49"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L50">50</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC50"><span class="pl-c">/*!</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L51">51</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC51"><span class="pl-c">\endverbatim</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L52">52</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC52"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L53">53</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC53"><span class="pl-c"> *  \n</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L54">54</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC54"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L55">55</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC55"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L56">56</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC56"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L57">57</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC57"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L58">58</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC58">#<span class="pl-k">ifndef</span> PCASM</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L59">59</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC59">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>asm/types.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L60">60</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC60">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L61">61</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC61"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L62">62</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC62">#<span class="pl-k">define</span>   <span class="pl-en">HW_ID_SUPPORT</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L63">63</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC63"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L64">64</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC64">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&quot;</span>../../lms2012/source/lms2012.h<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L65">65</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC65">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&quot;</span>../../lms2012/source/am1808.h<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L66">66</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC66"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L67">67</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC67">#<span class="pl-k">ifndef</span>    DISABLE_FIQ_IIC</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L68">68</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC68">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&quot;</span>d_iic.h<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L69">69</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC69">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L70">70</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC70"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L71">71</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC71">#<span class="pl-k">ifdef</span>    DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L72">72</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC72">#<span class="pl-k">define</span>   <span class="pl-en">DEBUG_D_IIC</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L73">73</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC73">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L74">74</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC74">#<span class="pl-k">ifdef</span>    DEBUG_D_IIC</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L75">75</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC75">#<span class="pl-k">define</span>   <span class="pl-en">DEBUG_IIC_WRITE</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L76">76</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC76">#<span class="pl-k">define</span>   <span class="pl-en">HIGHDEBUG</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L77">77</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC77">#<span class="pl-k">define</span>   <span class="pl-en">DEBUG_TRACE_MODE_CHANGE</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L78">78</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC78">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L79">79</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC79"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L80">80</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC80"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L81">81</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC81"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L82">82</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC82">#<span class="pl-k">define</span>   <span class="pl-en">MODULE_NAME</span>                   <span class="pl-s"><span class="pl-pds">&quot;</span>iic_module<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L83">83</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC83">#<span class="pl-k">define</span>   <span class="pl-en">DEVICE1_NAME</span>                  IIC_DEVICE</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L84">84</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC84"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L85">85</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC85"><span class="pl-k">static</span>    <span class="pl-k">int</span>  <span class="pl-en">ModuleInit</span>(<span class="pl-k">void</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L86">86</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC86"><span class="pl-k">static</span>    <span class="pl-k">void</span> <span class="pl-en">ModuleExit</span>(<span class="pl-k">void</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L87">87</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC87"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L88">88</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC88">#<span class="pl-k">define</span>   <span class="pl-en">__USE_POSIX</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L89">89</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC89"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L90">90</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC90">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/kernel.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L91">91</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC91">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/fs.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L92">92</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC92"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L93">93</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC93">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/sched.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L94">94</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC94"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L95">95</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC95"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L96">96</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC96">#<span class="pl-k">ifndef</span>   PCASM</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L97">97</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC97">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/circ_buf.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L98">98</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC98">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/hrtimer.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L99">99</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC99"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L100">100</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC100">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/mm.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L101">101</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC101">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/hrtimer.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L102">102</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC102"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L103">103</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC103">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/init.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L104">104</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC104">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/uaccess.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L105">105</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC105">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/debugfs.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L106">106</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC106"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L107">107</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC107">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/ioport.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L108">108</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC108">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>asm/gpio.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L109">109</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC109">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>asm/io.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L110">110</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC110">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/module.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L111">111</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC111">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/miscdevice.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L112">112</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC112">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>asm/uaccess.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L113">113</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC113"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L114">114</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC114"><span class="pl-en">MODULE_LICENSE</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>GPL<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L115">115</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC115"><span class="pl-en">MODULE_AUTHOR</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>The LEGO Group<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L116">116</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC116"><span class="pl-en">MODULE_DESCRIPTION</span>(MODULE_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L117">117</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC117"><span class="pl-en">MODULE_SUPPORTED_DEVICE</span>(DEVICE1_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L118">118</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC118"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L119">119</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC119"><span class="pl-en">module_init</span>(ModuleInit);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L120">120</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC120"><span class="pl-en">module_exit</span>(ModuleExit);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L121">121</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC121"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L122">122</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC122">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L123">123</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC123"><span class="pl-c">// Keep Eclipse happy</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L124">124</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC124">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L125">125</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC125"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L126">126</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC126"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L127">127</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC127">#<span class="pl-k">define</span>   <span class="pl-en">NO_OF_IIC_PORTS</span>             INPUTS</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L128">128</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC128"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L129">129</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC129"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L130">130</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC130">#<span class="pl-k">ifndef</span>    DISABLE_FIQ_IIC</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L131">131</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC131"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L132">132</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC132"><span class="pl-k">extern</span>    INPIN IicPortPin[NO_OF_IIC_PORTS][IIC_PORT_PINS];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L133">133</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC133"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L134">134</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC134">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L135">135</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC135"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L136">136</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC136"><span class="pl-k">enum</span>      IicPortPins</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L137">137</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC137">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L138">138</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC138">  IIC_PORT_BUFFER_CTRL,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L139">139</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC139">  IIC_PORT_CLOCK,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L140">140</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC140">  IIC_PORT_DATA,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L141">141</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC141">  IIC_PORT_PINS,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L142">142</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC142">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L143">143</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC143"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L144">144</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC144">INPIN     IicPortPin[NO_OF_IIC_PORTS][IIC_PORT_PINS];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L145">145</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC145"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L146">146</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC146">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L147">147</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC147"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L148">148</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC148"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L149">149</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC149"><span class="pl-k">int</span>       Hw = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L150">150</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC150"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L151">151</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC151"><span class="pl-c">/*! \page IicModuleResources Gpios and Resources used for Module</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L152">152</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC152"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L153">153</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC153"><span class="pl-c"> *  Describes use of gpio and resources\n</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L154">154</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC154"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L155">155</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC155"><span class="pl-c"> *  \verbatim</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L156">156</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC156"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L157">157</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC157"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L158">158</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC158"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L159">159</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC159">INPIN     EP2_IicPortPin[][IIC_PORT_PINS] =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L160">160</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC160">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L161">161</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC161">  { <span class="pl-c">// Input port 1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L162">162</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC162">    { GP8_11 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Buffer disable</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L163">163</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC163">    { GP1_0  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 5  - Digital input   // CLOCK</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L164">164</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC164">    { GP0_15 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 6  - Digital output  // DATA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L165">165</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC165">  },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L166">166</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC166">  { <span class="pl-c">// Input port 2</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L167">167</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC167">    { GP8_14 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Buffer disable</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L168">168</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC168">    { GP8_3  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 5  - Digital input   // CLOCK</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L169">169</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC169">    { GP0_13 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 6  - Digital output  // DATA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L170">170</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC170">  },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L171">171</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC171">  { <span class="pl-c">// Input port 3</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L172">172</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC172">    { GP7_9  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Buffer disable</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L173">173</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC173">    { GP1_12 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 5  - Digital input   // CLOCK</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L174">174</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC174">    { GP1_14 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 6  - Digital output  // DATA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L175">175</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC175">  },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L176">176</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC176">  { <span class="pl-c">// Input port 4</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L177">177</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC177">    { GP7_10 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Buffer disable</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L178">178</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC178">    { GP1_11 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 5  - Digital input   // CLOCK</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L179">179</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC179">    { GP1_15 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 6  - Digital output  // DATA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L180">180</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC180">  },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L181">181</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC181">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L182">182</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC182"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L183">183</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC183"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L184">184</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC184">INPIN     FINALB_IicPortPin[][IIC_PORT_PINS] =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L185">185</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC185">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L186">186</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC186">  { <span class="pl-c">// Input port 1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L187">187</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC187">    { GP8_11 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Buffer disable</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L188">188</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC188">    { GP1_0  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 5  - Digital input   // CLOCK</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L189">189</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC189">    { GP0_15 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 6  - Digital output  // DATA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L190">190</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC190">  },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L191">191</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC191">  { <span class="pl-c">// Input port 2</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L192">192</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC192">    { GP8_14 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Buffer disable</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L193">193</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC193">    { GP8_3  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 5  - Digital input   // CLOCK</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L194">194</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC194">    { GP0_13 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 6  - Digital output  // DATA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L195">195</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC195">  },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L196">196</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC196">  { <span class="pl-c">// Input port 3</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L197">197</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC197">    { GP7_9  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Buffer disable</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L198">198</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC198">    { GP1_12 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 5  - Digital input   // CLOCK</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L199">199</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC199">    { GP1_14 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 6  - Digital output  // DATA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L200">200</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC200">  },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L201">201</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC201">  { <span class="pl-c">// Input port 4</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L202">202</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC202">    { GP7_10 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Buffer disable</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L203">203</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC203">    { GP1_11 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 5  - Digital input   // CLOCK</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L204">204</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC204">    { GP1_15 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 6  - Digital output  // DATA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L205">205</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC205">  },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L206">206</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC206">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L207">207</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC207"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L208">208</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC208"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L209">209</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC209">INPIN     FINAL_IicPortPin[][IIC_PORT_PINS] =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L210">210</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC210">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L211">211</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC211">  { <span class="pl-c">// Input port 1</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L212">212</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC212">    { GP8_11 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Buffer disable</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L213">213</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC213">    { GP0_2  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 5  - Digital input   // CLOCK</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L214">214</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC214">    { GP0_15 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 6  - Digital output  // DATA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L215">215</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC215">  },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L216">216</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC216">  { <span class="pl-c">// Input port 2</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L217">217</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC217">    { GP8_14 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Buffer disable</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L218">218</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC218">    { GP0_14 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 5  - Digital input   // CLOCK</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L219">219</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC219">    { GP0_13 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 6  - Digital output  // DATA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L220">220</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC220">  },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L221">221</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC221">  { <span class="pl-c">// Input port 3</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L222">222</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC222">    { GP7_9  , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Buffer disable</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L223">223</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC223">    { GP0_12 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 5  - Digital input   // CLOCK</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L224">224</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC224">    { GP1_14 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 6  - Digital output  // DATA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L225">225</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC225">  },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L226">226</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC226">  { <span class="pl-c">// Input port 4</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L227">227</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC227">    { GP7_10 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Buffer disable</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L228">228</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC228">    { GP1_13 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 5  - Digital input   // CLOCK</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L229">229</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC229">    { GP1_15 , <span class="pl-c1">NULL</span>, <span class="pl-c1">0</span> }, <span class="pl-c">// Pin 6  - Digital output  // DATA</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L230">230</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC230">  },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L231">231</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC231">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L232">232</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC232"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L233">233</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC233"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L234">234</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC234"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L235">235</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC235"><span class="pl-c">/*  \endverbatim</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L236">236</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC236"><span class="pl-c"> *  \n</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L237">237</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC237"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L238">238</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC238"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L239">239</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC239"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L240">240</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC240">#<span class="pl-k">define</span>   <span class="pl-en">PUDisable</span>                     <span class="pl-en">iowrite32</span>(ioread32(da8xx_syscfg1_base + 0x0C) &amp; ~0xFFFFFFFF,da8xx_syscfg1_base + 0x0C)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L241">241</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC241"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L242">242</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC242">INPIN     *pIicPortPin[] =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L243">243</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC243">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L244">244</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC244">  [FINAL]     =   (INPIN*)&amp;FINAL_IicPortPin[<span class="pl-c1">0</span>],    <span class="pl-c">//  FINAL   platform</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L245">245</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC245">  [FINALB]    =   (INPIN*)&amp;FINALB_IicPortPin[<span class="pl-c1">0</span>],   <span class="pl-c">//  FINALB  platform</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L246">246</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC246">  [EP2]       =   (INPIN*)&amp;EP2_IicPortPin[<span class="pl-c1">0</span>],      <span class="pl-c">//  EP2     platform</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L247">247</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC247">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L248">248</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC248"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L249">249</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC249"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L250">250</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC250"><span class="pl-c">//*****************************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L251">251</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC251"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L252">252</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC252"><span class="pl-k">static</span>    <span class="pl-k">void</span>      __iomem *GpioBase;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L253">253</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC253"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L254">254</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC254"><span class="pl-k">void</span>      <span class="pl-en">SetGpio</span>(<span class="pl-k">int</span> Pin)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L255">255</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC255">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L256">256</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC256">  <span class="pl-k">int</span>     Tmp = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L257">257</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC257">  <span class="pl-k">void</span>    __iomem *Reg;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L258">258</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC258"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L259">259</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC259">  <span class="pl-k">if</span> (Pin &gt;= <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L260">260</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC260">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L261">261</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC261">    <span class="pl-c">// unlock</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L262">262</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC262">    REGUnlock;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L263">263</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC263"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L264">264</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC264">    <span class="pl-k">while</span> ((MuxRegMap[Tmp].<span class="pl-smi">Pin</span> != -<span class="pl-c1">1</span>) &amp;&amp; (MuxRegMap[Tmp].<span class="pl-smi">Pin</span> != Pin))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L265">265</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC265">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L266">266</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC266">      Tmp++;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L267">267</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC267">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L268">268</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC268">    <span class="pl-k">if</span> (MuxRegMap[Tmp].<span class="pl-smi">Pin</span> == Pin)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L269">269</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC269">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L270">270</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC270">      Reg   =  da8xx_syscfg0_base + 0x120 + (MuxRegMap[Tmp].<span class="pl-smi">MuxReg</span> &lt;&lt; <span class="pl-c1">2</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L271">271</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC271"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L272">272</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC272">      *(u32*)Reg &amp;=  MuxRegMap[Tmp].<span class="pl-smi">Mask</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L273">273</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC273">      *(u32*)Reg |=  MuxRegMap[Tmp].<span class="pl-smi">Mode</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L274">274</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC274">  #<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L275">275</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC275">      <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>    GP<span class="pl-c1">%d</span>_<span class="pl-c1">%-2d</span>  0x<span class="pl-c1">%08X</span> and 0x<span class="pl-c1">%08X</span> or 0x<span class="pl-c1">%08X</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,(Pin &gt;&gt; <span class="pl-c1">4</span>),(Pin &amp; 0x0F),(u32)Reg, MuxRegMap[Tmp].<span class="pl-smi">Mask</span>, MuxRegMap[Tmp].<span class="pl-smi">Mode</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L276">276</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC276">  #<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L277">277</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC277">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L278">278</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC278">    <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L279">279</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC279">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L280">280</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC280">      <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>*   GP<span class="pl-c1">%d</span>_<span class="pl-c1">%-2d</span>  ********* ERROR not found *********<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,(Pin &gt;&gt; <span class="pl-c1">4</span>),(Pin &amp; 0x0F));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L281">281</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC281">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L282">282</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC282">    <span class="pl-c">// lock</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L283">283</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC283">    REGLock;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L284">284</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC284">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L285">285</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC285">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L286">286</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC286"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L287">287</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC287"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L288">288</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC288"><span class="pl-k">void</span>      <span class="pl-en">InitGpio</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L289">289</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC289">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L290">290</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC290">  <span class="pl-k">int</span>     Port;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L291">291</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC291">  <span class="pl-k">int</span>     Pin;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L292">292</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC292"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L293">293</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC293"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L294">294</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC294">  <span class="pl-c1">memcpy</span>(IicPortPin,pIicPortPin[Hw],<span class="pl-k">sizeof</span>(EP2_IicPortPin));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L295">295</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC295"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L296">296</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC296">#<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L297">297</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC297">  <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-cce">\n\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L298">298</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC298">  <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>FINALB_IicPortPin            = <span class="pl-c1">%p</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,FINALB_IicPortPin);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L299">299</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC299">  <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>pIicPortPin[Hw]              = <span class="pl-c1">%p</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,pIicPortPin[Hw]);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L300">300</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC300">  <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>sizeof(INPIN)                = <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,<span class="pl-k">sizeof</span>(INPIN));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L301">301</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC301">  <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>sizeof(EP2_IicPortPin)       = <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,<span class="pl-k">sizeof</span>(EP2_IicPortPin));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L302">302</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC302"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L303">303</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC303">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L304">304</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC304"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L305">305</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC305">  <span class="pl-k">if</span> (<span class="pl-c1">memcmp</span>((<span class="pl-k">const</span> <span class="pl-k">void</span>*)IicPortPin,(<span class="pl-k">const</span> <span class="pl-k">void</span>*)pIicPortPin[Hw],<span class="pl-k">sizeof</span>(EP2_IicPortPin)) != <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L306">306</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC306">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L307">307</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC307">    <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span> IicPortPin tabel broken!<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,MODULE_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L308">308</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC308">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L309">309</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC309"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L310">310</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC310">  <span class="pl-k">for</span> (Port = <span class="pl-c1">0</span>;Port &lt; NO_OF_IIC_PORTS;Port++)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L311">311</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC311">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L312">312</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC312">#<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L313">313</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC313">    <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  Iic   port <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,Port + <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L314">314</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC314">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L315">315</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC315">    <span class="pl-k">for</span> (Pin = <span class="pl-c1">0</span>;Pin &lt; IIC_PORT_PINS;Pin++)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L316">316</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC316">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L317">317</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC317">      <span class="pl-k">if</span> ((Port != DEBUG_UART) || (Pin != IIC_PORT_CLOCK))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L318">318</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC318">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L319">319</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC319">        <span class="pl-k">if</span> (IicPortPin[Port][Pin].<span class="pl-smi">Pin</span> &gt;= <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L320">320</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC320">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L321">321</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC321">          IicPortPin[Port][Pin].<span class="pl-smi">pGpio</span>  =  (<span class="pl-k">struct</span> gpio_controller *__iomem)(GpioBase + ((IicPortPin[Port][Pin].<span class="pl-smi">Pin</span> &gt;&gt; <span class="pl-c1">5</span>) * 0x28) + 0x10);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L322">322</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC322">          IicPortPin[Port][Pin].<span class="pl-smi">Mask</span>   =  (<span class="pl-c1">1</span> &lt;&lt; (IicPortPin[Port][Pin].<span class="pl-smi">Pin</span> &amp; 0x1F));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L323">323</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC323"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L324">324</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC324">          <span class="pl-c1">SetGpio</span>(IicPortPin[Port][Pin].<span class="pl-smi">Pin</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L325">325</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC325">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L326">326</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC326">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L327">327</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC327">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L328">328</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC328">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L329">329</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC329"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L330">330</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC330">  <span class="pl-c">// unlock</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L331">331</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC331">  REGUnlock;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L332">332</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC332"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L333">333</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC333">  <span class="pl-c">// Disable pull up/down</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L334">334</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC334">  PUDisable;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L335">335</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC335"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L336">336</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC336">  <span class="pl-c">// lock</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L337">337</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC337">  REGLock;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L338">338</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC338">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L339">339</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC339"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L340">340</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC340"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L341">341</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC341">#<span class="pl-k">ifdef</span>    DISABLE_FIQ_IIC</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L342">342</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC342">#<span class="pl-k">define</span>   <span class="pl-en">PINFloat</span>(<span class="pl-v">port,pin</span>)            {\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L343">343</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC343">                                          (*IicPortPin[port][pin].<span class="pl-smi">pGpio</span>).<span class="pl-smi">dir</span> |=  IicPortPin[port][pin].<span class="pl-smi">Mask</span>;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L344">344</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC344">                                        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L345">345</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC345"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L346">346</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC346"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L347">347</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC347">#<span class="pl-k">define</span>   <span class="pl-en">PINRead</span>(<span class="pl-v">port,pin</span>)             ((*IicPortPin[port][pin].pGpio).in_data &amp; IicPortPin[port][pin].Mask)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L348">348</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC348"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L349">349</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC349"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L350">350</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC350">#<span class="pl-k">define</span>   <span class="pl-en">PINHigh</span>(<span class="pl-v">port,pin</span>)             {\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L351">351</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC351">                                          (*IicPortPin[port][pin].<span class="pl-smi">pGpio</span>).<span class="pl-smi">set_data</span>  =  IicPortPin[port][pin].<span class="pl-smi">Mask</span>;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L352">352</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC352">                                          (*IicPortPin[port][pin].<span class="pl-smi">pGpio</span>).<span class="pl-smi">dir</span>      &amp;= ~IicPortPin[port][pin].<span class="pl-smi">Mask</span>;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L353">353</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC353">                                        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L354">354</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC354"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L355">355</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC355">#<span class="pl-k">define</span>   <span class="pl-en">PINLow</span>(<span class="pl-v">port,pin</span>)              {\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L356">356</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC356">                                          (*IicPortPin[port][pin].<span class="pl-smi">pGpio</span>).<span class="pl-smi">clr_data</span>  =  IicPortPin[port][pin].<span class="pl-smi">Mask</span>;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L357">357</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC357">                                          (*IicPortPin[port][pin].<span class="pl-smi">pGpio</span>).<span class="pl-smi">dir</span>      &amp;= ~IicPortPin[port][pin].<span class="pl-smi">Mask</span>;\</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L358">358</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC358">                                        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L359">359</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC359">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L360">360</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC360"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L361">361</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC361"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L362">362</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC362"><span class="pl-k">typedef</span> <span class="pl-k">struct</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L363">363</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC363">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L364">364</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC364">  UWORD   Timer;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L365">365</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC365">  UWORD   Time;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L366">366</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC366">  UBYTE   Initialised;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L367">367</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC367">  UBYTE   ChangeMode;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L368">368</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC368">  UBYTE   State;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L369">369</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC369">  UBYTE   OldState;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L370">370</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC370">  UBYTE   SubState;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L371">371</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC371">  UBYTE   Repeat;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L372">372</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC372">  UBYTE   Cmd;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L373">373</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC373">  UBYTE   Mode;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L374">374</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC374">  UBYTE   Addr;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L375">375</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC375">  UBYTE   Retries;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L376">376</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC376">  SBYTE   Name[TYPE_NAME_LENGTH + <span class="pl-c1">1</span>];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L377">377</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC377">  UBYTE   Reverse;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L378">378</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC378">  UBYTE   InLength;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L379">379</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC379">  UBYTE   InPointer;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L380">380</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC380">  UBYTE   OutLength;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L381">381</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC381">  UBYTE   OutPointer;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L382">382</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC382">  UBYTE   InBuffer[IIC_DATA_LENGTH];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L383">383</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC383">  UBYTE   OutBuffer[IIC_DATA_LENGTH];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L384">384</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC384">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L385">385</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC385">IICPORT;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L386">386</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC386"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L387">387</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC387"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L388">388</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC388">IICPORT  IicPortDefault =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L389">389</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC389">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L390">390</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC390">  <span class="pl-c1">0</span>,                        <span class="pl-c">// Timer</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L391">391</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC391">  <span class="pl-c1">0</span>,                        <span class="pl-c">// Time</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L392">392</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC392">  <span class="pl-c1">0</span>,                        <span class="pl-c">// Initialised</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L393">393</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC393">  <span class="pl-c1">0</span>,                        <span class="pl-c">// ChangeMode</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L394">394</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC394">  <span class="pl-c1">0</span>,                        <span class="pl-c">// State</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L395">395</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC395">  -<span class="pl-c1">1</span>,                       <span class="pl-c">// OldState</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L396">396</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC396">  <span class="pl-c1">0</span>,                        <span class="pl-c">// SubState</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L397">397</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC397">  <span class="pl-c1">0</span>,                        <span class="pl-c">// Repeat</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L398">398</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC398">  <span class="pl-c1">0</span>,                        <span class="pl-c">// Cmd</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L399">399</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC399">  <span class="pl-c1">0</span>,                        <span class="pl-c">// Mode</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L400">400</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC400">  <span class="pl-c1">1</span>,                        <span class="pl-c">// Addr</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L401">401</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC401">  <span class="pl-c1">3</span>,                        <span class="pl-c">// Retries</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L402">402</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC402">  <span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-pds">&quot;</span></span>,                       <span class="pl-c">// Name</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L403">403</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC403">  <span class="pl-c1">0</span>,                        <span class="pl-c">// Reverse</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L404">404</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC404">  <span class="pl-c1">0</span>,                        <span class="pl-c">// InLength</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L405">405</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC405">  <span class="pl-c1">0</span>,                        <span class="pl-c">// InPointer</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L406">406</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC406">  <span class="pl-c1">0</span>,                        <span class="pl-c">// OutLength</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L407">407</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC407">  <span class="pl-c1">0</span>,                        <span class="pl-c">// OutPointer</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L408">408</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC408">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L409">409</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC409"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L410">410</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC410"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L411">411</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC411">#<span class="pl-k">ifdef</span> DEBUG_IIC_WRITE</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L412">412</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC412"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L413">413</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC413">#<span class="pl-k">define</span>   <span class="pl-en">IICBUFFERSIZE</span>    <span class="pl-c1">250</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L414">414</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC414"><span class="pl-k">static</span>    <span class="pl-k">char</span> IicBuffer[IICBUFFERSIZE];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L415">415</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC415"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L416">416</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC416">#<span class="pl-k">define</span>   <span class="pl-en">LOGPOOLSIZE</span>       <span class="pl-c1">100000</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L417">417</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC417">ULONG     LogPointer = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L418">418</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC418">ULONG     LogOutPointer  =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L419">419</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC419"><span class="pl-k">char</span>      LogPool[LOGPOOLSIZE];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L420">420</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC420"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L421">421</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC421"><span class="pl-k">void</span>      <span class="pl-en">IicWrite</span>(<span class="pl-k">char</span> *pString)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L422">422</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC422">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L423">423</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC423">  ULONG   Tmp;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L424">424</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC424"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L425">425</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC425">  <span class="pl-k">while</span> (*pString)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L426">426</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC426">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L427">427</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC427">    LogPool[LogPointer]  =  *pString;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L428">428</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC428"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L429">429</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC429">    Tmp  =  LogPointer;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L430">430</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC430">    Tmp++;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L431">431</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC431">    <span class="pl-k">if</span> (Tmp &gt;= LOGPOOLSIZE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L432">432</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC432">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L433">433</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC433">      Tmp  =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L434">434</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC434">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L435">435</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC435">    <span class="pl-k">if</span> (Tmp != LogOutPointer)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L436">436</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC436">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L437">437</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC437">      LogPointer  =  Tmp;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L438">438</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC438">      pString++;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L439">439</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC439"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L440">440</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC440">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L441">441</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC441">    <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L442">442</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC442">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L443">443</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC443">      pString++;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L444">444</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC444">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L445">445</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC445">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L446">446</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC446">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L447">447</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC447">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L448">448</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC448"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L449">449</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC449"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L450">450</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC450">UBYTE     IicConfigured[INPUTS];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L451">451</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC451">IICPORT   IicPort[INPUTS];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L452">452</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC452"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L453">453</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC453"><span class="pl-k">static</span>    IIC  IicDefault;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L454">454</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC454"><span class="pl-k">static</span>    IIC *pIic   =  &amp;IicDefault;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L455">455</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC455"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L456">456</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC456"><span class="pl-c">// FIQ Interface **************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L457">457</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC457"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L458">458</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC458">#<span class="pl-k">ifndef</span>   DISABLE_FIQ_IIC</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L459">459</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC459"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L460">460</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC460">#<span class="pl-k">ifndef</span>   PCASM</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L461">461</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC461">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/circ_buf.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L462">462</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC462">#<span class="pl-k">include</span>  <span class="pl-s"><span class="pl-pds">&lt;</span>linux/delay.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L463">463</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC463">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L464">464</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC464"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L465">465</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC465"><span class="pl-k">extern</span> <span class="pl-k">struct</span> IIC_control_t IicCtrl;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L466">466</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC466"><span class="pl-k">extern</span> <span class="pl-k">void</span> <span class="pl-en">iic_fiq_start_transfer</span>(<span class="pl-k">unsigned</span> <span class="pl-k">int</span> time, <span class="pl-k">bool</span> fiq_nirq);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L467">467</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC467"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L468">468</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC468">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L469">469</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC469"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L470">470</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC470"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L471">471</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC471"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">IicPortDisable</span>(UBYTE Port)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L472">472</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC472">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L473">473</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC473">#<span class="pl-k">ifndef</span>   DISABLE_FIQ_IIC</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L474">474</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC474"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L475">475</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC475">  IicCtrl.<span class="pl-smi">port_enabled</span> &amp;= ~(<span class="pl-c1">1</span> &lt;&lt; Port);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L476">476</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC476"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L477">477</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC477">  <span class="pl-k">if</span> (Port != DEBUG_UART)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L478">478</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC478">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L479">479</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC479">    <span class="pl-c1">PINHigh</span>(Port,IIC_PORT_BUFFER_CTRL);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L480">480</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC480">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L481">481</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC481">  <span class="pl-c1">PINInput</span>(Port,IIC_PORT_DATA);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L482">482</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC482"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L483">483</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC483">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L484">484</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC484">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L485">485</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC485"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L486">486</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC486"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L487">487</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC487"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">IicPortEnable</span>(UBYTE Port)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L488">488</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC488">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L489">489</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC489">#<span class="pl-k">ifndef</span>   DISABLE_FIQ_IIC</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L490">490</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC490"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L491">491</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC491">  <span class="pl-c1">SetGpio</span>(IicPortPin[Port][IIC_PORT_CLOCK].<span class="pl-smi">Pin</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L492">492</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC492"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L493">493</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC493">  <span class="pl-c1">PINLow</span>(Port,IIC_PORT_BUFFER_CTRL);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L494">494</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC494">  <span class="pl-c1">PINHigh</span>(Port,IIC_PORT_CLOCK);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L495">495</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC495">  <span class="pl-c1">PINHigh</span>(Port,IIC_PORT_DATA);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L496">496</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC496">  <span class="pl-c1">PINOutput</span>(Port,IIC_PORT_BUFFER_CTRL);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L497">497</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC497">  <span class="pl-c1">PINOutput</span>(Port,IIC_PORT_CLOCK);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L498">498</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC498">  <span class="pl-c1">PINOutput</span>(Port,IIC_PORT_DATA);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L499">499</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC499"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L500">500</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC500">  IicCtrl.<span class="pl-smi">data_package</span>[Port].<span class="pl-smi">clock_state</span> = <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L501">501</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC501"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L502">502</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC502">  IicCtrl.<span class="pl-smi">port_enabled</span> |=  (<span class="pl-c1">1</span> &lt;&lt; Port);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L503">503</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC503"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L504">504</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC504">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L505">505</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC505">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L506">506</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC506"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L507">507</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC507"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L508">508</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC508"><span class="pl-k">static</span> UBYTE <span class="pl-en">IicPortBusy</span>(UBYTE Port)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L509">509</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC509">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L510">510</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC510">  UBYTE   Result = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L511">511</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC511"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L512">512</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC512">#<span class="pl-k">ifndef</span>   DISABLE_FIQ_IIC</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L513">513</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC513"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L514">514</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC514">  <span class="pl-k">if</span> (IicCtrl.<span class="pl-smi">transfers_active</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L515">515</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC515">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L516">516</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC516">    Result  =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L517">517</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC517">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L518">518</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC518"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L519">519</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC519">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L520">520</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC520"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L521">521</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC521">  <span class="pl-k">return</span> (Result);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L522">522</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC522">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L523">523</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC523"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L524">524</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC524"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L525">525</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC525"><span class="pl-k">static</span> RESULT <span class="pl-en">IicPortSend</span>(UBYTE Port)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L526">526</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC526">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L527">527</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC527">  RESULT  Result = OK;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L528">528</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC528"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L529">529</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC529">#<span class="pl-k">ifndef</span>   DISABLE_FIQ_IIC</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L530">530</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC530">  DATA8   Tmp;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L531">531</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC531"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L532">532</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC532">  IicCtrl.<span class="pl-smi">data_package</span>[Port].<span class="pl-smi">addr</span>             =  IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">0</span>];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L533">533</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC533"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L534">534</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC534">#<span class="pl-k">ifdef</span> HIGHDEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L535">535</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC535">  <span class="pl-c1">snprintf</span>(IicBuffer,IICBUFFERSIZE,<span class="pl-s"><span class="pl-pds">&quot;</span>    <span class="pl-c1">%d</span> Send <span class="pl-c1">%02X</span>   <span class="pl-pds">&quot;</span></span>,Port,IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">0</span>]);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L536">536</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC536">  <span class="pl-c1">IicWrite</span>(IicBuffer);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L537">537</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC537">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L538">538</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC538">  <span class="pl-k">for</span> (Tmp = <span class="pl-c1">1</span>;Tmp &lt; IicPort[Port].<span class="pl-smi">OutLength</span>;Tmp++)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L539">539</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC539">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L540">540</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC540">#<span class="pl-k">ifdef</span> HIGHDEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L541">541</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC541">    <span class="pl-c1">snprintf</span>(IicBuffer,IICBUFFERSIZE,<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%02X</span> <span class="pl-pds">&quot;</span></span>,IicPort[Port].<span class="pl-smi">OutBuffer</span>[Tmp]);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L542">542</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC542">    <span class="pl-c1">IicWrite</span>(IicBuffer);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L543">543</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC543">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L544">544</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC544">    IicCtrl.<span class="pl-smi">data_package</span>[Port].<span class="pl-smi">data</span>[Tmp - <span class="pl-c1">1</span>]  =  IicPort[Port].<span class="pl-smi">OutBuffer</span>[Tmp];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L545">545</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC545">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L546">546</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC546">#<span class="pl-k">ifdef</span> HIGHDEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L547">547</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC547">  <span class="pl-c1">snprintf</span>(IicBuffer,IICBUFFERSIZE,<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-cce">\r\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L548">548</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC548">  <span class="pl-c1">IicWrite</span>(IicBuffer);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L549">549</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC549">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L550">550</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC550">  IicCtrl.<span class="pl-smi">data_package</span>[Port].<span class="pl-smi">write_length</span>     =  IicPort[Port].<span class="pl-smi">OutLength</span> - <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L551">551</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC551">  IicCtrl.<span class="pl-smi">data_package</span>[Port].<span class="pl-smi">read_length</span>      =  IicPort[Port].<span class="pl-smi">InLength</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L552">552</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC552">  IicCtrl.<span class="pl-smi">data_package</span>[Port].<span class="pl-smi">port</span>             =  Port;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L553">553</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC553"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L554">554</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC554">  IicCtrl.<span class="pl-smi">data_package</span>[Port].<span class="pl-smi">nacked</span>           =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L555">555</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC555">  IicCtrl.<span class="pl-smi">data_package</span>[Port].<span class="pl-smi">clock_state</span>      =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L556">556</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC556">  IicCtrl.<span class="pl-smi">data_package</span>[Port].<span class="pl-smi">transfer_state</span>   =  TRANSFER_START;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L557">557</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC557"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L558">558</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC558">  <span class="pl-c1">iic_fiq_start_transfer</span>(<span class="pl-c1">50</span>,<span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L559">559</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC559"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L560">560</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC560">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L561">561</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC561"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L562">562</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC562">  <span class="pl-k">return</span> (Result);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L563">563</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC563">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L564">564</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC564"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L565">565</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC565"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L566">566</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC566"><span class="pl-k">static</span> RESULT <span class="pl-en">IicPortReceive</span>(UBYTE Port,UBYTE *pTmpBuffer)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L567">567</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC567">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L568">568</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC568">  RESULT  Result = BUSY;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L569">569</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC569"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L570">570</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC570">#<span class="pl-k">ifndef</span>   DISABLE_FIQ_IIC</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L571">571</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC571">  DATA8   Tmp;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L572">572</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC572"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L573">573</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC573">  <span class="pl-k">if</span> (IicCtrl.<span class="pl-smi">data_package</span>[Port].<span class="pl-smi">transfer_state</span> == TRANSFER_IDLE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L574">574</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC574">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L575">575</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC575">    <span class="pl-c1">memset</span>((<span class="pl-k">void</span>*)pTmpBuffer,<span class="pl-c1">0</span>,IIC_DATA_LENGTH);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L576">576</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC576">#<span class="pl-k">ifdef</span> HIGHDEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L577">577</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC577">    <span class="pl-c1">snprintf</span>(IicBuffer,IICBUFFERSIZE,<span class="pl-s"><span class="pl-pds">&quot;</span>    <span class="pl-c1">%d</span> Receiving   <span class="pl-pds">&quot;</span></span>,Port);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L578">578</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC578">    <span class="pl-c1">IicWrite</span>(IicBuffer);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L579">579</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC579">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L580">580</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC580">    <span class="pl-k">for</span> (Tmp = <span class="pl-c1">0</span>;Tmp &lt; IicPort[Port].<span class="pl-smi">InLength</span>;Tmp++)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L581">581</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC581">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L582">582</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC582">#<span class="pl-k">ifdef</span> HIGHDEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L583">583</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC583">      <span class="pl-c1">snprintf</span>(IicBuffer,IICBUFFERSIZE,<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%02X</span> <span class="pl-pds">&quot;</span></span>,IicCtrl.<span class="pl-smi">data_package</span>[Port].<span class="pl-smi">data</span>[Tmp]);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L584">584</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC584">      <span class="pl-c1">IicWrite</span>(IicBuffer);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L585">585</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC585">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L586">586</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC586">      pTmpBuffer[Tmp]        =  IicCtrl.<span class="pl-smi">data_package</span>[Port].<span class="pl-smi">data</span>[Tmp];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L587">587</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC587">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L588">588</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC588">#<span class="pl-k">ifdef</span> HIGHDEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L589">589</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC589">      <span class="pl-c1">snprintf</span>(IicBuffer,IICBUFFERSIZE,<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-cce">\r\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L590">590</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC590">      <span class="pl-c1">IicWrite</span>(IicBuffer);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L591">591</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC591">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L592">592</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC592"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L593">593</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC593">    <span class="pl-k">if</span> (!(IicCtrl.<span class="pl-smi">data_package</span>[Port].<span class="pl-smi">nacked</span>))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L594">594</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC594">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L595">595</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC595">      Result  =  OK;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L596">596</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC596">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L597">597</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC597">    <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L598">598</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC598">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L599">599</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC599">      Result  =  FAIL;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L600">600</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC600">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L601">601</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC601">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L602">602</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC602"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L603">603</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC603">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L604">604</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC604"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L605">605</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC605">  <span class="pl-k">return</span> (Result);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L606">606</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC606">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L607">607</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC607"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L608">608</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC608"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L609">609</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC609"><span class="pl-c">// DEVICE1 ********************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L610">610</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC610"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L611">611</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC611"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L612">612</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC612"><span class="pl-k">enum</span>      IIC_STATE</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L613">613</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC613">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L614">614</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC614">  IIC_IDLE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L615">615</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC615">  IIC_INIT,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L616">616</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC616">  IIC_RESTART,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L617">617</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC617">  IIC_ENABLE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L618">618</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC618">  IIC_NXT_TEMP_START,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L619">619</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC619">  IIC_NXT_TEMP_WRITE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L620">620</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC620">  IIC_NXT_TEMP_READ,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L621">621</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC621">  IIC_MANUFACTURER_START,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L622">622</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC622">  IIC_MANUFACTURER_WRITE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L623">623</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC623">  IIC_MANUFACTURER_READ,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L624">624</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC624">  IIC_TYPE_START,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L625">625</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC625">  IIC_TYPE_WRITE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L626">626</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC626">  IIC_TYPE_READ,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L627">627</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC627">  IIC_SETUP_WAIT,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L628">628</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC628">  IIC_SETUP_START,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L629">629</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC629">  IIC_SETUP_WRITE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L630">630</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC630">  IIC_SETUP_READ,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L631">631</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC631">  IIC_WAITING,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L632">632</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC632">  IIC_WRITING,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L633">633</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC633">  IIC_READING,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L634">634</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC634">  IIC_REPEAT,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L635">635</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC635">  IIC_ERROR,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L636">636</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC636">  IIC_EXIT,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L637">637</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC637">  IIC_STATES</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L638">638</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC638">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L639">639</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC639"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L640">640</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC640"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L641">641</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC641"><span class="pl-k">char</span>      IicStateText[IIC_STATES][<span class="pl-c1">50</span>] =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L642">642</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC642">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L643">643</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC643">  <span class="pl-s"><span class="pl-pds">&quot;</span>IDLE<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L644">644</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC644">  <span class="pl-s"><span class="pl-pds">&quot;</span>INIT<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L645">645</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC645">  <span class="pl-s"><span class="pl-pds">&quot;</span>RESTART<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L646">646</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC646">  <span class="pl-s"><span class="pl-pds">&quot;</span>ENABLE<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L647">647</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC647">  <span class="pl-s"><span class="pl-pds">&quot;</span>IIC_NXT_TEMP_START<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L648">648</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC648">  <span class="pl-s"><span class="pl-pds">&quot;</span>IIC_NXT_TEMP_WRITE<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L649">649</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC649">  <span class="pl-s"><span class="pl-pds">&quot;</span>IIC_NXT_TEMP_READ<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L650">650</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC650">  <span class="pl-s"><span class="pl-pds">&quot;</span>MANUFACTURER_START<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L651">651</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC651">  <span class="pl-s"><span class="pl-pds">&quot;</span>MANUFACTURER_WRITE<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L652">652</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC652">  <span class="pl-s"><span class="pl-pds">&quot;</span>MANUFACTURER_READ<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L653">653</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC653">  <span class="pl-s"><span class="pl-pds">&quot;</span>TYPE_START<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L654">654</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC654">  <span class="pl-s"><span class="pl-pds">&quot;</span>TYPE_WRITE<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L655">655</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC655">  <span class="pl-s"><span class="pl-pds">&quot;</span>TYPE_READ<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L656">656</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC656">  <span class="pl-s"><span class="pl-pds">&quot;</span>SETUP_WAIT<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L657">657</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC657">  <span class="pl-s"><span class="pl-pds">&quot;</span>SETUP_START<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L658">658</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC658">  <span class="pl-s"><span class="pl-pds">&quot;</span>SETUP_WRITE<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L659">659</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC659">  <span class="pl-s"><span class="pl-pds">&quot;</span>SETUP_READ<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L660">660</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC660">  <span class="pl-s"><span class="pl-pds">&quot;</span>WAITING<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L661">661</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC661">  <span class="pl-s"><span class="pl-pds">&quot;</span>WRITING<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L662">662</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC662">  <span class="pl-s"><span class="pl-pds">&quot;</span>READING<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L663">663</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC663">  <span class="pl-s"><span class="pl-pds">&quot;</span>REPEAT<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L664">664</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC664">  <span class="pl-s"><span class="pl-pds">&quot;</span>ERROR<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L665">665</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC665">  <span class="pl-s"><span class="pl-pds">&quot;</span>EXIT<span class="pl-pds">&quot;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L666">666</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC666">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L667">667</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC667"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L668">668</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC668"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L669">669</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC669">DATA8     IicPortType[INPUTS];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L670">670</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC670">IICSTR    IicStrings[INPUTS];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L671">671</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC671"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L672">672</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC672"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L673">673</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC673">#<span class="pl-k">define</span>   <span class="pl-en">IIC_TIMER_RESOLUTION</span>            <span class="pl-c1">20</span> <span class="pl-c">// [100u]</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L674">674</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC674"><span class="pl-k">static</span>    <span class="pl-k">struct</span> hrtimer Device1Timer;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L675">675</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC675"><span class="pl-k">static</span>    <span class="pl-c1">ktime_t</span>        Device1Time;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L676">676</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC676"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L677">677</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC677"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L678">678</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC678"><span class="pl-k">static</span> <span class="pl-k">enum</span> hrtimer_restart <span class="pl-en">Device1TimerInterrupt1</span>(<span class="pl-k">struct</span> hrtimer *pTimer)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L679">679</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC679">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L680">680</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC680">  UBYTE   Port;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L681">681</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC681">  UBYTE   Tmp;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L682">682</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC682">  UBYTE   TmpBuffer[IIC_DATA_LENGTH];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L683">683</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC683"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L684">684</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC684">  <span class="pl-c1">hrtimer_forward_now</span>(pTimer,Device1Time);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L685">685</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC685"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L686">686</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC686">  <span class="pl-k">for</span> (Port = <span class="pl-c1">0</span>;Port &lt; NO_OF_IIC_PORTS;Port++)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L687">687</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC687">  { <span class="pl-c">// look at one port at a time</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L688">688</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC688"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L689">689</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC689">    <span class="pl-k">switch</span> (IicPort[Port].<span class="pl-smi">State</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L690">690</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC690">    { <span class="pl-c">// Main state machine</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L691">691</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC691"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L692">692</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC692">      <span class="pl-k">case</span> IIC_IDLE :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L693">693</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC693">      { <span class="pl-c">// Port inactive</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L694">694</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC694"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L695">695</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC695">        (*pIic).<span class="pl-smi">Status</span>[Port]        =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L696">696</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC696">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L697">697</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC697">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L698">698</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC698"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L699">699</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC699">      <span class="pl-k">case</span> IIC_INIT :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L700">700</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC700">      { <span class="pl-c">// Initialise port hardware</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L701">701</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC701"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L702">702</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC702">        <span class="pl-c1">memset</span>((<span class="pl-k">void</span>*)IicStrings[Port].<span class="pl-smi">Manufacturer</span>,<span class="pl-c1">0</span>,IIC_NAME_LENGTH + <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L703">703</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC703">        <span class="pl-c1">memset</span>((<span class="pl-k">void</span>*)IicStrings[Port].<span class="pl-smi">SensorType</span>,<span class="pl-c1">0</span>,IIC_NAME_LENGTH + <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L704">704</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC704">        IicPort[Port].<span class="pl-smi">State</span>         =  IIC_ENABLE;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L705">705</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC705">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L706">706</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC706">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L707">707</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC707"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L708">708</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC708">      <span class="pl-k">case</span> IIC_RESTART :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L709">709</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC709">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L710">710</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC710">        <span class="pl-c1">IicPortDisable</span>(Port);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L711">711</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC711">        IicPort[Port].<span class="pl-smi">State</span>         =  IIC_ENABLE;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L712">712</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC712">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L713">713</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC713">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L714">714</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC714"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L715">715</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC715">      <span class="pl-k">case</span> IIC_ENABLE :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L716">716</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC716">      { <span class="pl-c">// Initialise port variables</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L717">717</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC717"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L718">718</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC718">        <span class="pl-c1">IicPortEnable</span>(Port);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L719">719</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC719"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L720">720</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC720">        IicPort[Port]               =  IicPortDefault;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L721">721</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC721"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L722">722</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC722">        IicPort[Port].<span class="pl-smi">Timer</span>         =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L723">723</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC723"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L724">724</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC724">        IicPort[Port].<span class="pl-smi">State</span>         =  IIC_NXT_TEMP_START;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L725">725</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC725">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L726">726</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC726">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L727">727</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC727"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L728">728</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC728"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L729">729</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC729"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L730">730</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC730"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L731">731</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC731"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L732">732</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC732">      <span class="pl-k">case</span> IIC_NXT_TEMP_START :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L733">733</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC733">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L734">734</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC734">        <span class="pl-k">if</span> (++(IicPort[Port].<span class="pl-smi">Timer</span>) &gt;= (<span class="pl-c1">10</span> / IIC_TIMER_RESOLUTION))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L735">735</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC735">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L736">736</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC736">          IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">0</span>]  =  0x4C;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L737">737</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC737">          IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">1</span>]  =  0x01;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L738">738</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC738">          IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">2</span>]  =  0x60;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L739">739</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC739">          IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">3</span>]  =  0x00;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L740">740</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC740">          IicPort[Port].<span class="pl-smi">OutLength</span>     =  <span class="pl-c1">3</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L741">741</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC741">          IicPort[Port].<span class="pl-smi">InLength</span>      =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L742">742</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC742">          IicPort[Port].<span class="pl-smi">Repeat</span>        =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L743">743</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC743">          IicPort[Port].<span class="pl-smi">Time</span>          =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L744">744</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC744">          IicPort[Port].<span class="pl-smi">Timer</span>         =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L745">745</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC745">          IicPort[Port].<span class="pl-smi">State</span>         =  IIC_NXT_TEMP_WRITE;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L746">746</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC746">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L747">747</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC747">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L748">748</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC748">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L749">749</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC749"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L750">750</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC750">      <span class="pl-k">case</span> IIC_NXT_TEMP_WRITE :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L751">751</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC751">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L752">752</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC752">        <span class="pl-c1">IicPortSend</span>(Port);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L753">753</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC753">        IicPort[Port].<span class="pl-smi">Timer</span>       =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L754">754</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC754">        IicPort[Port].<span class="pl-smi">State</span>       =  IIC_NXT_TEMP_READ;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L755">755</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC755">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L756">756</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC756">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L757">757</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC757"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L758">758</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC758">      <span class="pl-k">case</span> IIC_NXT_TEMP_READ :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L759">759</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC759">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L760">760</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC760">        <span class="pl-k">if</span> (<span class="pl-c1">IicPortReceive</span>(Port,TmpBuffer) != BUSY)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L761">761</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC761">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L762">762</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC762">          <span class="pl-k">if</span> (TmpBuffer[<span class="pl-c1">0</span>] == 0x60)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L763">763</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC763">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L764">764</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC764">            <span class="pl-c1">memcpy</span>((<span class="pl-k">void</span>*)IicStrings[Port].<span class="pl-smi">Manufacturer</span>,(<span class="pl-k">void</span>*)<span class="pl-s"><span class="pl-pds">&quot;</span>LEGO<span class="pl-pds">&quot;</span></span>,IIC_NAME_LENGTH);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L765">765</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC765">            IicStrings[Port].<span class="pl-smi">Manufacturer</span>[IIC_NAME_LENGTH]  =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L766">766</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC766">            <span class="pl-c1">memcpy</span>((<span class="pl-k">void</span>*)IicStrings[Port].<span class="pl-smi">SensorType</span>,(<span class="pl-k">void</span>*)<span class="pl-s"><span class="pl-pds">&quot;</span>Temp.<span class="pl-pds">&quot;</span></span>,IIC_NAME_LENGTH);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L767">767</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC767">            IicStrings[Port].<span class="pl-smi">SensorType</span>[IIC_NAME_LENGTH]  =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L768">768</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC768"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L769">769</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC769">            (*pIic).<span class="pl-smi">Changed</span>[Port]       =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L770">770</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC770"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L771">771</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC771">            IicPort[Port].<span class="pl-smi">Initialised</span>   =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L772">772</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC772">            IicPort[Port].<span class="pl-smi">Timer</span>         =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L773">773</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC773">            IicPort[Port].<span class="pl-smi">State</span>         =  IIC_SETUP_WAIT;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L774">774</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC774">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L775">775</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC775">          <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L776">776</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC776">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L777">777</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC777">            IicPort[Port].<span class="pl-smi">Timer</span>       =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L778">778</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC778">            IicPort[Port].<span class="pl-smi">State</span>         =  IIC_MANUFACTURER_START;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L779">779</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC779">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L780">780</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC780">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L781">781</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC781">        <span class="pl-k">if</span> (++(IicPort[Port].<span class="pl-smi">Timer</span>) &gt;= (<span class="pl-c1">500</span> / IIC_TIMER_RESOLUTION))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L782">782</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC782">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L783">783</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC783">          IicPort[Port].<span class="pl-smi">Timer</span>       =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L784">784</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC784">          IicPort[Port].<span class="pl-smi">State</span>         =  IIC_MANUFACTURER_START;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L785">785</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC785">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L786">786</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC786">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L787">787</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC787">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L788">788</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC788"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L789">789</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC789">      <span class="pl-k">case</span> IIC_MANUFACTURER_START :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L790">790</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC790">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L791">791</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC791">        <span class="pl-k">if</span> (++(IicPort[Port].<span class="pl-smi">Timer</span>) &gt;= (<span class="pl-c1">10</span> / IIC_TIMER_RESOLUTION))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L792">792</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC792">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L793">793</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC793">          IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">0</span>]  =  IicPort[Port].<span class="pl-smi">Addr</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L794">794</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC794">          IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">1</span>]  =  0x08;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L795">795</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC795">          IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">2</span>]  =  0x00;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L796">796</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC796">          IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">3</span>]  =  0x00;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L797">797</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC797">          IicPort[Port].<span class="pl-smi">OutLength</span>     =  <span class="pl-c1">2</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L798">798</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC798">          IicPort[Port].<span class="pl-smi">InLength</span>      =  <span class="pl-c1">8</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L799">799</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC799">          IicPort[Port].<span class="pl-smi">Repeat</span>        =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L800">800</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC800">          IicPort[Port].<span class="pl-smi">Time</span>          =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L801">801</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC801">          IicPort[Port].<span class="pl-smi">Timer</span>         =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L802">802</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC802">          IicPort[Port].<span class="pl-smi">State</span>         =  IIC_MANUFACTURER_WRITE;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L803">803</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC803">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L804">804</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC804">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L805">805</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC805">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L806">806</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC806"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L807">807</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC807">      <span class="pl-k">case</span> IIC_MANUFACTURER_WRITE :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L808">808</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC808">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L809">809</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC809">        <span class="pl-c1">IicPortSend</span>(Port);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L810">810</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC810">        IicPort[Port].<span class="pl-smi">Timer</span>       =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L811">811</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC811">        IicPort[Port].<span class="pl-smi">State</span>       =  IIC_MANUFACTURER_READ;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L812">812</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC812">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L813">813</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC813">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L814">814</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC814"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L815">815</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC815">      <span class="pl-k">case</span> IIC_MANUFACTURER_READ :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L816">816</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC816">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L817">817</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC817">        <span class="pl-k">if</span> (<span class="pl-c1">IicPortReceive</span>(Port,TmpBuffer) != BUSY)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L818">818</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC818">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L819">819</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC819">          <span class="pl-c1">memcpy</span>((<span class="pl-k">void</span>*)IicStrings[Port].<span class="pl-smi">Manufacturer</span>,(<span class="pl-k">void</span>*)TmpBuffer,IIC_NAME_LENGTH);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L820">820</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC820">          IicStrings[Port].<span class="pl-smi">Manufacturer</span>[IIC_NAME_LENGTH]  =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L821">821</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC821"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L822">822</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC822">          <span class="pl-k">if</span> (TmpBuffer[<span class="pl-c1">0</span>] == 0x08)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L823">823</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC823">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L824">824</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC824">            <span class="pl-k">if</span> (IicPort[Port].<span class="pl-smi">Addr</span> &lt; 0x50)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L825">825</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC825">            {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L826">826</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC826">              IicPort[Port].<span class="pl-smi">Addr</span>++;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L827">827</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC827">              IicPort[Port].<span class="pl-smi">Timer</span>         =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L828">828</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC828">              IicPort[Port].<span class="pl-smi">State</span>         =  IIC_MANUFACTURER_START;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L829">829</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC829">            }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L830">830</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC830">            <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L831">831</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC831">            {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L832">832</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC832">              <span class="pl-k">if</span> (--IicPort[Port].<span class="pl-smi">Retries</span> &gt; <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L833">833</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC833">              {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L834">834</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC834">                IicPort[Port].<span class="pl-smi">Addr</span>          =  0x01;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L835">835</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC835">                IicPort[Port].<span class="pl-smi">Timer</span>         =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L836">836</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC836">                IicPort[Port].<span class="pl-smi">State</span>         =  IIC_MANUFACTURER_START;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L837">837</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC837">              }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L838">838</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC838">              <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L839">839</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC839">              {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L840">840</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC840">                IicPort[Port].<span class="pl-smi">Initialised</span>   =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L841">841</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC841">                IicPort[Port].<span class="pl-smi">State</span>         =  IIC_SETUP_START;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L842">842</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC842">              }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L843">843</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC843">            }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L844">844</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC844">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L845">845</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC845">          <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L846">846</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC846">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L847">847</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC847">            <span class="pl-k">if</span> (TmpBuffer[<span class="pl-c1">0</span>] == <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L848">848</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC848">            {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L849">849</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC849">              <span class="pl-c1">memcpy</span>((<span class="pl-k">void</span>*)IicStrings[Port].<span class="pl-smi">Manufacturer</span>,(<span class="pl-k">void</span>*)<span class="pl-s"><span class="pl-pds">&quot;</span>LEGO<span class="pl-pds">&quot;</span></span>,IIC_NAME_LENGTH);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L850">850</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC850">              IicStrings[Port].<span class="pl-smi">Manufacturer</span>[IIC_NAME_LENGTH]  =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L851">851</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC851">            }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L852">852</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC852">            IicPort[Port].<span class="pl-smi">Initialised</span>     =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L853">853</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC853">            IicPort[Port].<span class="pl-smi">State</span>           =  IIC_TYPE_START;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L854">854</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC854">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L855">855</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC855"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L856">856</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC856">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L857">857</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC857">        <span class="pl-k">if</span> (++(IicPort[Port].<span class="pl-smi">Timer</span>) &gt;= (<span class="pl-c1">500</span> / IIC_TIMER_RESOLUTION))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L858">858</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC858">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L859">859</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC859">          <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>IIC timeout<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L860">860</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC860">          IicPort[Port].<span class="pl-smi">Addr</span>        =  0x01;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L861">861</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC861">          (*pIic).<span class="pl-smi">Status</span>[Port]     &amp;= ~IIC_WRITE_REQUEST;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L862">862</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC862">          (*pIic).<span class="pl-smi">Status</span>[Port]     &amp;= ~IIC_DATA_READY;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L863">863</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC863">          IicPort[Port].<span class="pl-smi">State</span>       =  IIC_WAITING;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L864">864</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC864">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L865">865</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC865">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L866">866</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC866">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L867">867</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC867"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L868">868</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC868">      <span class="pl-k">case</span> IIC_TYPE_START :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L869">869</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC869">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L870">870</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC870">        IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">0</span>]  =  IicPort[Port].<span class="pl-smi">Addr</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L871">871</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC871">        IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">1</span>]  =  0x10;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L872">872</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC872">        IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">2</span>]  =  0x00;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L873">873</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC873">        IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">3</span>]  =  0x00;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L874">874</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC874">        IicPort[Port].<span class="pl-smi">OutLength</span>     =  <span class="pl-c1">2</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L875">875</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC875">        IicPort[Port].<span class="pl-smi">InLength</span>      =  <span class="pl-c1">8</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L876">876</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC876">        IicPort[Port].<span class="pl-smi">Repeat</span>        =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L877">877</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC877">        IicPort[Port].<span class="pl-smi">Time</span>          =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L878">878</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC878">        IicPort[Port].<span class="pl-smi">Timer</span>         =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L879">879</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC879">        IicPort[Port].<span class="pl-smi">State</span>         =  IIC_TYPE_WRITE;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L880">880</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC880">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L881">881</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC881">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L882">882</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC882"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L883">883</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC883">      <span class="pl-k">case</span> IIC_TYPE_WRITE :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L884">884</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC884">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L885">885</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC885">        <span class="pl-c1">IicPortSend</span>(Port);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L886">886</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC886">        IicPort[Port].<span class="pl-smi">Timer</span>       =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L887">887</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC887">        IicPort[Port].<span class="pl-smi">State</span>       =  IIC_TYPE_READ;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L888">888</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC888">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L889">889</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC889">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L890">890</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC890"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L891">891</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC891">      <span class="pl-k">case</span> IIC_TYPE_READ :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L892">892</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC892">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L893">893</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC893">        <span class="pl-k">if</span> (<span class="pl-c1">IicPortReceive</span>(Port,TmpBuffer) != BUSY)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L894">894</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC894">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L895">895</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC895">          <span class="pl-c1">memcpy</span>((<span class="pl-k">void</span>*)IicStrings[Port].<span class="pl-smi">SensorType</span>,(<span class="pl-k">void</span>*)TmpBuffer,IIC_NAME_LENGTH);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L896">896</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC896">          IicStrings[Port].<span class="pl-smi">SensorType</span>[IIC_NAME_LENGTH]  =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L897">897</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC897"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L898">898</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC898">          <span class="pl-k">if</span> (TmpBuffer[<span class="pl-c1">0</span>] == <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L899">899</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC899">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L900">900</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC900">            <span class="pl-c1">memcpy</span>((<span class="pl-k">void</span>*)IicStrings[Port].<span class="pl-smi">SensorType</span>,(<span class="pl-k">void</span>*)<span class="pl-s"><span class="pl-pds">&quot;</span>Store<span class="pl-pds">&quot;</span></span>,IIC_NAME_LENGTH);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L901">901</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC901">            IicStrings[Port].<span class="pl-smi">Manufacturer</span>[IIC_NAME_LENGTH]  =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L902">902</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC902">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L903">903</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC903"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L904">904</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC904">          (*pIic).<span class="pl-smi">Changed</span>[Port]       =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L905">905</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC905"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L906">906</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC906">          IicPort[Port].<span class="pl-smi">Initialised</span>   =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L907">907</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC907">          IicPort[Port].<span class="pl-smi">Timer</span>         =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L908">908</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC908">          IicPort[Port].<span class="pl-smi">State</span>         =  IIC_SETUP_WAIT;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L909">909</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC909">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L910">910</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC910">        <span class="pl-k">if</span> (++(IicPort[Port].<span class="pl-smi">Timer</span>) &gt;= (<span class="pl-c1">500</span> / IIC_TIMER_RESOLUTION))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L911">911</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC911">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L912">912</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC912">          (*pIic).<span class="pl-smi">Status</span>[Port]     &amp;= ~IIC_WRITE_REQUEST;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L913">913</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC913">          (*pIic).<span class="pl-smi">Status</span>[Port]     &amp;= ~IIC_DATA_READY;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L914">914</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC914">          IicPort[Port].<span class="pl-smi">State</span>       =  IIC_WAITING;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L915">915</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC915">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L916">916</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC916">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L917">917</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC917">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L918">918</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC918"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L919">919</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC919">      <span class="pl-k">case</span> IIC_SETUP_WAIT :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L920">920</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC920">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L921">921</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC921">        <span class="pl-k">if</span> (++(IicPort[Port].<span class="pl-smi">Timer</span>) &gt;= (<span class="pl-c1">10000</span> / IIC_TIMER_RESOLUTION))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L922">922</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC922">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L923">923</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC923">          IicPort[Port]               =  IicPortDefault;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L924">924</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC924">          IicPort[Port].<span class="pl-smi">Timer</span>         =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L925">925</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC925">          IicPort[Port].<span class="pl-smi">State</span>         =  IIC_NXT_TEMP_START;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L926">926</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC926">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L927">927</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC927">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L928">928</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC928">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L929">929</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC929"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L930">930</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC930">      <span class="pl-k">case</span> IIC_SETUP_START :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L931">931</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC931">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L932">932</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC932">#<span class="pl-k">ifndef</span> DISABLE_FAST_DATALOG_BUFFER</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L933">933</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC933">        (*pIic).<span class="pl-smi">Actual</span>[Port]        =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L934">934</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC934">        (*pIic).<span class="pl-smi">LogIn</span>[Port]         =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L935">935</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC935">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L936">936</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC936"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L937">937</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC937">        <span class="pl-k">if</span> (IicStrings[Port].<span class="pl-smi">SetupLng</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L938">938</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC938">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L939">939</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC939">          IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">0</span>]  =  (UBYTE)((IicStrings[Port].<span class="pl-smi">SetupString</span> &gt;&gt; <span class="pl-c1">24</span>) &amp; 0xFF);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L940">940</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC940">          IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">1</span>]  =  (UBYTE)((IicStrings[Port].<span class="pl-smi">SetupString</span> &gt;&gt; <span class="pl-c1">16</span>) &amp; 0xFF);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L941">941</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC941">          IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">2</span>]  =  (UBYTE)((IicStrings[Port].<span class="pl-smi">SetupString</span> &gt;&gt;  <span class="pl-c1">8</span>) &amp; 0xFF);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L942">942</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC942">          IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">3</span>]  =  (UBYTE)((IicStrings[Port].<span class="pl-smi">SetupString</span>) &amp; 0xFF);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L943">943</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC943">          IicPort[Port].<span class="pl-smi">OutLength</span>     =  IicStrings[Port].<span class="pl-smi">SetupLng</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L944">944</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC944">          IicPort[Port].<span class="pl-smi">InLength</span>      =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L945">945</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC945">          IicPort[Port].<span class="pl-smi">Repeat</span>        =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L946">946</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC946">          IicPort[Port].<span class="pl-smi">Time</span>          =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L947">947</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC947">          IicPort[Port].<span class="pl-smi">State</span>         =  IIC_SETUP_WRITE;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L948">948</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC948">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L949">949</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC949">        <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L950">950</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC950">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L951">951</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC951">          IicPort[Port].<span class="pl-smi">State</span>         =  IIC_SETUP_READ;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L952">952</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC952">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L953">953</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC953">        IicPort[Port].<span class="pl-smi">Timer</span>           =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L954">954</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC954">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L955">955</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC955">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L956">956</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC956"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L957">957</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC957">      <span class="pl-k">case</span> IIC_SETUP_WRITE :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L958">958</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC958">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L959">959</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC959">        <span class="pl-c1">IicPortSend</span>(Port);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L960">960</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC960">        IicPort[Port].<span class="pl-smi">Timer</span>       =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L961">961</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC961">        IicPort[Port].<span class="pl-smi">State</span>       =  IIC_SETUP_READ;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L962">962</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC962">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L963">963</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC963">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L964">964</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC964"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L965">965</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC965">      <span class="pl-k">case</span> IIC_SETUP_READ :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L966">966</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC966">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L967">967</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC967">        <span class="pl-k">if</span> (<span class="pl-c1">IicPortReceive</span>(Port,TmpBuffer) != BUSY)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L968">968</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC968">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L969">969</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC969">          IicPort[Port].<span class="pl-smi">State</span>           =  IIC_WAITING;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L970">970</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC970">          <span class="pl-k">if</span> (IicStrings[Port].<span class="pl-smi">PollLng</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L971">971</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC971">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L972">972</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC972">            IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">0</span>]  =  (UBYTE)((IicStrings[Port].<span class="pl-smi">PollString</span> &gt;&gt; <span class="pl-c1">24</span>) &amp; 0xFF);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L973">973</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC973">            IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">1</span>]  =  (UBYTE)((IicStrings[Port].<span class="pl-smi">PollString</span> &gt;&gt; <span class="pl-c1">16</span>) &amp; 0xFF);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L974">974</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC974">            IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">2</span>]  =  (UBYTE)((IicStrings[Port].<span class="pl-smi">PollString</span> &gt;&gt;  <span class="pl-c1">8</span>) &amp; 0xFF);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L975">975</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC975">            IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">3</span>]  =  (UBYTE)((IicStrings[Port].<span class="pl-smi">PollString</span>) &amp; 0xFF);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L976">976</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC976">            IicPort[Port].<span class="pl-smi">OutLength</span>     =  IicStrings[Port].<span class="pl-smi">PollLng</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L977">977</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC977">            <span class="pl-k">if</span> (IicStrings[Port].<span class="pl-smi">ReadLng</span> &lt; <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L978">978</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC978">            {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L979">979</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC979">              IicPort[Port].<span class="pl-smi">InLength</span>    =  <span class="pl-c1">0</span> - IicStrings[Port].<span class="pl-smi">ReadLng</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L980">980</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC980">              IicPort[Port].<span class="pl-smi">Reverse</span>     =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L981">981</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC981">            }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L982">982</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC982">            <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L983">983</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC983">            {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L984">984</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC984">              IicPort[Port].<span class="pl-smi">InLength</span>    =  IicStrings[Port].<span class="pl-smi">ReadLng</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L985">985</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC985">              IicPort[Port].<span class="pl-smi">Reverse</span>     =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L986">986</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC986">            }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L987">987</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC987">            IicPort[Port].<span class="pl-smi">Repeat</span>        =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L988">988</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC988">            IicPort[Port].<span class="pl-smi">Time</span>          =  IicStrings[Port].<span class="pl-smi">Time</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L989">989</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC989">            IicPort[Port].<span class="pl-smi">Timer</span>         =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L990">990</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC990">            IicPort[Port].<span class="pl-smi">State</span>         =  IIC_WRITING;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L991">991</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC991">            (*pIic).<span class="pl-smi">Status</span>[Port]        =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L992">992</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC992">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L993">993</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC993">          IicPort[Port].<span class="pl-smi">Initialised</span>     =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L994">994</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC994">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L995">995</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC995">        <span class="pl-k">if</span> (++(IicPort[Port].<span class="pl-smi">Timer</span>) &gt;= (<span class="pl-c1">500</span> / IIC_TIMER_RESOLUTION))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L996">996</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC996">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L997">997</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC997">          (*pIic).<span class="pl-smi">Status</span>[Port]     &amp;= ~IIC_WRITE_REQUEST;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L998">998</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC998">          (*pIic).<span class="pl-smi">Status</span>[Port]     &amp;= ~IIC_DATA_READY;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L999">999</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC999">          IicPort[Port].<span class="pl-smi">State</span>       =  IIC_WAITING;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1000">1000</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1000">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1001">1001</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1001">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1002">1002</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1002">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1003">1003</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1003"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1004">1004</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1004">      <span class="pl-k">case</span> IIC_WAITING :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1005">1005</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1005">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1006">1006</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1006">        <span class="pl-k">if</span> ((*pIic).<span class="pl-smi">Status</span>[Port] &amp; IIC_WRITE_REQUEST)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1007">1007</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1007">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1008">1008</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1008">          <span class="pl-k">if</span> (<span class="pl-c1">IicPortBusy</span>(Port) == <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1009">1009</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1009">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1010">1010</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1010">            IicPort[Port].<span class="pl-smi">Timer</span>       =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1011">1011</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1011">            IicPort[Port].<span class="pl-smi">State</span>       =  IIC_WRITING;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1012">1012</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1012">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1013">1013</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1013">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1014">1014</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1014">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1015">1015</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1015">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1016">1016</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1016"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1017">1017</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1017">      <span class="pl-k">case</span> IIC_WRITING :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1018">1018</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1018">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1019">1019</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1019">        <span class="pl-c1">IicPortSend</span>(Port);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1020">1020</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1020">        IicPort[Port].<span class="pl-smi">State</span>       =  IIC_READING;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1021">1021</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1021">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1022">1022</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1022">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1023">1023</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1023"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1024">1024</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1024">      <span class="pl-k">case</span> IIC_READING :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1025">1025</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1025">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1026">1026</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1026">        <span class="pl-k">if</span> (<span class="pl-c1">IicPortReceive</span>(Port,TmpBuffer) != BUSY)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1027">1027</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1027">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1028">1028</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1028"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1029">1029</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1029">#<span class="pl-k">ifndef</span> DISABLE_FAST_DATALOG_BUFFER</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1030">1030</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1030">          <span class="pl-k">if</span> (IicPort[Port].<span class="pl-smi">InLength</span> &gt; <span class="pl-c1">1</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1031">1031</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1031">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1032">1032</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1032">            <span class="pl-k">if</span> (IicPort[Port].<span class="pl-smi">Reverse</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1033">1033</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1033">            {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1034">1034</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1034">              <span class="pl-k">for</span> (Tmp = <span class="pl-c1">0</span>;Tmp &lt; IicPort[Port].<span class="pl-smi">InLength</span>;Tmp++)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1035">1035</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1035">              {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1036">1036</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1036">                IicPort[Port].<span class="pl-smi">InBuffer</span>[Tmp]                  =  TmpBuffer[Tmp];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1037">1037</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1037">                (*pIic).<span class="pl-smi">Raw</span>[Port][(*pIic).<span class="pl-smi">LogIn</span>[Port]][Tmp]  =  TmpBuffer[Tmp];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1038">1038</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1038">              }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1039">1039</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1039">            }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1040">1040</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1040">            <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1041">1041</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1041">            {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1042">1042</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1042">              <span class="pl-k">for</span> (Tmp = <span class="pl-c1">0</span>;Tmp &lt; IicPort[Port].<span class="pl-smi">InLength</span>;Tmp++)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1043">1043</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1043">              {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1044">1044</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1044">                IicPort[Port].<span class="pl-smi">InBuffer</span>[Tmp]       =  TmpBuffer[(IicPort[Port].<span class="pl-smi">InLength</span> - <span class="pl-c1">1</span>) - Tmp];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1045">1045</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1045">                (*pIic).<span class="pl-smi">Raw</span>[Port][(*pIic).<span class="pl-smi">LogIn</span>[Port]][Tmp]  =  TmpBuffer[(IicPort[Port].<span class="pl-smi">InLength</span> - <span class="pl-c1">1</span>) - Tmp];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1046">1046</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1046">              }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1047">1047</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1047">            }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1048">1048</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1048">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1049">1049</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1049">          <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1050">1050</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1050">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1051">1051</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1051">            IicPort[Port].<span class="pl-smi">InBuffer</span>[<span class="pl-c1">0</span>]                  =  TmpBuffer[<span class="pl-c1">0</span>];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1052">1052</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1052">            IicPort[Port].<span class="pl-smi">InBuffer</span>[<span class="pl-c1">1</span>]                  =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1053">1053</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1053">            (*pIic).<span class="pl-smi">Raw</span>[Port][(*pIic).<span class="pl-smi">LogIn</span>[Port]][<span class="pl-c1">0</span>]  =  TmpBuffer[<span class="pl-c1">0</span>];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1054">1054</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1054">            (*pIic).<span class="pl-smi">Raw</span>[Port][(*pIic).<span class="pl-smi">LogIn</span>[Port]][<span class="pl-c1">1</span>]  =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1055">1055</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1055">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1056">1056</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1056"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1057">1057</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1057">          (*pIic).<span class="pl-smi">Actual</span>[Port]  =  (*pIic).<span class="pl-smi">LogIn</span>[Port];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1058">1058</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1058">          (*pIic).<span class="pl-smi">Repeat</span>[Port][(*pIic).<span class="pl-smi">Actual</span>[Port]]  =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1059">1059</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1059"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1060">1060</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1060">          <span class="pl-k">if</span> (++((*pIic).<span class="pl-smi">LogIn</span>[Port]) &gt;= DEVICE_LOGBUF_SIZE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1061">1061</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1061">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1062">1062</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1062">            (*pIic).<span class="pl-smi">LogIn</span>[Port]      =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1063">1063</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1063">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1064">1064</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1064">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1065">1065</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1065">          <span class="pl-k">if</span> (IicPort[Port].<span class="pl-smi">InLength</span> &gt; <span class="pl-c1">1</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1066">1066</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1066">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1067">1067</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1067">            <span class="pl-k">if</span> (IicPort[Port].<span class="pl-smi">Reverse</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1068">1068</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1068">            {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1069">1069</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1069">              <span class="pl-k">for</span> (Tmp = <span class="pl-c1">0</span>;Tmp &lt; IicPort[Port].<span class="pl-smi">InLength</span>;Tmp++)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1070">1070</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1070">              {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1071">1071</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1071">                IicPort[Port].<span class="pl-smi">InBuffer</span>[Tmp]       =  TmpBuffer[Tmp];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1072">1072</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1072">                (*pIic).<span class="pl-smi">Raw</span>[Port][Tmp]            =  TmpBuffer[Tmp];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1073">1073</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1073">              }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1074">1074</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1074">            }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1075">1075</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1075">            <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1076">1076</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1076">            {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1077">1077</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1077">              <span class="pl-k">for</span> (Tmp = <span class="pl-c1">0</span>;Tmp &lt; IicPort[Port].<span class="pl-smi">InLength</span>;Tmp++)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1078">1078</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1078">              {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1079">1079</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1079">                IicPort[Port].<span class="pl-smi">InBuffer</span>[Tmp]       =  TmpBuffer[(IicPort[Port].<span class="pl-smi">InLength</span> - <span class="pl-c1">1</span>) - Tmp];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1080">1080</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1080">                (*pIic).<span class="pl-smi">Raw</span>[Port][Tmp]            =  TmpBuffer[(IicPort[Port].<span class="pl-smi">InLength</span> - <span class="pl-c1">1</span>) - Tmp];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1081">1081</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1081">              }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1082">1082</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1082">            }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1083">1083</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1083">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1084">1084</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1084">          <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1085">1085</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1085">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1086">1086</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1086">            IicPort[Port].<span class="pl-smi">InBuffer</span>[<span class="pl-c1">0</span>]                  =  TmpBuffer[<span class="pl-c1">0</span>];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1087">1087</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1087">            IicPort[Port].<span class="pl-smi">InBuffer</span>[<span class="pl-c1">1</span>]                  =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1088">1088</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1088">            (*pIic).<span class="pl-smi">Raw</span>[Port][<span class="pl-c1">0</span>]  =  TmpBuffer[<span class="pl-c1">0</span>];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1089">1089</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1089">            (*pIic).<span class="pl-smi">Raw</span>[Port][<span class="pl-c1">1</span>]  =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1090">1090</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1090">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1091">1091</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1091">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1092">1092</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1092"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1093">1093</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1093">          (*pIic).<span class="pl-smi">Status</span>[Port]     |=  IIC_DATA_READY;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1094">1094</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1094">          IicPort[Port].<span class="pl-smi">State</span>       =  IIC_REPEAT;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1095">1095</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1095"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1096">1096</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1096">          <span class="pl-k">if</span> (IicPort[Port].<span class="pl-smi">Repeat</span> != <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1097">1097</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1097">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1098">1098</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1098">            IicPort[Port].<span class="pl-smi">Repeat</span>--;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1099">1099</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1099">            <span class="pl-k">if</span> (IicPort[Port].<span class="pl-smi">Repeat</span> == <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1100">1100</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1100">            {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1101">1101</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1101">              IicPort[Port].<span class="pl-smi">State</span>       =  IIC_WAITING;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1102">1102</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1102">            }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1103">1103</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1103">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1104">1104</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1104">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1105">1105</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1105">        <span class="pl-k">if</span> (++(IicPort[Port].<span class="pl-smi">Timer</span>) &gt;= (<span class="pl-c1">5000</span> / IIC_TIMER_RESOLUTION))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1106">1106</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1106">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1107">1107</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1107">          (*pIic).<span class="pl-smi">Status</span>[Port]     &amp;= ~IIC_WRITE_REQUEST;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1108">1108</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1108">          (*pIic).<span class="pl-smi">Status</span>[Port]     &amp;= ~IIC_DATA_READY;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1109">1109</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1109">          IicPort[Port].<span class="pl-smi">State</span>       =  IIC_WAITING;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1110">1110</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1110">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1111">1111</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1111">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1112">1112</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1112">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1113">1113</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1113"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1114">1114</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1114">      <span class="pl-k">case</span> IIC_REPEAT :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1115">1115</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1115">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1116">1116</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1116">        <span class="pl-k">if</span> ((*pIic).<span class="pl-smi">Status</span>[Port] &amp; IIC_WRITE_REQUEST)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1117">1117</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1117">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1118">1118</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1118">          (*pIic).<span class="pl-smi">Status</span>[Port]      =  IIC_WRITE_REQUEST;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1119">1119</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1119">          IicPort[Port].<span class="pl-smi">State</span>       =  IIC_WAITING;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1120">1120</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1120">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1121">1121</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1121">        <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1122">1122</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1122">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1123">1123</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1123">          <span class="pl-k">if</span> (++(IicPort[Port].<span class="pl-smi">Timer</span>) &gt;= (UWORD)(IicPort[Port].<span class="pl-smi">Time</span> / (IIC_TIMER_RESOLUTION / <span class="pl-c1">10</span>)))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1124">1124</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1124">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1125">1125</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1125">            IicPort[Port].<span class="pl-smi">Timer</span>       =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1126">1126</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1126">            IicPort[Port].<span class="pl-smi">State</span>       =  IIC_WRITING;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1127">1127</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1127">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1128">1128</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1128">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1129">1129</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1129">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1130">1130</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1130">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1131">1131</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1131"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1132">1132</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1132">      <span class="pl-k">case</span> IIC_EXIT :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1133">1133</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1133">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1134">1134</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1134">        <span class="pl-c1">IicPortDisable</span>(Port);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1135">1135</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1135">        IicPort[Port]                           =  IicPortDefault;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1136">1136</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1136"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1137">1137</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1137">        (*pIic).<span class="pl-smi">Status</span>[Port]                    =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1138">1138</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1138"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1139">1139</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1139">        IicPort[Port].<span class="pl-smi">State</span>                     =  IIC_IDLE;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1140">1140</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1140">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1141">1141</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1141">      <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1142">1142</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1142"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1143">1143</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1143">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1144">1144</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1144"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1145">1145</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1145">#<span class="pl-k">ifndef</span> DISABLE_FAST_DATALOG_BUFFER</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1146">1146</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1146">    ((*pIic).<span class="pl-smi">Repeat</span>[Port][(*pIic).<span class="pl-smi">Actual</span>[Port]]) += (IIC_TIMER_RESOLUTION / <span class="pl-c1">10</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1147">1147</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1147">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1148">1148</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1148"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1149">1149</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1149">#<span class="pl-k">ifdef</span> HIGHDEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1150">1150</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1150">    <span class="pl-k">if</span> (IicPort[Port].<span class="pl-smi">OldState</span> != IicPort[Port].<span class="pl-smi">State</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1151">1151</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1151">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1152">1152</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1152">      IicPort[Port].<span class="pl-smi">OldState</span>    =  IicPort[Port].<span class="pl-smi">State</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1153">1153</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1153">      <span class="pl-k">if</span> (IicPort[Port].<span class="pl-smi">State</span>  !=  IIC_ENABLE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1154">1154</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1154">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1155">1155</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1155">        <span class="pl-c1">snprintf</span>(IicBuffer,IICBUFFERSIZE,<span class="pl-s"><span class="pl-pds">&quot;</span>    <span class="pl-c1">%d</span> <span class="pl-c1">%s</span><span class="pl-cce">\r\n</span><span class="pl-pds">&quot;</span></span>,Port,IicStateText[IicPort[Port].<span class="pl-smi">State</span>]);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1156">1156</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1156">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1157">1157</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1157">      <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1158">1158</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1158">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1159">1159</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1159">        <span class="pl-c1">snprintf</span>(IicBuffer,IICBUFFERSIZE,<span class="pl-s"><span class="pl-pds">&quot;</span>*** <span class="pl-c1">%d</span> <span class="pl-c1">%s</span> ***<span class="pl-cce">\r\n</span><span class="pl-pds">&quot;</span></span>,Port,IicStateText[IicPort[Port].<span class="pl-smi">State</span>]);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1160">1160</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1160">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1161">1161</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1161">      <span class="pl-c1">IicWrite</span>(IicBuffer);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1162">1162</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1162">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1163">1163</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1163">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1164">1164</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1164"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1165">1165</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1165">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1166">1166</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1166"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1167">1167</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1167"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1168">1168</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1168">  <span class="pl-k">return</span> (HRTIMER_RESTART);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1169">1169</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1169">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1170">1170</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1170"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1171">1171</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1171"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1172">1172</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1172"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">Device1Ioctl</span>(<span class="pl-k">struct</span> inode *pNode, <span class="pl-k">struct</span> file *File, <span class="pl-k">unsigned</span> <span class="pl-k">int</span> Request, <span class="pl-k">unsigned</span> <span class="pl-k">long</span> Pointer)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1173">1173</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1173">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1174">1174</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1174">  DEVCON  *pDevCon;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1175">1175</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1175">  IICSTR  *pIicStr;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1176">1176</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1176">  IICDAT  *pIicDat;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1177">1177</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1177">  DATA8   Port = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1178">1178</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1178"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1179">1179</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1179">  <span class="pl-k">switch</span> (Request)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1180">1180</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1180">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1181">1181</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1181"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1182">1182</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1182">    <span class="pl-k">case</span> IIC_SET_CONN :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1183">1183</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1183">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1184">1184</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1184">      pDevCon   =  (DEVCON*)Pointer;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1185">1185</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1185"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1186">1186</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1186">      <span class="pl-k">for</span> (Port = <span class="pl-c1">0</span>;Port &lt; INPUTS;Port++)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1187">1187</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1187">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1188">1188</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1188">        <span class="pl-k">if</span> ((*pDevCon).<span class="pl-smi">Connection</span>[Port] == CONN_NXT_IIC)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1189">1189</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1189">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1190">1190</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1190">          <span class="pl-k">if</span> (IicConfigured[Port] == <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1191">1191</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1191">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1192">1192</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1192">#<span class="pl-k">ifdef</span> DEBUG_TRACE_MODE_CHANGE</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1193">1193</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1193"><span class="pl-c">//            printk(&quot;d_iic  %d   Device1Ioctl: Changing to IIC\n&quot;,Port);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1194">1194</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1194">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1195">1195</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1195">            IicConfigured[Port]        =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1196">1196</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1196">            IicPortType[Port]          =  (*pDevCon).<span class="pl-smi">Type</span>[Port];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1197">1197</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1197">            IicPort[Port].<span class="pl-smi">State</span>        =  IIC_INIT;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1198">1198</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1198">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1199">1199</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1199">          <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1200">1200</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1200">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1201">1201</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1201">            <span class="pl-k">if</span> (IicPort[Port].<span class="pl-smi">Initialised</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1202">1202</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1202">            {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1203">1203</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1203">              <span class="pl-k">if</span> (IicPort[Port].<span class="pl-smi">Mode</span> != (*pDevCon).<span class="pl-smi">Mode</span>[Port])</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1204">1204</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1204">              {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1205">1205</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1205">#<span class="pl-k">ifdef</span> DEBUG_TRACE_MODE_CHANGE</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1206">1206</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1206"><span class="pl-c">//                printk(&quot;d_iic  %d   Device1Ioctl: Changing to    %c\n&quot;,Port,(*pDevCon).Mode[Port] + &#39;0&#39;);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1207">1207</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1207">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1208">1208</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1208">                IicPort[Port].<span class="pl-smi">Mode</span>         =  (*pDevCon).<span class="pl-smi">Mode</span>[Port];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1209">1209</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1209">                IicPort[Port].<span class="pl-smi">ChangeMode</span>   =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1210">1210</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1210">                (*pIic).<span class="pl-smi">Status</span>[Port]      &amp;= ~IIC_DATA_READY;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1211">1211</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1211">                IicPort[Port].<span class="pl-smi">State</span>        =  IIC_SETUP_START;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1212">1212</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1212">              }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1213">1213</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1213">            }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1214">1214</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1214">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1215">1215</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1215">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1216">1216</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1216">        <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1217">1217</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1217">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1218">1218</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1218">#<span class="pl-k">ifdef</span> DEBUG_TRACE_MODE_CHANGE</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1219">1219</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1219"><span class="pl-c">//          printk(&quot;d_iic  %d   Device1Ioctl: Changing to non IIC\n&quot;,Port);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1220">1220</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1220">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1221">1221</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1221">          (*pIic).<span class="pl-smi">Status</span>[Port] &amp;= ~IIC_DATA_READY;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1222">1222</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1222">          <span class="pl-k">if</span> (IicConfigured[Port])</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1223">1223</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1223">          {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1224">1224</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1224">            IicConfigured[Port]        =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1225">1225</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1225">            IicPort[Port].<span class="pl-smi">State</span>        =  IIC_EXIT;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1226">1226</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1226">          }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1227">1227</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1227">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1228">1228</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1228">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1229">1229</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1229"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1230">1230</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1230">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1231">1231</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1231">    <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1232">1232</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1232"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1233">1233</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1233">    <span class="pl-k">case</span> IIC_SET :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1234">1234</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1234">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1235">1235</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1235">      pIicStr                     = (IICSTR*)Pointer;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1236">1236</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1236"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1237">1237</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1237">      Port                        =  (*pIicStr).<span class="pl-smi">Port</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1238">1238</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1238"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1239">1239</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1239">      <span class="pl-c1">memcpy</span>((<span class="pl-k">void</span>*)&amp;IicStrings[Port],(<span class="pl-k">void</span>*)pIicStr,<span class="pl-k">sizeof</span>(IICSTR));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1240">1240</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1240">      IicPort[Port].<span class="pl-smi">State</span>         =  IIC_SETUP_START;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1241">1241</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1241"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1242">1242</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1242">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1243">1243</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1243">    <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1244">1244</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1244"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1245">1245</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1245">    <span class="pl-k">case</span> IIC_SETUP :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1246">1246</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1246">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1247">1247</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1247">      pIicDat                     = (IICDAT*)Pointer;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1248">1248</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1248"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1249">1249</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1249">      Port                        =  (*pIicDat).<span class="pl-smi">Port</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1250">1250</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1250">      (*pIicDat).<span class="pl-smi">Result</span>           =  BUSY;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1251">1251</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1251"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1252">1252</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1252">      <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>1<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1253">1253</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1253">      <span class="pl-k">if</span> (!((*pIic).<span class="pl-smi">Status</span>[Port] &amp; IIC_WRITE_REQUEST))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1254">1254</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1254">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1255">1255</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1255">        <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>2<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1256">1256</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1256">        IicPort[Port].<span class="pl-smi">Repeat</span>      =  (*pIicDat).<span class="pl-smi">Repeat</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1257">1257</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1257">        IicPort[Port].<span class="pl-smi">Time</span>        =  (*pIicDat).<span class="pl-smi">Time</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1258">1258</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1258">        IicPort[Port].<span class="pl-smi">OutLength</span>   =  (*pIicDat).<span class="pl-smi">WrLng</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1259">1259</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1259">        <span class="pl-k">if</span> ((*pIicDat).<span class="pl-smi">RdLng</span> &lt; <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1260">1260</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1260">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1261">1261</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1261">          IicPort[Port].<span class="pl-smi">InLength</span>    =  <span class="pl-c1">0</span> - (*pIicDat).<span class="pl-smi">RdLng</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1262">1262</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1262">          IicPort[Port].<span class="pl-smi">Reverse</span>     =  <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1263">1263</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1263">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1264">1264</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1264">        <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1265">1265</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1265">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1266">1266</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1266">          IicPort[Port].<span class="pl-smi">InLength</span>    =  (*pIicDat).<span class="pl-smi">RdLng</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1267">1267</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1267">          IicPort[Port].<span class="pl-smi">Reverse</span>     =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1268">1268</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1268">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1269">1269</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1269"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1270">1270</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1270">        <span class="pl-k">if</span> (IicPort[Port].<span class="pl-smi">OutLength</span> &gt; IIC_DATA_LENGTH)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1271">1271</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1271">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1272">1272</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1272">          IicPort[Port].<span class="pl-smi">OutLength</span> =   IIC_DATA_LENGTH;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1273">1273</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1273">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1274">1274</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1274">        <span class="pl-k">if</span> (IicPort[Port].<span class="pl-smi">InLength</span> &gt; IIC_DATA_LENGTH)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1275">1275</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1275">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1276">1276</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1276">          IicPort[Port].<span class="pl-smi">InLength</span>  =   IIC_DATA_LENGTH;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1277">1277</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1277">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1278">1278</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1278"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1279">1279</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1279">        <span class="pl-c1">memcpy</span>((<span class="pl-k">void</span>*)&amp;IicPort[Port].<span class="pl-smi">OutBuffer</span>[<span class="pl-c1">0</span>],(<span class="pl-k">void</span>*)&amp;(*pIicDat).<span class="pl-smi">WrData</span>[<span class="pl-c1">0</span>],IicPort[Port].<span class="pl-smi">OutLength</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1280">1280</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1280">        <span class="pl-c1">memset</span>((<span class="pl-k">void</span>*)&amp;IicPort[Port].<span class="pl-smi">InBuffer</span>[<span class="pl-c1">0</span>],<span class="pl-c1">0</span>,IIC_DATA_LENGTH);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1281">1281</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1281"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1282">1282</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1282">        (*pIic).<span class="pl-smi">Status</span>[Port]  =  IIC_WRITE_REQUEST;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1283">1283</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1283">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1284">1284</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1284"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1285">1285</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1285">      <span class="pl-k">if</span> (((*pIic).<span class="pl-smi">Status</span>[Port] &amp; IIC_DATA_READY))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1286">1286</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1286">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1287">1287</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1287">        <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>3<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1288">1288</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1288">        <span class="pl-c1">memcpy</span>((<span class="pl-k">void</span>*)&amp;(*pIicDat).<span class="pl-smi">RdData</span>[<span class="pl-c1">0</span>],(<span class="pl-k">void</span>*)&amp;IicPort[Port].<span class="pl-smi">InBuffer</span>[<span class="pl-c1">0</span>],IicPort[Port].<span class="pl-smi">InLength</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1289">1289</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1289"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1290">1290</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1290">        (*pIicDat).<span class="pl-smi">Result</span>         =  OK;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1291">1291</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1291">        (*pIic).<span class="pl-smi">Status</span>[Port]      =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1292">1292</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1292">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1293">1293</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1293">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1294">1294</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1294">    <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1295">1295</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1295"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1296">1296</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1296">    <span class="pl-k">case</span> IIC_READ_TYPE_INFO :</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1297">1297</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1297">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1298">1298</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1298">      pIicStr                     = (IICSTR*)Pointer;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1299">1299</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1299"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1300">1300</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1300">      Port                        =  (*pIicStr).<span class="pl-smi">Port</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1301">1301</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1301">      <span class="pl-c1">memcpy</span>((<span class="pl-k">void</span>*)((*pIicStr).<span class="pl-smi">Manufacturer</span>),(<span class="pl-k">void</span>*)IicStrings[Port].<span class="pl-smi">Manufacturer</span>,IIC_NAME_LENGTH + <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1302">1302</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1302">      <span class="pl-c1">memcpy</span>((<span class="pl-k">void</span>*)((*pIicStr).<span class="pl-smi">SensorType</span>),(<span class="pl-k">void</span>*)IicStrings[Port].<span class="pl-smi">SensorType</span>,IIC_NAME_LENGTH + <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1303">1303</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1303"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1304">1304</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1304">      (*pIic).<span class="pl-smi">Changed</span>[Port]       =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1305">1305</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1305"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1306">1306</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1306">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1307">1307</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1307">    <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1308">1308</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1308"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1309">1309</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1309">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1310">1310</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1310"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1311">1311</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1311">  <span class="pl-k">return</span> (<span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1312">1312</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1312">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1313">1313</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1313"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1314">1314</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1314"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1315">1315</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1315"><span class="pl-k">static</span> <span class="pl-c1">ssize_t</span> <span class="pl-en">Device1Write</span>(<span class="pl-k">struct</span> file *File,<span class="pl-k">const</span> <span class="pl-k">char</span> *Buffer,<span class="pl-c1">size_t</span> Count,<span class="pl-c1">loff_t</span> *Data)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1316">1316</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1316">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1317">1317</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1317">  <span class="pl-k">int</span>     Lng     = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1318">1318</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1318"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1319">1319</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1319">  Lng           =  Count;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1320">1320</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1320"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1321">1321</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1321">  <span class="pl-k">return</span> (Lng);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1322">1322</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1322">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1323">1323</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1323"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1324">1324</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1324"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1325">1325</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1325"><span class="pl-k">static</span> <span class="pl-c1">ssize_t</span> <span class="pl-en">Device1Read</span>(<span class="pl-k">struct</span> file *File,<span class="pl-k">char</span> *Buffer,<span class="pl-c1">size_t</span> Count,<span class="pl-c1">loff_t</span> *Offset)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1326">1326</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1326">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1327">1327</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1327">  <span class="pl-k">int</span>     Lng     = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1328">1328</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1328"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1329">1329</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1329">#<span class="pl-k">ifdef</span> DEBUG_IIC_WRITE</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1330">1330</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1330">  <span class="pl-k">if</span> (LogOutPointer != LogPointer)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1331">1331</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1331">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1332">1332</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1332">    <span class="pl-k">while</span> ((Count--) &amp;&amp; (LogOutPointer != LogPointer))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1333">1333</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1333">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1334">1334</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1334">      Buffer[Lng++]  =  LogPool[LogOutPointer];</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1335">1335</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1335">      Buffer[Lng]    =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1336">1336</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1336"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1337">1337</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1337">      LogOutPointer++;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1338">1338</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1338">      <span class="pl-k">if</span> (LogOutPointer &gt;= LOGPOOLSIZE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1339">1339</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1339">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1340">1340</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1340">        LogOutPointer  =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1341">1341</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1341">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1342">1342</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1342">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1343">1343</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1343">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1344">1344</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1344">  <span class="pl-k">if</span> (Lng == <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1345">1345</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1345">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1346">1346</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1346">    <span class="pl-c1">IicWrite</span>(IicBuffer);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1347">1347</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1347">    <span class="pl-c1">snprintf</span>(IicBuffer,IICBUFFERSIZE,<span class="pl-s"><span class="pl-pds">&quot;</span>-----------------------------------------------------------------<span class="pl-cce">\r\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1348">1348</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1348">    <span class="pl-c1">IicWrite</span>(IicBuffer);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1349">1349</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1349">    <span class="pl-c1">snprintf</span>(IicBuffer,IICBUFFERSIZE,<span class="pl-s"><span class="pl-pds">&quot;</span>    IIC DUMP<span class="pl-cce">\r\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1350">1350</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1350">    <span class="pl-c1">IicWrite</span>(IicBuffer);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1351">1351</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1351">    <span class="pl-c1">snprintf</span>(IicBuffer,IICBUFFERSIZE,<span class="pl-s"><span class="pl-pds">&quot;</span>-----------------------------------------------------------------<span class="pl-cce">\r\n</span><span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1352">1352</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1352">    <span class="pl-c1">IicWrite</span>(IicBuffer);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1353">1353</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1353">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1354">1354</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1354">#<span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1355">1355</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1355">  <span class="pl-k">int</span>     Tmp;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1356">1356</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1356">  <span class="pl-k">int</span>     Port;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1357">1357</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1357"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1358">1358</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1358">  Port   =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1359">1359</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1359">  Tmp    =  <span class="pl-c1">5</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1360">1360</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1360">  <span class="pl-k">while</span> ((Count &gt; Tmp) &amp;&amp; (Port &lt; INPUTS))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1361">1361</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1361">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1362">1362</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1362">    <span class="pl-k">if</span> (Port != (INPUTS - <span class="pl-c1">1</span>))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1363">1363</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1363">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1364">1364</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1364">      Tmp    =  <span class="pl-c1">snprintf</span>(&amp;Buffer[Lng],<span class="pl-c1">4</span>,<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%2u</span> <span class="pl-pds">&quot;</span></span>,(UWORD)IicPort[Port].<span class="pl-smi">State</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1365">1365</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1365">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1366">1366</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1366">    <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1367">1367</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1367">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1368">1368</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1368">      Tmp    =  <span class="pl-c1">snprintf</span>(&amp;Buffer[Lng],<span class="pl-c1">5</span>,<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%2u</span><span class="pl-cce">\r</span><span class="pl-pds">&quot;</span></span>,(UWORD)IicPort[Port].<span class="pl-smi">State</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1369">1369</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1369">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1370">1370</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1370">    Lng   +=  Tmp;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1371">1371</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1371">    Count -=  Tmp;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1372">1372</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1372">    Port++;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1373">1373</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1373">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1374">1374</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1374">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1375">1375</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1375"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1376">1376</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1376">  <span class="pl-k">return</span> (Lng);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1377">1377</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1377">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1378">1378</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1378"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1379">1379</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1379"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1380">1380</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1380">#<span class="pl-k">define</span>     <span class="pl-en">SHM_LENGTH</span>    (<span class="pl-k">sizeof</span>(IicDefault))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1381">1381</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1381">#<span class="pl-k">define</span>     <span class="pl-en">NPAGES</span>        ((SHM_LENGTH + PAGE_SIZE - <span class="pl-c1">1</span>) / PAGE_SIZE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1382">1382</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1382"><span class="pl-k">static</span> <span class="pl-k">void</span> *kmalloc_ptr;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1383">1383</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1383"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1384">1384</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1384"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">Device1Mmap</span>(<span class="pl-k">struct</span> file *filp, <span class="pl-k">struct</span> vm_area_struct *vma)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1385">1385</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1385">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1386">1386</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1386">   <span class="pl-k">int</span> ret;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1387">1387</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1387"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1388">1388</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1388">   ret = <span class="pl-c1">remap_pfn_range</span>(vma,vma-&gt;vm_start,<span class="pl-c1">virt_to_phys</span>((<span class="pl-k">void</span>*)((<span class="pl-k">unsigned</span> <span class="pl-k">long</span>)pIic)) &gt;&gt; PAGE_SHIFT,vma-&gt;vm_end-vma-&gt;vm_start,PAGE_SHARED);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1389">1389</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1389"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1390">1390</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1390">   <span class="pl-k">if</span> (ret != <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1391">1391</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1391">   {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1392">1392</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1392">     ret  =  -EAGAIN;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1393">1393</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1393">   }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1394">1394</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1394"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1395">1395</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1395">   <span class="pl-k">return</span> (ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1396">1396</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1396">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1397">1397</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1397"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1398">1398</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1398"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1399">1399</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1399"><span class="pl-k">static</span>    <span class="pl-k">const</span> <span class="pl-k">struct</span> file_operations Device1Entries =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1400">1400</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1400">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1401">1401</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1401">  .<span class="pl-smi">owner</span>        = THIS_MODULE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1402">1402</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1402">  .<span class="pl-smi">read</span>         = Device1Read,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1403">1403</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1403">  .<span class="pl-smi">write</span>        = Device1Write,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1404">1404</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1404">  .<span class="pl-smi">mmap</span>         = Device1Mmap,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1405">1405</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1405">  .<span class="pl-smi">ioctl</span>        = Device1Ioctl,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1406">1406</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1406">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1407">1407</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1407"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1408">1408</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1408"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1409">1409</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1409"><span class="pl-k">static</span>    <span class="pl-k">struct</span> miscdevice Device1 =</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1410">1410</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1410">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1411">1411</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1411">  MISC_DYNAMIC_MINOR,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1412">1412</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1412">  DEVICE1_NAME,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1413">1413</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1413">  &amp;Device1Entries</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1414">1414</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1414">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1415">1415</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1415"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1416">1416</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1416"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1417">1417</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1417"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">Device1Init</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1418">1418</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1418">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1419">1419</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1419">  <span class="pl-k">int</span>     Result = -<span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1420">1420</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1420">  UWORD   *pTmp;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1421">1421</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1421">  <span class="pl-k">int</span>     i;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1422">1422</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1422">#<span class="pl-k">ifndef</span>   DISABLE_FIQ_IIC</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1423">1423</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1423">  UBYTE   Port;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1424">1424</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1424">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1425">1425</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1425"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1426">1426</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1426">  Result  =  <span class="pl-c1">misc_register</span>(&amp;Device1);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1427">1427</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1427">  <span class="pl-k">if</span> (Result)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1428">1428</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1428">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1429">1429</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1429">    <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  <span class="pl-c1">%s</span> device register failed<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,DEVICE1_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1430">1430</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1430">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1431">1431</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1431">  <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1432">1432</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1432">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1433">1433</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1433">    <span class="pl-c">// allocate kernel shared memory for analog values (pAnalog)</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1434">1434</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1434">    <span class="pl-k">if</span> ((kmalloc_ptr = <span class="pl-c1">kmalloc</span>((NPAGES + <span class="pl-c1">2</span>) * PAGE_SIZE, GFP_KERNEL)) != <span class="pl-c1">NULL</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1435">1435</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1435">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1436">1436</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1436">      pTmp = (UWORD*)((((<span class="pl-k">unsigned</span> <span class="pl-k">long</span>)kmalloc_ptr) + PAGE_SIZE - <span class="pl-c1">1</span>) &amp; PAGE_MASK);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1437">1437</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1437">      <span class="pl-k">for</span> (i = <span class="pl-c1">0</span>; i &lt; NPAGES * PAGE_SIZE; i += PAGE_SIZE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1438">1438</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1438">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1439">1439</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1439">        <span class="pl-c1">SetPageReserved</span>(<span class="pl-c1">virt_to_page</span>(((<span class="pl-k">unsigned</span> <span class="pl-k">long</span>)pTmp) + i));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1440">1440</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1440">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1441">1441</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1441">      pIic         =  (IIC*)pTmp;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1442">1442</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1442">      <span class="pl-c1">memset</span>(pIic,<span class="pl-c1">0</span>,<span class="pl-k">sizeof</span>(IIC));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1443">1443</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1443"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1444">1444</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1444">#<span class="pl-k">ifndef</span>   DISABLE_FIQ_IIC</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1445">1445</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1445">      IicCtrl.<span class="pl-smi">port_enabled</span>  = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1446">1446</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1446"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1447">1447</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1447">      <span class="pl-k">for</span> (Port = <span class="pl-c1">0</span>;Port &lt; INPUTS;Port++)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1448">1448</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1448">      {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1449">1449</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1449">        IicPort[Port]                               =  IicPortDefault;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1450">1450</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1450">        IicConfigured[Port]                         =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1451">1451</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1451">        IicCtrl.<span class="pl-smi">data_package</span>[Port].<span class="pl-smi">transfer_state</span>   =  TRANSFER_IDLE;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1452">1452</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1452">        IicStrings[Port].<span class="pl-smi">Manufacturer</span>[<span class="pl-c1">0</span>]            =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1453">1453</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1453">        IicStrings[Port].<span class="pl-smi">SensorType</span>[<span class="pl-c1">0</span>]              =  <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1454">1454</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1454">        <span class="pl-k">if</span> (Port == DEBUG_UART)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1455">1455</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1455">        {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1456">1456</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1456">          <span class="pl-c1">PINLow</span>(Port,IIC_PORT_BUFFER_CTRL);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1457">1457</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1457">          <span class="pl-c1">PINOutput</span>(Port,IIC_PORT_BUFFER_CTRL);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1458">1458</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1458">        }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1459">1459</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1459">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1460">1460</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1460">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1461">1461</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1461"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1462">1462</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1462">      Device1Time  =  <span class="pl-c1">ktime_set</span>(<span class="pl-c1">0</span>,IIC_TIMER_RESOLUTION * <span class="pl-c1">100000</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1463">1463</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1463">      <span class="pl-c1">hrtimer_init</span>(&amp;Device1Timer,CLOCK_MONOTONIC,HRTIMER_MODE_REL);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1464">1464</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1464">      Device1Timer.<span class="pl-smi">function</span>  =  Device1TimerInterrupt1;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1465">1465</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1465">      <span class="pl-c1">hrtimer_start</span>(&amp;Device1Timer,Device1Time,HRTIMER_MODE_REL);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1466">1466</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1466"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1467">1467</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1467">#<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1468">1468</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1468">      <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  <span class="pl-c1">%s</span> device register succes<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,DEVICE1_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1469">1469</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1469">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1470">1470</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1470">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1471">1471</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1471">    <span class="pl-k">else</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1472">1472</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1472">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1473">1473</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1473">      <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  <span class="pl-c1">%s</span> kmalloc failed !!<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,DEVICE1_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1474">1474</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1474">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1475">1475</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1475">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1476">1476</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1476"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1477">1477</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1477">  <span class="pl-k">return</span> (Result);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1478">1478</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1478">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1479">1479</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1479"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1480">1480</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1480"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1481">1481</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1481"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">Device1Exit</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1482">1482</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1482">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1483">1483</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1483">  IIC     *pTmp;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1484">1484</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1484">  <span class="pl-k">int</span>     i;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1485">1485</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1485"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1486">1486</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1486">  <span class="pl-c1">hrtimer_cancel</span>(&amp;Device1Timer);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1487">1487</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1487"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1488">1488</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1488">  pTmp      =  pIic;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1489">1489</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1489">  pIic      =  &amp;IicDefault;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1490">1490</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1490"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1491">1491</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1491">  <span class="pl-c">// free shared memory</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1492">1492</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1492">  <span class="pl-k">for</span> (i = <span class="pl-c1">0</span>; i &lt; NPAGES * PAGE_SIZE; i+= PAGE_SIZE)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1493">1493</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1493">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1494">1494</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1494">    <span class="pl-c1">ClearPageReserved</span>(<span class="pl-c1">virt_to_page</span>(((<span class="pl-k">unsigned</span> <span class="pl-k">long</span>)pTmp) + i));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1495">1495</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1495">#<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1496">1496</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1496">    <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  <span class="pl-c1">%s</span> memory page <span class="pl-c1">%d</span> unmapped<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,DEVICE1_NAME,i);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1497">1497</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1497">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1498">1498</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1498">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1499">1499</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1499">  <span class="pl-c1">kfree</span>(kmalloc_ptr);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1500">1500</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1500"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1501">1501</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1501">  <span class="pl-c1">misc_deregister</span>(&amp;Device1);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1502">1502</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1502">#<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1503">1503</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1503">  <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>  <span class="pl-c1">%s</span> device unregistered<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,DEVICE1_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1504">1504</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1504">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1505">1505</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1505">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1506">1506</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1506"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1507">1507</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1507"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1508">1508</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1508"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1509">1509</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1509"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1510">1510</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1510"><span class="pl-c">// MODULE *********************************************************************</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1511">1511</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1511"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1512">1512</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1512"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1513">1513</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1513">#<span class="pl-k">ifndef</span> PCASM</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1514">1514</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1514"><span class="pl-en">module_param</span> (HwId, charp, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1515">1515</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1515">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1516">1516</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1516"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1517">1517</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1517"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">ModuleInit</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1518">1518</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1518">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1519">1519</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1519">  Hw  =  HWID;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1520">1520</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1520"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1521">1521</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1521">  <span class="pl-k">if</span> (Hw &lt; PLATFORM_START)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1522">1522</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1522">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1523">1523</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1523">    Hw  =  PLATFORM_START;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1524">1524</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1524">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1525">1525</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1525">  <span class="pl-k">if</span> (Hw &gt; PLATFORM_END)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1526">1526</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1526">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1527">1527</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1527">    Hw  =  PLATFORM_END;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1528">1528</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1528">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1529">1529</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1529"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1530">1530</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1530">#<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1531">1531</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1531">  <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span> init started<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,MODULE_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1532">1532</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1532">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1533">1533</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1533">  <span class="pl-k">if</span> (<span class="pl-c1">request_mem_region</span>(DA8XX_GPIO_BASE,0xD8,MODULE_NAME) &gt;= <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1534">1534</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1534">  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1535">1535</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1535">    GpioBase  =  (<span class="pl-k">void</span>*)<span class="pl-c1">ioremap</span>(DA8XX_GPIO_BASE,0xD8);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1536">1536</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1536">    <span class="pl-k">if</span> (GpioBase != <span class="pl-c1">NULL</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1537">1537</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1537">    {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1538">1538</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1538">#<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1539">1539</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1539">      <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span> gpio address mapped<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,MODULE_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1540">1540</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1540">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1541">1541</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1541"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1542">1542</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1542">      <span class="pl-c1">InitGpio</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1543">1543</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1543"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1544">1544</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1544">      <span class="pl-c1">Device1Init</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1545">1545</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1545">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1546">1546</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1546">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1547">1547</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1547"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1548">1548</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1548">  <span class="pl-k">return</span> (<span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1549">1549</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1549">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1550">1550</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1550"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1551">1551</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1551"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1552">1552</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1552"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">ModuleExit</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1553">1553</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1553">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1554">1554</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1554">#<span class="pl-k">ifdef</span> DEBUG</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1555">1555</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1555">  <span class="pl-c1">printk</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span> exit started<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,MODULE_NAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1556">1556</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1556">#<span class="pl-k">endif</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1557">1557</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1557"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1558">1558</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1558">  <span class="pl-c1">Device1Exit</span>();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1559">1559</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1559"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1560">1560</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1560">  <span class="pl-c1">iounmap</span>(GpioBase);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1561">1561</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1561">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1562">1562</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1562"></td>
          </tr>
    </table>
  </div>
</div>


        </div>

      </div><!-- /.repo-container -->
      <div class="modal-backdrop"></div>
    </div><!-- /.container -->
  </div><!-- /.site -->


    </div><!-- /.wrapper -->

      <div class="container">
  <div class="site-footer" role="contentinfo">
    <ul class="site-footer-links right">
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage">
      <span class="mega-octicon octicon-mark-github" title="GitHub"></span>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2015 <span title="0.23272s from github-fe141-cp1-prd.iad.github.net">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact</a></li>
    </ul>
  </div>
</div>


    <div class="fullscreen-overlay js-fullscreen-overlay" id="fullscreen_overlay">
  <div class="fullscreen-container js-suggester-container">
    <div class="textarea-wrap">
      <textarea name="fullscreen-contents" id="fullscreen-contents" class="fullscreen-contents js-fullscreen-contents" placeholder=""></textarea>
      <div class="suggester-container">
        <div class="suggester fullscreen-suggester js-suggester js-navigation-container"></div>
      </div>
    </div>
  </div>
  <div class="fullscreen-sidebar">
    <a href="#" class="exit-fullscreen js-exit-fullscreen tooltipped tooltipped-w" aria-label="Exit Zen Mode">
      <span class="mega-octicon octicon-screen-normal"></span>
    </a>
    <a href="#" class="theme-switcher js-theme-switcher tooltipped tooltipped-w"
      aria-label="Switch themes">
      <span class="octicon octicon-color-mode"></span>
    </a>
  </div>
</div>



    

    <div id="ajax-error-message" class="flash flash-error">
      <span class="octicon octicon-alert"></span>
      <a href="#" class="octicon octicon-x flash-close js-ajax-error-dismiss" aria-label="Dismiss error"></a>
      Something went wrong with that request. Please try again.
    </div>


      <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-447ce66a36506ebddc8e84b4e32a77f6062f3d3482e77dd21a77a01f0643ad98.js"></script>
      <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github/index-83be60956d0d00076a726f0864b49916aae8e7bc6ee140798791be0b6644d661.js"></script>
      
      
  </body>
</html>

