


<!DOCTYPE html>
<html lang="en" class="">
  <head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# object: http://ogp.me/ns/object# article: http://ogp.me/ns/article# profile: http://ogp.me/ns/profile#">
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    
    
    <title>ev3sources/extra/linux-03.20.00.13/drivers/video/st7586fb.c at 7357369b6ebae4ee62001f3964f0f5fd0cce3c32 · mindboards/ev3sources · GitHub</title>
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-144.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144.png">
    <meta property="fb:app_id" content="1401488693436528">

      <meta content="@github" name="twitter:site" /><meta content="summary" name="twitter:card" /><meta content="mindboards/ev3sources" name="twitter:title" /><meta content="LEGO MINDSTORMS EV3 source code. Contribute to ev3sources development by creating an account on GitHub." name="twitter:description" /><meta content="https://avatars3.githubusercontent.com/u/2578456?v=3&amp;s=400" name="twitter:image:src" />
      <meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="https://avatars3.githubusercontent.com/u/2578456?v=3&amp;s=400" property="og:image" /><meta content="mindboards/ev3sources" property="og:title" /><meta content="https://github.com/mindboards/ev3sources" property="og:url" /><meta content="LEGO MINDSTORMS EV3 source code. Contribute to ev3sources development by creating an account on GitHub." property="og:description" />
      <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">
    <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">
    <link rel="assets" href="https://assets-cdn.github.com/">
    
    <meta name="pjax-timeout" content="1000">
    

    <meta name="msapplication-TileImage" content="/windows-tile.png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="selected-link" value="repo_source" data-pjax-transient>
      <meta name="google-analytics" content="UA-3769691-2">

    <meta content="collector.githubapp.com" name="octolytics-host" /><meta content="collector-cdn.github.com" name="octolytics-script-host" /><meta content="github" name="octolytics-app-id" /><meta content="70C64D49:7BA5:6E3CDCD:556C27D8" name="octolytics-dimension-request_id" />
    
    <meta content="Rails, view, blob#blame" name="analytics-event" />
    <meta class="js-ga-set" name="dimension1" content="Logged Out">
    <meta class="js-ga-set" name="dimension2" content="Header v3">
    <meta name="is-dotcom" content="true">
      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

    
    <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">


    <meta content="authenticity_token" name="csrf-param" />
<meta content="y4sCIRqoujHOV0OLgxP5oaRYpIVZ3xinO1TI0vvP/FPxKNFRvp5viRuXNUpVuPRolgmeY1o9ln2lha06roliUg==" name="csrf-token" />

    <link href="https://assets-cdn.github.com/assets/github/index-7e77e66f8436e66d6a9791d7a09cec15828e9e04a0ad97cf73e83223f8b9cb3a.css" media="all" rel="stylesheet" />
    <link href="https://assets-cdn.github.com/assets/github2/index-5df271cf586eee5e48a88e30cdb6b5c32413ce1d7337835a905fc8c16294237e.css" media="all" rel="stylesheet" />
    
    


    <meta http-equiv="x-pjax-version" content="840467a6cd0c672c678f4fd42f529999">

            <meta content="noindex, nofollow" name="robots" />

  <meta name="description" content="LEGO MINDSTORMS EV3 source code. Contribute to ev3sources development by creating an account on GitHub.">
  <meta name="go-import" content="github.com/mindboards/ev3sources git https://github.com/mindboards/ev3sources.git">

  <meta content="2578456" name="octolytics-dimension-user_id" /><meta content="mindboards" name="octolytics-dimension-user_login" /><meta content="11771262" name="octolytics-dimension-repository_id" /><meta content="mindboards/ev3sources" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="11771262" name="octolytics-dimension-repository_network_root_id" /><meta content="mindboards/ev3sources" name="octolytics-dimension-repository_network_root_nwo" />
  <link href="https://github.com/mindboards/ev3sources/commits/7357369b6ebae4ee62001f3964f0f5fd0cce3c32.atom" rel="alternate" title="Recent Commits to ev3sources:7357369b6ebae4ee62001f3964f0f5fd0cce3c32" type="application/atom+xml">

  </head>


  <body class="logged_out  env-production  vis-public">
    <a href="#start-of-content" tabindex="1" class="accessibility-aid js-skip-to-content">Skip to content</a>
    <div class="wrapper">
      
      
      


        
        <div class="header header-logged-out" role="banner">
  <div class="container clearfix">

    <a class="header-logo-wordmark" href="https://github.com/" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
      <span class="mega-octicon octicon-logo-github"></span>
    </a>

    <div class="header-actions" role="navigation">
        <a class="btn btn-primary" href="/join" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
      <a class="btn" href="/login?return_to=%2Fmindboards%2Fev3sources%2Fblame%2F7357369b6ebae4ee62001f3964f0f5fd0cce3c32%2Fextra%2Flinux-03.20.00.13%2Fdrivers%2Fvideo%2Fst7586fb.c" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
    </div>

    <div class="site-search repo-scope js-site-search" role="search">
      <form accept-charset="UTF-8" action="/mindboards/ev3sources/search" class="js-site-search-form" data-global-search-url="/search" data-repo-search-url="/mindboards/ev3sources/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
  <label class="js-chromeless-input-container form-control">
    <div class="scope-badge">This repository</div>
    <input type="text"
      class="js-site-search-focus js-site-search-field is-clearable chromeless-input"
      data-hotkey="s"
      name="q"
      placeholder="Search"
      data-global-scope-placeholder="Search GitHub"
      data-repo-scope-placeholder="Search"
      tabindex="1"
      autocapitalize="off">
  </label>
</form>
    </div>

      <ul class="header-nav left" role="navigation">
          <li class="header-nav-item">
            <a class="header-nav-link" href="/explore" data-ga-click="(Logged out) Header, go to explore, text:explore">Explore</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/features" data-ga-click="(Logged out) Header, go to features, text:features">Features</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="https://enterprise.github.com/" data-ga-click="(Logged out) Header, go to enterprise, text:enterprise">Enterprise</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/blog" data-ga-click="(Logged out) Header, go to blog, text:blog">Blog</a>
          </li>
      </ul>

  </div>
</div>



      <div id="start-of-content" class="accessibility-aid"></div>
          <div class="site" itemscope itemtype="http://schema.org/WebPage">
    <div id="js-flash-container">
      
    </div>
    <div class="pagehead repohead instapaper_ignore readability-menu">
      <div class="container">
        
<ul class="pagehead-actions">

  <li>
      <a href="/login?return_to=%2Fmindboards%2Fev3sources"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <span class="octicon octicon-eye"></span>
    Watch
  </a>
  <a class="social-count" href="/mindboards/ev3sources/watchers">
    82
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fmindboards%2Fev3sources"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <span class="octicon octicon-star"></span>
    Star
  </a>

    <a class="social-count js-social-count" href="/mindboards/ev3sources/stargazers">
      241
    </a>

  </li>

    <li>
      <a href="/login?return_to=%2Fmindboards%2Fev3sources"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <span class="octicon octicon-repo-forked"></span>
        Fork
      </a>
      <a href="/mindboards/ev3sources/network" class="social-count">
        123
      </a>
    </li>
</ul>

        <h1 itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="entry-title public">
          <span class="mega-octicon octicon-repo"></span>
          <span class="author"><a href="/mindboards" class="url fn" itemprop="url" rel="author"><span itemprop="title">mindboards</span></a></span><!--
       --><span class="path-divider">/</span><!--
       --><strong><a href="/mindboards/ev3sources" data-pjax="#js-repo-pjax-container">ev3sources</a></strong>

          <span class="page-context-loader">
            <img alt="" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </span>

        </h1>
      </div><!-- /.container -->
    </div><!-- /.repohead -->

    <div class="container">
      <div class="repository-with-sidebar repo-container new-discussion-timeline  ">
        <div class="repository-sidebar clearfix">
            
<nav class="sunken-menu repo-nav js-repo-nav js-sidenav-container-pjax js-octicon-loaders"
     role="navigation"
     data-pjax="#js-repo-pjax-container"
     data-issue-count-url="/mindboards/ev3sources/issues/counts">
  <ul class="sunken-menu-group">
    <li class="tooltipped tooltipped-w" aria-label="Code">
      <a href="/mindboards/ev3sources" aria-label="Code" class="selected js-selected-navigation-item sunken-menu-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /mindboards/ev3sources">
        <span class="octicon octicon-code"></span> <span class="full-word">Code</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Issues">
        <a href="/mindboards/ev3sources/issues" aria-label="Issues" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /mindboards/ev3sources/issues">
          <span class="octicon octicon-issue-opened"></span> <span class="full-word">Issues</span>
          <span class="js-issue-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>

    <li class="tooltipped tooltipped-w" aria-label="Pull requests">
      <a href="/mindboards/ev3sources/pulls" aria-label="Pull requests" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g p" data-selected-links="repo_pulls /mindboards/ev3sources/pulls">
          <span class="octicon octicon-git-pull-request"></span> <span class="full-word">Pull requests</span>
          <span class="js-pull-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Wiki">
        <a href="/mindboards/ev3sources/wiki" aria-label="Wiki" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g w" data-selected-links="repo_wiki /mindboards/ev3sources/wiki">
          <span class="octicon octicon-book"></span> <span class="full-word">Wiki</span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>
  </ul>
  <div class="sunken-menu-separator"></div>
  <ul class="sunken-menu-group">

    <li class="tooltipped tooltipped-w" aria-label="Pulse">
      <a href="/mindboards/ev3sources/pulse" aria-label="Pulse" class="js-selected-navigation-item sunken-menu-item" data-selected-links="pulse /mindboards/ev3sources/pulse">
        <span class="octicon octicon-pulse"></span> <span class="full-word">Pulse</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

    <li class="tooltipped tooltipped-w" aria-label="Graphs">
      <a href="/mindboards/ev3sources/graphs" aria-label="Graphs" class="js-selected-navigation-item sunken-menu-item" data-selected-links="repo_graphs repo_contributors /mindboards/ev3sources/graphs">
        <span class="octicon octicon-graph"></span> <span class="full-word">Graphs</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>
  </ul>


</nav>

              <div class="only-with-full-nav">
                  
<div class="js-clone-url clone-url open"
  data-protocol-type="http">
  <h3><span class="text-emphasized">HTTPS</span> clone URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/mindboards/ev3sources.git" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>

  
<div class="js-clone-url clone-url "
  data-protocol-type="subversion">
  <h3><span class="text-emphasized">Subversion</span> checkout URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/mindboards/ev3sources" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>



<div class="clone-options">You can clone with
  <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=http&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="c4jaqCp5J52UHYpsa/Ai08K/mnk0U2iM7TJ1c8WLntgdho/hS6Nj1P1EMdcdHGSfxwIUidcMSCiIdNbreo9obQ==" /></div><button class="btn-link js-clone-selector" data-protocol="http" type="submit">HTTPS</button></form> or <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=subversion&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="w0nE7Y2oS+ICCiy9Skfi6Rme0H1cBmmtRvvKYvaS94D9Dno+LZvc+WVwXrG2BJnpQsji6HzsnaIQ3B1uZpX8Ow==" /></div><button class="btn-link js-clone-selector" data-protocol="subversion" type="submit">Subversion</button></form>.
  <a href="https://help.github.com/articles/which-remote-url-should-i-use" class="help tooltipped tooltipped-n" aria-label="Get help on which URL is right for you.">
    <span class="octicon octicon-question"></span>
  </a>
</div>




                <a href="/mindboards/ev3sources/archive/7357369b6ebae4ee62001f3964f0f5fd0cce3c32.zip"
                   class="btn btn-sm sidebar-button"
                   aria-label="Download the contents of mindboards/ev3sources as a zip file"
                   title="Download the contents of mindboards/ev3sources as a zip file"
                   rel="nofollow">
                  <span class="octicon octicon-cloud-download"></span>
                  Download ZIP
                </a>
              </div>
        </div><!-- /.repository-sidebar -->

        <div id="js-repo-pjax-container" class="repository-content context-loader-container" data-pjax-container>

          
<a href="/mindboards/ev3sources/blame/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra/linux-03.20.00.13/drivers/video/st7586fb.c" class="hidden js-permalink-shortcut" data-hotkey="y">Permalink</a>

<div class="breadcrumb css-truncate blame-breadcrumb js-zeroclipboard-container">
  <span class="css-truncate-target js-zeroclipboard-target"><span class='repo-root js-repo-root'><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">ev3sources</span></a></span></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">extra</span></a></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra/linux-03.20.00.13" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">linux-03.20.00.13</span></a></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra/linux-03.20.00.13/drivers" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">drivers</span></a></span><span class="separator">/</span><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/mindboards/ev3sources/tree/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra/linux-03.20.00.13/drivers/video" class="" data-branch="7357369b6ebae4ee62001f3964f0f5fd0cce3c32" data-direction="back" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">video</span></a></span><span class="separator">/</span><strong class="final-path">st7586fb.c</strong></span>
  <button aria-label="Copy file path to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
</div>

<div class="line-age-legend">
  <span>Newer</span>
  <ol>
      <li class="heat1"></li>
      <li class="heat2"></li>
      <li class="heat3"></li>
      <li class="heat4"></li>
      <li class="heat5"></li>
      <li class="heat6"></li>
      <li class="heat7"></li>
      <li class="heat8"></li>
      <li class="heat9"></li>
      <li class="heat10"></li>
  </ol>
  <span>Older</span>
</div>

<div class="file">
  <div class="file-header">
    <div class="file-actions">
      <div class="btn-group">
        <a href="/mindboards/ev3sources/raw/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra/linux-03.20.00.13/drivers/video/st7586fb.c" class="btn btn-sm" id="raw-url">Raw</a>
        <a href="/mindboards/ev3sources/blob/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra/linux-03.20.00.13/drivers/video/st7586fb.c" class="btn btn-sm js-update-url-with-hash">Normal view</a>
        <a href="/mindboards/ev3sources/commits/7357369b6ebae4ee62001f3964f0f5fd0cce3c32/extra/linux-03.20.00.13/drivers/video/st7586fb.c" class="btn btn-sm" rel="nofollow">History</a>
      </div>
    </div>



    <div class="file-info">
      <span class="octicon octicon-file-text"></span>
      <span class="file-mode" title="File Mode">100644</span>
      <span class="file-info-divider"></span>
        561 lines (458 sloc)
        <span class="file-info-divider"></span>
      12.579 kb
    </div>
  </div>

  <div class="blob-wrapper">
    <table class="blame-container highlight data js-file-line-container">
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="561">
            <a href="/mindboards/ev3sources/commit/fea79c0e219cd5e43193ce2987b496e04758f3e2" class="blame-sha">fea79c0</a>
            <img alt="" class="avatar blame-commit-avatar" height="32" src="https://1.gravatar.com/avatar/a3114595e89094e76e43ffc615e7655f?d=https%3A%2F%2Fassets-cdn.github.com%2Fimages%2Fgravatars%2Fgravatar-user-420.png&amp;r=x&amp;s=140" width="32" />
            <a href="/mindboards/ev3sources/commit/fea79c0e219cd5e43193ce2987b496e04758f3e2" class="blame-commit-title" title="Additional files, like kernel, uboot and device specific lib/includes">Additional files, like kernel, uboot and device specific lib/includes</a>
            <div class="blame-commit-meta">
              <span class="muted-link">Xander Soldaat</span> authored
              <time datetime="2013-07-31T21:58:56Z" is="relative-time">Jul 31, 2013</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1">1</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1"><span class="pl-c">/*</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L2">2</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC2"><span class="pl-c"> * linux/drivers/video/st7856fb.c -- FB driver for ST7856 display controller</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L3">3</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC3"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L4">4</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC4"><span class="pl-c"> * Based on st7735fb.c by Matt Porter</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L5">5</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC5"><span class="pl-c"> * Layout is based on skeletonfb.c by James Simmons and Geert Uytterhoeven.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L6">6</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC6"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L7">7</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC7"><span class="pl-c"> * Copyright (C) 2011 Matt Porter &lt;matt@ohporter.com&gt;</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L8">8</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC8"><span class="pl-c"> * Copyright (C) 2011 Texas Instruments</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L9">9</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC9"><span class="pl-c"> *</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L10">10</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC10"><span class="pl-c"> * This file is subject to the terms and conditions of the GNU General Public</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L11">11</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC11"><span class="pl-c"> * License. See the file COPYING in the main directory of this archive for</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L12">12</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC12"><span class="pl-c"> * more details.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L13">13</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC13"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L14">14</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC14"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L15">15</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC15">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/module.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L16">16</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC16">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/kernel.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L17">17</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC17">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/errno.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L18">18</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC18">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/string.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L19">19</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC19">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/mm.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L20">20</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC20">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/vmalloc.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L21">21</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC21">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/slab.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L22">22</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC22">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/init.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L23">23</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC23">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/fb.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L24">24</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC24">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/gpio.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L25">25</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC25">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/spi/spi.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L26">26</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC26">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/delay.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L27">27</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC27">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>linux/uaccess.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L28">28</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC28"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L29">29</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC29">#<span class="pl-k">include</span> <span class="pl-s"><span class="pl-pds">&lt;</span>video/st7586fb.h<span class="pl-pds">&gt;</span></span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L30">30</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC30"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L31">31</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC31"><span class="pl-k">static</span> <span class="pl-k">struct</span> st7586_function st7586_cfg_script[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L32">32</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC32">	{ ST7586_START, ST7586_START},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L33">33</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC33">	{ ST7586_CMD, ST7586_ARDCTL},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L34">34</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC34">	{ ST7586_DATA, 0x9f},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L35">35</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC35">	{ ST7586_CMD, ST7586_OTPRWCTL},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L36">36</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC36">	{ ST7586_DATA, 0x00},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L37">37</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC37">	{ ST7586_DELAY, <span class="pl-c1">10</span>},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L38">38</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC38">	{ ST7586_CMD, ST7586_OTPRD},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L39">39</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC39">	{ ST7586_DELAY, <span class="pl-c1">20</span>},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L40">40</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC40">	{ ST7586_CMD, ST7586_OTPCOUT},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L41">41</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC41">	{ ST7586_CMD, ST7586_SLPOUT},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L42">42</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC42">	{ ST7586_CMD, ST7586_DISPOFF},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L43">43</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC43">	{ ST7586_DELAY, <span class="pl-c1">50</span>},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L44">44</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC44">	{ ST7586_CMD, ST7586_VOPOFF},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L45">45</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC45">	{ ST7586_DATA, 0x00},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L46">46</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC46">	{ ST7586_CMD, ST7586_VOP},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L47">47</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC47">	{ ST7586_DATA, 0xE3},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L48">48</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC48">	{ ST7586_DATA, 0x00},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L49">49</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC49">	{ ST7586_CMD, ST7586_BIAS},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L50">50</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC50">	{ ST7586_DATA, 0x02},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L51">51</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC51">	{ ST7586_CMD, ST7586_BOOST},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L52">52</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC52">	{ ST7586_DATA, 0x04},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L53">53</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC53">	{ ST7586_CMD, ST7586_ANCTL},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L54">54</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC54">	{ ST7586_DATA, 0x1d},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L55">55</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC55">	{ ST7586_CMD, ST7586_NLNINV},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L56">56</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC56">	{ ST7586_DATA, 0x00},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L57">57</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC57">	{ ST7586_CMD, ST7586_DSPMONO},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L58">58</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC58">	{ ST7586_CMD, ST7586_RAMENB},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L59">59</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC59">	{ ST7586_DATA, 0x02},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L60">60</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC60">	{ ST7586_CMD, ST7586_DSPCTL},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L61">61</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC61">	{ ST7586_DATA, 0x00},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L62">62</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC62">	{ ST7586_CMD, ST7586_DSPDUTY},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L63">63</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC63">	{ ST7586_DATA, 0x7f},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L64">64</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC64">	{ ST7586_CMD, ST7586_PARDISP},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L65">65</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC65">	{ ST7586_DATA, 0xa0},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L66">66</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC66">	{ ST7586_CMD, ST7586_PARAREA},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L67">67</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC67">	{ ST7586_DATA, 0x00},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L68">68</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC68">	{ ST7586_DATA, 0x00},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L69">69</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC69">	{ ST7586_DATA, 0x00},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L70">70</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC70">	{ ST7586_DATA, 0x77},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L71">71</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC71">	{ ST7586_CMD, ST7586_INVOFF},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L72">72</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC72">	{ ST7586_CMD, ST7586_CASET},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L73">73</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC73">	{ ST7586_DATA, 0x00},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L74">74</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC74">	{ ST7586_DATA, 0x00},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L75">75</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC75">	{ ST7586_DATA, 0x00},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L76">76</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC76">	{ ST7586_DATA, 0x7f},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L77">77</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC77">	{ ST7586_CMD, ST7586_RASET},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L78">78</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC78">	{ ST7586_DATA, 0x00},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L79">79</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC79">	{ ST7586_DATA, 0x00},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L80">80</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC80">	{ ST7586_DATA, 0x00},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L81">81</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC81">	{ ST7586_DATA, 0x9f},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L82">82</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC82">	{ ST7586_CLR, ST7586_CLR},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L83">83</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC83">	{ ST7586_DELAY, <span class="pl-c1">100</span>},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L84">84</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC84">	{ ST7586_END, ST7586_END},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L85">85</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC85">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L86">86</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC86"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L87">87</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC87"><span class="pl-k">static</span> <span class="pl-k">bool</span> driver_inited = <span class="pl-c1">false</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L88">88</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC88"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L89">89</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC89"><span class="pl-k">static</span> <span class="pl-k">struct</span> fb_fix_screeninfo st7586fb_fix __devinitdata = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L90">90</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC90">	.<span class="pl-smi">id</span>		= <span class="pl-s"><span class="pl-pds">&quot;</span>ST7586<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L91">91</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC91">	.<span class="pl-smi">type</span>		= FB_TYPE_PACKED_PIXELS,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L92">92</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC92">	.<span class="pl-smi">visual</span>		= FB_VISUAL_PSEUDOCOLOR,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L93">93</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC93">	.<span class="pl-smi">xpanstep</span>	= <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L94">94</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC94">	.<span class="pl-smi">ypanstep</span>	= <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L95">95</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC95">	.<span class="pl-smi">ywrapstep</span>	= <span class="pl-c1">0</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L96">96</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC96">	.<span class="pl-smi">line_length</span>	= (WIDTH+<span class="pl-c1">2</span>)/<span class="pl-c1">3</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L97">97</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC97">	.<span class="pl-smi">accel</span>		= FB_ACCEL_NONE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L98">98</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC98">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L99">99</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC99"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L100">100</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC100"><span class="pl-k">static</span> <span class="pl-k">struct</span> fb_var_screeninfo st7586fb_var __devinitdata = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L101">101</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC101">	.<span class="pl-smi">xres</span>		= WIDTH,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L102">102</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC102">	.<span class="pl-smi">yres</span>		= HEIGHT,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L103">103</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC103">	.<span class="pl-smi">xres_virtual</span>	= WIDTH,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L104">104</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC104">	.<span class="pl-smi">yres_virtual</span>	= HEIGHT,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L105">105</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC105">	.<span class="pl-smi">bits_per_pixel</span>	= <span class="pl-c1">2</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L106">106</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC106">	.<span class="pl-smi">nonstd</span>		= <span class="pl-c1">1</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L107">107</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC107">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L108">108</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC108"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L109">109</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC109"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">st7586_write</span>(<span class="pl-k">struct</span> st7586fb_par *par, u8 data)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L110">110</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC110">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L111">111</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC111">	<span class="pl-k">int</span> ret = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L112">112</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC112"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L113">113</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC113">	<span class="pl-c">/* Assert out-of-band CS */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L114">114</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC114">	<span class="pl-k">if</span> (par-&gt;cs)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L115">115</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC115">		<span class="pl-c1">gpio_set_value</span>(par-&gt;cs, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L116">116</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC116"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L117">117</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC117">	par-&gt;buf[<span class="pl-c1">0</span>] = data;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L118">118</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC118"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L119">119</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC119">	ret = <span class="pl-c1">spi_write</span>(par-&gt;spi, par-&gt;buf, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L120">120</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC120"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L121">121</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC121">	<span class="pl-c">/* Deassert out-of-band CS */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L122">122</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC122">	<span class="pl-k">if</span> (par-&gt;cs)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L123">123</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC123">		<span class="pl-c1">gpio_set_value</span>(par-&gt;cs, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L124">124</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC124"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L125">125</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC125">	<span class="pl-k">return</span> ret;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L126">126</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC126">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L127">127</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC127"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L128">128</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC128"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">st7586_write_data</span>(<span class="pl-k">struct</span> st7586fb_par *par, u8 data)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L129">129</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC129">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L130">130</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC130">	<span class="pl-k">int</span> ret = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L131">131</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC131"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L132">132</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC132">	<span class="pl-c">/* Set data mode */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L133">133</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC133">	<span class="pl-c1">gpio_set_value</span>(par-&gt;a0, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L134">134</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC134"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L135">135</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC135">	ret = <span class="pl-c1">st7586_write</span>(par, data);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L136">136</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC136">	<span class="pl-k">if</span> (ret &lt; <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L137">137</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC137">		<span class="pl-c1">pr_err</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span>: write data <span class="pl-c1">%02x</span> failed with status <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L138">138</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC138">			par-&gt;info-&gt;fix.<span class="pl-smi">id</span>, data, ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L139">139</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC139">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L140">140</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC140"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L141">141</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC141"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">st7586_write_data_buf</span>(<span class="pl-k">struct</span> st7586fb_par *par,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L142">142</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC142">					u8 *txbuf, <span class="pl-k">int</span> size)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L143">143</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC143">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L144">144</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC144">	<span class="pl-k">int</span> ret = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L145">145</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC145"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L146">146</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC146">	<span class="pl-c">/* Set data mode */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L147">147</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC147">	<span class="pl-c1">gpio_set_value</span>(par-&gt;a0, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L148">148</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC148"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L149">149</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC149">	<span class="pl-c">/* Assert out-of-band CS */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L150">150</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC150">	<span class="pl-k">if</span> (par-&gt;cs)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L151">151</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC151">		<span class="pl-c1">gpio_set_value</span>(par-&gt;cs, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L152">152</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC152"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L153">153</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC153">	<span class="pl-c">/* Write entire buffer */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L154">154</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC154">	ret = <span class="pl-c1">spi_write</span>(par-&gt;spi, txbuf, size);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L155">155</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC155"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L156">156</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC156">	<span class="pl-c">/* Deassert out-of-band CS */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L157">157</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC157">	<span class="pl-k">if</span> (par-&gt;cs)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L158">158</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC158">		<span class="pl-c1">gpio_set_value</span>(par-&gt;cs, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L159">159</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC159"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L160">160</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC160">	<span class="pl-k">return</span> ret;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L161">161</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC161">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L162">162</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC162"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L163">163</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC163"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">st7586_write_cmd</span>(<span class="pl-k">struct</span> st7586fb_par *par, u8 data)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L164">164</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC164">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L165">165</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC165">	<span class="pl-k">int</span> ret = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L166">166</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC166"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L167">167</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC167">	<span class="pl-c">/* Set command mode */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L168">168</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC168">	<span class="pl-c1">gpio_set_value</span>(par-&gt;a0, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L169">169</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC169"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L170">170</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC170">	ret = <span class="pl-c1">st7586_write</span>(par, data);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L171">171</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC171">	<span class="pl-k">if</span> (ret &lt; <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L172">172</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC172">		<span class="pl-c1">pr_err</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span>: write command <span class="pl-c1">%02x</span> failed with status <span class="pl-c1">%d</span><span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L173">173</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC173">			par-&gt;info-&gt;fix.<span class="pl-smi">id</span>, data, ret);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L174">174</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC174">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L175">175</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC175"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L176">176</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC176"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">st7586_clear_ddrram</span>(<span class="pl-k">struct</span> st7586fb_par *par)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L177">177</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC177">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L178">178</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC178">	u8 *buf;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L179">179</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC179"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L180">180</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC180">	buf = <span class="pl-c1">kzalloc</span>(<span class="pl-c1">128</span>*<span class="pl-c1">128</span>, GFP_KERNEL);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L181">181</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC181">	<span class="pl-c1">st7586_write_cmd</span>(par, ST7586_RAMWR);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L182">182</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC182">	<span class="pl-c1">st7586_write_data_buf</span>(par, buf, <span class="pl-c1">128</span>*<span class="pl-c1">128</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L183">183</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC183">	<span class="pl-c1">kfree</span>(buf);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L184">184</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC184">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L185">185</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC185"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L186">186</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC186"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">st7586_run_cfg_script</span>(<span class="pl-k">struct</span> st7586fb_par *par)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L187">187</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC187">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L188">188</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC188">	<span class="pl-k">int</span> i = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L189">189</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC189">	<span class="pl-k">int</span> end_script = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L190">190</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC190"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L191">191</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC191">	<span class="pl-k">do</span> {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L192">192</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC192">		<span class="pl-k">switch</span> (st7586_cfg_script[i].<span class="pl-smi">cmd</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L193">193</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC193">		{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L194">194</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC194">		<span class="pl-k">case</span> ST7586_START:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L195">195</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC195">			<span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L196">196</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC196">		<span class="pl-k">case</span> ST7586_CLR:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L197">197</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC197">			<span class="pl-c1">st7586_clear_ddrram</span>(par);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L198">198</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC198">			<span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L199">199</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC199">		<span class="pl-k">case</span> ST7586_CMD:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L200">200</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC200">			<span class="pl-c1">st7586_write_cmd</span>(par,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L201">201</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC201">				st7586_cfg_script[i].<span class="pl-smi">data</span> &amp; 0xff);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L202">202</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC202">			<span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L203">203</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC203">		<span class="pl-k">case</span> ST7586_DATA:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L204">204</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC204">			<span class="pl-c1">st7586_write_data</span>(par,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L205">205</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC205">				st7586_cfg_script[i].<span class="pl-smi">data</span> &amp; 0xff);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L206">206</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC206">			<span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L207">207</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC207">		<span class="pl-k">case</span> ST7586_DELAY:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L208">208</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC208">			<span class="pl-c1">mdelay</span>(st7586_cfg_script[i].<span class="pl-smi">data</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L209">209</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC209">			<span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L210">210</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC210">		<span class="pl-k">case</span> ST7586_END:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L211">211</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC211">			end_script = <span class="pl-c1">1</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L212">212</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC212">		}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L213">213</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC213">		i++;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L214">214</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC214">	} <span class="pl-k">while</span> (!end_script);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L215">215</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC215">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L216">216</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC216"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L217">217</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC217"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">st7586_set_addr_win</span>(<span class="pl-k">struct</span> st7586fb_par *par,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L218">218</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC218">				<span class="pl-k">int</span> xs, <span class="pl-k">int</span> ys, <span class="pl-k">int</span> xe, <span class="pl-k">int</span> ye)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L219">219</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC219">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L220">220</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC220">	<span class="pl-c1">st7586_write_cmd</span>(par, ST7586_CASET);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L221">221</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC221">	<span class="pl-c1">st7586_write_data</span>(par, 0x00);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L222">222</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC222">	<span class="pl-c1">st7586_write_data</span>(par, xs);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L223">223</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC223">	<span class="pl-c1">st7586_write_data</span>(par, 0x00);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L224">224</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC224">	<span class="pl-c1">st7586_write_data</span>(par, ((xe+<span class="pl-c1">2</span>)/<span class="pl-c1">3</span>)-<span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L225">225</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC225">	<span class="pl-c1">st7586_write_cmd</span>(par, ST7586_RASET);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L226">226</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC226">	<span class="pl-c1">st7586_write_data</span>(par, 0x00);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L227">227</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC227">	<span class="pl-c1">st7586_write_data</span>(par, ys);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L228">228</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC228">	<span class="pl-c1">st7586_write_data</span>(par, 0x00);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L229">229</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC229">	<span class="pl-c1">st7586_write_data</span>(par, ye-<span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L230">230</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC230">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L231">231</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC231"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L232">232</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC232"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">st7586_reset</span>(<span class="pl-k">struct</span> st7586fb_par *par)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L233">233</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC233">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L234">234</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC234">	<span class="pl-c">/* Reset controller */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L235">235</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC235">	<span class="pl-c1">gpio_set_value</span>(par-&gt;rst, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L236">236</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC236">	<span class="pl-c1">mdelay</span>(<span class="pl-c1">10</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L237">237</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC237">	<span class="pl-c1">gpio_set_value</span>(par-&gt;rst, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L238">238</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC238">	<span class="pl-c1">mdelay</span>(<span class="pl-c1">120</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L239">239</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC239">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L240">240</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC240"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L241">241</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC241"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">st7586fb_update_display</span>(<span class="pl-k">struct</span> st7586fb_par *par)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L242">242</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC242">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L243">243</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC243">    <span class="pl-k">int</span> ret = <span class="pl-c1">0</span>, i=<span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L244">244</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC244">	u8 *vmem = par-&gt;info-&gt;screen_base;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L245">245</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC245"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L246">246</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC246">	<span class="pl-c">// Check if any data has been put into screen buffer. </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L247">247</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC247">	<span class="pl-c">// In case data written - Select display as inited </span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L248">248</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC248">	<span class="pl-k">if</span> (!driver_inited) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L249">249</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC249">	  <span class="pl-k">while</span> ( (!vmem[i]) &amp;&amp; (i &lt;(WIDTH+<span class="pl-c1">2</span>)/<span class="pl-c1">3</span>*HEIGHT)) i++;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L250">250</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC250">	  <span class="pl-k">if</span> (i != ((WIDTH+<span class="pl-c1">2</span>)/<span class="pl-c1">3</span>*HEIGHT)) driver_inited = <span class="pl-c1">true</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L251">251</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC251">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L252">252</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC252"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L253">253</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC253">	<span class="pl-k">if</span> (driver_inited) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L254">254</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC254">	  <span class="pl-c1">st7586_set_addr_win</span>(par, <span class="pl-c1">0</span>, <span class="pl-c1">0</span>, WIDTH, HEIGHT);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L255">255</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC255">	  <span class="pl-c1">st7586_write_cmd</span>(par, ST7586_RAMWR);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L256">256</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC256"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L257">257</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC257">	  <span class="pl-c">/* Blast framebuffer to ST7586 internal display RAM */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L258">258</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC258">	  ret = <span class="pl-c1">st7586_write_data_buf</span>(par, vmem, (WIDTH+<span class="pl-c1">2</span>)/<span class="pl-c1">3</span>*HEIGHT);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L259">259</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC259">	  </td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L260">260</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC260">	  <span class="pl-k">if</span> (ret &lt; <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L261">261</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC261">	    <span class="pl-c1">pr_err</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span>: spi_write failed to update display buffer<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L262">262</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC262">		   par-&gt;info-&gt;fix.<span class="pl-smi">id</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L263">263</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC263">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L264">264</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC264">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L265">265</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC265"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L266">266</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC266"><span class="pl-k">static</span> <span class="pl-k">void</span> <span class="pl-en">st7586fb_deferred_io</span>(<span class="pl-k">struct</span> fb_info *info,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L267">267</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC267">				<span class="pl-k">struct</span> list_head *pagelist)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L268">268</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC268">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L269">269</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC269">	<span class="pl-c1">st7586fb_update_display</span>(info-&gt;par);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L270">270</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC270">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L271">271</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC271"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L272">272</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC272"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L273">273</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC273"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">st7586fb_request_gpios</span>(<span class="pl-k">struct</span> st7586fb_par *par)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L274">274</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC274">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L275">275</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC275">	<span class="pl-c">/* TODO: Need some error checking on gpios */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L276">276</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC276"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L277">277</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC277">        <span class="pl-c">/* Request GPIOs and initialize to default values */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L278">278</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC278">        <span class="pl-c1">gpio_request</span>(par-&gt;rst, <span class="pl-s"><span class="pl-pds">&quot;</span>ST7586 Reset Pin<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L279">279</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC279">	<span class="pl-c1">gpio_direction_output</span>(par-&gt;rst, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L280">280</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC280">        <span class="pl-c1">gpio_request</span>(par-&gt;a0, <span class="pl-s"><span class="pl-pds">&quot;</span>ST7586 A0 Pin<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L281">281</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC281">	<span class="pl-c1">gpio_direction_output</span>(par-&gt;a0, <span class="pl-c1">0</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L282">282</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC282">	<span class="pl-k">if</span> (par-&gt;cs) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L283">283</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC283">		<span class="pl-c1">gpio_request</span>(par-&gt;cs, <span class="pl-s"><span class="pl-pds">&quot;</span>ST7586 CS Pin<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L284">284</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC284">		<span class="pl-c1">gpio_direction_output</span>(par-&gt;cs, <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L285">285</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC285">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L286">286</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC286">	<span class="pl-k">return</span> <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L287">287</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC287">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L288">288</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC288"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L289">289</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC289"><span class="pl-k">static</span> <span class="pl-k">int</span> <span class="pl-en">st7586fb_init_display</span>(<span class="pl-k">struct</span> st7586fb_par *par)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L290">290</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC290">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L291">291</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC291">	<span class="pl-c1">st7586_reset</span>(par);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L292">292</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC292"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L293">293</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC293">	<span class="pl-c1">st7586_run_cfg_script</span>(par);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L294">294</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC294"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L295">295</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC295">	<span class="pl-c">/* Set row/column data window */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L296">296</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC296">	<span class="pl-c1">st7586_set_addr_win</span>(par, <span class="pl-c1">0</span>, <span class="pl-c1">0</span>, WIDTH, HEIGHT);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L297">297</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC297"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L298">298</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC298">	<span class="pl-c1">st7586_write_cmd</span>(par, ST7586_DISPON);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L299">299</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC299"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L300">300</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC300">	<span class="pl-k">return</span> <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L301">301</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC301">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L302">302</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC302"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L303">303</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC303"><span class="pl-k">void</span> <span class="pl-en">st7586fb_fillrect</span>(<span class="pl-k">struct</span> fb_info *info, <span class="pl-k">const</span> <span class="pl-k">struct</span> fb_fillrect *rect)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L304">304</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC304">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L305">305</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC305">	<span class="pl-k">struct</span> st7586fb_par *par = info-&gt;par;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L306">306</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC306"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L307">307</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC307">	<span class="pl-c1">sys_fillrect</span>(info, rect);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L308">308</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC308"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L309">309</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC309">	<span class="pl-c1">st7586fb_update_display</span>(par);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L310">310</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC310">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L311">311</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC311"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L312">312</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC312"><span class="pl-k">void</span> <span class="pl-en">st7586fb_copyarea</span>(<span class="pl-k">struct</span> fb_info *info, <span class="pl-k">const</span> <span class="pl-k">struct</span> fb_copyarea *area)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L313">313</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC313">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L314">314</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC314">	<span class="pl-k">struct</span> st7586fb_par *par = info-&gt;par;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L315">315</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC315"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L316">316</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC316">	<span class="pl-c1">sys_copyarea</span>(info, area);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L317">317</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC317"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L318">318</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC318">	<span class="pl-c1">st7586fb_update_display</span>(par);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L319">319</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC319">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L320">320</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC320"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L321">321</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC321"><span class="pl-k">void</span> <span class="pl-en">st7586fb_imageblit</span>(<span class="pl-k">struct</span> fb_info *info, <span class="pl-k">const</span> <span class="pl-k">struct</span> fb_image *image)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L322">322</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC322">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L323">323</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC323">	<span class="pl-k">struct</span> st7586fb_par *par = info-&gt;par;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L324">324</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC324"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L325">325</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC325">	<span class="pl-c1">sys_imageblit</span>(info, image);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L326">326</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC326"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L327">327</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC327">	<span class="pl-c1">st7586fb_update_display</span>(par);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L328">328</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC328">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L329">329</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC329"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L330">330</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC330"><span class="pl-k">int</span> <span class="pl-en">st7586fb_ioctl</span>(<span class="pl-k">struct</span> fb_info *info, <span class="pl-k">unsigned</span> <span class="pl-k">int</span> cmd, <span class="pl-k">unsigned</span> <span class="pl-k">long</span> arg)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L331">331</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC331">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L332">332</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC332">	<span class="pl-k">int</span> retval = -ENOMEM;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L333">333</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC333">	<span class="pl-k">struct</span> st7586fb_par *par = info-&gt;par;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L334">334</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC334"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L335">335</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC335">	<span class="pl-c1">printk</span>(KERN_ERR <span class="pl-s"><span class="pl-pds">&quot;</span>fb<span class="pl-c1">%d</span>: Initing display<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, info-&gt;node);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L336">336</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC336"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L337">337</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC337">	<span class="pl-k">switch</span> (cmd) </td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L338">338</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC338">	  {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L339">339</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC339">	  <span class="pl-k">case</span> FB_ST7586_INIT_DISPLAY: </td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L340">340</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC340">	    retval = <span class="pl-c1">st7586fb_init_display</span>(par);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L341">341</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC341">	    <span class="pl-k">if</span> (retval &lt; <span class="pl-c1">0</span>) driver_inited = <span class="pl-c1">true</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L342">342</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC342">	    <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L343">343</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC343">	  <span class="pl-k">case</span> FB_ST7586_START_DISPLAY: </td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L344">344</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC344">	    retval = <span class="pl-c1">0</span>;	  </td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L345">345</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC345">	    driver_inited = <span class="pl-c1">true</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L346">346</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC346">	  <span class="pl-k">default</span>: </td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L347">347</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC347">	    <span class="pl-k">break</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L348">348</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC348">	  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L349">349</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC349">	</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L350">350</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC350">	<span class="pl-k">return</span> retval;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L351">351</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC351">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L352">352</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC352"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L353">353</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC353"><span class="pl-k">static</span> <span class="pl-c1">ssize_t</span> <span class="pl-en">st7586fb_write</span>(<span class="pl-k">struct</span> fb_info *info, <span class="pl-k">const</span> <span class="pl-k">char</span> __user *buf,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L354">354</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC354">		<span class="pl-c1">size_t</span> count, <span class="pl-c1">loff_t</span> *ppos)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L355">355</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC355">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L356">356</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC356">	<span class="pl-k">struct</span> st7586fb_par *par = info-&gt;par;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L357">357</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC357">	<span class="pl-k">unsigned</span> <span class="pl-k">long</span> p = *ppos;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L358">358</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC358">	<span class="pl-k">void</span> *dst;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L359">359</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC359">	<span class="pl-k">int</span> err = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L360">360</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC360">	<span class="pl-k">unsigned</span> <span class="pl-k">long</span> total_size;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L361">361</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC361"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L362">362</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC362">	<span class="pl-k">if</span> (info-&gt;state != FBINFO_STATE_RUNNING)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L363">363</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC363">		<span class="pl-k">return</span> -EPERM;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L364">364</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC364"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L365">365</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC365">	total_size = info-&gt;fix.<span class="pl-smi">smem_len</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L366">366</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC366"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L367">367</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC367">	<span class="pl-k">if</span> (p &gt; total_size)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L368">368</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC368">		<span class="pl-k">return</span> -EFBIG;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L369">369</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC369"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L370">370</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC370">	<span class="pl-k">if</span> (count &gt; total_size) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L371">371</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC371">		err = -EFBIG;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L372">372</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC372">		count = total_size;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L373">373</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC373">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L374">374</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC374"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L375">375</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC375">	<span class="pl-k">if</span> (count + p &gt; total_size) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L376">376</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC376">		<span class="pl-k">if</span> (!err)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L377">377</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC377">			err = -ENOSPC;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L378">378</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC378"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L379">379</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC379">		count = total_size - p;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L380">380</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC380">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L381">381</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC381"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L382">382</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC382">	dst = (<span class="pl-k">void</span> __force *) (info-&gt;screen_base + p);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L383">383</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC383"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L384">384</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC384">	<span class="pl-k">if</span> (<span class="pl-c1">copy_from_user</span>(dst, buf, count))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L385">385</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC385">		err = -EFAULT;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L386">386</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC386"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L387">387</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC387">	<span class="pl-k">if</span>  (!err)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L388">388</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC388">		*ppos += count;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L389">389</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC389"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L390">390</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC390">	<span class="pl-c1">st7586fb_update_display</span>(par);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L391">391</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC391"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L392">392</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC392">	<span class="pl-k">return</span> (err) ? err : count;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L393">393</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC393">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L394">394</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC394"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L395">395</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC395"><span class="pl-k">static</span> <span class="pl-k">struct</span> fb_ops st7586fb_ops = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L396">396</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC396">	.<span class="pl-smi">owner</span>		= THIS_MODULE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L397">397</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC397">	.<span class="pl-smi">fb_read</span>	= fb_sys_read,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L398">398</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC398">	.<span class="pl-smi">fb_write</span>	= st7586fb_write,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L399">399</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC399">	.<span class="pl-smi">fb_fillrect</span>	= st7586fb_fillrect,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L400">400</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC400">	.<span class="pl-smi">fb_copyarea</span>	= st7586fb_copyarea,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L401">401</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC401">	.<span class="pl-smi">fb_imageblit</span>	= st7586fb_imageblit,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L402">402</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC402">	.<span class="pl-smi">fb_ioctl</span>       = st7586fb_ioctl</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L403">403</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC403">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L404">404</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC404"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L405">405</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC405"><span class="pl-k">static</span> <span class="pl-k">struct</span> fb_deferred_io st7586fb_defio = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L406">406</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC406">	.<span class="pl-smi">delay</span>		= HZ / <span class="pl-c1">20</span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L407">407</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC407">	.<span class="pl-smi">deferred_io</span>	= st7586fb_deferred_io,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L408">408</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC408">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L409">409</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC409"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L410">410</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC410"><span class="pl-k">static</span> <span class="pl-k">int</span> __devinit <span class="pl-en">st7586fb_probe</span> (<span class="pl-k">struct</span> spi_device *spi)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L411">411</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC411">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L412">412</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC412">	<span class="pl-k">int</span> chip = <span class="pl-c1">spi_get_device_id</span>(spi)-&gt;driver_data;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L413">413</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC413">	<span class="pl-k">struct</span> st7586fb_platform_data *pdata = spi-&gt;dev.<span class="pl-smi">platform_data</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L414">414</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC414">	<span class="pl-k">int</span> vmem_size = (WIDTH+<span class="pl-c1">2</span>)/<span class="pl-c1">3</span>*HEIGHT;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L415">415</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC415">	u8 *vmem;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L416">416</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC416">	<span class="pl-k">struct</span> fb_info *info;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L417">417</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC417">	<span class="pl-k">struct</span> st7586fb_par *par;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L418">418</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC418">	<span class="pl-k">int</span> retval = -ENOMEM;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L419">419</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC419"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L420">420</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC420">	<span class="pl-k">if</span> (chip != ST7586_DISPLAY_LMS2012_LCD) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L421">421</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC421">		<span class="pl-c1">pr_err</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span>: only the <span class="pl-c1">%s</span> device is supported<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>, DRVNAME,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L422">422</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC422">			<span class="pl-c1">to_spi_driver</span>(spi-&gt;dev.<span class="pl-smi">driver</span>)-&gt;id_table-&gt;name);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L423">423</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC423">		<span class="pl-k">return</span> -EINVAL;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L424">424</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC424">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L425">425</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC425"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L426">426</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC426">	<span class="pl-k">if</span> (!pdata) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L427">427</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC427">		<span class="pl-c1">pr_err</span>(<span class="pl-s"><span class="pl-pds">&quot;</span><span class="pl-c1">%s</span>: platform data required for rst and a0 info<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L428">428</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC428">			DRVNAME);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L429">429</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC429">		<span class="pl-k">return</span> -EINVAL;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L430">430</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC430">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L431">431</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC431"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L432">432</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC432">	vmem = (u8 *)<span class="pl-c1">kmalloc</span>(vmem_size, GFP_KERNEL);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L433">433</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC433">	<span class="pl-k">if</span> (!vmem)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L434">434</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC434">		<span class="pl-k">return</span> retval;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L435">435</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC435"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L436">436</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC436">	<span class="pl-c">// Zero memory for easy detection if any new data has been written to screenbuffer</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L437">437</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC437">	<span class="pl-c1">memset</span>(vmem, <span class="pl-c1">0</span>, vmem_size);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L438">438</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC438"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L439">439</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC439">	info = <span class="pl-c1">framebuffer_alloc</span>(<span class="pl-k">sizeof</span>(<span class="pl-k">struct</span> st7586fb_par), &amp;spi-&gt;dev);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L440">440</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC440">	<span class="pl-k">if</span> (!info)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L441">441</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC441">		<span class="pl-k">goto</span> fballoc_fail;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L442">442</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC442"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L443">443</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC443">	info-&gt;screen_base = vmem;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L444">444</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC444">	info-&gt;fbops = &amp;st7586fb_ops;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L445">445</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC445">	info-&gt;fix = st7586fb_fix;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L446">446</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC446">	info-&gt;fix.<span class="pl-smi">smem_start</span> = <span class="pl-c1">virt_to_phys</span>(vmem);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L447">447</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC447">	info-&gt;fix.<span class="pl-smi">smem_len</span> = vmem_size;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L448">448</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC448">	info-&gt;var = st7586fb_var;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L449">449</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC449">	<span class="pl-c">/* The ST7586 packed pixel format does not translate well here */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L450">450</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC450">	<span class="pl-c">/* FIXME - change to mono reporting */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L451">451</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC451">	info-&gt;var.<span class="pl-smi">red</span>.<span class="pl-smi">offset</span> = <span class="pl-c1">11</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L452">452</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC452">	info-&gt;var.<span class="pl-smi">red</span>.<span class="pl-smi">length</span> = <span class="pl-c1">5</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L453">453</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC453">	info-&gt;var.<span class="pl-smi">green</span>.<span class="pl-smi">offset</span> = <span class="pl-c1">5</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L454">454</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC454">	info-&gt;var.<span class="pl-smi">green</span>.<span class="pl-smi">length</span> = <span class="pl-c1">6</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L455">455</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC455">	info-&gt;var.<span class="pl-smi">blue</span>.<span class="pl-smi">offset</span> = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L456">456</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC456">	info-&gt;var.<span class="pl-smi">blue</span>.<span class="pl-smi">length</span> = <span class="pl-c1">5</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L457">457</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC457">	info-&gt;var.<span class="pl-smi">transp</span>.<span class="pl-smi">offset</span> = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L458">458</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC458">	info-&gt;var.<span class="pl-smi">transp</span>.<span class="pl-smi">length</span> = <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L459">459</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC459">	info-&gt;flags = FBINFO_FLAG_DEFAULT | FBINFO_VIRTFB;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L460">460</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC460">	info-&gt;fbdefio = &amp;st7586fb_defio;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L461">461</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC461">	<span class="pl-c1">fb_deferred_io_init</span>(info);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L462">462</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC462"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L463">463</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC463">	par = info-&gt;par;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L464">464</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC464">	par-&gt;info = info;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L465">465</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC465">	par-&gt;spi = spi;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L466">466</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC466">	par-&gt;rst = pdata-&gt;rst_gpio;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L467">467</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC467">	par-&gt;a0 = pdata-&gt;a0_gpio;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L468">468</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC468">	par-&gt;cs = pdata-&gt;cs_gpio;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L469">469</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC469">	par-&gt;buf = <span class="pl-c1">kmalloc</span>(<span class="pl-c1">1</span>, GFP_KERNEL);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L470">470</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC470"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L471">471</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC471">	retval = <span class="pl-c1">register_framebuffer</span>(info);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L472">472</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC472">	<span class="pl-k">if</span> (retval &lt; <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L473">473</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC473">		<span class="pl-k">goto</span> fbreg_fail;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L474">474</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC474"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L475">475</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC475">	<span class="pl-c1">spi_set_drvdata</span>(spi, info);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L476">476</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC476"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L477">477</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC477">	retval = <span class="pl-c1">st7586fb_request_gpios</span>(par);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L478">478</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC478"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L479">479</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC479">	<span class="pl-c">// Move initing of display to ioctl call to avoid dispaly flickering</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L480">480</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC480">	<span class="pl-c">// as dispaly has already been inited in uboot</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L481">481</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC481">	<span class="pl-c">// retval |= st7586fb_init_display(par);</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L482">482</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC482">	<span class="pl-k">if</span> (retval &lt; <span class="pl-c1">0</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L483">483</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC483">		<span class="pl-k">goto</span> init_fail;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L484">484</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC484"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L485">485</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC485">	<span class="pl-c1">printk</span>(KERN_INFO</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L486">486</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC486">		<span class="pl-s"><span class="pl-pds">&quot;</span>fb<span class="pl-c1">%d</span>: <span class="pl-c1">%s</span> frame buffer device, using <span class="pl-c1">%d</span> KiB of video memory<span class="pl-cce">\n</span><span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L487">487</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC487">		info-&gt;node, info-&gt;fix.<span class="pl-smi">id</span>, vmem_size/<span class="pl-c1">1024</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L488">488</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC488"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L489">489</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC489">	<span class="pl-k">return</span> <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L490">490</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC490"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L491">491</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC491">init_fail:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L492">492</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC492">	<span class="pl-c1">spi_set_drvdata</span>(spi, <span class="pl-c1">NULL</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L493">493</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC493"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L494">494</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC494">fbreg_fail:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L495">495</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC495">	<span class="pl-c1">kfree</span>(par-&gt;buf);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L496">496</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC496">	<span class="pl-c1">framebuffer_release</span>(info);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L497">497</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC497"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L498">498</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC498">fballoc_fail:</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L499">499</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC499">	<span class="pl-c1">kfree</span>(vmem);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L500">500</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC500"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L501">501</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC501">	<span class="pl-k">return</span> retval;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L502">502</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC502">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L503">503</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC503"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L504">504</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC504"><span class="pl-k">static</span> <span class="pl-k">int</span> __devexit <span class="pl-en">st7586fb_remove</span>(<span class="pl-k">struct</span> spi_device *spi)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L505">505</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC505">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L506">506</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC506">	<span class="pl-k">struct</span> fb_info *info = <span class="pl-c1">spi_get_drvdata</span>(spi);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L507">507</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC507"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L508">508</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC508">	<span class="pl-c1">spi_set_drvdata</span>(spi, <span class="pl-c1">NULL</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L509">509</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC509"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L510">510</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC510">	<span class="pl-k">if</span> (info) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L511">511</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC511">		<span class="pl-k">struct</span> st7586fb_par *par = info-&gt;par;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L512">512</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC512"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L513">513</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC513">		<span class="pl-c1">unregister_framebuffer</span>(info);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L514">514</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC514">		<span class="pl-c1">kfree</span>(info-&gt;screen_base);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L515">515</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC515">		<span class="pl-c1">kfree</span>(par-&gt;buf);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L516">516</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC516">		<span class="pl-c1">gpio_free</span>(par-&gt;rst);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L517">517</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC517">		<span class="pl-c1">gpio_free</span>(par-&gt;a0);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L518">518</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC518">		<span class="pl-k">if</span> (par-&gt;cs)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L519">519</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC519">			<span class="pl-c1">gpio_free</span>(par-&gt;cs);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L520">520</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC520">		<span class="pl-c1">framebuffer_release</span>(info);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L521">521</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC521">	}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L522">522</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC522"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L523">523</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC523">	<span class="pl-k">return</span> <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L524">524</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC524">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L525">525</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC525"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L526">526</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC526"><span class="pl-k">static</span> <span class="pl-k">const</span> <span class="pl-k">struct</span> spi_device_id st7586fb_ids[] = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L527">527</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC527">	{ <span class="pl-s"><span class="pl-pds">&quot;</span>lms2012_lcd<span class="pl-pds">&quot;</span></span>, ST7586_DISPLAY_LMS2012_LCD },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L528">528</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC528">	{ },</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L529">529</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC529">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L530">530</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC530"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L531">531</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC531"><span class="pl-en">MODULE_DEVICE_TABLE</span>(spi, st7586fb_ids);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L532">532</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC532"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L533">533</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC533"><span class="pl-k">static</span> <span class="pl-k">struct</span> spi_driver st7586fb_driver = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L534">534</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC534">	.<span class="pl-smi">driver</span> = {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L535">535</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC535">		.<span class="pl-smi">name</span>   = <span class="pl-s"><span class="pl-pds">&quot;</span>st7586fb<span class="pl-pds">&quot;</span></span>,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L536">536</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC536">		.<span class="pl-smi">owner</span>  = THIS_MODULE,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L537">537</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC537">	},</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L538">538</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC538">	.<span class="pl-smi">id_table</span> = st7586fb_ids,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L539">539</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC539">	.<span class="pl-smi">probe</span>  = st7586fb_probe,</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L540">540</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC540">	.<span class="pl-smi">remove</span> = <span class="pl-c1">__devexit_p</span>(st7586fb_remove),</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L541">541</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC541">};</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L542">542</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC542"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L543">543</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC543"><span class="pl-k">static</span> <span class="pl-k">int</span> __init <span class="pl-en">st7586fb_init</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L544">544</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC544">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L545">545</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC545">	<span class="pl-k">return</span> <span class="pl-c1">spi_register_driver</span>(&amp;st7586fb_driver);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L546">546</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC546">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L547">547</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC547"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L548">548</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC548"><span class="pl-k">static</span> <span class="pl-k">void</span> __exit <span class="pl-en">st7586fb_exit</span>(<span class="pl-k">void</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L549">549</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC549">{</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L550">550</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC550">	<span class="pl-c1">spi_unregister_driver</span>(&amp;st7586fb_driver);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L551">551</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC551">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L552">552</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC552"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L553">553</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC553"><span class="pl-c">/* ------------------------------------------------------------------------- */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L554">554</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC554"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L555">555</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC555"><span class="pl-en">module_init</span>(st7586fb_init);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L556">556</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC556"><span class="pl-en">module_exit</span>(st7586fb_exit);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L557">557</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC557"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L558">558</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC558"><span class="pl-en">MODULE_DESCRIPTION</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>FB driver for ST7586 display controller<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L559">559</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC559"><span class="pl-en">MODULE_AUTHOR</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>Matt Porter &lt;mporter@ti.com&gt;<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L560">560</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC560"><span class="pl-en">MODULE_LICENSE</span>(<span class="pl-s"><span class="pl-pds">&quot;</span>GPL<span class="pl-pds">&quot;</span></span>);</td>
          </tr>
    </table>
  </div>
</div>


        </div>

      </div><!-- /.repo-container -->
      <div class="modal-backdrop"></div>
    </div><!-- /.container -->
  </div><!-- /.site -->


    </div><!-- /.wrapper -->

      <div class="container">
  <div class="site-footer" role="contentinfo">
    <ul class="site-footer-links right">
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage">
      <span class="mega-octicon octicon-mark-github" title="GitHub"></span>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2015 <span title="0.14167s from github-fe128-cp1-prd.iad.github.net">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact</a></li>
    </ul>
  </div>
</div>


    <div class="fullscreen-overlay js-fullscreen-overlay" id="fullscreen_overlay">
  <div class="fullscreen-container js-suggester-container">
    <div class="textarea-wrap">
      <textarea name="fullscreen-contents" id="fullscreen-contents" class="fullscreen-contents js-fullscreen-contents" placeholder=""></textarea>
      <div class="suggester-container">
        <div class="suggester fullscreen-suggester js-suggester js-navigation-container"></div>
      </div>
    </div>
  </div>
  <div class="fullscreen-sidebar">
    <a href="#" class="exit-fullscreen js-exit-fullscreen tooltipped tooltipped-w" aria-label="Exit Zen Mode">
      <span class="mega-octicon octicon-screen-normal"></span>
    </a>
    <a href="#" class="theme-switcher js-theme-switcher tooltipped tooltipped-w"
      aria-label="Switch themes">
      <span class="octicon octicon-color-mode"></span>
    </a>
  </div>
</div>



    

    <div id="ajax-error-message" class="flash flash-error">
      <span class="octicon octicon-alert"></span>
      <a href="#" class="octicon octicon-x flash-close js-ajax-error-dismiss" aria-label="Dismiss error"></a>
      Something went wrong with that request. Please try again.
    </div>


      <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-447ce66a36506ebddc8e84b4e32a77f6062f3d3482e77dd21a77a01f0643ad98.js"></script>
      <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github/index-83be60956d0d00076a726f0864b49916aae8e7bc6ee140798791be0b6644d661.js"></script>
      
      
  </body>
</html>

